from dataclasses import dataclass, field
from generated import vps_management_pb2
import time


@dataclass
class Node:
    node_code: str
    ip_address: str
    status: vps_management_pb2.NodeStatus = vps_management_pb2.NodeStatus.NODE_ONLINE  # type: ignore[attr-defined]
    risk_level: int = 0
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    traffic_in: int = 0
    traffic_out: int = 0
    geo_location: str = ""
    longitude: float = 0.0
    latitude: float = 0.0
    cloud_provider: str = ""
    run_role: str = ""
    created_at: str = field(default_factory=lambda: time.strftime("%Y-%m-%d %H:%M:%S"))
    last_heartbeat: str = field(
        default_factory=lambda: time.strftime("%Y-%m-%d %H:%M:%S")
    )
    relay_count: int = 0
    max_relay_capacity: int = 2
    anonymous_relay_code: str = ""
    access_relay_code: str = ""
    tcp_retrans_rate: float = 0.0

    # 业务行为可以放在这里
    def update_resource_usage(
        self,
        cpu: float,
        mem: float,
        traffic_in: int,
        traffic_out: int,
        tcp_retrans_rate: float,
    ) -> None:
        self.cpu_usage = cpu
        self.memory_usage = mem
        self.traffic_in = traffic_in
        self.traffic_out = traffic_out
        self.tcp_retrans_rate = tcp_retrans_rate
        self.last_heartbeat = time.strftime("%Y-%m-%d %H:%M:%S")

    def to_proto(self) -> vps_management_pb2.Node:  # type: ignore[attr-defined]
        return vps_management_pb2.Node(  # type: ignore[attr-defined]
            node_code=self.node_code,
            ip_address=self.ip_address,
            status=self.status,
            risk_level=self.risk_level,
            cpu_usage=self.cpu_usage,
            memory_usage=self.memory_usage,
            traffic_in=self.traffic_in,
            traffic_out=self.traffic_out,
            geo_location=self.geo_location,
            cloud_provider=self.cloud_provider,
            created_at=self.created_at,
            last_heartbeat=self.last_heartbeat,
            relay_count=self.relay_count,
            max_relay_capacity=self.max_relay_capacity,
            anonymous_relay_code=self.anonymous_relay_code,
            access_relay_code=self.access_relay_code,
            tcp_retrans_rate=self.tcp_retrans_rate,
            latitude=self.latitude,
            longitude=self.longitude,
            run_role=self.run_role,
        )

    @classmethod
    def from_proto(cls, pb: vps_management_pb2.Node) -> "Node":  # type: ignore[attr-defined]
        return cls(
            node_code=pb.node_code,
            ip_address=pb.ip_address,
            status=pb.status,
            risk_level=pb.risk_level,
            cpu_usage=pb.cpu_usage,
            memory_usage=pb.memory_usage,
            traffic_in=pb.traffic_in,
            traffic_out=pb.traffic_out,
            geo_location=pb.geo_location,
            cloud_provider=pb.cloud_provider,
            run_role=pb.run_role,
            created_at=pb.created_at,
            last_heartbeat=pb.last_heartbeat,
            relay_count=pb.relay_count,
            max_relay_capacity=pb.max_relay_capacity,
            anonymous_relay_code=pb.anonymous_relay_code,
            access_relay_code=pb.access_relay_code,
            tcp_retrans_rate=pb.tcp_retrans_rate,
        )

    def add_relay(
        self,
        relay_code: str,
        relay_type: vps_management_pb2.RelayType,  # type: ignore[attr-defined]
        current_count: int,
    ) -> None:
        """添加Relay并更新节点状态"""
        self.relay_count = current_count
        if relay_type == vps_management_pb2.RelayType.RELAY_ANONYMOUS:  # type: ignore[attr-defined]
            self.anonymous_relay_code = relay_code
        elif relay_type == vps_management_pb2.RelayType.RELAY_ACCESS:  # type: ignore[attr-defined]
            self.access_relay_code = relay_code

    def remove_relay(self, relay_code: str, current_count: int) -> None:
        """移除Relay并更新节点状态"""
        self.relay_count = current_count
        if self.anonymous_relay_code == relay_code:
            self.anonymous_relay_code = ""
        if self.access_relay_code == relay_code:
            self.access_relay_code = ""
