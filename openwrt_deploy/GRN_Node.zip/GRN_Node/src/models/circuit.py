from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from datetime import datetime
from generated import vps_management_pb2
import time

@dataclass
class Circuit:
    """电路模型类
    
    用于表示Tor电路的业务模型，与proto格式解耦。
    在内部业务逻辑中始终使用此模型，只在gRPC通信边界处转换为proto格式。
    """
    
    circuit_id: str
    relay_fingerprints: List[str]
    status: str = "BUILT"
    purpose: str = "GENERAL"
    hs_state: str = ""
    rend_query: str = ""
    created_at: str = field(default_factory=lambda: time.strftime("%Y-%m-%d %H:%M:%S"))
    reason: str = ""
    remote_reason: str = ""
    socks_username: str = ""
    socks_password: str = ""
    client_relay_code: str = ""  # 使用哪个Client Relay创建的电路
    node_code: str = ""  # 所属节点
    build_flags: List[str] = field(default_factory=list)  # 电路构建标志
    
    link_id: Optional[str] = None  # 新增：关联的 Link ID (SOCKS Username)
    
    def is_active(self) -> bool:
        """判断电路是否处于活动状态"""
        return self.status in ["BUILT", "EXTENDED"]
    
    def get_path_length(self) -> int:
        """获取电路路径长度"""
        return len(self.relay_fingerprints)
    
    def get_entry_fingerprint(self) -> Optional[str]:
        """获取入口Relay的指纹"""
        return self.relay_fingerprints[0] if self.relay_fingerprints else None
    
    def get_exit_fingerprint(self) -> Optional[str]:
        """获取出口Relay的指纹"""
        return self.relay_fingerprints[-1] if self.relay_fingerprints else None
    
    def update_status(self, status: str, reason: str = "") -> None:
        """更新电路状态"""
        self.status = status
        if reason:
            self.reason = reason
    
    def to_db(self) -> dict:
        """转换为字典格式（用于存储到 active_circuits）"""
        return {
            "circuit_id": self.circuit_id,
            "fingerprints": self.relay_fingerprints,
            "created_at": self.created_at,
            "status": self.status,
            "purpose": self.purpose,
            "client_relay_code": self.client_relay_code,
            "node_code": self.node_code,
        }
    
    @classmethod
    def from_db(cls, data: dict) -> "Circuit":
        """从字典创建实例"""
        return cls(
            circuit_id=data.get("circuit_id", ""),
            relay_fingerprints=data.get("fingerprints", []),
            created_at=data.get("created_at", ""),
            status=data.get("status", "BUILT"),
            purpose=data.get("purpose", "GENERAL"),
            client_relay_code=data.get("client_relay_code", ""),
            node_code=data.get("node_code", ""),
        )
    
    @classmethod
    def from_stem_circuit_info(
        cls, 
        circuit_id: str,
        circuit_info: Dict[str, Any],
        relay_fingerprints: List[str],
        client_relay_code: str = "",
        node_code: str = "",
        link_id: Optional[str] = None  # 新增参数
    ) -> "Circuit":
        """从Stem库的电路信息创建实例
        
        Args:
            circuit_id: 电路ID (可以是字符串或整数)
            circuit_info: Stem返回的电路信息字典，包含:
                - status: 电路状态
                - purpose: 电路用途
                - hs_state: Onion Service状态
                - rend_query: 会合点
                - created: 创建时间(datetime对象)
                - reason: 关闭原因
                - remote_reason: 远程关闭原因
                - socks_username: SOCKS用户名
                - socks_password: SOCKS密码
            relay_fingerprints: Relay指纹列表
            client_relay_code: 客户端Relay ID
            node_code: 节点ID
            
        Returns:
            Circuit实例
        """
        # 处理创建时间
        created_time = circuit_info.get("created")
        if isinstance(created_time, datetime):
            created_at = created_time.strftime("%Y-%m-%d %H:%M:%S")
        else:
            created_at = time.strftime("%Y-%m-%d %H:%M:%S")
        
        # 确保circuit_id是字符串
        circuit_id_str = str(circuit_id)
        
        return cls(
            circuit_id=circuit_id_str,
            relay_fingerprints=relay_fingerprints,
            status=str(circuit_info.get("status", "BUILT")),
            purpose=circuit_info.get("purpose", "GENERAL"),
            hs_state=circuit_info.get("hs_state", ""),
            rend_query=circuit_info.get("rend_query", ""),
            created_at=created_at,
            reason=circuit_info.get("reason", ""),
            remote_reason=circuit_info.get("remote_reason", ""),
            socks_username=circuit_info.get("socks_username", ""),
            socks_password=circuit_info.get("socks_password", ""),
            client_relay_code=client_relay_code,
            node_code=node_code,
            build_flags=circuit_info.get("build_flags", []),
            link_id=link_id,
        )
    
    def to_proto(self) -> vps_management_pb2.Circuit:
        """转换为protobuf格式（用于上报给管理面）
        Returns:
            vps_management_pb2.Circuit: protobuf格式的电路信息
        """

        # 定义状态映射：业务字符串 → proto 需要的整数
        status_map = {
            "LAUNCHED": 0,
            "BUILT": 1,
            "GUARD_WAIT": 2,
            "EXTENDED": 3,
            "FAILED": 4,
            "CLOSED": 5,
        }
        proto_status = status_map.get(self.status, 1)
        
        pb = vps_management_pb2.Circuit(
            circuit_code=self.circuit_id,
            status=proto_status,
            purpose=self.purpose,
            hs_state=self.hs_state,
            rend_query=self.rend_query,
            created=self.created_at,
            reason=self.reason,
            remote_reason=self.remote_reason,
            socks_username=self.socks_username,
            socks_password=self.socks_password,
        )

        pb.circuit_fingerprint_path.extend(self.relay_fingerprints)
        pb.build_flags.extend(self.build_flags)

        # 关键关联字段（proto 已定义，但之前未填充）
        if self.link_id:
            pb.link_id = self.link_id
        if self.client_relay_code:
            pb.client_relay_code = self.client_relay_code
        return pb
    
    @classmethod
    def from_proto(cls, pb: vps_management_pb2.Circuit, client_relay_code: str = "", node_code: str = "") -> "Circuit":
        """从protobuf格式创建实例
        
        Args:
            pb: protobuf格式的电路信息
            client_relay_code: 客户端Relay ID
            node_id: 节点ID
            
        Returns:
            Circuit实例
        """
        return cls(
            circuit_id=pb.circuit_code,
            relay_fingerprints=list(pb.circuit_fingerprint_path),
            status=pb.status,
            purpose=pb.purpose,
            hs_state=pb.hs_state,
            rend_query=pb.rend_query,
            created_at=pb.created,
            reason=pb.reason,
            remote_reason=pb.remote_reason,
            socks_username=pb.socks_username,
            socks_password=pb.socks_password,
            client_relay_code=client_relay_code,
            link_id=pb.link_id,
            node_code=node_code,
            build_flags=list(pb.build_flags),
        )
    
    def to_json_response(self) -> dict:
        """转换为JSON响应格式（用于命令响应）"""
        result = {
            "circuit_id": self.circuit_id,
            "status": self.status,
            "purpose": self.purpose,
            "hs_state": self.hs_state,
            "rend_query": self.rend_query,
            "created": self.created_at,
            "reason": self.reason,
            "remote_reason": self.remote_reason,
            "socks_username": self.socks_username,
            "socks_password": self.socks_password,
        }
        if self.link_id:
            result['link_id'] = self.link_id
        return result