from dataclasses import dataclass, field
from typing import Optional, List
from generated import vps_management_pb2


@dataclass
class Relay:
    """Relay模型类

    用于表示Tor Relay的业务模型，与proto格式解耦。
    在内部业务逻辑中始终使用此模型，只在gRPC通信边界处转换为proto格式。
    """

    relay_code: str
    nickname: str
    fingerprint: str
    ip_address: str
    or_port: int
    dir_port: int
    bandwidth: int
    exit_policy: str
    published: str
    flags: List[str] = field(default_factory=list)  # 修正为列表类型
    version: str = ""
    platform: str = "Linux"
    node_code: str = ""
    container_id: str = ""
    container_name: str = ""
    # 约定：
    # - RELAY_CREATING: 容器/进程启动中
    # - RELAY_BOOTSTRAPPED: 本地 Tor 已完成启动/引导，但未必进入共识
    # - RELAY_RUNNING: 已进入共识（Running+Valid）
    status: vps_management_pb2.RelayStatus = (  #
        vps_management_pb2.RelayStatus.RELAY_CREATING
    )
    relay_type: vps_management_pb2.RelayType = (
        vps_management_pb2.RelayType.RELAY_ANONYMOUS
    )
    relay_role: vps_management_pb2.RelayRole = vps_management_pb2.RelayRole.ROLE_RELAY
    created_at: str = field(
        default_factory=lambda: __import__("time").strftime("%Y-%m-%d %H:%M:%S")
    )
    updated_at: str = field(
        default_factory=lambda: __import__("time").strftime("%Y-%m-%d %H:%M:%S")
    )
    server_relay_id: int = 0

    def mark_created(self) -> None:
        # proto 中没有 RELAY_ONLINE；创建阶段用 RELAY_CREATING
        self.status = vps_management_pb2.RelayStatus.RELAY_CREATING

    def mark_bootstrapped(self) -> None:
        """标记 Relay 已完成本地启动/引导（但不代表进入共识）"""
        self.status = vps_management_pb2.RelayStatus.RELAY_BOOTSTRAPPED
        self.updated_at = __import__("time").strftime("%Y-%m-%d %H:%M:%S")

    def mark_online(self) -> None:
        """兼容旧调用：原先用 online 表示“可用”。

        在当前语义下，RELAY_RUNNING 代表“进入共识”，不能在本地信息更新时直接置为 RUNNING。
        因此这里改为标记为 RELAY_BOOTSTRAPPED。
        """
        self.status = vps_management_pb2.RelayStatus.RELAY_BOOTSTRAPPED
        self.updated_at = __import__("time").strftime("%Y-%m-%d %H:%M:%S")

    def mark_destroying(self) -> None:
        """标记Relay为销毁中状态"""
        self.status = vps_management_pb2.RelayStatus.RELAY_DESTROYING
        self.updated_at = __import__("time").strftime("%Y-%m-%d %H:%M:%S")

    def mark_stopped(self) -> None:
        """标记Relay为停止状态"""
        self.status = vps_management_pb2.RelayStatus.RELAY_STOPPED
        self.updated_at = __import__("time").strftime("%Y-%m-%d %H:%M:%S")

    def to_proto(self) -> vps_management_pb2.Relay:
        """转换为protobuf格式"""
        return vps_management_pb2.Relay(
            relay_code=self.relay_code,
            nickname=self.nickname,
            fingerprint=self.fingerprint,
            ip_address=self.ip_address,
            or_port=self.or_port,
            dir_port=self.dir_port,
            bandwidth=self.bandwidth,
            exit_policy=self.exit_policy,
            published=self.published,
            flags=self.flags,  # 现在是列表类型
            version=self.version,
            platform=self.platform,
            node_code=self.node_code,
            container_id=self.container_id,
            container_name=self.container_name,
            status=self.status,
            relay_type=self.relay_type,
            relay_role=self.relay_role,
            created_at=self.created_at,
            updated_at=self.updated_at,
            relay_id=self.server_relay_id
        )

    @classmethod
    def from_proto(cls, pb: vps_management_pb2.Relay) -> "Relay":
        return cls(
            relay_code=pb.relay_code,
            nickname=pb.nickname,
            fingerprint=pb.fingerprint,
            ip_address=pb.ip_address,
            or_port=pb.or_port,
            dir_port=pb.dir_port,
            bandwidth=pb.bandwidth,
            exit_policy=pb.exit_policy,
            published=pb.published,
            flags=pb.flags,
            version=pb.version,
            platform=pb.platform,
            node_code=pb.node_code,
            container_id=pb.container_id,
            container_name=pb.container_name,
            status=pb.status,
            relay_type=pb.relay_type,
            relay_role=pb.relay_role,
        )

    def update_from_tor_info(self, tor_info: dict) -> None:
        """从Tor节点信息更新Relay状态"""
        self.nickname = tor_info["nickname"]
        self.fingerprint = tor_info["fingerprint"]
        self.ip_address = tor_info["address"]
        self.or_port = tor_info["or_port"]
        self.dir_port = tor_info["dir_port"]
        self.bandwidth = tor_info["bandwidth"]
        self.published = tor_info["published"]
        self.flags = (
            tor_info["flags"]
            if isinstance(tor_info["flags"], list)
            else [tor_info["flags"]]
        )
        self.version = tor_info["version"]

        # 注意：这里更新的是“本地 Tor 信息”，不代表进入共识。
        # 让 consensus_observer 负责把 BOOTSTRAPPED -> RUNNING。
        if self.status == vps_management_pb2.RelayStatus.RELAY_CREATING:
            self.mark_bootstrapped()
        else:
            self.updated_at = __import__("time").strftime("%Y-%m-%d %H:%M:%S")
