from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum
from datetime import datetime
from generated import vps_management_pb2
import time


class LocalMsgType(Enum):
    MT_NONE = 0
    MT_UPDATE_CONFIG = 1
    MT_SWITCH_LINK = 2
    MT_ACCESS_STATUS = 3


@dataclass
class UserMsg:
    """用户消息类, 用户消息以json格式描述： type 指明消息类型，data 指示消息体
    消息格式示例：
    
    {
        "msg_type" : 1,
        "data" : {
            "field1" : "content1",
            "field2" : "content2"
        }
    }

    """

    type: LocalMsgType
    data: str

    def __init__(self, type: LocalMsgType, data: str):
        self.type = type
        self.data = data

