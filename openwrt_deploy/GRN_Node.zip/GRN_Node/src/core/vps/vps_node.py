import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import List, Dict, Optional
from dataclasses import dataclass, field
from core.base_node import AnonymousCommer
from core.node_context import NodeContext
from core.grpc_handler import GrpcHandler
from core.command_dispatcher import CommandDispatcher
from core.state_reporter import StateReporter
from config.config import GrpcConfig

from models.circuit import Circuit
from models.node import Node
from models.relay import Relay

from observers.subject import StateSubject
from observers.node_info_observer import NodeInfoObserver
from observers.situation_awareness_observer import SituationAwarenessObserver
from observers.relay_info_observer import RelayInfoObserver
from observers.da_info_observer import DAInfoObserver
from observers.consensus_observer import ConcensusObserver

from utils.network import get_network_info
from utils.cli import parse_args

import utils.logger
import hashlib
import asyncio
import signal


class VpsDispatcher(AnonymousCommer):
    def __init__(self,
                 node_id: Optional[str] = None,
                 server_addr: Optional[str] = None,
                 ip_addr: Optional[str] = None,
                 geo_location: Optional[str] = None,
                 cloud_provider: Optional[str] = None,
                 run_mode: Optional[str] = None,  # [cloud, test]
                 ) -> None:
        super().__init__(node_id, server_addr, ip_addr, geo_location, cloud_provider, run_mode)

        """VpsDispatcher类的初始化方法。
        """
    async def run(self) -> None:
        """启动所有异步任务，包括节点信息、DA信息、态势感知推送及命令处理。
        """
        # 首先进行初始化
        try:
            await self.grpc_handler.initialize()
            await self.grpc_handler.register_node()

            subject = StateSubject()
            subject.attach(NodeInfoObserver(self))
            subject.attach(SituationAwarenessObserver(self))
            subject.attach(DAInfoObserver(self))
            subject.attach(RelayInfoObserver(self))
            subject.attach(ConcensusObserver(self.reporter, self.context))

            tasks = [
                subject.start_all(),
                self.grpc_handler.handle_commands(),
            ]
            loop = asyncio.get_event_loop()
            try:
                loop.add_signal_handler(signal.SIGINT, self._sync_handle_interrupt)
            except NotImplementedError:
                # Windows下不支持add_signal_handler，依靠KeyboardInterrupt处理
                self.logger.info("当前环境不支持add_signal_handler，将使用默认信号处理")
            
            await asyncio.gather(*tasks)
        except asyncio.CancelledError:
            pass
        finally:
            if self.stem2tor_instances:
                await asyncio.gather(
                    *(inst.stop_tor()
                      for inst in self.stem2tor_instances.values()),
                    return_exceptions=True
                )
            await self.grpc_handler.close()
            self.logger.info("程序已安全退出。")