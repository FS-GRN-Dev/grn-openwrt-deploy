import utils.logger
from generated import vps_management_pb2
from utils.system import (
    get_cpu_usage,
    get_memory_usage,
    get_network_traffic,
    calculate_risk_level,
    get_tcp_retrans_rate,
)


class StateReporter:
    def __init__(self, context, grpc_handler):
        self.context = context
        self.grpc_handler = grpc_handler
        self.logger = utils.logger.get_logger(f"{self.__class__.__name__}")

    @property
    def stub(self):
        return self.grpc_handler.stub

    async def report_node_info(self) -> bool:
        """单次推送节点信息到管理服务器。"""
        try:
            # 更新节点状态信息
            traffic_in, traffic_out = get_network_traffic()
            self.context.node.update_resource_usage(
                cpu=get_cpu_usage(),
                mem=get_memory_usage(),
                traffic_in=traffic_in,
                traffic_out=traffic_out,
                tcp_retrans_rate=get_tcp_retrans_rate(),
            )
            self.context.node.relay_count = len(self.context.relays)

            # 转换为proto格式后推送
            response = await self.stub.PushNodeInfo(
                vps_management_pb2.PushNodeInfoRequest(  # type: ignore[attr-defined]
                    node=self.context.node.to_proto()
                )
            )
            self.logger.info(f"  节点信息更新结果：{response.message}")
            return response.success
        except Exception as e:
            self.logger.error(f"  更新节点信息失败: {e}")
            return False

    async def report_relay_info(self) -> bool:
        """单次推送Relay信息到管理服务器。"""
        try:
            if not self.context.relays:
                self.logger.debug("  没有Relay信息需要推送")
                return True

            success = True
            for relay_code, relay in self.context.relays.items():
                self.logger.info(f"🔍 正在查找Relay信息: {relay_code}")

                self.logger.info(f"🔍 正在查找昵称为 {relay.nickname} 的Tor节点信息...")
                stem2tor = self.context.stem2tor_instances[relay_code]
                tor_info = await stem2tor.wait_for_tor_node(
                    relay.nickname, relay.container_id
                )
                if tor_info["fingerprint"] != "" or stem2tor.role == "client":
                    self.logger.info(f"✅ 找到Tor节点 {relay.nickname}")
                else:
                    success = False
                    self.logger.warning(
                        f"⚠️ 超时：未能找到昵称为 {relay.nickname} 的Tor节点信息"
                    )

                # 更新Relay模型中的信息
                relay.update_from_tor_info(tor_info)

                # 更新到relays字典
                self.context.relays[relay_code] = relay

            # 将所有Relay信息打包发送（转换为proto格式）
            relay_protos = [relay.to_proto() for relay in self.context.relays.values()]
            response = await self.stub.PushRelayInfo(
                vps_management_pb2.PushRelayInfoRequest(relays=relay_protos)
            )
            self.logger.info(f"  Relay信息更新结果：{response.message}")
            return response.success
        except Exception as e:
            self.logger.error(f"  更新Relay信息失败: {e}")
            return False

    async def push_relays(self, relays: list) -> bool:
        try:
            if not relays:
                return True
            relay_protos = [relay.to_proto() for relay in relays]
            response = await self.stub.PushRelayInfo(
                vps_management_pb2.PushRelayInfoRequest(relays=relay_protos)
            )
            return response.success
        except Exception as e:
            self.logger.error(f"  增量推送Relay信息失败: {e}")
            return False

    async def report_situation_awareness(self) -> bool:
        """单次推送态势感知信息到管理服务器。"""
        try:
            situation_info = vps_management_pb2.SituationAwarenessInfo(
                node_code=self.context.node_code,
                ip_address=self.context.ip_address,
                risk_level=calculate_risk_level(),
                cpu_usage=get_cpu_usage(),
            )

            response = await self.stub.PushSituationAwarenessInfo(
                vps_management_pb2.PushSituationAwarenessInfoRequest(
                    situation_awareness_info=situation_info
                )
            )
            self.logger.info(f"  态势感知信息更新结果：{response.message}")
            return response.success
        except Exception as e:
            self.logger.error(f"  更新态势感知信息失败: {e}")
            return False

    async def report_da_info(self) -> bool:
        """单次推送DA信息到管理服务器。"""
        try:
            success = True
            for relay_code, relay in self.context.relays.items():
                if relay.relay_role != vps_management_pb2.RelayRole.ROLE_DA:
                    # self.logger.warning(f"  Relay {relay_code} 不是DA角色，跳过")
                    continue

                stem2tor = self.context.stem2tor_instances.get(relay_code)
                if not stem2tor:
                    continue

                dir_authorities = await stem2tor.get_dir_auths()

                # 创建DA信息
                # 每个都要上传一次
                for dir_auth in dir_authorities:
                    da_info = vps_management_pb2.DAInfo(
                        node_code=self.context.node_code,
                        relay_code=relay_code,
                        nick=dir_auth["nick"],
                        ip_address=dir_auth["address"],
                        or_port=dir_auth["orport"],
                        v3_ident=dir_auth["v3ident"],
                        fingerprint=dir_auth["fingerprint"],
                    )

                    response = await self.stub.PushDAInfo(
                        vps_management_pb2.PushDAInfoRequest(da_info=da_info)
                    )
                    self.logger.info(f"  DA信息更新结果：{response.message}")
                    success = success and response.success
            return success
        except Exception as e:
            self.logger.error(f"  更新DA信息失败: {e}")
            return False

    async def report_self_destruction_info(self) -> bool:
        """单次推送节点自毁信息到管理服务器。"""
        try:
            node_self_destruction_info = vps_management_pb2.SelfDestructionInfo(
                node_code=self.context.node.node_code,
                ip_address=self.context.node.ip_address,
            )

            response = await self.stub.PushSelfDestructionInfo(
                vps_management_pb2.PushSelfDestructionInfoRequest(
                    self_destruction_info=node_self_destruction_info
                )
            )
            self.logger.info(f"  节点自毁信息更新结果：{response.message}")
            return response.success
        except Exception as e:
            self.logger.error(f"  更新节点自毁信息失败: {e}")
            return False

    async def report_circuit_rebuilt_info(self, success, link_id, circuit_info) -> bool:
        """单次推送电路重建状态信息到管理服务器。"""
        try:
            circuit_proto = circuit_info.to_proto() if circuit_info is not None else None
            response = await self.stub.PushLinkHealthInfo(
                vps_management_pb2.LinkHealthStatusRequest(
                    link_id = int(link_id),
                    link_status = 1 if success else 0,
                    circuit = circuit_proto,
                )
            )
            self.logger.info(f"  电路重建状态信息更新结果：{response.message}")
            return response.success
        except Exception as e:
            self.logger.error(f"  更新电路重建状态信息失败: {e}")
            return False

