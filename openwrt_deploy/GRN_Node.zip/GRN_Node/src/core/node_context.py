from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
import time

from models.node import Node
from models.relay import Relay
from models.circuit import Circuit
from core.stem_api import Stem2Tor
from config.config import NodeConfig
from utils.util import get_cpu_usage, get_memory_usage, get_role


@dataclass
class NodeContext:
    node_code: str
    ip_address: str
    geo_location: str
    cloud_provider: str
    run_role: str
    longitude: Optional[float] = None
    latitude: Optional[float] = None

    # State
    node: Optional[Node] = None
    relays: Dict[str, Relay] = field(default_factory=dict)
    stem2tor_instances: Dict[str, Stem2Tor] = field(default_factory=dict)
    active_circuits: Dict[str, Circuit] = field(default_factory=dict)
    dir_auth: Optional[List[Dict[str, Any]]] = None

    def __post_init__(self):
        self.node = self._create_node()

    def _create_node(self) -> Node:
        """创建并返回节点的基本信息对象（使用Node模型）。"""
        return Node(
            node_code=self.node_code,
            ip_address=self.ip_address,
            status=NodeConfig.DEFAULT_NODE_STATUS,
            risk_level=NodeConfig.DEFAULT_RISK_LEVEL,
            cpu_usage=get_cpu_usage(),
            memory_usage=get_memory_usage(),
            traffic_in=NodeConfig.DEFAULT_TRAFFIC_IN,
            traffic_out=NodeConfig.DEFAULT_TRAFFIC_OUT,
            geo_location=self.geo_location,
            longitude=self.longitude if self.longitude is not None else 0.0,
            latitude=self.latitude if self.latitude is not None else 0.0,
            cloud_provider=self.cloud_provider,
            run_role=self.run_role,
            created_at=time.strftime("%Y-%m-%d %H:%M:%S"),
            last_heartbeat=time.strftime("%Y-%m-%d %H:%M:%S"),
            relay_count=NodeConfig.DEFAULT_RELAY_COUNT,
            max_relay_capacity=NodeConfig.DEFAULT_MAX_RELAY_CAPACITY,
            anonymous_relay_code="",
            access_relay_code="",
        )

    def get_latest_circuit_id(self) -> str | None:
        """获取最新的电路ID。"""
        return list(self.active_circuits.keys())[-1] if self.active_circuits else None

    def get_active_circuit(self, circuit_id: str) -> Optional[Circuit]:
        """获取指定ID的活动电路"""
        return self.active_circuits.get(circuit_id)

    def get_all_active_circuits(self) -> List[Circuit]:
        """获取所有活动电路列表"""
        return list(self.active_circuits.values())

    def get_relay(self, relay_code: str) -> Optional[Relay]:
        """获取指定ID的Relay"""
        return self.relays.get(relay_code)

    def get_all_relays(self) -> List[Relay]:
        """获取所有Relay列表"""
        return list(self.relays.values())

    def _get_role(self, role_enum) -> str:
        """获取角色字符串"""
        return get_role(role_enum)
