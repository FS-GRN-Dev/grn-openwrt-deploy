import asyncio
import uuid
import re
import threading
from typing import Dict, Optional, List, Set
from stem import StreamStatus
from stem.control import EventType
from models.circuit import Circuit
import utils.logger


class RoutingMode:
    IDLE = "idle"
    SINGLE = "single"
    MULTI = "multi"


class CircuitManager:
    """
    电路管理器
    负责维护 Link -> Circuit 的映射关系，处理流附加和电路保活
    """
    
    def __init__(self, context, reporter, stem2tor, client_relay_code: str):
        """
        Args:
            stem2tor: Stem2Tor 实例（提供 controller 和电路操作能力）
        """
        self.context = context
        self.reporter = reporter
        self.stem2tor = stem2tor
        self.client_relay_code = client_relay_code
        self.logger = utils.logger.get_logger("CircuitManager")
        
        # 核心数据结构
        # link_id (SOCKS Username) -> circuit_id
        self._link_circuit_map: Dict[str, str] = {}
        
        # link_id -> 路径配置 (fingerprint list)，用于电路重建
        self._link_path_map: Dict[str, List[str]] = {}
        
        # 兼容字段：最近激活的单链路（不再作为无 username 唯一选路依据）
        self._default_link_id: Optional[str] = None

        # 激活单链路池 + 路由模式（单/多互斥）
        self._active_single_pool: List[str] = []
        self._last_success_index: int = 0
        self._routing_mode: str = RoutingMode.IDLE
        self._active_multi_link_id: Optional[str] = None
        self._pool_lock = threading.Lock()
        
        # 监听器引用
        self._stream_listener = None
        self._circuit_listener = None
        self._is_running = False

        # 手动删除电路时，避免 CLOSED 事件触发自动重建
        self._ignore_closed_circuits: Set[str] = set()

        # Stem 的事件回调可能不在 asyncio 线程执行；保存 loop 以便线程安全调度协程
        self._event_loop: Optional[asyncio.AbstractEventLoop] = None

        # 采样打印 STREAM 原始事件行（避免日志风暴）。用于排查 socks_username 为 None
        # 到底是 Tor 没发送 SOCKS_USERNAME，还是 Stem 解析/字段兼容问题。
        self._stream_raw_log_budget: int = 30

        # 找不到可用电路时，是否允许 attach_stream(id, 0) 让 Tor 自动建路。
        # False：改为 close_stream，禁止 Tor 自动创建电路。
        self.allow_auto_circuit: bool = False

    def set_allow_auto_circuit(self, allow: bool) -> None:
        """设置是否允许 Tor 在无映射电路时自动建路。"""
        self.allow_auto_circuit = bool(allow)
        self.logger.info(
            f"Client Relay {self.client_relay_code} allow_auto_circuit={self.allow_auto_circuit}"
        )

    def _attach_or_reject_unmapped_stream(self, ctrl, stream) -> None:
        """SOCKS 流找不到可用电路时：按开关决定 attach(0) 或 close_stream。"""
        if self.allow_auto_circuit:
            try:
                self.logger.info(
                    f"🔗 没有可用电路且允许自动建路：attach_stream(0), 流 {stream.id}"
                )
                ctrl.attach_stream(stream.id, 0)
            except Exception:
                pass
            return

        try:
            self.logger.info(
                f"🚫 没有可用电路且禁止自动建路：close_stream, 流 {stream.id}"
            )
            ctrl.close_stream(stream.id)
        except Exception as e:
            self.logger.warning(f"关闭流 {stream.id} 失败: {e}")

    def activate_single(self, link_id: str) -> bool:
        """将单链路加入激活池（幂等）。"""
        link_id = str(link_id).strip()
        if not link_id:
            return False
        if not self.get_circuit_for_link(link_id):
            self.logger.warning(f"activate_single 失败：链路 {link_id} 无电路映射")
            return False
        with self._pool_lock:
            if link_id not in self._active_single_pool:
                self._active_single_pool.append(link_id)
            self._default_link_id = link_id
            self._routing_mode = RoutingMode.SINGLE
            self._active_multi_link_id = None
            self.logger.info(
                f"激活单链路入池: {link_id}, pool={list(self._active_single_pool)}"
            )
            return True

    def deactivate_single(self, link_id: str) -> bool:
        """将单链路移出激活池。"""
        link_id = str(link_id).strip()
        with self._pool_lock:
            if link_id not in self._active_single_pool:
                self.logger.info(f"deactivate_single 幂等：{link_id} 本就不在池中")
                self._refresh_routing_mode_locked()
                return True
            # 删前记住上次成功链路，删后再按 link_id 回填 index，避免游标指错
            last_link = None
            if 0 <= self._last_success_index < len(self._active_single_pool):
                last_link = self._active_single_pool[self._last_success_index]
            self._active_single_pool.remove(link_id)
            if not self._active_single_pool:
                self._last_success_index = 0
            elif last_link and last_link in self._active_single_pool:
                self._last_success_index = self._active_single_pool.index(last_link)
            else:
                # 上次成功链路本身被删：钳位到新池合法下标
                self._last_success_index = min(
                    self._last_success_index, len(self._active_single_pool) - 1
                )
            if self._default_link_id == link_id:
                self._default_link_id = (
                    self._active_single_pool[-1] if self._active_single_pool else None
                )
            self._refresh_routing_mode_locked()
            self.logger.info(
                f"单链路出池: {link_id}, pool={list(self._active_single_pool)}, "
                f"mode={self._routing_mode}, last_success_index={self._last_success_index}"
            )
            return True

    def clear_all_singles(self) -> None:
        """清空激活单链路池（单→多等场景）。"""
        with self._pool_lock:
            self._active_single_pool.clear()
            self._last_success_index = 0
            self._default_link_id = None
            self._refresh_routing_mode_locked()
            self.logger.info(f"已清空单链路池, mode={self._routing_mode}")

    def set_multi_active(self, link_id: str) -> None:
        """标记当前激活的多链路父 ID，并进入 multi 模式。"""
        link_id = str(link_id).strip()
        with self._pool_lock:
            self._active_multi_link_id = link_id
            self._routing_mode = RoutingMode.MULTI
            self.logger.info(f"激活多链路: {link_id}, mode=multi")

    def clear_multi_active(self) -> None:
        """清除激活多链路标记。"""
        with self._pool_lock:
            old = self._active_multi_link_id
            self._active_multi_link_id = None
            self._refresh_routing_mode_locked()
            self.logger.info(f"清除激活多链路: {old}, mode={self._routing_mode}")

    def get_active_multi_link_id(self) -> Optional[str]:
        return self._active_multi_link_id

    def get_routing_mode(self) -> str:
        return self._routing_mode

    def get_active_single_pool(self) -> List[str]:
        with self._pool_lock:
            return list(self._active_single_pool)

    def get_active_single_count(self) -> int:
        with self._pool_lock:
            return len(self._active_single_pool)

    def get_enabled_parent_link_ids(self) -> List[str]:
        """当前启用的父链路 ID（单池 ∪ 激活多），不含子链路。"""
        with self._pool_lock:
            ids = list(self._active_single_pool)
            if self._active_multi_link_id:
                ids.append(self._active_multi_link_id)
            return ids

    def _refresh_routing_mode_locked(self) -> None:
        if self._active_multi_link_id:
            self._routing_mode = RoutingMode.MULTI
        elif self._active_single_pool:
            self._routing_mode = RoutingMode.SINGLE
        else:
            self._routing_mode = RoutingMode.IDLE

    def try_attach_round_robin(self, ctrl, stream) -> bool:
        """从上次成功链路的下一条起整圈轮询 attach；成功返回 True，全失败返回 False。"""
        with self._pool_lock:
            pool = [
                lid
                for lid in self._active_single_pool
                if self._link_circuit_map.get(lid)
            ]
            if not pool:
                return False
            # 真正轮询：下次从「上次成功的下一条」开始。
            last_link = None
            if 0 <= self._last_success_index < len(self._active_single_pool):
                last_link = self._active_single_pool[self._last_success_index]
            if last_link in pool:
                start = (pool.index(last_link) + 1) % len(pool)
            else:
                start = 0
            ordered = pool[start:] + pool[:start]
            # 释放锁后再 attach，避免持锁调用 Tor
            candidates = list(ordered)

        for link_id in candidates:
            circuit_id = self._link_circuit_map.get(link_id)
            if not circuit_id:
                continue
            try:
                ctrl.attach_stream(stream.id, circuit_id)
                with self._pool_lock:
                    if link_id in self._active_single_pool:
                        self._last_success_index = self._active_single_pool.index(link_id)
                self.logger.info(
                    f"✅ 流 {stream.id} 轮询附加成功: link={link_id} -> circuit={circuit_id}"
                )
                return True
            except Exception as e:
                self.logger.warning(
                    f"⚠️ 流 {stream.id} 轮询附加失败 link={link_id}: {e}"
                )
                continue
        return False

    def generate_link_id(self) -> str:
        """生成唯一的 LinkID (即 SOCKS Username)"""
        return f"link-{uuid.uuid4().hex[:8]}"

    async def register_link(self, link_id: str, path: List[str], set_as_default: bool = False) -> Optional[str]:
        """
        注册一个 Link 并创建对应的电路
        
        Args:
            link_id: 链路ID (将作为 SOCKS Username)
            path: 电路路径 (fingerprint 列表)
            set_as_default: 是否设为默认链路（无 socks_username 的流将使用此电路）
            
        Returns:
            circuit_id: 创建成功返回电路ID，失败返回 None
        """
        self.logger.info(f"注册链路: {link_id}, 路径: {path}")
        
        # 保存路径配置（用于重建）
        self._link_path_map[link_id] = path
        
        # 创建电路
        circuit_id = await self.stem2tor.create_circuit(path)
        if not circuit_id:
            self.logger.error(f"链路 {link_id} 电路创建失败")
            return None
            
        # 建立映射
        self._link_circuit_map[link_id] = circuit_id
        self.logger.info(f"链路 {link_id} -> 电路 {circuit_id} 映射建立")
        
        if set_as_default:
            self._default_link_id = link_id
            self.logger.info(f"设置默认链路: {link_id}")
        else:
            self.logger.info(f"链路 {link_id} 等待被执行切换链路而激活")
            
        return circuit_id

    async def unregister_link(self, link_id: str, delete_circuit: bool = True) -> bool:
        """
        注销一个 Link，删除对应的电路
        
        Args:
            link_id: 链路ID
            
        Returns:
            是否成功
        """
        circuit_id = self._link_circuit_map.get(link_id)
        if delete_circuit and circuit_id:
            await self.stem2tor.delete_circuit(circuit_id)
            
        self._link_circuit_map.pop(link_id, None)
        self._link_path_map.pop(link_id, None)
        self.deactivate_single(link_id)
        
        if self._default_link_id == link_id:
            self._default_link_id = None
            
        self.logger.info(f"链路 {link_id} 已注销")
        return True

    def find_link_by_circuit_id(self, circuit_id: str) -> Optional[str]:
        """通过 circuit_id 反查 link_id"""
        for link_id, mapped_circuit_id in self._link_circuit_map.items():
            if mapped_circuit_id == circuit_id:
                return link_id
        return None

    def mark_circuit_for_manual_close(self, circuit_id: str) -> None:
        """标记某个 circuit_id 为手动关闭（避免触发自动重建）"""
        if circuit_id:
            self._ignore_closed_circuits.add(str(circuit_id))

    def mark_default_link_for_active(self, link_id: str) -> bool:
        """兼容旧接口：激活单链路入池。"""
        return self.activate_single(link_id)

    def mark_default_link_for_inactive(self, link_id: str) -> bool:
        """兼容旧接口：单链路出池；若传入的是当前激活多则清除多标记。"""
        link_id = str(link_id).strip()
        if self._active_multi_link_id == link_id:
            self.clear_multi_active()
            return True
        return self.deactivate_single(link_id)

    def get_circuit_for_link(self, link_id: str) -> Optional[str]:
        """根据 link_id 获取对应的 circuit_id"""
        return self._link_circuit_map.get(link_id)

    def get_all_mappings(self) -> Dict[str, str]:
        """获取所有 link -> circuit 映射（用于上报同步）"""
        return self._link_circuit_map.copy()

    async def start(self) -> bool:
        """
        启动电路管理器，开始监听流事件
        """
        if self._is_running:
            self.logger.warning("CircuitManager 已在运行")
            return True
            
        ctrl = self.stem2tor._get_controller()

        # start() 必须在 asyncio 事件循环中调用；保存 loop 供 Stem 回调线程使用
        try:
            self._event_loop = asyncio.get_running_loop()
        except RuntimeError:
            self.logger.error("CircuitManager.start() 必须在运行中的 asyncio 事件循环内调用")
            return False
        
        try:
            # 设置 Tor 不自动附加流
            ctrl.set_conf('__LeaveStreamsUnattached', '1')
            self.logger.info("已设置 __LeaveStreamsUnattached = 1")
        except Exception as e:
            self.logger.error(f"设置 __LeaveStreamsUnattached 失败: {e}")
            return False

        # 启动自检：确认当前控制的 Tor 实例到底监听哪些 SOCKS 端口
        # 这能快速排查“curl 连的 9050 不是这台 Tor”导致完全看不到 STREAM 事件的情况。
        try:
            tor_pid = None
            tor_version = None
            socks_listeners = None
            socks_port_conf = None
            client_reject_internal = None
            socks_policy = None
            prefer_socks_no_auth = None
            safe_logging = None

            try:
                tor_pid = ctrl.get_info("process/pid")
            except Exception:
                pass

            try:
                tor_version = ctrl.get_info("version")
            except Exception:
                pass

            try:
                socks_listeners = ctrl.get_info("net/listeners/socks")
            except Exception:
                socks_listeners = None

            try:
                socks_port_conf = ctrl.get_conf("SocksPort")
            except Exception:
                socks_port_conf = None

            try:
                client_reject_internal = ctrl.get_conf("ClientRejectInternalAddresses")
            except Exception:
                client_reject_internal = None

            try:
                socks_policy = ctrl.get_conf("SocksPolicy")
            except Exception:
                socks_policy = None

            try:
                prefer_socks_no_auth = ctrl.get_conf("PreferSOCKSNoAuth")
            except Exception:
                prefer_socks_no_auth = None

            try:
                safe_logging = ctrl.get_conf("SafeLogging")
            except Exception:
                safe_logging = None

            self.logger.info(
                "Tor自检: pid=%s version=%s net/listeners/socks=%s SocksPort=%s ClientRejectInternalAddresses=%s SocksPolicy=%s PreferSOCKSNoAuth=%s SafeLogging=%s",
                tor_pid,
                tor_version,
                socks_listeners,
                socks_port_conf,
                client_reject_internal,
                socks_policy,
                prefer_socks_no_auth,
                safe_logging,
            )
        except Exception as e:
            self.logger.warning(f"Shr自检日志输出失败: {e}")

        # 定义流监听器
        def stream_listener(stream):
            # 关注 NEW/NEWRESOLVE 用于 attach；同时关注 FAILED/CLOSED 以便解释 curl 的 SOCKS 失败原因。
            if stream.status not in {
                StreamStatus.NEW,
                StreamStatus.NEWRESOLVE,
                StreamStatus.SUCCEEDED,
                StreamStatus.DETACHED,
                StreamStatus.FAILED,
                StreamStatus.CLOSED,
            }:
                return
            # Stem 事件回调可能运行在非 asyncio 线程：用线程安全方式调度
            if not self._event_loop:
                return
            asyncio.run_coroutine_threadsafe(self._handle_new_stream(stream), self._event_loop)

        # 定义电路监听器
        def circuit_listener(circuit):
            if circuit.status in ("FAILED", "CLOSED"):
                if not self._event_loop:
                    return
                asyncio.run_coroutine_threadsafe(self._handle_circuit_closed(circuit), self._event_loop)

        try:
            ctrl.add_event_listener(stream_listener, EventType.STREAM)
            ctrl.add_event_listener(circuit_listener, EventType.CIRC)
            self._stream_listener = stream_listener
            self._circuit_listener = circuit_listener
            self._is_running = True
            self.logger.info("✅ CircuitManager 已启动，开始监听流和电路事件")
            return True
        except Exception as e:
            self.logger.error(f"启动监听器失败: {e}")
            return False

    async def stop(self):
        """停止电路管理器"""
        ctrl = self.stem2tor._get_controller()
        
        if self._stream_listener:
            try:
                ctrl.remove_event_listener(self._stream_listener)
            except:
                pass
                
        if self._circuit_listener:
            try:
                ctrl.remove_event_listener(self._circuit_listener)
            except:
                pass
                
        try:
            ctrl.set_conf('__LeaveStreamsUnattached', '0')
        except:
            pass
            
        self._stream_listener = None
        self._circuit_listener = None
        self._is_running = False
        self._event_loop = None
        self.logger.info("CircuitManager 已停止")

    async def _handle_new_stream(self, stream):
        """
        处理新流事件
        
        根据流的 socks_username 查找对应的电路并附加
        """
        ctrl = self.stem2tor._get_controller()

        # 统一采集关键字段（不同 Tor/Stem 版本字段可能缺失）。
        stream_status = getattr(stream, 'status', None)
        stream_purpose = getattr(stream, 'purpose', None)
        stream_target = getattr(stream, 'target', None)
        socks_username = getattr(stream, 'socks_username', None)
        socks_password = getattr(stream, 'socks_password', None)
        client_protocol = getattr(stream, 'client_protocol', None)

        def _parse_kv(raw: str, key: str) -> Optional[str]:
            # STREAM 事件一般是空格分隔的 key=value；值通常无空格，偶尔可能带引号。
            m = re.search(rf"\b{re.escape(key)}=(\"[^\"]*\"|\S+)", raw)
            if not m:
                return None
            value = m.group(1)
            if value.startswith('"') and value.endswith('"') and len(value) >= 2:
                return value[1:-1]
            return value

        # 如果 socks_username 为空，额外采样输出 Tor 控制协议的原始 STREAM 事件行。
        # 这能把问题一刀切分为：
        # - 原始事件里就没有 SOCKS_USERNAME => Tor 实际走的是 NoAuth（或该版本/配置不暴露）
        # - 原始事件里有 SOCKS_USERNAME 但解析后为 None => Stem 版本/解析兼容问题
        raw_line = None
        if not socks_username or not socks_password:
            try:
                # stem.response.events.Event 通常提供 raw_content()
                raw_line = stream.raw_content()  # type: ignore[attr-defined]
            except Exception:
                try:
                    raw_line = str(stream)
                except Exception:
                    raw_line = None

        # 若 Stem 没填充字段，但原始事件里有，则回退解析
        if raw_line:
            if not socks_username:
                socks_username = _parse_kv(raw_line, "SOCKS_USERNAME")
            if not socks_password:
                socks_password = _parse_kv(raw_line, "SOCKS_PASSWORD")
            if not client_protocol:
                client_protocol = _parse_kv(raw_line, "CLIENT_PROTOCOL")

        # 只处理 SOCKS 客户端发起的流。
        # Tor 自身会创建大量内部流（例如 DIR_FETCH），这些流不应由 controller attach，
        # 否则会出现 TORPROTOCOL / Connection is not managed by controller 并导致电路抖动，
        # 最终拖累真正的 SOCKS CONNECT（表现为 tun_bridge 超时）。
        is_socks_stream = False
        try:
            cp = (str(client_protocol) if client_protocol is not None else "").upper()
            if cp in {"SOCKS4", "SOCKS5"}:
                is_socks_stream = True
        except Exception:
            pass
        if socks_username or socks_password:
            is_socks_stream = True

        if not is_socks_stream:
            # 内部流：仅保留少量采样日志，直接交给 Tor 自行处理。
            return

        if (not socks_username) and self._stream_raw_log_budget > 0:

            if raw_line:
                self._stream_raw_log_budget -= 1
                self.logger.info("🧾 STREAM_RAW sample=%s: %s", self._stream_raw_log_budget, raw_line)

        # 对 FAILED/DETACHED/CLOSED 做可观测输出：这能直接解释 SOCKS CONNECT 为何失败/超时。
        if stream_status in (StreamStatus.FAILED, StreamStatus.DETACHED, StreamStatus.CLOSED):
            reason = getattr(stream, 'reason', None)
            remote_reason = getattr(stream, 'remote_reason', None)

            # Avoid logging raw SOCKS password.
            socks_password_log = None
            if socks_password is None:
                socks_password_log = None
            elif str(socks_password) == "":
                socks_password_log = "<empty>"
            else:
                socks_password_log = "<set>"
            self.logger.warning(
                "🧵 STREAM %s id=%s target=%s purpose=%s socks_username=%s socks_password=%s reason=%s remote_reason=%s",
                stream_status,
                getattr(stream, 'id', None),
                stream_target,
                stream_purpose,
                socks_username,
                socks_password_log,
                reason,
                remote_reason,
            )

            # When EXITPOLICY happens, log which exit relay the circuit uses and
            # what policy the *client tor* believes that exit has (descriptor view).
            try:
                if str(remote_reason).upper() == "EXITPOLICY":
                    circ_id = getattr(stream, 'circ_id', None)
                    if circ_id:
                        circuit = None
                        try:
                            circuit = ctrl.get_circuit(str(circ_id))
                        except Exception:
                            circuit = None

                        exit_fp = None
                        if circuit and getattr(circuit, 'path', None):
                            try:
                                last_hop = circuit.path[-1]
                                # last_hop is typically (fingerprint, nickname)
                                if isinstance(last_hop, (list, tuple)) and last_hop:
                                    exit_fp = str(last_hop[0])
                            except Exception:
                                exit_fp = None

                        policy_summary = None
                        if exit_fp:
                            try:
                                desc = ctrl.get_server_descriptor(exit_fp)
                                # descriptor.exit_policy can be large; keep a short summary
                                ep = getattr(desc, 'exit_policy', None)
                                if ep is not None:
                                    policy_summary = str(ep)
                            except Exception:
                                policy_summary = None

                        self.logger.warning(
                            "🧭 EXITPOLICY detail: stream_id=%s circ_id=%s exit_fp=%s exit_policy=%s",
                            getattr(stream, 'id', None),
                            circ_id,
                            exit_fp,
                            (policy_summary[:300] + "..." if policy_summary and len(policy_summary) > 300 else policy_summary),
                        )
            except Exception:
                pass
            return

        # SUCCEEDED：不需要 attach，但对排查“SOCKS 端一直等”的场景很关键。
        if stream_status == StreamStatus.SUCCEEDED:
            self.logger.info(
                "🧵 STREAM %s id=%s target=%s purpose=%s socks_username=%s",
                stream_status,
                getattr(stream, 'id', None),
                stream_target,
                stream_purpose,
                socks_username,
            )
            return

        # NEW/NEWRESOLVE：精确 username → 单链路池轮询 → allow_auto_circuit 兜底
        self.logger.info(
            "🧵 STREAM %s id=%s target=%s purpose=%s socks_username=%s socks_password=%s",
            stream_status,
            getattr(stream, 'id', None),
            stream_target,
            stream_purpose,
            socks_username,
            ("<empty>" if (socks_password is not None and str(socks_password) == "") else ("<set>" if socks_password else None)),
        )
        
        # 2. 查找对应的电路
        target_circuit_id = None
        resolved_link_id = None

        # 注意：不能依赖 purpose==USER。部分环境 purpose 可能缺失，导致误判为“非用户流”从而完全不打印路由日志。
        if socks_username and socks_username in self._link_circuit_map:
            # 有明确的 link_id
            target_circuit_id = self._link_circuit_map[socks_username]
            resolved_link_id = socks_username
            self.logger.info(
                f"🔗 USER流 {stream.id} target={stream_target} socks_username={socks_username} -> 电路 {target_circuit_id}"
            )
        elif self._routing_mode == RoutingMode.SINGLE and self.get_active_single_pool():
            if self.try_attach_round_robin(ctrl, stream):
                return
            self.logger.warning(
                f"流 {stream.id} 单链路池整圈附加均失败，交由 allow_auto_circuit 兜底"
            )
            self._attach_or_reject_unmapped_stream(ctrl, stream)
            return
        else:
            # multi / idle / 池空：按开关兜底
            self._attach_or_reject_unmapped_stream(ctrl, stream)
            return
            
        # 3. 附加流到精确电路
        if not target_circuit_id:
            self._attach_or_reject_unmapped_stream(ctrl, stream)
            return

        try:
            ctrl.attach_stream(stream.id, target_circuit_id)
            self.logger.info(f"✅ 流 {stream.id} 已附加到电路 {target_circuit_id}")
        except Exception as e:
            # 在 __LeaveStreamsUnattached=1 时，如果 attach 失败且不做兜底，客户端会直接在 CONNECTTIMEOUT 处超时。
            # 实测 Tor/Stem 偶发会在 NEW 事件刚到时返回 "Unknown stream"（stream 竞态/瞬时状态）。
            # 对此类错误：先快速重试一次；仍失败则按 allow_auto_circuit 决定 attach(0) 或 close_stream。
            msg = str(e)
            self.logger.error(f"附加流 {stream.id} 到电路 {target_circuit_id} 失败: {e}")

            # 部分流不是 controller 可管理对象（例如 Tor 内部流或竞态），不要因此触发重建风暴。
            if "not managed by controller" in msg.lower() or "unable to attach stream" in msg.lower():
                self._attach_or_reject_unmapped_stream(ctrl, stream)
                return

            if "Unknown stream" in msg or "unknown stream" in msg:
                try:
                    await asyncio.sleep(0.05)
                    ctrl.attach_stream(stream.id, target_circuit_id)
                    self.logger.info(f"✅ 流 {stream.id} 重试后已附加到电路 {target_circuit_id}")
                    return
                except Exception as e2:
                    self.logger.warning(
                        f"⚠️ 流 {stream.id} 重试附加仍失败: {e2}，按 allow_auto_circuit 兜底处理"
                    )
                    self._attach_or_reject_unmapped_stream(ctrl, stream)
                    return

            # 其它 attach 失败更可能是电路已失效：尝试重建。
            link_id = resolved_link_id or socks_username or self._default_link_id
            if link_id:
                await self._rebuild_circuit(link_id)

    async def _handle_circuit_closed(self, circuit):
        """
        处理电路关闭事件
        
        查找是否有 link 使用了这个电路，如果有则重建
        """
        closed_circuit_id = str(circuit.id)

        # 如果是手动关闭，忽略一次并退出
        if closed_circuit_id in self._ignore_closed_circuits:
            self._ignore_closed_circuits.discard(closed_circuit_id)
            self.logger.info(f"🔕 电路 {closed_circuit_id} 为手动关闭，跳过重建")
            return
        
        # 查找使用此电路的 link
        affected_link_id = None
        for link_id, circuit_id in self._link_circuit_map.items():
            if circuit_id == closed_circuit_id:
                affected_link_id = link_id
                break
                
        if affected_link_id:
            self.logger.warning(
                "⚠️ 电路 %s (链路 %s) 已关闭，触发重建 | status=%s reason=%s remote_reason=%s purpose=%s path=%s",
                closed_circuit_id,
                affected_link_id,
                getattr(circuit, "status", None),
                getattr(circuit, "reason", None),
                getattr(circuit, "remote_reason", None),
                getattr(circuit, "purpose", None),
                getattr(circuit, "path", None),
            )
            await self._rebuild_circuit(affected_link_id)

    async def _get_circuit(self, link_id: str, circuit_id: str) -> Circuit:
        # 获取电路详细信息
        try:
            circuit_info = await self.stem2tor.get_circuit_info(circuit_id)
        except Exception as e:
            self.logger.error(f"获取电路 {circuit_id} 详细信息失败: {e}")
            return None
        
        if circuit_info:
            circuit = Circuit.from_stem_circuit_info(
                circuit_id=circuit_id,
                circuit_info=circuit_info,
                relay_fingerprints=self._link_path_map.get(link_id),
                client_relay_code=self.client_relay_code,
                node_code=self.context.node_code,
                link_id=link_id,
            )

            # 存储到活动电路字典
            self.context.active_circuits[circuit_id] = circuit
            return circuit
        else:
            return None

    async def _rebuild_circuit(self, link_id: str) -> bool:
        """
        重建指定链路的电路
        
        Args:
            link_id: 链路ID
            
        Returns:
            是否重建成功
        """
        path = self._link_path_map.get(link_id)
        if not path:
            self.logger.error(f"无法重建链路 {link_id}：找不到路径配置")
            return False
            
        self.logger.info(f"🔄 正在重建链路 {link_id} 的电路...")
        
        old_circuit_id = self._link_circuit_map.get(link_id)
        new_circuit_id = await self.stem2tor.create_circuit(path)
        if new_circuit_id:
            self._link_circuit_map[link_id] = new_circuit_id
            self.context.active_circuits.pop(old_circuit_id, None)
            self.logger.info(f"✅ 链路 {link_id} 电路重建成功: {new_circuit_id}")
            # 上报给 Server 端
            circuit = await self._get_circuit(link_id, new_circuit_id)
            await self.reporter.report_circuit_rebuilt_info(True, link_id, circuit)
            return True
        else:
            self.logger.error(f"❌ 链路 {link_id} 电路重建失败")
            self.context.active_circuits.pop(old_circuit_id, None)
            await self.reporter.report_circuit_rebuilt_info(False, link_id, None)
            return False