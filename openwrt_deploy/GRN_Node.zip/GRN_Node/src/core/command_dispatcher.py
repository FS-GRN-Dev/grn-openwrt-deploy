from typing import Dict, Any
from generated import vps_management_pb2
import utils.logger

# Import commands
from commands.create_relay_command import CreateRelayCommand
from commands.set_node_status_command import SetNodeStatusCommand
from commands.destroy_relay_command import DestroyRelayCommand
from commands.destroy_node_command import DestroyNodeCommand
from commands.inform_da_info_command import InformDAInfoCommand
from commands.refresh_info_command import RefreshInfoCommand
from commands.update_relay_command import UpdateRelayCommand
from commands.create_circuit_command import CreateCircuitCommand
from commands.delete_circuit_command import DeleteCircuitCommand
from commands.switch_link_command import SwitchLinkCommand
from commands.heart_beat_response_command import HeartBeatResponseCommand
from commands.multipath_download_command import MultipathDownloadCommand
from commands.tun_bridge_start_command import TunBridgeStartCommand
from commands.tun_bridge_stop_command import TunBridgeStopCommand
from commands.tun_bridge_status_command import TunBridgeStatusCommand
from commands.ping_command import PingCommand
from commands.cleanup_data_command import CleanupDataCommand
from commands.set_allow_auto_circuit_command import SetAllowAutoCircuitCommand


class CommandDispatcher:
    def __init__(self, context):
        self.context = context
        self.reporter = None
        self.commands = {}
        self.logger = utils.logger.get_logger(f"{self.__class__.__name__}")

    def set_reporter(self, reporter) -> None:
        self.reporter = reporter

    def set_relay_service(self, relay_service) -> None:
        self.relay_service = relay_service

    def set_node_service(self, node_service) -> None:
        self.node_service = node_service

    def set_link_service(self, link_service) -> None:
        self.link_service = link_service

    def set_tun_bridge_service(self, tun_bridge_service) -> None:
        self.tun_bridge_service = tun_bridge_service

    def _check_init(self) -> bool:
        if (
            self.reporter
            and self.relay_service
            and self.node_service
            and self.link_service
            and getattr(self, "tun_bridge_service", None)
        ):
            self._init_commands()

    def _init_commands(self) -> None:
        self.commands = {
            vps_management_pb2.CommandType.HEART_BEAT_RESPONSE: HeartBeatResponseCommand(
                self.context, self.reporter, None
            ),
            vps_management_pb2.CommandType.CREATE_RELAY: CreateRelayCommand(
                self.context, self.reporter, self.relay_service
            ),
            vps_management_pb2.CommandType.SET_NODE_STATUS: SetNodeStatusCommand(
                self.context, self.reporter, self.node_service
            ),
            vps_management_pb2.CommandType.DESTROY_RELAY: DestroyRelayCommand(
                self.context, self.reporter, self.relay_service
            ),
            vps_management_pb2.CommandType.DESTROY_NODE: DestroyNodeCommand(
                self.context, self.reporter, self.node_service
            ),
            vps_management_pb2.CommandType.INFORM_DA_INFO: InformDAInfoCommand(
                self.context, self.reporter, self.node_service
            ),
            vps_management_pb2.CommandType.REFRESH_INFO: RefreshInfoCommand(
                self.context, self.reporter, self.node_service
            ),
            vps_management_pb2.CommandType.UPDATE_RELAY: UpdateRelayCommand(
                self.context, self.reporter, self.relay_service
            ),
            vps_management_pb2.CommandType.CREATE_CIRCUIT: CreateCircuitCommand(
                self.context, self.reporter, self.link_service
            ),
            vps_management_pb2.CommandType.DELETE_CIRCUIT: DeleteCircuitCommand(
                self.context, self.reporter, self.link_service
            ),
            vps_management_pb2.CommandType.SWITCH_LINK: SwitchLinkCommand(
                self.context, self.reporter, self.link_service
            ),
            vps_management_pb2.CommandType.CLEANUP_DATA: CleanupDataCommand(
                self.context, self.reporter, self.relay_service
            ),
            vps_management_pb2.CommandType.SET_ALLOW_AUTO_CIRCUIT: SetAllowAutoCircuitCommand(
                self.context, self.reporter, self.relay_service
            ),
            # vps_management_pb2.CommandType.MULTIPATH_DOWNLOAD: MultipathDownloadCommand(
            #     self.context, self.reporter, self.link_service
            # ),
            # vps_management_pb2.CommandType.TUN_BRIDGE_START: TunBridgeStartCommand(
            #     self.context, self.reporter, self.tun_bridge_service
            # ),
            # vps_management_pb2.CommandType.TUN_BRIDGE_STOP: TunBridgeStopCommand(
            #     self.context, self.reporter, self.tun_bridge_service
            # ),
            # vps_management_pb2.CommandType.TUN_BRIDGE_STATUS: TunBridgeStatusCommand(
            #     self.context, self.reporter, self.tun_bridge_service
            # ),
            # vps_management_pb2.CommandType.PING: PingCommand(
            #     self.context, self.reporter, self.node_service
            # ),
        }

    async def dispatch(self, command_type, msg_data, command_id):
        if not self.commands:
            self.logger.warning("命令尚未初始化 (Reporter missing)")
            return None

        if command_type in self.commands:
            command_handler = self.commands[command_type]
            return await command_handler.execute(msg_data, command_id)
        else:
            try:
                name = vps_management_pb2.CommandType.Name(command_type)
            except Exception:
                name = str(command_type)
            raise Exception(f"未知命令类型: {name}")
