import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from abc import ABC, abstractmethod
from typing import List, Dict, Optional
from dataclasses import dataclass, field
from core.container import ServiceContainer
from config.config import GrpcConfig

from models.circuit import Circuit
from models.node import Node
from models.relay import Relay

from observers.subject import StateSubject
from observers.node_info_observer import NodeInfoObserver
from observers.situation_awareness_observer import SituationAwarenessObserver
from observers.relay_info_observer import RelayInfoObserver
from observers.da_info_observer import DAInfoObserver

from utils.network import get_network_info
from utils.cli import parse_args

import utils.logger
import hashlib
import asyncio
import signal

from generated import vps_management_pb2


class AnonymousCommer:
    def __init__(self,
                 node_id: Optional[str] = None,
                 server_addr: Optional[str] = None,
                 ip_addr: Optional[str] = None,
                 geo_location: Optional[str] = None,
                 cloud_provider: Optional[str] = None,
                 run_mode: Optional[str] = None,  # [cloud, test]
                 ) -> None:
        """AnonymousCommer类的初始化方法。

        Args:
            server_addr (_type_, optional): 服务器地址. Defaults to 'localhost:50051'.
        """
        self.logger = utils.logger.get_logger(f"{self.__class__.__name__}")

        self.mode = run_mode
        self.server_addr = server_addr or GrpcConfig.DEFAULT_SERVER_ADDR

        # 节点基本信息
        ip, geo, provider = get_network_info(
            logger=self.logger, ip_addr=ip_addr, mode=self.mode)

        final_ip = ip
        final_geo = geo_location or geo
        final_provider = cloud_provider or provider
        final_node_id = node_id if node_id else f"node-{hashlib.sha256(final_ip.encode('utf-8')).hexdigest()[:8]}"

        # Initialize Context
        self.container = ServiceContainer(
            node_id=final_node_id,
            ip_address=final_ip,
            geo_location=final_geo,
            cloud_provider=final_provider,
            server_addr=self.server_addr
        )

    # --- Delegation Properties for Backward Compatibility ---
    @property
    def node_id(self): return self.context.node_id
    @property
    def ip_address(self): return self.context.ip_address
    @property
    def geo_location(self): return self.context.geo_location
    @property
    def cloud_provider(self): return self.context.cloud_provider
    @property
    def node(self): return self.context.node
    @property
    def relays(self): return self.context.relays
    @property
    def stem2tor_instances(self): return self.context.stem2tor_instances
    @property
    def active_circuits(self): return self.context.active_circuits
    @property
    def dir_auth(self): return self.context.dir_auth
    @dir_auth.setter
    def dir_auth(self, value): self.context.dir_auth = value

    @property
    def stub(self): return self.grpc_handler.stub
    @property
    def channel(self): return self.grpc_handler.channel

    @property
    def context(self): return self.container.context
    @property
    def grpc_handler(self): return self.container.grpc_handler
    @property
    def dispatcher(self): return self.container.dispatcher
    @property
    def reporter(self): return self.container.reporter
    @property
    def consensus_monitor(self): return self.container.consensus_monitor
    
    # --- Delegation Methods ---f
    def _get_latest_circuit_id(self) -> str | None:
        return self.context.get_latest_circuit_id()

    def _get_active_circuit(self, circuit_id: str) -> Optional[Circuit]:
        return self.context.get_active_circuit(circuit_id)

    def _get_all_active_circuits(self) -> List[Circuit]:
        return self.context.get_all_active_circuits()

    def _get_relay(self, relay_id: str) -> Optional[Relay]:
        return self.context.get_relay(relay_id)

    def _get_all_relays(self) -> List[Relay]:
        return self.context.get_all_relays()

    def _create_node(self) -> Node:
        return self.context._create_node()
        
    def _get_role(self, role_enum) -> str:
        return self.context._get_role(role_enum)

    async def _delayed_exit(self):
        """延迟退出进程，确保响应消息发送完成。
        """
        await asyncio.sleep(GrpcConfig.EXIT_DELAY)  # 等待确保响应发送完成
        self.logger.info("节点执行销毁命令，程序退出")
        # 关闭通道
        await self.grpc_handler.close()
        # 退出程序
        sys.exit(0)

    def _sync_handle_interrupt(self):
        self.logger.info("收到中断信号，正在关闭...")

        for task in asyncio.all_tasks():
            if task is not asyncio.current_task():
                task.cancel()

    @abstractmethod
    async def run(self) -> None:
        """启动所有异步任务，包括节点信息、DA信息、态势感知推送及命令处理。
        """
        pass