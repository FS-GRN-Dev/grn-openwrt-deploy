from abc import ABC, abstractmethod
from typing import Optional, Dict, List, Any, Union
from config.tor_node_config import TorNodeConfig
from config.config import StemConfig

class ITorRuntime(ABC):
    """
    Tor 运行时接口，定义了 Tor 节点生命周期管理和操作的方法。
    旨在解耦具体的 Tor 实现（如 Docker + Stem）与业务逻辑，便于测试和扩展。
    """
    
    @property
    @abstractmethod
    def role(self) -> str: ...

    @property
    @abstractmethod
    def container_name(self) -> str: ...
    
    @property
    @abstractmethod
    def container_id(self) -> Optional[str]: ...

    @abstractmethod
    async def start_tor(self) -> Optional[Dict]: ...

    @abstractmethod
    async def stop_tor(self) -> bool: ...

    @abstractmethod
    async def create_circuit(self, path) -> Optional[str]: ...

    @abstractmethod
    async def delete_circuit(self, cir_id) -> bool: ...
    
    @abstractmethod
    async def get_circuit_info(self, cir_id: Optional[int] = None) -> Dict | list[Dict] | None: ...

    @abstractmethod
    async def get_streams(self) -> Optional[List[Dict]]: ...
    
    @abstractmethod
    async def get_network_statuses(self, fingerprint: Optional[str] = None) -> Optional[Union[Dict, List[Dict]]]: ...

    @abstractmethod
    async def start_global_stream_listener(self, circuit_id: str) -> bool: ...

    @abstractmethod
    def stop_global_stream_listener(self) -> None: ...

    @abstractmethod
    def wait_for_port(self, port: int, timeout: int = 10) -> bool: ...

    @abstractmethod
    async def wait_for_tor_node(self, nickname: str, container_id: str,
                                max_wait_time: int = 30, check_interval: float = 2.0) -> Optional[Dict]: ...

    @abstractmethod
    async def get_dir_auths(self) -> Optional[List[Dict[str, str]]]: ...

    @abstractmethod
    async def update_dir_auths(self, dir_auths): ...

class TorRuntimeFactory:
    """
    Tor 运行时工厂，用于创建 ITorRuntime 实例。
    """
    def create(self, 
               role: str, 
               nick: str, 
               pwd: str,
               or_port: str = StemConfig.DEFAULT_OR_PORT,
               socks_port: str = StemConfig.DEFAULT_SOCKS_PORT,
               control_port: str = StemConfig.DEFAULT_CONTROL_PORT,
               dir_port: Optional[str] = StemConfig.DEFAULT_DIR_PORT,
               dir_auths: Optional[List[Dict[str, Any]]] = None,
               outer_ip_addr: Optional[str] = None
               ):
        
        # 1. 构建配置对象
        config = TorNodeConfig(
            role=role,
            nick=nick,
            pwd=pwd,
            or_port=or_port if or_port else StemConfig.DEFAULT_OR_PORT,
            socks_port=socks_port if socks_port else StemConfig.DEFAULT_SOCKS_PORT,
            control_port=control_port if control_port else StemConfig.DEFAULT_CONTROL_PORT,
            dir_port=dir_port if dir_port else StemConfig.DEFAULT_DIR_PORT,
            outer_ip_addr=outer_ip_addr,
            dir_auths=dir_auths
        )

        # 2. 延迟导入具体实现 (避免循环依赖)
        from core.stem_api import Stem2Tor
        
        # 3. 注入配置
        return Stem2Tor(config)