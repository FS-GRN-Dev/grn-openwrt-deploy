import sys
import os
import platform

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import List, Optional
from pathlib import Path
from core.container import ServiceContainer
from config.config import GrpcConfig

from models.circuit import Circuit
from models.node import Node
from models.relay import Relay

from observers.subject import StateSubject
from observers.node_info_observer import NodeInfoObserver
from observers.situation_awareness_observer import SituationAwarenessObserver
from observers.relay_info_observer import RelayInfoObserver
from observers.da_info_observer import DAInfoObserver
from observers.consensus_observer import ConcensusObserver

from utils.network import get_network_info
from utils.cli import parse_args

import utils.logger
import hashlib
import asyncio
import signal
import subprocess


class NodeClient:
    def __init__(
        self,
        node_code: Optional[str] = None,
        server_addr: Optional[str] = None,
        ip_addr: Optional[str] = None,
        geo_location: Optional[str] = None,
        longitude: Optional[float] = None,
        latitude: Optional[float] = None,
        cloud_provider: Optional[str] = None,
        run_mode: Optional[str] = None,  # [cloud, test]
        run_role: Optional[str] = None,
    ) -> None:
        """NodeClient类的初始化方法。

        Args:
            server_addr (_type_, optional): 服务器地址. Defaults to 'localhost:50051'.
        """
        self.logger = utils.logger.get_logger(f"{self.__class__.__name__}")

        self.mode = run_mode or "test"
        self.server_addr = server_addr or GrpcConfig.DEFAULT_SERVER_ADDR
        self.run_role = run_role if run_role is not None else "vps"
        self._grn_iptables_started = False

        # 节点基本信息
        ip, geo, provider, net_latitude, net_longitude = get_network_info(
            logger=self.logger, ip_addr=ip_addr, mode=self.mode
        )

        self.logger.info(f"ip={ip}, geo={geo}, provider={provider}, net_latitude={net_latitude}, net_longitude={net_longitude}")

        final_ip = ip
        final_geo = geo_location or geo
        final_provider = cloud_provider or provider

        # 生成节点编码
        if node_code:
            final_node_code = node_code
        elif run_role == 'openwrt':
            br_lan_mac = None
            try:
                # 以路由器 br-lan 网卡的 MAC 地址作为输入
                with open('/sys/class/net/br-lan/address', 'r') as f:
                    br_lan_mac = f.read().strip()
            except FileNotFoundError:
                self.logger.warning("未找到 br-lan 网卡，回退使用 IP 生成 node_code")
            
            hash_source = br_lan_mac if br_lan_mac else final_ip
            final_node_code = f"node-{hashlib.sha256(hash_source.encode('utf-8')).hexdigest()[:8]}"
        else:
            final_node_code = f"node-{hashlib.sha256(final_ip.encode('utf-8')).hexdigest()[:8]}"

        # Initialize Context
        self.container = ServiceContainer(
            node_code=final_node_code,
            ip_address=final_ip,
            geo_location=final_geo,
            longitude=longitude if net_longitude == 0.0 else net_longitude,
            latitude=latitude if net_latitude == 0.0 else net_latitude,
            cloud_provider=final_provider,
            run_role=run_role,
            server_addr=self.server_addr,
        )

        # 中断信号标记
        self.shutdown_event = asyncio.Event()

    # --- Delegation Properties for Backward Compatibility ---
    @property
    def node_code(self):
        return self.context.node_code

    @property
    def ip_address(self):
        return self.context.ip_address

    @property
    def geo_location(self):
        return self.context.geo_location

    @property
    def cloud_provider(self):
        return self.context.cloud_provider

    @property
    def node(self):
        return self.context.node

    @property
    def relays(self):
        return self.context.relays

    @property
    def stem2tor_instances(self):
        return self.context.stem2tor_instances

    @property
    def active_circuits(self):
        return self.context.active_circuits

    @property
    def dir_auth(self):
        return self.context.dir_auth

    @dir_auth.setter
    def dir_auth(self, value):
        self.context.dir_auth = value

    @property
    def stub(self):
        return self.grpc_handler.stub

    @property
    def channel(self):
        return self.grpc_handler.channel

    @property
    def context(self):
        return self.container.context

    @property
    def grpc_handler(self):
        return self.container.grpc_handler

    @property
    def reporter(self):
        return self.container.reporter

    @property
    def consensus_monitor(self):
        return self.container.consensus_monitor

    # --- Delegation Methods ---
    def _get_latest_circuit_id(self) -> str | None:
        return self.context.get_latest_circuit_id()

    def _get_active_circuit(self, circuit_id: str) -> Optional[Circuit]:
        return self.context.get_active_circuit(circuit_id)

    def _get_all_active_circuits(self) -> List[Circuit]:
        return self.context.get_all_active_circuits()

    def _get_relay(self, relay_code: str) -> Optional[Relay]:
        return self.context.get_relay(relay_code)

    def _get_all_relays(self) -> List[Relay]:
        return self.context.get_all_relays()

    def _create_node(self) -> Node:
        return self.context._create_node()

    def _get_role(self, role_enum) -> str:
        return self.context._get_role(role_enum)

    async def _delayed_exit(self):
        """延迟退出进程，确保响应消息发送完成。"""
        await asyncio.sleep(GrpcConfig.EXIT_DELAY)  # 等待确保响应发送完成
        self.logger.info("节点执行销毁命令，程序退出")
        # 关闭通道
        await self.grpc_handler.close()
        # 退出程序
        sys.exit(0)

    def _is_openwrt(self) -> bool:
        return str(self.run_role or "").lower() == "openwrt"

    @staticmethod
    def _grn_iptables_script() -> Path:
        # src/core/node_client.py -> 仓库根目录/scripts/grn-iptables.sh
        return Path(__file__).resolve().parents[2] / "scripts" / "grn-iptables.sh"

    async def _run_grn_iptables(self, action: str) -> None:
        """执行 scripts/grn-iptables.sh {start|stop}（仅 OpenWrt）。"""
        script = self._grn_iptables_script()
        if not script.is_file():
            raise FileNotFoundError(f"grn-iptables script not found: {script}")

        def _run() -> subprocess.CompletedProcess:
            return subprocess.run(
                ["sh", str(script), action],
                check=False,
                capture_output=True,
                text=True,
            )

        result = await asyncio.get_running_loop().run_in_executor(None, _run)
        stdout = (result.stdout or "").strip()
        stderr = (result.stderr or "").strip()
        if stdout:
            self.logger.info("grn-iptables.sh %s: %s", action, stdout)
        if stderr:
            self.logger.warning("grn-iptables.sh %s stderr: %s", action, stderr)
        if result.returncode != 0:
            raise RuntimeError(
                f"grn-iptables.sh {action} failed with code {result.returncode}"
            )

    # 信号处理函数（只标记中断，不执行清理）
    def _signal_handler(self, signum, frame):
        self.logger.info(f"收到信号 {signum}，准备优雅退出...")
        self.shutdown_event.set()  # 标记需要退出

    async def _cleanup(self):
        """执行清理操作（异步安全）"""
        self.logger.info("开始执行清理操作...")
        # OpenWrt：先卸 REDIRECT，再停 sing-box，避免流量打到已关闭端口
        if self._is_openwrt():
            try:
                await self._run_grn_iptables("stop")
                self._grn_iptables_started = False
            except Exception as e:
                self.logger.error("停止 grn-iptables 失败: %s", e, exc_info=True)

        try:
            from services.transparent_proxy import stop_client_proxy
            await stop_client_proxy()
        except Exception as e:
            self.logger.error("停止 client sing-box 失败: %s", e, exc_info=True)

        try:
            if self.stem2tor_instances:
                self.logger.info(f"停止 {len(self.stem2tor_instances)} 个 stem2tor 实例")
                await asyncio.gather(
                    *(inst.stop_tor() for inst in self.stem2tor_instances.values()),
                    return_exceptions=True,
                )
        except Exception as e:
            self.logger.error("停止 tor 实例失败: %s", e, exc_info=True)

        try:
            await self.grpc_handler.close()
        except Exception as e:
            self.logger.error("关闭 gRPC 通道失败: %s", e, exc_info=True)

        self.logger.info("清理操作完成，程序即将安全退出")

    async def run(self) -> None:
        """启动所有异步任务，包括节点信息、DA信息、态势感知推送及命令处理。"""
        # 注册信号处
        loop = asyncio.get_running_loop()
        try:
            # Linux/Unix/MacOS 适配 SIGINT、SIGTERM、SIGQUIT
            platforms = ["Linux", "Unix", "Darwin"]
            supported_signals = []
            if platform.system() in platforms:
                supported_signals = [signal.SIGINT, signal.SIGTERM, signal.SIGQUIT]
            for sig in supported_signals:
                loop.add_signal_handler(sig, self._signal_handler, sig, None)
        except NotImplementedError:
            self.logger.error("当前环境不支持add_signal_handler，将使用KeyboardInterrupt处理")

        # openwrt + 业务主循环：失败则不再往下跑，finally 仍做清理
        try:
            if self._is_openwrt():
                from services.http_local_service import start_openwrt_http_service
                from services.transparent_proxy import switch_proxy_to_direct

                def get_info():
                    return {
                        "node_code": self.node_code,
                        "anonymous_relay_code": getattr(self.node, "anonymous_relay_code", None),
                    }

                start_openwrt_http_service(get_info)
                await switch_proxy_to_direct()
                self.logger.info("Client transparent proxy started in DIRECT mode")
                await self._run_grn_iptables("start")
                self._grn_iptables_started = True
                self.logger.info("grn-iptables.sh start completed")

            # await self.grpc_handler.initialize_from_config(False)
            # await self.grpc_handler.initialize(True, GrpcConfig.DEFAULT_CA_CERT_PATH, None, None, False, None)
            await self.grpc_handler.initialize(True, GrpcConfig.DEFAULT_CA_CERT_PATH, None, None, True, self.server_addr)
            await self.grpc_handler.register_node()

            subject = StateSubject()
            subject.attach(NodeInfoObserver(self.reporter))
            subject.attach(SituationAwarenessObserver(self.reporter))
            # subject.attach(DAInfoObserver(self.reporter))
            subject.attach(RelayInfoObserver(self.reporter))
            subject.attach(ConcensusObserver(self.reporter, self.context))

            business_tasks  = [
                subject.start_all(),
                self.grpc_handler.handle_commands(),
            ]
            task_group = asyncio.gather(*business_tasks, return_exceptions=True)

            # 等待：任务完成 或 收到中断信号
            wait_list = [
                task_group,  # Future 对象，直接用
                asyncio.create_task(self.shutdown_event.wait())  # 裸协程，必须封装
            ]
            done, pending = await asyncio.wait(
                wait_list,
                return_when=asyncio.FIRST_COMPLETED
            )

            # 收到中断信号，取消所有任务
            if self.shutdown_event.is_set():
                self.logger.warning("收到退出信号，取消所有异步任务...")
                task_group.cancel()
                try:
                    await task_group  # 等待任务取消完成
                except asyncio.CancelledError:
                    self.logger.error("所有异步任务已取消")
        except asyncio.CancelledError:
            # 打印异常信息
            self.logger.error("主任务被取消", exc_info=True)
            if platform.system() == "Windows":
                # 主动抛出 KeyboardInterrupt
                raise KeyboardInterrupt()
        except Exception as e:
            self.logger.error("程序运行异常: %s", e, exc_info=True)
            raise
        finally:
            # 无论如何都执行清理
            await asyncio.shield(self._cleanup())
            self.logger.info("程序已安全退出。")


def main() -> None:
    """程序入口，启动NodeClient并运行主循环。"""
    utils.logger.setup_logging(
        "INFO",
        "/home/node-test/node_client.log",
        enable_console=False,
    )
    args = parse_args()
    client = NodeClient(
        server_addr=args.server_addr,
        geo_location=args.geo_location,
        longitude=args.longitude,
        latitude=args.latitude,
        cloud_provider=args.cloud_provider,
        ip_addr=args.address,
        run_mode=args.mode,
        run_role=args.role,
    )
    try:
        asyncio.run(client.run())
    except KeyboardInterrupt:
        client.logger.error("收到KeyboardInterrupt，执行最终清理")
        print("程序终止")


if __name__ == "__main__":
    main()