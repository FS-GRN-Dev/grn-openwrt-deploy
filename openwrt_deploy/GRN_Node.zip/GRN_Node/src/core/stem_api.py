import time
import requests
import asyncio
from typing import List, Dict, Optional, Union, Callable, Any

from utils import logger
from config.tor_node_config import TorNodeConfig
from services.tor_container_service import TorContainerService
from services.tor_controller_service import TorControllerService
from stem.control import Controller

class Stem2Tor:
    """
    Stem2Tor 外观类 (Facade)
    协调 TorContainerService 和 TorControllerService
    保持与原有接口兼容
    """
    def __init__(self, config: TorNodeConfig):
        self.logger = logger.get_logger(f"{self.__class__.__name__}")
        
        # 初始化配置
        self.config = config

        # 初始化服务
        self.container_service = TorContainerService(self.config)
        self.controller_service = TorControllerService(self.config)

        # 兼容性属性
        self.container_id: Optional[str] = None
        self.container_name = self.container_service.container_name
        self.container_ip_addr: Optional[str] = None
        self.controller: Optional[Controller] = None
        
    @property
    def role(self) -> str:
        return self.config.role
    
    @property
    def nick(self) -> str:
        return self.config.nick
    
    @property
    def pwd(self) -> str:
        return self.config.pwd
    
    @property
    def or_port(self) -> int:
        return self.config.or_port
    
    @property
    def socks_port(self) -> int:
        return self.config.socks_port
    
    @property
    def control_port(self) -> int:
        return self.config.control_port
    
    @property
    def dir_port(self) -> str:
        return self.config.dir_port
    
    @property
    def dir_auths(self) -> str:
        return self.config.dir_auths
    
    @property
    def outer_ip_addr(self) -> str:
        return self.config.outer_ip_addr
    
    @property
    def container_handler(self):
        return self.container_service.container

    def _get_controller(self) -> Controller:
        return self.controller_service._get_controller()

    async def _with_controller(self, func: Callable[[Controller], Any], *args, **kwargs) -> Any:
        controller = self._get_controller()
        return await asyncio.get_event_loop().run_in_executor(None, func, controller, *args, **kwargs)

    async def create_circuit(self, path) -> Optional[str]:
        return await self.controller_service.create_circuit(path)

    async def delete_circuit(self, cir_id) -> bool:
        return await self.controller_service.delete_circuit(cir_id)

    async def get_circuit_info(self, cir_id: Optional[int] = None) -> Dict | list[Dict] | None:
        # 注意：原接口 cir_id 是 int 或 None，但 stem 通常用 str。这里做个转换兼容
        cid_str = str(cir_id) if cir_id is not None else None
        return await self.controller_service.get_circuit_info(cid_str)

    async def start_tor(self) -> Optional[Dict]:
        """启动 Tor 节点"""
        if self.role != "da" and not self.dir_auths:
            self.logger.error("❌ 参数错误：必须提供 'dir_auths'")
            return None

        self.logger.info("🛠️ 正在通过 Docker 启动 Tor 容器...")
        self.container_id = self.container_service.start_container()

        if not self.container_id:
            self.logger.error("❌ Docker 容器启动失败")
            return None

        self.container_ip_addr = self.container_service.container_ip_addr
        self.logger.info(f"✅ 容器创建成功，ID: {self.container_id}...")

        # 尝试建立控制连接
        self.logger.info("⏳ 正在等待 Tor 控制端口可用...")
        await asyncio.sleep(1)
        
        # 确定连接地址
        connect_addr = self.container_ip_addr
        if not connect_addr or self.config.network_mode == 'host':
            connect_addr = '127.0.0.1'

        success = await self.controller_service.connect(address=connect_addr)
        
        if success:
            self.controller = self.controller_service.controller
            self.logger.info(f"🔍 正在等待节点 {self.nick} 在网络中注册...")
            tor_info = await self.controller_service.wait_for_tor_node(self.nick, self.container_id)
            
            if tor_info['fingerprint'] != '' or self.role == 'client':
                self.logger.info(f"✅ 找到节点 {self.nick}")
            else:
                self.logger.error(f"⚠️ 超时：未能找到昵称为 {self.nick} 的Tor节点信息")
            return tor_info
        else:
            self.logger.error("❌ 超时：Shr 控制端口不可用")
            await self.stop_tor()
            return None

    async def stop_tor(self) -> bool:
        """停止 Tor 节点"""
        self.controller_service.close()
        self.controller = None
        return self.container_service.stop_container()

    async def get_network_statuses(self, fingerprint: Optional[str] = None) -> Optional[Union[Dict, List[Dict]]]:
        return await self.controller_service.get_network_statuses(fingerprint)

    async def get_streams(self) -> Optional[List[Dict]]:
        return await self.controller_service.get_streams()

    async def start_global_stream_listener(self, circuit_id: str) -> bool:
        return await self.controller_service.start_global_stream_listener(circuit_id)

    def stop_global_stream_listener(self) -> None:
        self.controller_service.stop_global_stream_listener()

    def wait_for_port(self, port: int, timeout: int = 10) -> bool:
        return self.container_service.wait_for_port(port, timeout)

    async def wait_for_tor_node(self, nickname: str, container_id: str,
                                max_wait_time: int = 30, check_interval: float = 2.0) -> Optional[Dict]:
        return await self.controller_service.wait_for_tor_node(nickname, container_id, max_wait_time, check_interval)

    def start_tor_container(self, network_mode: str = "bridge") -> Optional[str]:
        # 兼容旧接口，虽然 network_mode 已经在 config 中
        # 如果传入的 network_mode 与 config 不一致，可能需要警告或临时修改 config
        if network_mode != self.config.network_mode:
            self.logger.warning(f"⚠️ start_shr_container 传入的 network_mode ({network_mode}) 与配置 ({self.config.network_mode}) 不一致，使用配置值。")
        return self.container_service.start_container()

    async def get_dir_auths(self) -> Optional[List[Dict[str, Any]]]:
        return await self.container_service.get_dir_auths()

    async def update_dir_auths(self, dir_auths):
        return await self.container_service.update_dir_auths(dir_auths)

    async def connect_controller(self):
        """连接 Tor 控制端口"""
        # 尝试建立控制连接
        self.logger.info("⏳ 正在等待 Tor 控制端口可用...")
        await asyncio.sleep(1)
        
        # 确定连接地址
        connect_addr = self.container_ip_addr
        if not connect_addr or self.config.network_mode == 'host':
            connect_addr = '127.0.0.1'

        # 连接 Tor 控制端口
        try:
            success = await self.controller_service.connect(address=connect_addr)
            
            if success:
                self.controller = self.controller_service.controller
                self.logger.info(f"🔍 正在等待节点 {self.nick} 在网络中注册...")
                tor_info = await self.controller_service.wait_for_tor_node(self.nick, self.container_id)
                
                if tor_info['fingerprint'] != '' or self.role == 'client':
                    self.logger.info(f"✅ 找到节点 {self.nick}")
                else:
                    self.logger.error(f"⚠️ 超时：未能找到昵称为 {self.nick} 的Tor节点信息")
                return tor_info
            else:
                self.logger.error("❌ 超时：Shr 控制端口不可用")
                await self.stop_tor()
                return None
        except Exception as e:
            self.logger.error(f"❌ 连接 Shr 控制端口失败: {e}")
            return None

    async def disconnect_controller(self):
        """断开 Tor 控制端口连接"""
        self.logger.info("⏳ 正在断开 Tor 控制端口连接...")
        self.controller_service.close()
    
    def stop_tor_process(self):
        self.container_service.stop_tor_process()

    def start_tor_process(self):
        self.container_service.start_tor_process()

