from core.node_context import NodeContext
from core.state_reporter import StateReporter
from core.grpc_handler import GrpcHandler
from core.command_dispatcher import CommandDispatcher
from services.relay_service import RelayService
from services.node_service import NodeService
from services.link_service import LinkService
from core.tor_runtime import TorRuntimeFactory
from services.tun_bridge_service import TunBridgeService
from services.node_init_sync_service import NodeInitSyncService


class ServiceContainer:
    def __init__(
        self,
        node_code,
        ip_address,
        geo_location,
        longitude,
        latitude,
        cloud_provider,
        run_role,
        server_addr,
    ):
        # 1. 初始化 Context (数据核心)
        self.context = NodeContext(
            node_code=node_code,
            ip_address=ip_address,
            geo_location=geo_location,
            longitude=longitude,
            latitude=latitude,
            cloud_provider=cloud_provider,
            run_role=run_role,
        )
        self.tor_runtime_factory = TorRuntimeFactory()

        # 2. 初始化 Dispatcher (控制核心)
        self.dispatcher = CommandDispatcher(self.context)

        # 3. 初始化 gRPC (网络核心)
        self.grpc_handler = GrpcHandler(server_addr, self.context, self.dispatcher)

        # 4. 初始化 Reporter (服务核心)
        self.reporter = StateReporter(self.context, self.grpc_handler)

        self.tun_bridge_service = TunBridgeService(self.context)

        # Services
        self.node_service = NodeService(self.context, self.reporter)
        self.link_service = LinkService(
            self.context, self.reporter, tun_bridge_service=self.tun_bridge_service
        )
        self.tun_bridge_service.set_link_service(self.link_service)
        self.relay_service = RelayService(
            self.context,
            self.reporter,
            self.tor_runtime_factory,
            tun_bridge_service=self.tun_bridge_service,
            link_service=self.link_service,
        )
        self.init_sync_service = NodeInitSyncService(
            self.context,
            self.reporter,
            self.node_service,
            self.relay_service,
            self.link_service,
        )
        self.grpc_handler.set_init_sync_service(self.init_sync_service)
        
        # 5. 解决循环依赖：注入 Reporter 到 Dispatcher
        self.dispatcher.set_reporter(self.reporter)
        self.dispatcher.set_relay_service(self.relay_service)
        self.dispatcher.set_node_service(self.node_service)
        self.dispatcher.set_link_service(self.link_service)
        self.dispatcher.set_tun_bridge_service(self.tun_bridge_service)
        self.dispatcher._check_init()
