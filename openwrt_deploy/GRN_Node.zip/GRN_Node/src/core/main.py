import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


from core.base_node import AnonymousCommer
from core.open_wrt.client_node import ClientAccesser
from core.vps.vps_node import VpsDispatcher

from utils.cli import parse_args

import utils.logger
import asyncio
import signal





def main() -> None:
    """程序入口，启动并运行主循环。
    """
    utils.logger.setup_logging("INFO")
    args = parse_args()

    args.role = "OpenWrt"
    print (args.role)

    try:
        if args.role == "VPS":
            anonymous_commer = VpsDispatcher("",
                                             server_addr=args.server_addr,
                                             ip_addr=args.address,
                                             geo_location=args.geo_location,
                                             cloud_provider=args.cloud_provider,
                                             run_mode=args.mode)
        else:
            anonymous_commer = ClientAccesser("",
                                              server_addr=args.server_addr,
                                              ip_addr=args.address,
                                              geo_location=args.geo_location,
                                              cloud_provider=args.cloud_provider,
                                              run_mode=args.mode)
            asyncio.run(anonymous_commer.run())
    except KeyboardInterrupt:
        print("程序终止")


if __name__ == '__main__':
    main()