import asyncio
import json
import os
import pkgutil
import time
import utils.logger
from typing import Any, Optional

from grpc import aio, ssl_channel_credentials
from grpc._cython import cygrpc
from generated import vps_management_pb2, vps_management_pb2_grpc  # type: ignore
from core.node_context import NodeContext
from config.config import GrpcConfig


class GrpcHandler:

    def __init__(self, server_addr: str, context: NodeContext, command_dispatcher):
        self.server_addr = server_addr
        self.context = context
        self.command_dispatcher: Any = command_dispatcher
        self.logger = utils.logger.get_logger(f"{self.__class__.__name__}")
        self.channel = None
        self.stub = None
        self.is_running = False

        self.response_queue: asyncio.Queue = asyncio.Queue()
        self.cancel_event = asyncio.Event()

        self.heartbeat_task = None
        self.response_task = None
        self.init_sync_service = None

        self._stored_init_kwargs: dict[str, Any] = {"tls_enable": False}
        self._stream_write_lock: Optional[asyncio.Lock] = None

    def set_init_sync_service(self, init_sync_service) -> None:
        self.init_sync_service = init_sync_service

    @staticmethod
    def _normalize_pem_path(pem_file_path: str) -> str:
        return pem_file_path.strip().lstrip("./").replace("\\", "/")

    @staticmethod
    def _host_from_target(server_addr: str) -> str:
        host = server_addr.rsplit(":", 1)[0]
        if host.startswith("[") and host.endswith("]"):
            return host[1:-1]
        return host

    def get_pem_data(self, pem_file_path: Optional[str] = None) -> Optional[bytes]:
        """读取 PEM 文件，优先文件系统路径，其次包内资源。"""
        if not pem_file_path or not str(pem_file_path).strip():
            self.logger.warning("未指定 PEM 文件路径（pem_file_path 为空）")
            return None

        raw_path = str(pem_file_path).strip()
        normalized = self._normalize_pem_path(raw_path)
        module_dir = os.path.dirname(os.path.abspath(__file__))
        src_dir = os.path.dirname(module_dir)

        candidate_paths = [
            raw_path,
            normalized,
            os.path.join(module_dir, normalized),
            os.path.join(src_dir, normalized),
            os.path.join(os.getcwd(), normalized),
        ]
        seen_paths: set[str] = set()
        for candidate in candidate_paths:
            abs_candidate = os.path.abspath(candidate)
            if abs_candidate in seen_paths:
                continue
            seen_paths.add(abs_candidate)
            if os.path.isfile(abs_candidate):
                with open(abs_candidate, "rb") as pem_file:
                    pem_data = pem_file.read()
                self.logger.info(
                    f"成功读取 PEM 文件，路径：{abs_candidate}，数据长度：{len(pem_data)} 字节"
                )
                return pem_data

        resource_name = normalized
        if resource_name.startswith("core/"):
            resource_name = resource_name[len("core/") :]
        for package_name in ("core", __name__):
            try:
                pem_data = pkgutil.get_data(package_name, resource_name)
            except Exception as exc:
                self.logger.debug(f"包内读取 PEM 失败 package={package_name}: {exc}")
                pem_data = None
            if pem_data:
                self.logger.info(
                    f"成功读取包内 PEM 资源 package={package_name}, "
                    f"resource={resource_name}，数据长度：{len(pem_data)} 字节"
                )
                return pem_data

        raise FileNotFoundError(f"未找到 PEM 文件：{raw_path}")

    def _build_keepalive_options(self) -> tuple[tuple[str, int | bool], ...]:
        return (
            ("grpc.keepalive_time_ms", 600000),
            ("grpc.keepalive_timeout_ms", 10000),
            ("grpc.keepalive_permit_without_calls", True),
            ("grpc.http2.max_pings_without_data", 0),
            ("grpc.http2.min_time_between_pings_ms", 60000),
            ("grpc.http2.min_ping_interval_without_data_ms", 300000),
            ("grpc.http2.max_ping_strikes", 3),
        )

    def _apply_tls_hostname_options(
        self,
        channel_options: list[tuple[str, Any]],
        verify_server_hostname: bool,
        server_host_override: Optional[str],
    ) -> None:
        override = (server_host_override or "").strip()
        if not verify_server_hostname:
            if not override:
                override = (GrpcConfig.SERVER_HOST_OVERRIDE or "").strip()
            if not override:
                override = self._host_from_target(self.server_addr)
            channel_options.append(("grpc.ssl_target_name_override", override))
            self.logger.info(
                f"关闭严格主机名校验，使用 ssl_target_name_override={override}"
            )
            return

        if override:
            channel_options.append(("grpc.ssl_target_name_override", self._host_from_target(override)))
            self.logger.info(f"启用服务端主机名覆盖：{override}")
        self.logger.info("服务端主机名验证：开启")

    async def initialize(
        self,
        tls_enable: bool = False,
        ca_cert_path: Optional[str] = None,
        private_key_path: Optional[str] = None,
        cert_chain_path: Optional[str] = None,
        verify_server_hostname: Optional[bool] = None,
        server_host_override: Optional[str] = None,
    ) -> None:
        self._stored_init_kwargs = {
            "tls_enable": tls_enable,
            "ca_cert_path": ca_cert_path,
            "private_key_path": private_key_path,
            "cert_chain_path": cert_chain_path,
            "verify_server_hostname": verify_server_hostname,
            "server_host_override": server_host_override,
        }

        keepalive_options = self._build_keepalive_options()
        verify_hostname = (
            GrpcConfig.DEFAULT_VERIFY_HOSTNAME
            if verify_server_hostname is None
            else verify_server_hostname
        )

        if tls_enable:
            root_certs = None
            private_key = None
            cert_chain = None

            try:
                if ca_cert_path:
                    root_certs = self.get_pem_data(ca_cert_path)
                    self.logger.info(f"加载 CA 证书成功，路径：{ca_cert_path}")
                else:
                    self.logger.info("未指定 CA 证书路径，使用系统根 CA 验证")
            except FileNotFoundError as exc:
                raise RuntimeError("初始化 gRPC 通道失败：CA 证书加载失败") from exc

            has_private_key = bool(private_key_path)
            has_cert_chain = bool(cert_chain_path)
            if has_private_key ^ has_cert_chain:
                raise RuntimeError(
                    "初始化 gRPC 通道失败：双向 TLS 需要同时提供 client key 与 cert chain"
                )

            try:
                if private_key_path:
                    private_key = self.get_pem_data(private_key_path)
                    self.logger.info(f"加载客户端私钥成功，路径：{private_key_path}")
                if cert_chain_path:
                    cert_chain = self.get_pem_data(cert_chain_path)
                    self.logger.info(f"加载客户端证书链成功，路径：{cert_chain_path}")
            except FileNotFoundError as exc:
                raise RuntimeError("初始化 gRPC 通道失败：客户端证书加载失败") from exc

            try:
                channel_credentials = ssl_channel_credentials(
                    root_certificates=root_certs,
                    private_key=private_key,
                    certificate_chain=cert_chain,
                )
            except Exception as exc:
                raise RuntimeError("初始化 gRPC 通道失败：TLS 凭证构建失败") from exc

            channel_options = list(keepalive_options)
            self._apply_tls_hostname_options(
                channel_options,
                verify_hostname,
                server_host_override,
            )

            try:
                self.channel = aio.secure_channel(
                    target=self.server_addr,
                    credentials=channel_credentials,
                    options=channel_options,
                )
            except Exception as exc:
                raise RuntimeError("初始化 gRPC 通道失败：创建加密通道失败") from exc
        else:
            self.channel = aio.insecure_channel(
                target=self.server_addr,
                options=keepalive_options,
            )
            self.logger.info("使用非加密 gRPC 通道（TLS 禁用）")

        try:
            self.stub = vps_management_pb2_grpc.VpsManagementServiceStub(self.channel)
            await asyncio.wait_for(
                self.channel.channel_ready(),
                timeout=GrpcConfig.CHANNEL_READY_TIMEOUT_SEC,
            )
            self.logger.info(
                f"gRPC 通道初始化完成: {self.server_addr}（TLS：{'开启' if tls_enable else '关闭'}）"
            )
        except asyncio.TimeoutError as exc:
            raise RuntimeError(
                f"初始化 gRPC 通道失败：{GrpcConfig.CHANNEL_READY_TIMEOUT_SEC}s 内未就绪"
            ) from exc
        except Exception as exc:
            raise RuntimeError("初始化 gRPC 通道失败：创建 Stub 或等待就绪失败") from exc

    async def initialize_from_config(self, tls_enable: bool = False) -> None:
        """按 GrpcConfig 默认值初始化 gRPC 通道。"""
        if tls_enable:
            await self.initialize(
                tls_enable=True,
                ca_cert_path=GrpcConfig.DEFAULT_CA_CERT_PATH,
                private_key_path=None,
                cert_chain_path=None,
                verify_server_hostname=GrpcConfig.DEFAULT_VERIFY_HOSTNAME,
                server_host_override=GrpcConfig.SERVER_HOST_OVERRIDE,
            )
            return

        await self.initialize(tls_enable=False)

    async def _close_channel_only(self) -> None:
        if self.channel:
            try:
                await self.channel.close()
            except Exception as exc:
                self.logger.warning(f"关闭 gRPC channel 时发生异常: {exc}")
        self.channel = None
        self.stub = None

    async def _reset_channel(self) -> None:
        self.logger.warning("连续流连接失败，重建 gRPC channel...")
        await self._close_channel_only()
        await self.initialize(**self._stored_init_kwargs)
        await self.register_node()

    async def close(self) -> None:
        self.logger.info("关闭 gRPC 处理器...")
        self.is_running = False
        self.cancel_event.set()

        tasks_to_cancel = []
        if self.heartbeat_task:
            tasks_to_cancel.append(self.heartbeat_task)
        if self.response_task:
            tasks_to_cancel.append(self.response_task)

        if tasks_to_cancel:
            for task in tasks_to_cancel:
                task.cancel()
            try:
                await asyncio.gather(*tasks_to_cancel, return_exceptions=True)
            except asyncio.CancelledError:
                self.logger.info("任务已被取消")
            except Exception as exc:
                self.logger.warning(f"任务处理过程中发生非取消异常: {exc}")
            self.heartbeat_task = None
            self.response_task = None

        await self._close_channel_only()
        self.logger.info("gRPC 处理器已关闭")

    async def register_node(self) -> None:
        """注册节点信息"""
        retry_count = 0
        max_retry = 5
        while retry_count < max_retry:
            try:
                request = vps_management_pb2.PushNodeInfoRequest(  # type: ignore[attr-defined]
                    node=self.context.node.to_proto()  # type: ignore[attr-defined]
                )
                response = await self.stub.PushNodeInfo(request)  # type: ignore[attr-defined]
                if response.success:
                    self.logger.info(f"节点注册成功: {response.message}")
                    return
                self.logger.warning(f"节点注册失败: {response.message}")
            except Exception as exc:
                self.logger.error(f"注册异常（第 {retry_count + 1} 次）: {exc}")
            retry_count += 1
            await asyncio.sleep(GrpcConfig.RETRY_INTERVAL)
        raise RuntimeError("节点注册重试耗尽")

    async def _write_to_stream(self, stream, message) -> None:
        if self._stream_write_lock is None:
            self._stream_write_lock = asyncio.Lock()
        async with self._stream_write_lock:
            await stream.write(message)

    async def _heartbeat_sender(self, stream) -> None:
        while self.is_running and not self.cancel_event.is_set():
            try:
                heartbeat_msg = vps_management_pb2.ClientMessage(  # type: ignore[attr-defined]
                    node_code=self.context.node_code,
                    ip_address=self.context.ip_address,
                    timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
                    message_type="HEARTBEAT",
                    message=f"{self.context.node_code} 心跳信息",
                    type=vps_management_pb2.ClientMessageType.HEARTBEAT,  # type: ignore[attr-defined]
                )
                await self._write_to_stream(stream, heartbeat_msg)
                self.logger.info(f"发送心跳信息: {self.context.node_code} 心跳信息")
            except Exception as exc:
                self.logger.error(f"发送心跳时出错: {exc}")
                break

            await asyncio.sleep(GrpcConfig.HEARTBEAT_INTERVAL)

    async def _response_sender(self, stream) -> None:
        while self.is_running and not self.cancel_event.is_set():
            try:
                response = await self.response_queue.get()
                await self._write_to_stream(stream, response)
                self.logger.info(f"发送命令响应:\n{response}")
            except Exception as exc:
                self.logger.error(f"发送响应时出错: {exc}")
                break

    async def _read_command(self, stream):
        read_timeout = GrpcConfig.STREAM_READ_TIMEOUT_SEC
        if read_timeout and read_timeout > 0:
            return await asyncio.wait_for(stream.read(), timeout=read_timeout)
        return await stream.read()

    async def _process_command(self, command) -> None:
        self.logger.info(f"收到命令:\n{command}")
        command_id = command.command_id
        self.logger.info(f"命令ID: {command_id}")

        try:
            msg_data = json.loads(command.message)
            response = await self.command_dispatcher.dispatch(
                command.command_type, msg_data, command_id
            )
            if response:
                await self.response_queue.put(response)
        except json.JSONDecodeError:
            err_resp = self._create_error_response(
                command_id, "消息格式错误，无法解析JSON"
            )
            await self.response_queue.put(err_resp)
        except Exception as exc:
            err_resp = self._create_error_response(command_id, f"处理失败: {exc}")
            await self.response_queue.put(err_resp)

    def _create_error_response(self, command_id, message):
        return vps_management_pb2.ClientMessage(  # type: ignore[attr-defined]
            node_code=self.context.node_code,
            relay_codes=[relay.relay_code for relay in self.context.relays.values()],
            ip_address=self.context.ip_address,
            timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
            message_type="GENERAL_RESPONSE",
            success=False,
            message=f"命令{command_id}-{message}",
            command_id=command_id,
        )

    async def _connect_stream(self):
        stream = self.stub.Connect2M()
        relay_codes = [relay.relay_code for relay in self.context.relays.values()]
        init_msg = vps_management_pb2.ClientMessage(
            node_code=self.context.node_code,
            relay_codes=relay_codes,
            ip_address=self.context.ip_address,
            timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
            message_type="INIT_CONNECT",
        )
        await self._write_to_stream(stream, init_msg)
        self.logger.info("发送初始化连接消息")

        try:
            await self.register_node()
        except Exception as exc:
            self.logger.error(f"流重建后节点注册失败: {exc}")

        if self.init_sync_service:
            try:
                await self.init_sync_service.sync_after_reconnect(self.stub)
            except Exception as exc:
                self.logger.error(f"InitNodeSync 对账异常: {exc}")

        return stream

    async def _cleanup_stream_tasks(self, stream) -> None:
        if self.heartbeat_task:
            self.heartbeat_task.cancel()
            try:
                await self.heartbeat_task
            except asyncio.CancelledError:
                pass
            self.heartbeat_task = None
        if self.response_task:
            self.response_task.cancel()
            try:
                await self.response_task
            except asyncio.CancelledError:
                pass
            self.response_task = None

        try:
            await stream.done_writing()
        except Exception as exc:
            self.logger.warning(f"关闭当前流时出错: {exc}")

    async def _await_reconnect_backoff(self, consecutive_failures: int) -> None:
        backoff = min(
            GrpcConfig.RETRY_INTERVAL * (2 ** max(consecutive_failures - 1, 0)),
            GrpcConfig.RECONNECT_MAX_BACKOFF_SEC,
        )
        self.logger.info(f"等待 {backoff} 秒后尝试重建连接...")
        await asyncio.sleep(backoff)

    async def handle_commands(self) -> None:
        """异步处理来自管理服务器的命令流，并发送响应或心跳。"""
        self.is_running = True
        self.cancel_event.clear()
        consecutive_failures = 0

        while self.is_running and not self.cancel_event.is_set():
            stream = None
            should_rebuild_channel = False
            try:
                self._stream_write_lock = asyncio.Lock()
                stream = await self._connect_stream()
                consecutive_failures = 0

                self.heartbeat_task = asyncio.create_task(self._heartbeat_sender(stream))
                self.response_task = asyncio.create_task(self._response_sender(stream))

                while self.is_running and not self.cancel_event.is_set():
                    try:
                        command = await self._read_command(stream)

                        if command is None or command is cygrpc.EOF:
                            self.logger.warning(
                                "服务端关闭了通道，底层 read 收到 EOF，将重建流..."
                            )
                            break

                        asyncio.create_task(self._process_command(command))

                    except asyncio.TimeoutError:
                        self.logger.warning("read 超时，准备重连")
                        break
                    except Exception as exc:
                        self.logger.error(f"命令读取异常: {exc}")
                        break

            except Exception as exc:
                consecutive_failures += 1
                self.logger.error(f"创建或使用流时出错: {exc}")
                should_rebuild_channel = (
                    consecutive_failures >= GrpcConfig.CHANNEL_REBUILD_AFTER_FAILURES
                )
            finally:
                if stream is not None:
                    await self._cleanup_stream_tasks(stream)

            if not self.is_running or self.cancel_event.is_set():
                break

            if should_rebuild_channel:
                try:
                    await self._reset_channel()
                    consecutive_failures = 0
                except Exception as reset_exc:
                    self.logger.error(f"重建 gRPC channel 失败: {reset_exc}")

            await self._await_reconnect_backoff(max(consecutive_failures, 1))

        self.logger.info("退出命令处理循环")
        await self.close()
