import socket
import asyncio
import os
import json
import time
import threading
import utils.logger
import platform
import errno

from typing import Optional, List, Dict, Union, Any
from config.config import LocalServiceConfig
from core.grpc_handler import GrpcHandler
from models.user import LocalMsgType
from models.user import UserMsg



class Connection:
    def __init__(self, conn_id: int, conn_socket: socket.socket, addr: str):
        self.conn_id = conn_id
        self.conn_socket = conn_socket
        self.addr = addr
        self.connected_at = time.time()
        self.is_closed = False
        self.logger = utils.logger.get_logger("LocalIpcService-Connection")
        self.socket_valid = True

    async def handle(self):
        """异步处理客户端"""
        try:
            self.conn_socket.setblocking(False)  # 设为非阻塞，避免线程卡死
            if self.conn_socket.family == socket.AF_INET:  # TCP Socket（Windows/Linux TCP）
                self.conn_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError as e:
            self.logger.error(f"客户端 {self.conn_id} 初始化Socket失败: {e}", exc_info=True)
            self.socket_valid = False
            self.close()
            return
        
        self.logger.info(f"客户端 {self.conn_id} (地址: {self.addr}) 开始处理消息")

        try:
            while not self.is_closed and self.socket_valid:
                if not self.is_socket_alive():
                    self.logger.warning(f"客户端 {self.conn_id} Socket已失效，退出处理循环")
                    break

                try:
                    # 用asyncio.wait_for包裹，避免无限阻塞
                    data = await asyncio.wait_for(
                        asyncio.to_thread(self.conn_socket.recv, LocalServiceConfig.DEFAULT_MAX_MSG_LEN),
                        timeout=1.0  # 1秒超时，让出事件循环
                    )

                except asyncio.TimeoutError:
                    continue  # 超时继续，不退出循环

                except BlockingIOError:
                    await asyncio.sleep(0.001)
                    continue

                except asyncio.CancelledError:
                    self.logger.info(f"客户端 {self.conn_id} 处理任务被取消")
                    break  # 任务取消时直接退出循环

                except OSError as e:
                    # 跨平台判断：错误码匹配 或 错误信息包含关键词
                    is_bad_fd = (
                        e.errno == errno.EBADF 
                        or "bad file descriptor" in str(e).lower()
                        or "invalid handle" in str(e).lower()  # Windows下的关键词
                    )
                    if is_bad_fd:
                        self.logger.info(f"客户端 {self.conn_id} Socket已关闭（正常退出）")
                        self._socket_valid = False
                        break
                    else:
                        self.logger.error(f"客户端 {self.conn_id} (地址: {self.addr}) 接收消息失败: {e}", exc_info=True)
                        break

                except Exception as e:
                    self.logger.error(f"客户端 {self.conn_id} (地址: {self.addr}) 接收消息失败: {e}", exc_info=True)
                    break

                if not data:
                    self.logger.info(f"客户端 {self.conn_id} (地址: {self.addr}) 主动关闭连接")
                    break

                msg = data.decode('utf-8', errors='replace')
                self.logger.info(f"客户端 {self.conn_id} (地址: {self.addr}) 收到消息: {msg[:100]}")
                
                self.process_request(msg)

                # 发送响应（非阻塞+超时）
                try:
                    response = "Hello client, I'm server.".encode('utf-8')
                    sent = 0
                    while sent < len(response) and not self.is_closed and self.socket_valid:
                        if not self.is_socket_alive():
                            break
                        # 捕获send返回None的情况
                        send_result = await asyncio.wait_for(
                            asyncio.to_thread(self.conn_socket.send, response[sent:]),
                            timeout=1.0
                        )
                        # 如果send返回None（例如：Mock场景），默认按发送全部字节处理
                        if send_result is None:
                            sent = len(response)  # 直接标记发送完成
                        else:
                            sent += send_result
                    self.logger.info(f"客户端 {self.conn_id} (地址: {self.addr}) 响应发送完成")
                except Exception as e:
                    self.logger.error(f"客户端 {self.conn_id} (地址: {self.addr}) 发送响应失败: {e}", exc_info=True)
                    break

        except ConnectionResetError:
            self.logger.info(f"客户端 {self.conn_id} (地址: {self.addr}) 连接被重置")
        except Exception as e:
            self.logger.error(f"客户端 {self.conn_id} (地址: {self.addr}) 处理异常: {e}", exc_info=True)
        finally:
            self.close()

    def is_socket_alive(self) -> bool:
        """检查Socket是否存活（Linux/Unix专用）"""
        if not self.socket_valid or self.is_closed:
            return False
        try:
            # 通过getsockopt检查Socket状态（Linux/Unix）
            if platform.system() != "Windows":
                self.conn_socket.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
            return True
        except OSError:
            return False


    def process_request(self, msg: str):
        """处理请求"""
        try:  # 包裹JSON解析逻辑，避免崩溃
            parsed_data = json.loads(msg)
            user_msg = UserMsg(parsed_data['msg_type'], parsed_data['data'])
            self.logger.info(f"客户端 {self.conn_id} 消息解析成功: parsed_data={parsed_data}, user_msg={user_msg}")

            match user_msg.type:
                case LocalMsgType.MT_UPDATE_CONFIG:
                    self.logger.debug(f"客户端 {self.conn_id} 处理更新配置请求")
                case LocalMsgType.MT_SWITCH_LINK:
                    self.logger.debug(f"客户端 {self.conn_id} 处理切换链路请求")
                case LocalMsgType.MT_ACCESS_STATUS:
                    self.logger.debug(f"客户端 {self.conn_id} 处理状态查询请求")
                case _:  # 新增：处理未知消息类型
                    self.logger.warning(f"客户端 {self.conn_id} 收到未知消息类型: {user_msg.type}")
        except json.JSONDecodeError as e:
            self.logger.error(f"客户端 {self.conn_id} JSON解析失败: {e}, 原始消息: {msg}")
        except KeyError as e:
            self.logger.error(f"客户端 {self.conn_id} 消息格式错误（缺少字段）: {e}, 原始消息: {msg}")
        except Exception as e:
            self.logger.error(f"客户端 {self.conn_id} 处理请求失败: {e}", exc_info=True)

            
    def close(self):
        """关闭连接"""
        if self.is_closed:  # 防止重复关闭
            return
        self.is_closed = True
        self.socket_valid = False

        try:
            # Windows非阻塞Socket调用shutdown会抛OSError，仅在Unix下执行
            if not platform.system() == "Windows":
                try:
                    self.conn_socket.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass  # 忽略shutdown失败（可能已关闭）

            self.conn_socket.close()
            self.logger.info(f"客户端 {self.conn_id} 连接已正常关闭")
        except OSError as e:
            # 忽略Windows非阻塞Socket的shutdown/close异常
            if platform.system() == "Windows" and "bad file descriptor" in str(e).lower():
                self.logger.debug(f"客户端 {self.conn_id} Windows Socket已关闭（忽略异常）: {e}")
            else:
                self.logger.error(f"客户端 {self.conn_id} 关闭连接失败: {e}")
        except Exception as e:
            self.logger.error(f"客户端 {self.conn_id} 关闭连接异常: {e}", exc_info=True)


class LocalIpcServer:
    def __init__(self):
        self.server_socket = None
        self.conn_id_counter = 0
        self.connections: Dict[int, Connection] = {}
        self.running = False
        self.lock = threading.Lock()  # 添加线程锁保护连接资源
        self.logger = utils.logger.get_logger("LocalIpcServer")
        self.is_windows = platform.system() == "Windows"
        self.windows_port = 0
        self.accept_task: Optional[asyncio.Task] = None
    
    async def start_server(self) -> None:
        """初始化 local ipc service"""
        self.logger.info(f"⏳ 开始启动 local ipc server 服务...")

        try:
            if self.is_windows:
                # Windows平台：使用TCP Socket (127.0.0.1 + 随机端口)
                self.logger.info(f"⏳ Windows平台，使用TCP Socket，绑定127.0.0.1:0...")
                self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                # 绑定到127.0.0.1的随机端口
                self.server_socket.bind(("127.0.0.1", 0))
                # 获取实际分配的端口
                self.windows_port = self.server_socket.getsockname()[1]
                self.logger.info(f"✅ Windows TCP Socket绑定成功，端口: {self.windows_port}")
            else:
                # Linux/Mac平台：使用Unix Domain Socket
                self.logger.info(f"⏳ 开始监听 local ipc server socket, socket路径:{LocalServiceConfig.DEFAULT_LOCAL_SOCKET_PATH}...")
                # 清理已存在的socket文件
                if os.path.exists(LocalServiceConfig.DEFAULT_LOCAL_SOCKET_PATH):
                    os.remove(LocalServiceConfig.DEFAULT_LOCAL_SOCKET_PATH)
                
                self.server_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                self.server_socket.bind(LocalServiceConfig.DEFAULT_LOCAL_SOCKET_PATH)
                os.chmod(LocalServiceConfig.DEFAULT_LOCAL_SOCKET_PATH, 0o666)  # 设置文件权限

            # 通用监听逻辑
            self.server_socket.listen(5)
            self.server_socket.setblocking(False)  # 设为非阻塞，避免accept卡死
            self.running = True
            self.logger.info("✅ local ipc server 启动成功，开始监听连接...")

            # 2. 异步接收连接（非阻塞循环）
            self.accept_task = asyncio.create_task(self.accept_connections())

        except Exception as e:
            self.logger.error(f"启动服务器失败: {e}", exc_info=True)
            self.running = False
            raise


    async def accept_connections(self):
        """异步接收连接（单独任务，避免阻塞主循环）"""
        self.logger.info("✅ accept_connections任务启动")
        empty_poll_count = 0  # 空轮询计数器
        while self.running:
            try:
                # 用wait_for包裹accept，避免卡死
                conn_socket, addr = await asyncio.wait_for(
                    asyncio.to_thread(self.server_socket.accept),
                    timeout=0.5  # 0.5秒超时，让出事件循环
                )
                self.logger.info(f"收到新连接: {addr}")

                with self.lock:
                    self.conn_id_counter += 1
                    conn_id = self.conn_id_counter
                    conn = Connection(conn_id, conn_socket, addr)
                    self.connections[conn_id] = conn

                # 立即调度handle任务，不阻塞accept
                asyncio.create_task(conn.handle())

            except asyncio.TimeoutError:
                continue  # 超时继续，不退出

            except asyncio.CancelledError:
                self.logger.debug(f"⏳ local ipc server服务器任务被取消")
                break

            except (BlockingIOError, InterruptedError, ConnectionAbortedError):
                empty_poll_count += 1
                # 每100次空轮询才输出一次日志，减少刷屏
                if empty_poll_count % 100 == 0:
                    self.logger.debug(f"⏳ 暂无新连接（已空轮询{empty_poll_count}次），sleep 0.001秒")
                await asyncio.sleep(0.001)

            except OSError:
                if self.running:
                    self.logger.error(f"系统错误: {e}")
                await asyncio.sleep(0.001)

            except Exception as e:
                if self.running:
                    self.logger.error(f"接收连接失败: {e}", exc_info=True)

        self.logger.info("✅ accept_connections任务退出循环")


    async def stop_server(self):
        """停止服务器"""
        self.running = False
        self.logger.info("正在停止local ipc server服务器...")

        # 主动取消accept任务，避免等待超时
        if self.accept_task and not self.accept_task.done():
            self.accept_task.cancel()
            try:
                await self.accept_task  # 等待任务真正退出
                self.logger.info("✅ accept_task已取消")
            except asyncio.CancelledError:
                self.logger.info("✅ accept_task被取消（正常流程）")

        # 立即清理资源
        await self.cleanup()


    async def cleanup(self):
        """清理资源"""
        # 使用锁保护连接资源的访问
        with self.lock:
            # 关闭所有连接
            for conn_id, conn in list(self.connections.items()):
                conn.close()
            self.connections.clear()
        
        # 关闭服务器socket
        if self.server_socket:
            try:
                # 仅在非Windows或已建立连接时执行shutdown
                if not self.is_windows:
                    self.server_socket.shutdown(socket.SHUT_RDWR)
                self.server_socket.close()
                self.logger.info("✅ 服务器socket已关闭")
            except OSError as e:
                # 忽略Windows未连接时的shutdown错误
                if self.is_windows and "shutdown" in str(e).lower():
                    self.server_socket.close()
                    self.logger.info("✅ Windows socket已关闭（忽略shutdown错误）")
                else:
                    self.logger.error(f"关闭服务器socket失败: {e}")
            self.server_socket = None

        self.running = False
            
        # 删除socket文件
        if not self.is_windows and os.path.exists(LocalServiceConfig.DEFAULT_LOCAL_SOCKET_PATH):
            os.remove(LocalServiceConfig.DEFAULT_LOCAL_SOCKET_PATH)
        self.logger.info("local ipc server服务器资源已全部清理")


    def get_socket(self) -> socket:
        """获取local ipc server socket实例，如果未监听则抛出异常"""
        if self.server_socket is None:
            raise RuntimeError("socket未监听。请先调用 bind() 并确保监听成功。")
        return self.server_socket
    

    def get_listen_address(self) -> tuple[str, int] | str:
        """获取监听地址（跨平台）
        - Windows: (host, port)
        - Linux/Mac: socket文件路径
        """
        if not self.server_socket:
            raise RuntimeError("服务器未启动")
        if self.is_windows:
            return ("127.0.0.1", self.windows_port)
        else:
            return LocalServiceConfig.DEFAULT_LOCAL_SOCKET_PATH