import pytest
from pathlib import Path
from unittest.mock import MagicMock, AsyncMock
import sys
import os
import types

# Windows 上没有 fcntl；TUN 相关模块在 import 时会用到它。
# 在收集用例前注入占位模块，保证 pytest 在 Windows / Linux 都能导入。
if sys.platform == "win32" and "fcntl" not in sys.modules:
    fcntl_stub = types.ModuleType("fcntl")
    fcntl_stub.ioctl = lambda *args, **kwargs: b""
    sys.modules["fcntl"] = fcntl_stub

# 确保 src 目录在 python path 中
sys.path.append(os.path.join(os.path.dirname(__file__), '../src'))


def pytest_collection_modifyitems(config, items):
    """
    直接从收集结果中移除指定目录/文件的测试用例（强制生效）
    """
    # 定义要跳过的路径前缀
    skip_prefixes = [
        # "src/tests/test_models/",
        # "src/tests/test_utils/",
        # "src/tests/test_config/",
        # "src/tests/test_services/test_link_service.py",
        # "src/tests/test_services/test_node_service.py",
        # "src/tests/test_services/test_relay_service.py",
        # "src/tests/test_services/test_container_service.py",
        # "src/tests/test_services/test_controller_service.py",
        # "src/tests/test_observers",
        # "src/tests/test_commands",
        # "src/tests/test_core/open_wrt/test_local_ipc_openwrt.py",
        # "src/tests/test_core/open_wrt/test_node_openwrt.py",
        # "src/tests/test_core/vps",
        # "src/tests/test_core/test_base_node_core.py",
        # "src/tests/test_core/test_circuit_manager_core.py",
        # "src/tests/test_core/test_command_dispatcher_core.py",
        # "src/tests/test_core/test_container_core.py",
        # "src/tests/test_core/test_grpc_handler_core.py",
        # "src/tests/test_core/test_main_core.py",
        # "src/tests/test_core/test_node_context_core.py",
        # "src/tests/test_core/test_state_reporter_core.py",
        # "src/tests/test_core/test_stem_api_core.py",
        # "src/tests/test_core/test_tor_runtime_core.py"
    ]
    
    # 过滤掉需要跳过的用例
    filtered_items = []
    for item in items:
        # item.nodeid 是测试用例的路径（如 src/tests/test_models/test_circuit_model.py::test_circuit_to_dict）
        if not any(item.nodeid.startswith(prefix) for prefix in skip_prefixes):
            filtered_items.append(item)
    
    # 替换原有的测试用例列表
    items[:] = filtered_items
