from pathlib import Path

from config.config import SingBoxConfig
from services.transparent_proxy import (
    _replace_placeholder_uuid,
    _is_project_runtime_config,
    _extract_singbox_config_arg,
    _config_listen_endpoints,
    derive_server_addr,
    derive_server_addrs,
    derive_peer_addrs,
)


def test_replace_placeholder_uuid():
    data = {"uuid": "UUID", "nested": [{"id": "UUID"}], "keep": "x"}
    replaced = _replace_placeholder_uuid(data)
    assert replaced["uuid"] == SingBoxConfig.UUID
    assert replaced["nested"][0]["id"] == SingBoxConfig.UUID
    assert replaced["keep"] == "x"


def test_is_project_runtime_config(tmp_path, monkeypatch):
    monkeypatch.setattr(SingBoxConfig, "RUNTIME_CONFIG_DIR", str(tmp_path))
    runtime = tmp_path / "client_singbox.runtime.json"
    runtime.write_text("{}", encoding="utf-8")
    assert _is_project_runtime_config(runtime) is True
    other = tmp_path / "other.json"
    other.write_text("{}", encoding="utf-8")
    assert _is_project_runtime_config(other) is False


def test_extract_singbox_config_arg():
    binary = Path(SingBoxConfig.BINARY).name
    args = [binary, "run", "-c", "/tmp/cfg.json"]
    path = _extract_singbox_config_arg(args)
    assert path == Path("/tmp/cfg.json")
    assert _extract_singbox_config_arg(["echo", "hi"]) is None


def test_config_listen_endpoints():
    cfg = {
        "inbounds": [
            {"listen": "127.0.0.1", "listen_port": 11090},
            {"listen": "::", "listen_port": "11091"},
            {"no": "port"},
        ]
    }
    endpoints = _config_listen_endpoints(cfg)
    assert ("127.0.0.1", 11090) in endpoints
    assert ("::", 11091) in endpoints


def test_derive_server_and_peer_addrs():
    tunnels = [
        {"tun_addr_cidr": "10.0.1.1/24"},
        {"tun_addr_cidr": "10.0.2.1/24"},
        {"tun_addr_cidr": ""},
    ]
    assert derive_server_addrs(tunnels) == ["10.0.1.1", "10.0.2.1"]
    assert derive_server_addr(tunnels) == "10.0.1.1"
    assert derive_server_addrs([]) == []

    local = [
        {"tun_addr_cidr": "10.0.1.2/24"},
        {"tun_addr_cidr": "10.0.2.1/24"},
    ]
    assert derive_peer_addrs(local) == ["10.0.1.1", "10.0.2.2"]
    assert derive_peer_addrs([]) == []
