from pathlib import Path

from config.config import SingBoxConfig
from services.transparent_proxy import (
    SingBoxProxy,
    _replace_placeholder_uuid,
    _is_project_runtime_config,
    _extract_singbox_config_arg,
    _config_listen_endpoints,
    derive_server_addr,
    derive_server_addrs,
    derive_peer_addrs,
    set_client_proxy_role,
)


def test_replace_placeholder_uuid():
    data = {"uuid": "UUID", "nested": [{"id": "UUID"}], "keep": "x"}
    replaced = _replace_placeholder_uuid(data)
    assert replaced["uuid"] == SingBoxConfig.UUID
    assert replaced["nested"][0]["id"] == SingBoxConfig.UUID
    assert replaced["keep"] == "x"


def test_is_project_runtime_config(tmp_path, monkeypatch):
    monkeypatch.setattr(SingBoxConfig, "RUNTIME_CONFIG_DIR", str(tmp_path))
    runtime = tmp_path / "client_singbox.runtime.json"
    runtime.write_text("{}", encoding="utf-8")
    assert _is_project_runtime_config(runtime) is True
    other = tmp_path / "other.json"
    other.write_text("{}", encoding="utf-8")
    assert _is_project_runtime_config(other) is False


def test_extract_singbox_config_arg():
    binary = Path(SingBoxConfig.BINARY).name
    args = [binary, "run", "-c", "/tmp/cfg.json"]
    path = _extract_singbox_config_arg(args)
    assert path == Path("/tmp/cfg.json")
    assert _extract_singbox_config_arg(["echo", "hi"]) is None


def test_config_listen_endpoints():
    cfg = {
        "inbounds": [
            {"listen": "127.0.0.1", "listen_port": 11090},
            {"listen": "::", "listen_port": "11091"},
            {"no": "port"},
        ]
    }
    endpoints = _config_listen_endpoints(cfg)
    assert ("127.0.0.1", 11090) in endpoints
    assert ("::", 11091) in endpoints


def test_derive_server_and_peer_addrs():
    tunnels = [
        {"tun_addr_cidr": "10.0.1.1/24"},
        {"tun_addr_cidr": "10.0.2.1/24"},
        {"tun_addr_cidr": ""},
    ]
    assert derive_server_addrs(tunnels) == ["10.0.1.1", "10.0.2.1"]
    assert derive_server_addr(tunnels) == "10.0.1.1"
    assert derive_server_addrs([]) == []

    local = [
        {"tun_addr_cidr": "10.0.1.2/24"},
        {"tun_addr_cidr": "10.0.2.1/24"},
    ]
    assert derive_peer_addrs(local) == ["10.0.1.1", "10.0.2.2"]
    assert derive_peer_addrs([]) == []


def _make_client_proxy(tmp_path, *, run_role: str):
    repo_template = (
        Path(__file__).resolve().parents[2] / "config" / "singbox" / "client_singbox.json"
    )
    template = tmp_path / "client.json"
    template.write_text(repo_template.read_text(encoding="utf-8"), encoding="utf-8")
    runtime = tmp_path / "runtime" / "client_singbox.runtime.json"
    return SingBoxProxy(
        "client",
        template,
        runtime,
        run_role=run_role,
    )


def test_build_client_config_openwrt_uses_inbound_sniff(tmp_path):
    proxy = _make_client_proxy(tmp_path, run_role="openwrt")
    config = proxy._build_client_config()
    inbound = config["inbounds"][0]
    assert inbound["sniff"] is True
    assert inbound["sniff_override_destination"] is True
    assert inbound["sniff_timeout"] == SingBoxConfig.CLIENT_SNIFF_TIMEOUT
    rules = (config.get("route") or {}).get("rules") or []
    assert not any(r.get("action") == "sniff" for r in rules if isinstance(r, dict))


def test_build_client_config_vps_uses_route_sniff(tmp_path):
    proxy = _make_client_proxy(tmp_path, run_role="vps")
    config = proxy._build_client_config()
    inbound = config["inbounds"][0]
    assert "sniff" not in inbound
    assert "sniff_override_destination" not in inbound
    assert "sniff_timeout" not in inbound
    rules = (config.get("route") or {}).get("rules") or []
    sniff_rules = [r for r in rules if isinstance(r, dict) and r.get("action") == "sniff"]
    assert len(sniff_rules) == 1
    assert sniff_rules[0]["inbound"] == SingBoxConfig.CLIENT_INBOUND_TAG
    assert sniff_rules[0]["timeout"] == SingBoxConfig.CLIENT_SNIFF_TIMEOUT
    assert config["route"]["final"] == SingBoxConfig.SELECTOR_TAG


def test_set_client_proxy_role_updates_module_defaults():
    set_client_proxy_role("openwrt")
    from services import transparent_proxy as tp

    assert tp._client_run_role == "openwrt"
    set_client_proxy_role("vps")
    assert tp._client_run_role == "vps"
