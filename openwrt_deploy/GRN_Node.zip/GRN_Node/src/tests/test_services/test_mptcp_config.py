from unittest.mock import MagicMock, patch

from services.mptcp_config import (
    MptcpEndpointInfo,
    ip_from_cidr,
    is_mptcp_enabled,
    show_endpoints,
    find_endpoints_by_dev,
    cleanup_endpoints_by_devs,
    try_set_scheduler,
    configure_scheduler,
)


def test_ip_from_cidr():
    assert ip_from_cidr("10.0.1.1/24") == "10.0.1.1"
    assert ip_from_cidr("10.0.1.1") == "10.0.1.1"


def test_is_mptcp_enabled():
    with patch("services.mptcp_config._run") as mock_run:
        mock_run.return_value = MagicMock(stdout="1\n")
        assert is_mptcp_enabled() is True
        mock_run.return_value = MagicMock(stdout="0\n")
        assert is_mptcp_enabled() is False


def test_show_endpoints_parse():
    stdout = "10.0.1.1 id 2 subflow dev tun1\n10.0.2.1 id 3 signal subflow dev tun2\n"
    with patch("services.mptcp_config._run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout=stdout)
        eps = show_endpoints()
    assert eps[0] == MptcpEndpointInfo(id=2, address="10.0.1.1", dev="tun1", flags="subflow")
    assert "signal" in eps[1].flags
    assert "subflow" in eps[1].flags
    assert eps[1].dev == "tun2"


def test_show_endpoints_error():
    with patch("services.mptcp_config._run") as mock_run:
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        assert show_endpoints() == []


def test_find_and_cleanup_endpoints():
    eps = [
        MptcpEndpointInfo(id=1, address="10.0.1.1", dev="tun1", flags="subflow"),
        MptcpEndpointInfo(id=2, address="10.0.2.1", dev="tun2", flags="signal"),
    ]
    with patch("services.mptcp_config.show_endpoints", return_value=eps), \
         patch("services.mptcp_config.delete_endpoint") as mock_del:
        found = find_endpoints_by_dev(["tun2"])
        assert found[0].id == 2
        removed = cleanup_endpoints_by_devs(["tun1", "tun2"])
        assert removed == 2
        assert mock_del.call_count == 2


def test_try_set_scheduler_and_configure():
    with patch("services.mptcp_config._run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        assert try_set_scheduler("roundrobin") is True
    with patch("services.mptcp_config._run") as mock_run:
        mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="no")
        assert try_set_scheduler("roundrobin") is False
    with patch("services.mptcp_config.try_load_scheduler_module", return_value=True), \
         patch("services.mptcp_config.try_set_scheduler", return_value=True):
        assert configure_scheduler("roundrobin") is True
