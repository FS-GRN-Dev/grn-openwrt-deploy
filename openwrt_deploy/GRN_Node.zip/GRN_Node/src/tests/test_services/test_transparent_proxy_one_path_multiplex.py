import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from config.config import SingBoxConfig
from services.transparent_proxy_one_path_multiplex import (
    PROXY_MODE_DIRECT,
    PROXY_MODE_MPTCP,
    PROXY_MODE_SOCKS,
    SINGBOX_OUT_DIRECT,
    SINGBOX_OUT_MPTCP,
    SINGBOX_OUT_SOCKS,
    SingBoxProxy,
    _config_listen_endpoints,
    _endpoint_conflicts,
    _extract_singbox_config_arg,
    _is_project_runtime_config,
    _iter_project_singbox_processes,
    _load_json_config,
    _load_runtime_listen_endpoints,
    _read_process_cmdline,
    _replace_placeholder_uuid,
    _repo_root,
    _write_json_config,
    derive_peer_addrs,
    derive_server_addr,
    derive_server_addrs,
    ensure_client_transparent_proxy,
    start_client_singbox_proxy,
    start_server_singbox_proxy,
    stop_client_proxy,
    switch_proxy_to_direct,
    switch_proxy_to_mptcp,
    switch_proxy_to_socks,
)
import services.transparent_proxy_one_path_multiplex as mux


CLIENT_TEMPLATE = {
    "log": {"level": "debug"},
    "experimental": {
        "clash_api": {"external_controller": "127.0.0.1:9090", "secret": "old"}
    },
    "inbounds": [
        {
            "type": "redirect",
            "tag": "redirect-in",
            "listen": "127.0.0.1",
            "listen_port": 1,
        }
    ],
    "outbounds": [
        {
            "type": "selector",
            "tag": "out-select",
            "outbounds": ["direct"],
            "default": "direct",
        },
        {"type": "direct", "tag": "direct"},
        {
            "type": "vless",
            "tag": "mptcp-tunnel",
            "server": "10.0.1.1",
            "server_port": 11091,
            "uuid": "UUID",
            "tcp_keep_alive": True,
            "tcp_keep_alive_interval": "10s",
        },
        {
            "type": "socks",
            "tag": "socks5",
            "server": "127.0.0.1",
            "server_port": 9050,
        },
    ],
}

SERVER_TEMPLATE = {
    "log": {"level": "debug"},
    "experimental": {"clash_api": {"external_controller": "127.0.0.1:9090"}},
    "inbounds": [
        {
            "type": "vless",
            "tag": "mptcp-path-1",
            "listen": "10.0.1.1",
            "listen_port": 11091,
            "tcp_keep_alive": True,
            "users": [{"uuid": "UUID"}],
        }
    ],
    "outbounds": [{"type": "direct", "tag": "direct"}],
}


@pytest.fixture(autouse=True)
def reset_client_proxy():
    mux._client_singbox_proxy = None
    yield
    mux._client_singbox_proxy = None


@pytest.fixture
def client_proxy(tmp_path):
    template = tmp_path / "client.json"
    template.write_text(json.dumps(CLIENT_TEMPLATE), encoding="utf-8")
    runtime = tmp_path / "runtime" / "client_singbox.runtime.json"
    # 默认按 OpenWrt 1.12 inbound sniff，兼容既有断言
    return SingBoxProxy(
        "client",
        template,
        runtime,
        run_role="openwrt",
    )


@pytest.fixture
def server_proxy(tmp_path):
    template = tmp_path / "server.json"
    template.write_text(json.dumps(SERVER_TEMPLATE), encoding="utf-8")
    runtime = tmp_path / "runtime" / "server_singbox.runtime.json"
    return SingBoxProxy("server", template, runtime)


def test_proxy_mode_constants():
    assert PROXY_MODE_DIRECT == "direct"
    assert PROXY_MODE_SOCKS == "socks"
    assert PROXY_MODE_MPTCP == "mptcp"
    assert SINGBOX_OUT_DIRECT == SingBoxConfig.DIRECT_OUTBOUND_TAG
    assert SINGBOX_OUT_SOCKS == SingBoxConfig.SOCKS_OUTBOUND_TAG
    assert SINGBOX_OUT_MPTCP == SingBoxConfig.MPTCP_OUTBOUND_TAG


def test_repo_root_points_to_project():
    root = _repo_root()
    assert (root / "src" / "services" / "transparent_proxy_one_path_multiplex.py").is_file()


def test_json_config_roundtrip(tmp_path):
    path = tmp_path / "nested" / "cfg.json"
    _write_json_config(path, {"a": 1, "uuid": "UUID"})
    loaded = _load_json_config(path)
    assert loaded["a"] == 1
    assert path.read_text(encoding="utf-8").endswith("\n")


def test_replace_placeholder_uuid():
    data = {"uuid": "UUID", "nested": [{"id": "UUID"}], "keep": "x"}
    replaced = _replace_placeholder_uuid(data)
    assert replaced["uuid"] == SingBoxConfig.UUID
    assert replaced["nested"][0]["id"] == SingBoxConfig.UUID
    assert replaced["keep"] == "x"


def test_is_project_runtime_config(tmp_path, monkeypatch):
    monkeypatch.setattr(SingBoxConfig, "RUNTIME_CONFIG_DIR", str(tmp_path))
    runtime = tmp_path / "client_singbox.runtime.json"
    runtime.write_text("{}", encoding="utf-8")
    assert _is_project_runtime_config(runtime) is True
    server = tmp_path / "server_singbox.2.runtime.json"
    server.write_text("{}", encoding="utf-8")
    assert _is_project_runtime_config(server) is True
    other = tmp_path / "other.json"
    other.write_text("{}", encoding="utf-8")
    assert _is_project_runtime_config(other) is False


def test_extract_singbox_config_arg():
    binary = Path(SingBoxConfig.BINARY).name
    assert _extract_singbox_config_arg([binary, "run", "-c", "/tmp/cfg.json"]) == Path(
        "/tmp/cfg.json"
    )
    assert _extract_singbox_config_arg([binary, "run", "--config", "/tmp/a.json"]) == Path(
        "/tmp/a.json"
    )
    assert _extract_singbox_config_arg([binary, "run", "-c=/tmp/b.json"]) == Path("/tmp/b.json")
    assert _extract_singbox_config_arg([binary, "run", "--config=/tmp/c.json"]) == Path(
        "/tmp/c.json"
    )
    assert _extract_singbox_config_arg(["echo", "hi"]) is None
    assert _extract_singbox_config_arg([binary, "version"]) is None


def test_read_process_cmdline_missing_proc():
    assert _read_process_cmdline(-1) == []


def test_iter_project_singbox_processes_without_proc():
    with patch("services.transparent_proxy_one_path_multiplex.Path") as mock_path:
        proc_dir = MagicMock()
        proc_dir.exists.return_value = False
        mock_path.return_value = proc_dir
        assert _iter_project_singbox_processes() == []


def test_config_listen_endpoints_includes_clash_api():
    cfg = {
        "inbounds": [
            {"listen": "127.0.0.1", "listen_port": 11090},
            {"listen": "::", "listen_port": "11091"},
            {"listen_port": "bad"},
        ],
        "experimental": {"clash_api": {"external_controller": "127.0.0.1:9090"}},
    }
    endpoints = _config_listen_endpoints(cfg)
    assert ("127.0.0.1", 11090) in endpoints
    assert ("::", 11091) in endpoints
    assert ("127.0.0.1", 9090) in endpoints


def test_endpoint_conflicts():
    assert _endpoint_conflicts({("127.0.0.1", 80)}, {("127.0.0.1", 80)}) is True
    assert _endpoint_conflicts({("0.0.0.0", 80)}, {("10.0.0.1", 80)}) is True
    assert _endpoint_conflicts({("10.0.0.1", 80)}, {("10.0.0.2", 80)}) is False
    assert _endpoint_conflicts({("10.0.0.1", 80)}, {("10.0.0.1", 81)}) is False


def test_load_runtime_listen_endpoints(tmp_path):
    good = tmp_path / "ok.json"
    _write_json_config(good, {"inbounds": [{"listen": "1.1.1.1", "listen_port": 9}]})
    assert ("1.1.1.1", 9) in _load_runtime_listen_endpoints(good)
    bad = tmp_path / "bad.json"
    bad.write_text("{not-json", encoding="utf-8")
    assert _load_runtime_listen_endpoints(bad) == set()
    assert _load_runtime_listen_endpoints(tmp_path / "missing.json") == set()


def test_derive_server_and_peer_addrs():
    tunnels = [
        {"tun_addr_cidr": "10.0.1.1/24"},
        {"tun_addr_cidr": "10.0.2.1/24"},
        {"tun_addr_cidr": ""},
    ]
    assert derive_server_addrs(tunnels) == ["10.0.1.1", "10.0.2.1"]
    assert derive_server_addr(tunnels) == "10.0.1.1"
    assert derive_server_addrs([]) == []
    assert derive_server_addr([]) == ""
    assert derive_server_addr([{"tun_addr_cidr": ""}]) == ""

    local = [
        {"tun_addr_cidr": "10.0.1.2/24"},
        {"tun_addr_cidr": "10.0.2.1/24"},
        {"tun_addr_cidr": "10.0.3.9/24"},
    ]
    assert derive_peer_addrs(local) == ["10.0.1.1", "10.0.2.2"]
    assert derive_peer_addrs([]) == []


def test_build_client_config_single_mptcp_path(client_proxy):
    client_proxy._server_addr = "10.9.9.9"
    client_proxy._server_port = 22000
    client_proxy._socks_host = "192.168.1.2"
    client_proxy._socks_port = 1080
    config = client_proxy._build_client_config()

    inbound = config["inbounds"][0]
    assert inbound["tag"] == SingBoxConfig.CLIENT_INBOUND_TAG
    assert inbound["listen"] == SingBoxConfig.CLIENT_LISTEN_HOST
    assert inbound["listen_port"] == SingBoxConfig.CLIENT_LISTEN_PORT
    assert inbound["sniff"] is True
    assert inbound["sniff_override_destination"] is True
    assert inbound["sniff_timeout"] == SingBoxConfig.CLIENT_SNIFF_TIMEOUT

    by_tag = {item["tag"]: item for item in config["outbounds"]}
    mptcp = by_tag[SINGBOX_OUT_MPTCP]
    assert mptcp["type"] == "vless"
    assert mptcp["server"] == "10.9.9.9"
    assert mptcp["server_port"] == 22000
    assert mptcp["tcp_multi_path"] is True
    assert "tcp_keep_alive" not in mptcp
    assert mptcp["uuid"] == SingBoxConfig.UUID

    socks = by_tag[SINGBOX_OUT_SOCKS]
    assert socks["server"] == "192.168.1.2"
    assert socks["server_port"] == 1080

    selector = by_tag[SingBoxConfig.SELECTOR_TAG]
    assert selector["outbounds"] == [
        SingBoxConfig.DIRECT_OUTBOUND_TAG,
        SingBoxConfig.MPTCP_OUTBOUND_TAG,
        SingBoxConfig.SOCKS_OUTBOUND_TAG,
    ]
    assert selector["default"] == SingBoxConfig.DIRECT_OUTBOUND_TAG
    assert config["experimental"]["clash_api"]["secret"] == SingBoxConfig.CLASH_API_SECRET


def test_build_server_config_generates_host_inbounds(server_proxy):
    config = server_proxy._build_server_config(
        listen_hosts=["10.0.1.1", "10.0.2.1", ""],
        listen_port=19001,
    )
    inbounds = config["inbounds"]
    assert [item["listen"] for item in inbounds] == ["10.0.1.1", "10.0.2.1"]
    assert [item["tag"] for item in inbounds] == [
        f"{SingBoxConfig.SERVER_INBOUND_TAG}1",
        f"{SingBoxConfig.SERVER_INBOUND_TAG}2",
    ]
    for inbound in inbounds:
        assert inbound["listen_port"] == 19001
        assert inbound["tcp_multi_path"] is True
        assert "tcp_keep_alive" not in inbound
        assert inbound["users"][0]["uuid"] == SingBoxConfig.UUID
    assert "experimental" not in config


def test_build_server_config_default_host(server_proxy):
    config = server_proxy._build_server_config(listen_hosts=[], listen_port=0)
    assert config["inbounds"][0]["listen"] == SingBoxConfig.SERVER_LISTEN_HOST
    assert config["inbounds"][0]["listen_port"] == SingBoxConfig.SERVER_LISTEN_PORT


def test_is_running_false_by_default(client_proxy):
    assert client_proxy.is_running is False


@pytest.mark.asyncio
async def test_stop_terminates_process(client_proxy):
    proc = MagicMock()
    proc.returncode = None
    proc.terminate = MagicMock()
    proc.kill = MagicMock()
    proc.wait = AsyncMock()
    client_proxy._proc = proc
    await client_proxy.stop()
    proc.terminate.assert_called_once()
    proc.wait.assert_awaited()
    assert client_proxy._proc is None


@pytest.mark.asyncio
async def test_stop_kills_after_timeout(client_proxy):
    proc = MagicMock()
    proc.returncode = None
    proc.terminate = MagicMock()
    proc.kill = MagicMock()
    proc.wait = AsyncMock(side_effect=[asyncio.TimeoutError(), None])
    client_proxy._proc = proc
    await client_proxy.stop()
    proc.kill.assert_called_once()


@pytest.mark.asyncio
async def test_switch_outbound_requires_running(client_proxy):
    with pytest.raises(RuntimeError, match="not running"):
        await client_proxy.switch_outbound(SINGBOX_OUT_DIRECT)


@pytest.mark.asyncio
async def test_clash_put_proxy_success(client_proxy):
    resp = MagicMock()
    resp.status = 204
    resp.__enter__.return_value = resp
    resp.__exit__.return_value = False
    with patch("services.transparent_proxy_one_path_multiplex.urllib.request.urlopen", return_value=resp):
        await client_proxy._clash_put_proxy("out-select", "direct")


@pytest.mark.asyncio
async def test_clash_put_proxy_http_error(client_proxy):
    resp = MagicMock()
    resp.status = 500
    resp.__enter__.return_value = resp
    resp.__exit__.return_value = False
    with patch("services.transparent_proxy_one_path_multiplex.urllib.request.urlopen", return_value=resp):
        with pytest.raises(RuntimeError, match="proxy switch failed"):
            await client_proxy._clash_put_proxy("out-select", "direct")


@pytest.mark.asyncio
async def test_start_client_calls_restart(client_proxy):
    client_proxy._restart = AsyncMock()
    await client_proxy.start_client(
        server_addr="10.0.1.1",
        server_port=11091,
        socks_host="127.0.0.1",
        socks_port=9050,
    )
    client_proxy._restart.assert_awaited_once()
    config = client_proxy._restart.await_args.args[0]
    by_tag = {item["tag"]: item for item in config["outbounds"]}
    assert by_tag[SINGBOX_OUT_MPTCP]["server"] == "10.0.1.1"


@pytest.mark.asyncio
async def test_start_server_calls_restart(server_proxy):
    server_proxy._restart = AsyncMock()
    await server_proxy.start_server(listen_hosts=["10.0.1.1"], listen_port=11091)
    server_proxy._restart.assert_awaited_once()
    config = server_proxy._restart.await_args.args[0]
    assert config["inbounds"][0]["listen"] == "10.0.1.1"


@pytest.mark.asyncio
async def test_restart_writes_runtime_and_starts_subprocess(client_proxy, tmp_path, monkeypatch):
    monkeypatch.setattr(SingBoxConfig, "LOG_DIR", str(tmp_path))
    proc = MagicMock()
    proc.returncode = None
    proc.stdout = None
    with patch.object(client_proxy, "stop", new=AsyncMock()), \
         patch.object(client_proxy, "_cleanup_conflicting_processes", new=AsyncMock()), \
         patch("services.transparent_proxy_one_path_multiplex.asyncio.create_subprocess_exec", new=AsyncMock(return_value=proc)), \
         patch("services.transparent_proxy_one_path_multiplex.asyncio.sleep", new=AsyncMock()):
        await client_proxy._restart({"ok": True})
    written = _load_json_config(client_proxy.runtime_path)
    assert written == {"ok": True}
    assert client_proxy._proc is proc


@pytest.mark.asyncio
async def test_restart_raises_on_early_exit(client_proxy, tmp_path):
    proc = MagicMock()
    proc.returncode = 1
    proc.stdout = None
    log_path = tmp_path / "client.log"
    log_path.write_text("fatal: bind failed\n", encoding="utf-8")
    with patch.object(client_proxy, "stop", new=AsyncMock()), \
         patch.object(client_proxy, "_cleanup_conflicting_processes", new=AsyncMock()), \
         patch.object(client_proxy, "_log_path", return_value=log_path), \
         patch("services.transparent_proxy_one_path_multiplex.asyncio.create_subprocess_exec", new=AsyncMock(return_value=proc)), \
         patch("services.transparent_proxy_one_path_multiplex.asyncio.sleep", new=AsyncMock()):
        with pytest.raises(RuntimeError, match="exited early"):
            await client_proxy._restart({"ok": True})


def test_tail_process_log(tmp_path):
    path = tmp_path / "p.log"
    path.write_text("a\nb\nc\n", encoding="utf-8")
    assert SingBoxProxy._tail_process_log(path, max_lines=2) == "b\nc"
    assert SingBoxProxy._tail_process_log(tmp_path / "missing.log") == ""


@pytest.mark.asyncio
async def test_cleanup_conflicting_processes_kills_same_runtime(client_proxy, tmp_path):
    runtime = client_proxy.runtime_path
    runtime.parent.mkdir(parents=True, exist_ok=True)
    _write_json_config(runtime, {"inbounds": [{"listen": "0.0.0.0", "listen_port": 11090}]})
    with patch(
        "services.transparent_proxy_one_path_multiplex._iter_project_singbox_processes",
        return_value=[(4242, runtime.resolve())],
    ), patch("services.transparent_proxy_one_path_multiplex.os.kill") as mock_kill, \
       patch("services.transparent_proxy_one_path_multiplex.asyncio.sleep", new=AsyncMock()), \
       patch("services.transparent_proxy_one_path_multiplex.Path.exists", return_value=False):
        await client_proxy._cleanup_conflicting_processes(
            {"inbounds": [{"listen": "0.0.0.0", "listen_port": 11090}]}
        )
    mock_kill.assert_called()


@pytest.mark.asyncio
async def test_start_client_singbox_proxy_reuses_singleton():
    proxy = MagicMock()
    proxy.start_client = AsyncMock()
    mux._client_singbox_proxy = proxy
    result = await start_client_singbox_proxy(server_connect_addr="1.1.1.1", server_proxy_port=9)
    assert result is proxy
    proxy.start_client.assert_awaited_once()


@pytest.mark.asyncio
async def test_ensure_and_stop_client_proxy():
    proxy = MagicMock()
    proxy.start_client = AsyncMock()
    proxy.stop = AsyncMock()
    mux._client_singbox_proxy = proxy
    await ensure_client_transparent_proxy()
    await stop_client_proxy()
    proxy.stop.assert_awaited_once()
    assert mux._client_singbox_proxy is None
    await stop_client_proxy()


@pytest.mark.asyncio
async def test_start_server_singbox_proxy(tmp_path, monkeypatch):
    monkeypatch.setattr(SingBoxConfig, "SERVER_TEMPLATE_PATH", "server.json")
    monkeypatch.setattr(mux, "SINGBOX_CONFIG_DIR", tmp_path)
    (tmp_path / "server.json").write_text(json.dumps(SERVER_TEMPLATE), encoding="utf-8")
    with patch.object(SingBoxProxy, "start_server", new=AsyncMock()) as mock_start, \
         patch.object(mux, "_repo_root", return_value=tmp_path):
        proxy = await start_server_singbox_proxy(["10.0.1.1"], listen_port=11091)
    assert isinstance(proxy, SingBoxProxy)
    mock_start.assert_awaited_once_with(listen_hosts=["10.0.1.1"], listen_port=11091)


@pytest.mark.asyncio
async def test_switch_proxy_helpers():
    proxy = MagicMock()
    proxy.is_running = True
    proxy.switch_outbound = AsyncMock()
    proxy._server_addr = "10.0.1.1"
    proxy._server_port = SingBoxConfig.SERVER_LISTEN_PORT
    proxy._socks_host = "127.0.0.1"
    proxy._socks_port = 9050
    mux._client_singbox_proxy = proxy

    await switch_proxy_to_direct()
    proxy.switch_outbound.assert_awaited_with(SINGBOX_OUT_DIRECT)

    await switch_proxy_to_socks()
    proxy.switch_outbound.assert_awaited_with(SINGBOX_OUT_SOCKS)

    await switch_proxy_to_mptcp(server_connect_addr="10.0.1.1")
    proxy.switch_outbound.assert_awaited_with(SINGBOX_OUT_MPTCP)


@pytest.mark.asyncio
async def test_switch_proxy_to_mptcp_restarts_when_addr_changes():
    proxy = MagicMock()
    proxy.is_running = True
    proxy.switch_outbound = AsyncMock()
    proxy.start_client = AsyncMock()
    proxy._server_addr = "old"
    proxy._server_port = 1
    proxy._socks_host = "127.0.0.1"
    proxy._socks_port = 9050
    mux._client_singbox_proxy = proxy
    await switch_proxy_to_mptcp(server_connect_addr="10.0.1.1", server_proxy_port=11091)
    proxy.start_client.assert_awaited_once()
    proxy.switch_outbound.assert_awaited_with(SINGBOX_OUT_MPTCP)


@pytest.mark.asyncio
async def test_switch_outbound_wraps_errors():
    proxy = MagicMock()
    proxy.is_running = True
    proxy.logger = MagicMock()
    proxy.switch_outbound = AsyncMock(side_effect=TimeoutError("timeout"))
    mux._client_singbox_proxy = proxy
    with pytest.raises(RuntimeError, match="failed to switch"):
        await mux._switch_singbox_client_outbound(SINGBOX_OUT_DIRECT)
