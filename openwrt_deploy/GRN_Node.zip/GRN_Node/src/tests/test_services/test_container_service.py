import pytest
import socket
from unittest.mock import MagicMock, AsyncMock, patch
from services.tor_container_service import TorContainerService
from config.tor_node_config import TorNodeConfig
from config.config import StemConfig, ContainerConfig

import docker


@pytest.fixture
def mock_config():
    """创建模拟配置对象"""
    config = MagicMock(spec=TorNodeConfig)
    config.role = "relay"
    config.nick = "da90c787510"
    config.pwd = StemConfig.DEFAULT_TOR_PASSWORD
    config.or_port = StemConfig.DEFAULT_OR_PORT
    config.socks_port = StemConfig.DEFAULT_SOCKS_PORT
    config.control_port = StemConfig.DEFAULT_CONTROL_PORT
    config.dir_port = StemConfig.DEFAULT_DIR_PORT
    config.outer_ip_addr = "192.168.1.100"
    config.dir_auths = None
    config.image = ContainerConfig.DEFAULT_IMAGE
    config.network_mode = ContainerConfig.DEFAULT_NETWORK_MODE
    return config


@pytest.fixture
def tor_service(mock_config):
    """创建 TorContainerService 实例, 模拟 Docker 客户端"""
    with patch('docker.from_env') as mock_from_env:
        client = MagicMock()
        mock_from_env.return_value = client

        service = TorContainerService(mock_config)
        # 模拟内部方法
        service._update_container_ip = MagicMock()
        service.start_tor_process = MagicMock()
        service.wait_for_port = MagicMock(return_value=True)
        return service
    
@pytest.fixture
def tor_service_naked(mock_config):
    """创建 TorContainerService 实例, 模拟 Docker 客户端"""
    with patch('docker.from_env') as mock_from_env:
        client = MagicMock()
        mock_from_env.return_value = client

        service = TorContainerService(mock_config)
        return service


@pytest.mark.asyncio
async def test_container_start_container_cleanup_existing_container(tor_service):
    """start_container 接口, 测试清理同名容器逻辑"""
    # 模拟存在同名容器
    mock_container = MagicMock()
    mock_container.name = tor_service.container_name
    mock_container.attrs = {"NetworkSettings": {"Ports": {"9001/tcp": [{"HostIp": "127.0.0.1", "HostPort":"9001"}]}}}

    mock_docker_client = tor_service.client
    mock_docker_client.containers.list.return_value = [mock_container]
    
    # 模拟容器不存在（触发新容器创建）
    mock_docker_client.containers.get.side_effect = docker.errors.NotFound("Not found")
    
    # 执行测试
    tor_service.start_container()
    
    # 验证清理操作
    mock_container.stop.assert_called_once()
    mock_container.remove.assert_called_once()


@pytest.mark.asyncio
async def test_container_start_container_reuse_existing_container(tor_service):
    """start_container 接口, 测试复用已存在的容器"""
    # 模拟容器存在但未运行
    mock_container = MagicMock()
    mock_container.status = "exited"
    mock_container.id = "existing_id"
    mock_docker_client = tor_service.client
    mock_docker_client.containers.get.return_value = mock_container
    
    # 执行测试
    container_id = tor_service.start_container()
    
    # 验证结果
    assert container_id == "existing_id"
    mock_container.start.assert_called_once()
    tor_service._update_container_ip.assert_called_once()
    mock_docker_client.containers.run.assert_not_called()


@pytest.mark.asyncio
@pytest.mark.dependency()
# 标记为 
# test_container_start_container_environment_variables
# test_container_start_container_port_mapping
# test_container_start_container_da_role_special_handling
# 依赖用例
async def test_container_start_container_create_new_container(tor_service):
    """start_container 接口, 测试创建新容器"""
    # 模拟容器不存在
    mock_docker_client = tor_service.client
    mock_container = MagicMock(id="34fa7fa76237", status="running")
    mock_docker_client.containers.get.side_effect = [
        docker.errors.NotFound("Not found"),
        # 第二次调用get返回新创建的容器（模拟run之后）
        mock_container
    ]

    # 模拟容器创建成功
    tor_service.client.containers.run = MagicMock()
    
    # 执行测试
    container_id = tor_service.start_container()
    
    # 验证结果
    assert container_id == mock_container.id

    # 以下接口调用次数断言都定位 >=1。原因是此创建容器成功接口，会被依赖用例调用多次，因此，所有接口调用次数断言都 >= 1
    mock_docker_client.containers.run.call_count >= 1
    mock_docker_client.containers.get.call_count >= 1
    tor_service._update_container_ip.call_count >= 1
    tor_service.start_tor_process.call_count >= 1
    tor_service.wait_for_port.call_count >= 1


@pytest.mark.asyncio
@pytest.mark.dependency(depends=["test_container_start_container_create_new_container"])
async def test_container_start_container_environment_variables(tor_service, mock_config):
    """start_container 接口, 测试环境变量配置"""
    # 设置目录授权信息
    mock_config.dir_auths = {
        "nick": "da90c787510",
        "or_port": 9001,
        "v3_ident": "v3id",
        "ip_address": "10.0.0.1",
        "fingerprint": "ABCD1234"
    }

    # # 模拟容器不存在
    # mock_docker_client = tor_service.client
    # mock_container = MagicMock(id="34fa7fa76237", status="running")
    # mock_docker_client.containers.get.side_effect = [
    #     docker.errors.NotFound("Not found"),
    #     # 第二次调用get返回新创建的容器（模拟run之后）
    #     mock_container
    # ]

    # # 模拟容器创建成功
    # tor_service.client.containers.run = MagicMock()

    # # 执行测试
    # tor_service.start_container()

    await test_container_start_container_create_new_container(tor_service)
    
    # 获取传递给containers.run的环境变量
    # mock_docker_client.containers.run.assert_called_once()
    run_args = tor_service.client.containers.run.call_args[1]
    env_vars = run_args.get("environment", {})
    
    # 验证基本环境变量
    assert env_vars["ROLE"] == "relay"
    assert env_vars["NICK"] == "da90c787510"
    assert env_vars["TOR_PWD"] == StemConfig.DEFAULT_TOR_PASSWORD
    
    # 验证目录授权环境变量
    expected_da_str = "DirAuthority da90c787510 orport=9001 no-v2 v3ident=v3id 10.0.0.1 ABCD1234"
    assert env_vars["TOR_DIR_AUTHORITIES"] == expected_da_str


@pytest.mark.asyncio
@pytest.mark.dependency(depends=["test_container_start_container_create_new_container"])
async def test_container_start_container_port_mapping(tor_service, mock_config):
    """start_container 接口, 测试端口映射配置"""
    # 设置不同角色测试
    test_cases = [
        ("da", {"control_port": 9051, "or_port": 9001, "dir_port": 9030}),
        ("relay", {"control_port": 9051, "or_port": 9001}),
        ("exit", {"control_port": 9051, "or_port": 9001}),
        ("client", {"control_port": 9051, "socks_port": 9050})
    ]
    
    for role, expected_ports in test_cases:
        mock_config.role = role
        if role == "da":
            mock_config.dir_port = 9030
        elif role == "client":
            mock_config.socks_port = 9050
        
        # 执行测试
        await test_container_start_container_create_new_container(tor_service)
        
        # 获取端口映射配置
        run_args = tor_service.client.containers.run.call_args[1]
        actual_ports = run_args.get("ports", {})
        
        # 验证端口映射
        for port in expected_ports.values():
            port_key = f"{port}/tcp"
            assert port_key in actual_ports


@pytest.mark.asyncio
@pytest.mark.dependency(depends=["test_container_start_container_create_new_container"])
async def test_container_da_role_special_handling(tor_service, mock_config):
    """start_container 接口, 测试DA角色的特殊处理"""
    # 设置为DA角色
    mock_config.role = "da"
    mock_config.dir_port = 9030

    with patch('time.sleep') as mock_sleep:
        # 执行测试
        await test_container_start_container_create_new_container(tor_service)
        
        # 验证等待时间
        mock_sleep.assert_called_once_with(3)


@pytest.mark.asyncio
async def test_container_start_container_wait_for_port(tor_service):
    """start_container 接口, 测试端口等待逻辑"""
    # 模拟容器不存在
    mock_docker_client = tor_service.client
    mock_container = MagicMock(id="34fa7fa76237", status="running")
    mock_docker_client.containers.get.side_effect = [
        docker.errors.NotFound("Not found"),
        # 第二次调用get返回新创建的容器（模拟run之后）
        mock_container
    ]

    # 模拟容器创建成功
    tor_service.client.containers.run = MagicMock()

    # 测试等待失败
    tor_service.wait_for_port.return_value = False

    # 执行测试
    with patch.object(tor_service, 'logger', new_callable=MagicMock):
        container_id = tor_service.start_container()
        assert container_id is None
        tor_service.logger.warning.assert_any_call("❌ 等待超时，Shr 可能未成功启动")


@pytest.mark.asyncio
async def test_container_start_container_docker_exception_handling(tor_service):
    """start_container 接口, 测试Docker异常处理"""
    # 模拟容器不存在
    mock_docker_client = tor_service.client
    mock_container = MagicMock(id="34fa7fa76237", status="running")
    mock_docker_client.containers.get.side_effect = [
        docker.errors.NotFound("Not found"),
        # 第二次调用get返回新创建的容器（模拟run之后）
        mock_container
    ]

    # 模拟容器创建成功
    tor_service.client.containers.run = MagicMock()

    # 模拟Docker异常
    mock_docker_client.containers.run.side_effect = docker.errors.DockerException("Test error")
    
    # 执行测试
    with patch.object(tor_service, 'logger', new_callable=MagicMock):
        container_id = tor_service.start_container()
        assert container_id is None
        tor_service.logger.error.assert_called_with("🐳 Docker 错误: Test error")


@pytest.mark.asyncio
async def test_container_start_container_host_network_mode(tor_service, mock_config):
    """start_container 接口, 测试host网络模式下的端口处理"""
    # 设置host网络模式
    mock_config.network_mode = "host"
    mock_docker_client = tor_service.client
    mock_container = MagicMock(id="34fa7fa76237", status="running")
    mock_docker_client.containers.get.side_effect = [
        docker.errors.NotFound("Not found"),
        # 第二次调用get返回新创建的容器（模拟run之后）
        mock_container
    ]
    
    # 模拟容器创建成功
    tor_service.client.containers.run = MagicMock()
    
    # 执行测试
    tor_service.start_container()
    
    # 获取端口映射配置
    run_args = mock_docker_client.containers.run.call_args[1]
    
    # 验证host模式下没有端口映射
    assert "ports" not in run_args


@pytest.mark.asyncio
async def test_container_stop_container_success(tor_service):
    """stop_container 接口, 测试正常停止容器"""
    # 模拟已存在的容器
    mock_container = MagicMock(id="34fa7fa76237", status="running")
    tor_service.container = mock_container
    
    # 执行测试
    result = tor_service.stop_container()
    
    # 验证结果
    assert result is True
    mock_container.stop.assert_called_once()
    mock_container.remove.assert_called_once()
    assert tor_service.container is None
    assert tor_service.container_id is None


@pytest.mark.asyncio
async def test_container_stop_container_not_found(tor_service):
    """stop_container 接口, 测试容器不存在"""
    # 模拟容器不存在
    tor_service.container = None
    mock_docker_client = tor_service.client
    
    # 执行测试
    result = tor_service.stop_container()
    
    # 验证结果
    assert result is True
    mock_docker_client.containers.get.assert_not_called()
    mock_docker_client.containers.stop.assert_not_called()
    mock_docker_client.containers.remove.assert_not_called()


@pytest.mark.asyncio
async def test_container_stop_container_api_error(tor_service_naked):
    """stop_container 接口, 测试API错误"""
    # 模拟API错误
    mock_container = MagicMock(id="34fa7fa76237", status="running")
    mock_container.stop.side_effect = docker.errors.APIError("API Error")
    tor_service_naked.container = mock_container
    # mock_docker_client = tor_service_naked.client
    
    # 执行测试
    result = tor_service_naked.stop_container()
    
    # 验证结果
    assert result is False
    mock_container.stop.assert_called_once()
    mock_container.remove.assert_not_called()


@pytest.mark.asyncio
async def test_container_update_container_ip_success(tor_service_naked):
    """_update_container_ip 接口, 测试成功更新容器IP地址"""
    mock_container = MagicMock()
    mock_container.attrs = {
        "NetworkSettings": {
            "Networks": {
                "bridge": {
                    "IPAddress": "172.17.0.2"
                }
            }
        }
    }
    mock_container.reload = MagicMock()
    tor_service_naked.container = mock_container
    tor_service_naked.config.network_mode = 'bridge'

    # 执行测试
    tor_service_naked._update_container_ip()
    
    # 验证结果
    mock_container.reload.assert_called_once()
    assert tor_service_naked.container_ip_addr == '172.17.0.2'


@pytest.mark.asyncio
async def test_container_update_container_ip_with_specific_network(tor_service_naked):
    """_update_container_ip 接口, 测试使用指定网络模式获取IP地址"""
    mock_container = MagicMock()
    mock_container.attrs = {
        'NetworkSettings': {
            'Networks': {
                'host': {
                    'IPAddress': '127.0.0.1'
                },
                'bridge': {
                    'IPAddress': '172.17.0.2'
                }
            }
        }
    }
    mock_container.reload = MagicMock()
    tor_service_naked.container = mock_container
    tor_service_naked.config.network_mode = 'host'
    
    # 执行测试
    tor_service_naked._update_container_ip()

    # 验证结果
    mock_container.reload.assert_called_once()
    assert tor_service_naked.container_ip_addr == '127.0.0.1'

@pytest.mark.asyncio
async def test_container_update_container_ip_fallback_to_first_network(tor_service_naked):
    """_update_container_ip 接口, 测试网络模式不存在时回退到第一个可用网络"""
    mock_container = MagicMock()
    mock_container.attrs = {
        'NetworkSettings': {
            'Networks': {
                'custom_network': {
                    'IPAddress': '192.168.1.100'
                }
            }
        }
    }
    mock_container.reload = MagicMock()
    tor_service_naked.container = mock_container
    tor_service_naked.config.network_mode = 'nonexistent'  # 不存在的网络模式
    
    # 执行测试
    tor_service_naked._update_container_ip()
    
    # 验证结果
    mock_container.reload.assert_called_once()
    assert tor_service_naked.container_ip_addr == '192.168.1.100'


@pytest.mark.asyncio
async def test_container_update_container_ip_no_container(tor_service_naked):
    """_update_container_ip 接口, 测试容器不存在时跳过更新"""
    tor_service_naked.container = None
    
    # 执行测试
    tor_service_naked._update_container_ip()
    
    # 验证结果
    assert tor_service_naked.container_ip_addr is None


@pytest.mark.asyncio
async def test_container_update_container_ip_empty_networks(tor_service_naked):
    """_update_container_ip 接口, 测试网络配置为空时返回空IP地址"""
    mock_container = MagicMock()
    mock_container.attrs = {
        'NetworkSettings': {
            'Networks': {}
        }
    }
    mock_container.reload = MagicMock()
    tor_service_naked.container = mock_container
    
    # 执行测试
    tor_service_naked._update_container_ip()
    
    # 验证结果
    mock_container.reload.assert_called_once()
    assert tor_service_naked.container_ip_addr == ''


@pytest.mark.asyncio
async def test_container_update_container_ip_missing_ip_field(tor_service_naked):
    """_update_container_ip 接口, 测试IPAddress字段缺失时返回空字符串"""
    mock_container = MagicMock()
    mock_container.attrs = {
        'NetworkSettings': {
            'Networks': {
                'bridge': {
                    'Gateway': '172.17.0.1'
                }
            }
        }
    }
    mock_container.reload = MagicMock()
    tor_service_naked.container = mock_container
    tor_service_naked.config.network_mode = 'bridge'
    
    # 执行测试
    tor_service_naked._update_container_ip()
    
    # 验证结果
    mock_container.reload.assert_called_once()
    assert tor_service_naked.container_ip_addr == ''


@pytest.mark.asyncio
async def test_container_update_container_ip_reload_exception(tor_service_naked):
    """_update_container_ip 接口, 测试reload方法异常时的处理"""
    mock_container = MagicMock()
    mock_container.reload.side_effect = Exception("Reload failed")
    
    tor_service_naked.container = mock_container
    
    # 执行测试
    try:
        tor_service_naked._update_container_ip()
    except Exception as e:
        assert str(e) == "Reload failed"
    else:
        assert False, "未抛出异常"
    
    # 验证结果
    assert tor_service_naked.container_ip_addr is None


@pytest.mark.asyncio
async def test_container_update_container_ip_multiple_networks(tor_service_naked):
    """_update_container_ip 接口, 测试多个网络接口时的IP地址获取"""
    mock_container = MagicMock()
    mock_container.attrs = {
        'NetworkSettings': {
            'Networks': {
                'host': {'IPAddress': '127.0.0.1'},
                'bridge': {'IPAddress': '172.17.0.2'},
                'custom': {'IPAddress': '10.0.0.5'}
            }
        }
    }
    mock_container.reload = MagicMock()
    tor_service_naked.container = mock_container
    tor_service_naked.config.network_mode = 'custom'

    # 执行测试
    tor_service_naked._update_container_ip()

    # 验证结果
    assert tor_service_naked.container_ip_addr == '10.0.0.5'
    tor_service_naked.config.network_mode = None
    tor_service_naked._update_container_ip()
    assert tor_service_naked.container_ip_addr == '127.0.0.1'  # 第一个网络


def test_container_wait_for_port_empty_ip(tor_service_naked):
    """wait_for_port 接口, 测试IP地址为空时返回False"""
    tor_service_naked.container_ip_addr = None
    
     # 执行测试
    result = tor_service_naked.wait_for_port(8080)

    # 验证结果
    assert result is False


def test_container_wait_for_port_host_mode(tor_service_naked):
    """wait_for_port 接口, 测试host模式下使用localhost"""
    tor_service_naked.container_ip_addr = None
    tor_service_naked.config.network_mode = 'host'
    with patch('socket.socket') as mock_socket:
        mock_sock_instance = MagicMock()
        mock_socket.return_value.__enter__.return_value = mock_sock_instance
        mock_sock_instance.connect.return_value = None

        # 执行测试
        result = tor_service_naked.wait_for_port(8080, timeout=1)

        # 验证结果
        assert result is True
        mock_sock_instance.connect.assert_called_once_with(('127.0.0.1', 8080))


def test_container_wait_for_port_non_host_mode_empty_ip(tor_service_naked):
    """wait_for_port 接口, 测试非host模式且IP为空时返回False"""
    tor_service_naked.container_ip_addr = None
    tor_service_naked.config.network_mode = 'bridge'

    # 执行测试
    result = tor_service_naked.wait_for_port(8080)

    # 验证结果
    assert result is False

def test_container_wait_for_port_success(tor_service_naked):
    """wait_for_port 接口, 测试端口可连接时返回True"""
    tor_service_naked.container_ip_addr = '127.0.0.1'
    with patch('socket.socket') as mock_socket:
        mock_sock_instance = MagicMock()
        mock_socket.return_value.__enter__.return_value = mock_sock_instance
        mock_sock_instance.connect.return_value = None

        # 执行测试
        result = tor_service_naked.wait_for_port(8080, timeout=1)
        assert result is True

        # 验证结果
        mock_socket.assert_called_once_with(socket.AF_INET, socket.SOCK_STREAM)
        mock_sock_instance.settimeout.assert_called_once_with(1)
        mock_sock_instance.connect.assert_called_once_with(('127.0.0.1', 8080))


def test_container_wait_for_port_connection_refused(tor_service_naked):
    """wait_for_port 接口, 测试连接被拒绝时返回False"""
    tor_service_naked.container_ip_addr = '127.0.0.1'
    with patch('socket.socket') as mock_socket:
        mock_sock_instance = MagicMock()
        mock_socket.return_value.__enter__.return_value = mock_sock_instance
        mock_sock_instance.connect.side_effect = ConnectionRefusedError()

        # 执行测试
        result = tor_service_naked.wait_for_port(8080, timeout=2)

        # 验证结果
        assert result is False
        assert mock_sock_instance.connect.call_count == 2
        mock_sock_instance.connect.assert_any_call(('127.0.0.1', 8080))


def test_container_wait_for_port_socket_timeout(tor_service_naked):
    """wait_for_port 接口, 测试socket超时时返回False"""
    tor_service_naked.container_ip_addr = '127.0.0.1'
    with patch('socket.socket') as mock_socket:
        mock_sock_instance = MagicMock()
        mock_socket.return_value.__enter__.return_value = mock_sock_instance
        mock_sock_instance.connect.side_effect = socket.timeout()

        # 执行测试
        result = tor_service_naked.wait_for_port(8080, timeout=3)

        # 验证结果
        assert result is False
        assert mock_sock_instance.connect.call_count == 3


def test_container_wait_for_port_os_error(tor_service_naked):
    """wait_for_port 接口, 测试OS错误时返回False"""
    tor_service_naked.container_ip_addr = '127.0.0.1'
    with patch('socket.socket') as mock_socket:
        mock_sock_instance = MagicMock()
        mock_socket.return_value.__enter__.return_value = mock_sock_instance
        mock_sock_instance.connect.side_effect = OSError()

        # 执行测试
        result = tor_service_naked.wait_for_port(8080, timeout=2)

        # 验证结果
        assert result is False
        assert mock_sock_instance.connect.call_count == 2


def test_container_wait_for_port_mixed_exceptions(tor_service_naked):
    """wait_for_port 接口, 测试混合异常情况"""
    tor_service_naked.container_ip_addr = '192.168.1.1'
    with patch('socket.socket') as mock_socket:
        mock_sock_instance = MagicMock()
        mock_socket.return_value.__enter__.return_value = mock_sock_instance
        mock_sock_instance.connect.side_effect = [
            ConnectionRefusedError(),
            socket.timeout(),
            None
        ]

        # 执行测试
        result = tor_service_naked.wait_for_port(8080, timeout=5)

        # 验证结果
        assert result is True
        assert mock_sock_instance.connect.call_count == 3


def test_container_exec_command_success(tor_service_naked):
    """exec_command 接口, 测试命令执行成功"""
    tor_service_naked.container = MagicMock()
    tor_service_naked.container.exec_run = MagicMock(return_value=(0, b"Success"))
    
    # 执行测试
    result = tor_service_naked.exec_command("ls /", user="root")
    
    # 验证结果
    assert result == (0, b"Success")
    tor_service_naked.container.exec_run.assert_called_once_with("ls /", user="root")


def test_container_exec_command_no_container(tor_service_naked):
    """exec_command 接口, 测试容器不存在时返回None"""
    tor_service_naked.container = None
    
    # 执行测试
    result = tor_service_naked.exec_command("ls /")
    
    # 验证结果
    assert result is None

    if tor_service_naked.container is not None:
        tor_service_naked.container.exec_run.assert_not_called()


def test_container_exec_command_with_user(tor_service_naked):
    """exec_command 接口, 测试指定用户执行命令"""
    tor_service_naked.container = MagicMock()
    tor_service_naked.container.exec_run.return_value = (0, b"Success")
    
    # 执行测试
    result = tor_service_naked.exec_command("whoami", user="user1")
    
    # 验证结果
    assert result == (0, b"Success")
    tor_service_naked.container.exec_run.assert_called_once_with("whoami", user="user1")


def test_container_exec_command_failure(tor_service_naked):
    """exec_command 接口, 测试命令执行失败"""
    tor_service_naked.container = MagicMock()
    tor_service_naked.container.exec_run.return_value = (1, b"Error")
    
    # 执行测试
    result = tor_service_naked.exec_command("invalid_cmd")
    
    # 验证结果
    assert result == (1, b"Error")
    tor_service_naked.container.exec_run.assert_called_once_with("invalid_cmd", user="root")


def test_container_exec_command_empty_command(tor_service_naked):
    """exec_command 接口, 测试空命令返回None"""
    tor_service_naked.container = MagicMock()
    tor_service_naked.container.exec_run.return_value = None

    # 执行测试
    result = tor_service_naked.exec_command("")
    
    # 验证结果
    assert result is None
    tor_service_naked.container.exec_run.assert_called_once()


def test_container_exec_command_non_root_user(tor_service_naked):
    """exec_command 接口, 测试非root用户执行命令"""
    tor_service_naked.container = MagicMock()
    tor_service_naked.container.exec_run.return_value = (0, b"Success")
    
    # 执行测试
    result = tor_service_naked.exec_command("ls /", user="user2")
    
    # 验证结果
    assert result == (0, b"Success")
    tor_service_naked.container.exec_run.assert_called_once_with("ls /", user="user2")


def test_container_stop_tor_process_success(tor_service_naked):
    """stop_tor_process 接口, 测试成功停止 tor 进程"""
    tor_service_naked.container = MagicMock()
    tor_service_naked.container.exec_run.return_value = (0, b"Success")
    
    # 执行测试
    tor_service_naked.stop_tor_process()
    
    # 验证结果
    tor_service_naked.container.exec_run.assert_called_once_with("pkill -x tor", user="root")


def test_container_stop_tor_process_no_container(tor_service_naked):
    """stop_tor_process 接口, 测试容器不存在"""
    tor_service_naked.container = None
    
    # 执行测试
    tor_service_naked.stop_tor_process()
    
    # 验证结果
    if tor_service_naked.container is not None:
        tor_service_naked.container.exec_run.assert_called_once()


def test_container_start_tor_process_success(tor_service_naked):
    """start_tor_process 接口, 测试成功启动 tor 进程"""
    tor_service_naked.container = MagicMock()
    tor_service_naked.logger = MagicMock()
    tor_service_naked.container.exec_run.return_value = (0, b"Success")
    
    # 执行测试
    tor_service_naked.start_tor_process()
    
    # 验证结果
    assert tor_service_naked.logger.info.called
    tor_service_naked.container.exec_run.assert_called_once_with(
        "sudo -u debian-tor tor -f /etc/tor/torrc",
        user="root",
        detach=True
    )


def test_container_start_tor_process_no_container(tor_service_naked):
    """start_tor_process 接口, 测试容器不存在"""
    tor_service_naked.container = None
    
    # 执行测试
    tor_service_naked.start_tor_process()
    
    # 验证结果
    if tor_service_naked.container is not None:
        tor_service_naked.container.exec_run.assert_called_once()


def test_container_start_tor_process_exec_failure(tor_service_naked):
    """start_tor_process 接口, 测试命令执行失败"""
    tor_service_naked.container = MagicMock()
    tor_service_naked.container.exec_run.return_value = (1, b"Error")
    
    # 执行测试
    tor_service_naked.start_tor_process()
    
    # 验证结果
    tor_service_naked.container.exec_run.assert_called_once_with(
        "sudo -u debian-tor tor -f /etc/tor/torrc",
        user="root",
        detach=True
    )


@pytest.mark.asyncio
async def test_container_get_dir_auths_success(tor_service_naked):
    """get_dir_auths 接口, 测试成功获取 DirAuthority 信息"""
    tor_service_naked.container = MagicMock()

    mock_result = MagicMock()
    mock_result.exit_code = 0
    mock_result.output = b"DirAuthority da90c787510 127.0.0.1 orport=9001 v3ident=3DF0E8427AE2A3F46E03A554D6CF56E828D3FD8F 6AC76F470754BE48B01F57D85D41C8A09DD56B76"
    tor_service_naked.container.exec_run.return_value = mock_result

    # 执行测试
    result = await tor_service_naked.get_dir_auths()
    
    # 验证结果
    assert result == [{
        "nick": "da90c787510",
        "orport": 9001,
        "v3ident": "3DF0E8427AE2A3F46E03A554D6CF56E828D3FD8F",
        "address": "127.0.0.1",
        "fingerprint": "6AC76F470754BE48B01F57D85D41C8A09DD56B76"
    }]
    tor_service_naked.container.exec_run.assert_called_once_with("cat /etc/tor/torrc")


@pytest.mark.asyncio
async def test_container_get_dir_auths_no_output(tor_service_naked):
    """get_dir_auths 接口, 测试无输出时返回None"""
    tor_service_naked.container = MagicMock()

    mock_result = MagicMock()
    mock_result.exit_code = 0
    mock_result.output = b""
    tor_service_naked.container.exec_run.return_value = mock_result
    
    # 执行测试
    result = await tor_service_naked.get_dir_auths()
    
    # 验证结果
    assert result is None
    tor_service_naked.container.exec_run.assert_called_once_with("cat /etc/tor/torrc")


@pytest.mark.asyncio
async def test_container_get_dir_auths_exec_failure(tor_service_naked):
    """get_dir_auths 接口, 测试命令执行失败时返回None"""
    tor_service_naked.container = MagicMock()

    mock_result = MagicMock()
    mock_result.exit_code = None
    mock_result.output = b"Error"
    tor_service_naked.container.exec_run.return_value = mock_result
    
    # 执行测试
    result = await tor_service_naked.get_dir_auths()
    
    # 验证结果
    assert result is None
    tor_service_naked.container.exec_run.assert_called_once_with("cat /etc/tor/torrc")


@pytest.mark.asyncio
async def test_container_get_dir_auths_no_container(tor_service_naked):
    """get_dir_auths 接口, 测试容器不存在时返回None"""
    tor_service_naked.container = None

    # 执行测试
    result = await tor_service_naked.get_dir_auths()
    
    # 验证结果
    assert result is None
    if tor_service_naked.container is not None:
        tor_service_naked.container.exec_run.assert_called_once()


@pytest.mark.asyncio
async def test_container_update_dir_auths_success(tor_service_naked):
    """update_dir_auths 接口, 测试成功更新 DirAuthority 配置"""
    # 准备测试数据
    dir_auths = [{
        'nick': 'da90c787510',
        'or_port': 9001,
        'v3_ident': '3DF0E8427AE2A3F46E03A554D6CF56E828D3FD8F',
        'ip_address': '192.168.1.1',
        'fingerprint': '6AC76F470754BE48B01F57D85D41C8A09DD56B76'
    }]
    
    tor_service_naked.container = MagicMock()

    # 模拟容器 exec_run 返回值
    mock_result_1 = MagicMock()
    mock_result_1.exit_code = 0
    mock_result_1.output = b"Address 183.205.154.218\n" \
                           b"AddressDisableIPv6 1\n" \
                           b"AssumeReachable 1\n" \
                           b"AuthoritativeDirectory 1\n" \
                           b"ContactInfo da90c787510 <da90c787510 AT localhost>\n" \
                           b"ControlPort 0.0.0.0:9051\n" \
                           b"CookieAuthentication 0\n" \
                           b"DirAuthority da90c787510 orport=9001 no-v2 v3ident=3DF0E8427AE2A3F46E03A554D6CF56E828D3FD8F 183.205.154.218:9030 6AC76F470754BE48B01F57D85D41C8A09DD56B76\n" \
                           b"DirPort 9030 IPv4Only\n" \
                           b"HashedControlPassword 16:AD64ADF31AE675F1602CE31A25A715DA06492FA605CA586BEF42EBEA73\n" \
                           b"Nickname da90c787510\n" \
                           b"ORPort 9001 IPv4Only\n" \
                           b"SocksPort 0\n" \
                           b"TestingDirAuthVoteGuard *\n" \
                           b"TestingDirAuthVoteHSDir *\n" \
                           b"TestingTorNetwork 1\n" \
                           b"V3AuthoritativeDirectory 1\n"
    
    mock_result_2 = MagicMock()
    mock_result_2.exit_code = 0
    mock_result_2.output = b""
    
    mock_result_3 = MagicMock()
    mock_result_3.exit_code = 0
    mock_result_3.output = b"1234"

    tor_service_naked.container.exec_run.side_effect = [
        mock_result_1,
        mock_result_2,
        mock_result_3
    ]

    tor_service_naked.stop_tor_process = MagicMock()
    tor_service_naked.start_tor_process = MagicMock()
    
    with patch("services.tor_container_service.asyncio.sleep", new_callable=AsyncMock):
        await tor_service_naked.update_dir_auths(dir_auths)
    
    # 验证调用次数和参数
    assert tor_service_naked.container.exec_run.call_count == 3
    tor_service_naked.stop_tor_process.assert_called_once()
    tor_service_naked.start_tor_process.assert_called_once()


@pytest.mark.asyncio
async def test_container_update_dir_auths_no_container(tor_service_naked):
    """update_dir_auths 接口, 测试容器未初始化时的处理"""
    tor_service_naked.container = None
    
    with patch.object(tor_service_naked, 'logger', new_callable=MagicMock) as mock_logger:
        # 执行测试
        await tor_service_naked.update_dir_auths([])
        
        # 验证日志记录
        mock_logger.error.assert_called_with("❌ 容器句柄未初始化")


@pytest.mark.asyncio
async def test_container_update_dir_auths_write_failure(tor_service_naked):
    """update_dir_auths 接口, 测试写入配置失败的情况"""
    dir_auths = [{
        'nick': 'da90c787510',
        'or_port': 9001,
        'v3_ident': '3DF0E8427AE2A3F46E03A554D6CF56E828D3FD8F',
        'ip_address': '192.168.1.1',
        'fingerprint': '6AC76F470754BE48B01F57D85D41C8A09DD56B76'
    }]

    tor_service_naked.container = MagicMock()

    # 模拟容器 exec_run 返回值
    mock_result_1 = MagicMock()
    mock_result_1.exit_code = 0
    mock_result_1.output = b"Address 183.205.154.218\n" \
                           b"AddressDisableIPv6 1\n" \
                           b"AssumeReachable 1\n" \
                           b"AuthoritativeDirectory 1\n" \
                           b"ContactInfo da90c787510 <da90c787510 AT localhost>\n" \
                           b"ControlPort 0.0.0.0:9051\n" \
                           b"CookieAuthentication 0\n" \
                           b"DirAuthority da90c787510 orport=9001 no-v2 v3ident=3DF0E8427AE2A3F46E03A554D6CF56E828D3FD8F 183.205.154.218:9030 6AC76F470754BE48B01F57D85D41C8A09DD56B76\n" \
                           b"DirPort 9030 IPv4Only\n" \
                           b"HashedControlPassword 16:AD64ADF31AE675F1602CE31A25A715DA06492FA605CA586BEF42EBEA73\n" \
                           b"Nickname da90c787510\n" \
                           b"ORPort 9001 IPv4Only\n" \
                           b"SocksPort 0\n" \
                           b"TestingDirAuthVoteGuard *\n" \
                           b"TestingDirAuthVoteHSDir *\n" \
                           b"TestingTorNetwork 1\n" \
                           b"V3AuthoritativeDirectory 1\n"
    
    mock_result_2 = MagicMock()
    mock_result_2.exit_code = 1
    mock_result_2.output = b"Permission denied"  # 写入失败
    
    mock_result_3 = MagicMock()
    mock_result_3.exit_code = 0
    mock_result_3.output = b"1234"  # 检查进程

    tor_service_naked.container.exec_run.side_effect = [
        mock_result_1,
        mock_result_2,
        mock_result_3
    ]

    tor_service_naked.stop_tor_process = MagicMock()
    tor_service_naked.start_tor_process = MagicMock()

    with patch.object(tor_service_naked, 'logger', new_callable=MagicMock) as mock_logger, \
         patch("services.tor_container_service.asyncio.sleep", new_callable=AsyncMock):
        # 执行测试
        await tor_service_naked.update_dir_auths(dir_auths)
        
        # 验证错误日志
        mock_logger.error.assert_called_with("❌ 写入 torrc 失败: Permission denied")
        
        # 验证调用次数和参数
        assert tor_service_naked.container.exec_run.call_count == 3
        tor_service_naked.stop_tor_process.assert_called_once()
        tor_service_naked.start_tor_process.assert_called_once()


@pytest.mark.asyncio
async def test_container_update_dir_auths_tor_start_failure(tor_service_naked):
    """update_dir_auths 接口, 测试 tor 启动失败的情况"""
    dir_auths = [{
        'nick': 'da90c787510',
        'or_port': 9001,
        'v3_ident': '3DF0E8427AE2A3F46E03A554D6CF56E828D3FD8F',
        'ip_address': '192.168.1.1',
        'fingerprint': '6AC76F470754BE48B01F57D85D41C8A09DD56B76'
    }]

    tor_service_naked.container = MagicMock()

    # 模拟容器 exec_run 返回值
    mock_result_1 = MagicMock()
    mock_result_1.exit_code = 0
    mock_result_1.output = b"Address 183.205.154.218\n" \
                           b"AddressDisableIPv6 1\n" \
                           b"AssumeReachable 1\n" \
                           b"AuthoritativeDirectory 1\n" \
                           b"ContactInfo da90c787510 <da90c787510 AT localhost>\n" \
                           b"ControlPort 0.0.0.0:9051\n" \
                           b"CookieAuthentication 0\n" \
                           b"DirAuthority da90c787510 orport=9001 no-v2 v3ident=3DF0E8427AE2A3F46E03A554D6CF56E828D3FD8F 183.205.154.218:9030 6AC76F470754BE48B01F57D85D41C8A09DD56B76\n" \
                           b"DirPort 9030 IPv4Only\n" \
                           b"HashedControlPassword 16:AD64ADF31AE675F1602CE31A25A715DA06492FA605CA586BEF42EBEA73\n" \
                           b"Nickname da90c787510\n" \
                           b"ORPort 9001 IPv4Only\n" \
                           b"SocksPort 0\n" \
                           b"TestingDirAuthVoteGuard *\n" \
                           b"TestingDirAuthVoteHSDir *\n" \
                           b"TestingTorNetwork 1\n" \
                           b"V3AuthoritativeDirectory 1\n"
    
    mock_result_2 = MagicMock()
    mock_result_2.exit_code = 0
    mock_result_2.output = b""  # 写入成功
    
    mock_result_3 = MagicMock()
    mock_result_3.exit_code = 1
    mock_result_3.output = b""  # 进程检查失败

    tor_service_naked.container.exec_run.side_effect = [
        mock_result_1,
        mock_result_2,
        mock_result_3
    ]

    tor_service_naked.stop_tor_process = MagicMock()
    tor_service_naked.start_tor_process = MagicMock()

    with patch.object(tor_service_naked, 'logger', new_callable=MagicMock) as mock_logger, \
         patch("services.tor_container_service.asyncio.sleep", new_callable=AsyncMock):
        # 执行测试
        await tor_service_naked.update_dir_auths(dir_auths)
        
        # 验证错误日志
        mock_logger.error.assert_called_with("❌ shr 启动失败，请检查 torrc 配置 ")
        
        # 验证调用次数和参数
        assert tor_service_naked.container.exec_run.call_count == 3
        tor_service_naked.stop_tor_process.assert_called_once()
        tor_service_naked.start_tor_process.assert_called_once()


@pytest.mark.asyncio
async def test_container_update_dir_auths_exception_handling(tor_service_naked):
    """update_dir_auths 接口, 测试异常处理"""
    dir_auths = [{
        'nick': 'da90c787510',
        'or_port': 9001,
        'v3_ident': '3DF0E8427AE2A3F46E03A554D6CF56E828D3FD8F',
        'ip_address': '192.168.1.1',
        'fingerprint': '6AC76F470754BE48B01F57D85D41C8A09DD56B76'
    }]

    tor_service_naked.container = MagicMock()

    # 模拟异常
    tor_service_naked.container.exec_run.side_effect = Exception("Connection failed")

    tor_service_naked.stop_tor_process = MagicMock()
    tor_service_naked.start_tor_process = MagicMock()
    
    with patch.object(tor_service_naked, 'logger', new_callable=MagicMock) as mock_logger:

        with pytest.raises(Exception, match="Connection failed"):
            await tor_service_naked.update_dir_auths(dir_auths)
    
        mock_logger.error.assert_called_with("更新 DirAuths 失败: Connection failed")

        tor_service_naked.stop_tor_process.assert_called_once()
