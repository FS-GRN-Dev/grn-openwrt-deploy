import json
import threading
import urllib.error
import urllib.request

from services.http_local_service import start_openwrt_http_service, DynamicHTTPServer, InfoHandler


def test_start_openwrt_http_service_info_and_404():
    payload = {"node_code": "n1", "ok": True}

    server = DynamicHTTPServer(("127.0.0.1", 0), InfoHandler, lambda: payload)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        host, port = server.server_address
        with urllib.request.urlopen(f"http://{host}:{port}/info", timeout=3) as resp:
            body = json.loads(resp.read().decode("utf-8"))
            assert body == payload
            assert resp.headers.get("Access-Control-Allow-Origin") == "*"

        try:
            urllib.request.urlopen(f"http://{host}:{port}/missing", timeout=3)
            assert False, "expected 404"
        except urllib.error.HTTPError as exc:
            assert exc.code == 404
    finally:
        server.shutdown()
        server.server_close()


def test_start_openwrt_http_service_bind_success():
    started = {"server": None}

    class CaptureServer(DynamicHTTPServer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            started["server"] = self

    import services.http_local_service as http_mod
    original = http_mod.DynamicHTTPServer
    http_mod.DynamicHTTPServer = CaptureServer
    try:
        start_openwrt_http_service(lambda: {"ok": True}, host="127.0.0.1", port=0)
        assert started["server"] is not None
        started["server"].shutdown()
        started["server"].server_close()
    finally:
        http_mod.DynamicHTTPServer = original
