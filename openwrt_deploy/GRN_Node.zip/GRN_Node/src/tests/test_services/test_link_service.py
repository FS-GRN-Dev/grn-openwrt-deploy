import pytest
from unittest.mock import MagicMock, AsyncMock, patch
from services.link_service import LinkService


@pytest.fixture
def mock_deps():
    return {
        "node_context": MagicMock(),
        "state_reporter": AsyncMock(return_value = True)
    }

@pytest.fixture
def link_service(mock_deps):
    return LinkService(
        context = mock_deps['node_context'],
        reporter = mock_deps['state_reporter']
    )


@pytest.mark.asyncio
async def test_link_create_circuit_relay_not_found(link_service, mock_deps):
    """创建电路，测试Relay不存在的情况"""
    
    # 准备测试数据
    relay_fingerprints = ["fingerprint1", "fingerprint2"]
    
    # 设置模拟环境，不包含请求的relay
    mock_deps['node_context'].stem2tor_instances = {
        "relay2": MagicMock()
    }
    
    # 执行测试并验证异常
    with pytest.raises(ValueError, match="Client Relay relay1 不存在或未启动"):
        await link_service.create_circuit(relay_fingerprints, "relay1")


@pytest.mark.asyncio
async def test_link_create_circuit_creation_failure(link_service, mock_deps):
    """创建电路，测试电路创建失败的情况"""
    
    # # 准备测试数据
    # relay_fingerprints = ["fingerprint1", "fingerprint2"]
    
    # # 设置模拟环境，create_circuit返回None
    # mock_stem = MagicMock()
    # mock_stem.create_circuit = AsyncMock(return_value=None)
    
    # mock_deps['node_context'].stem2tor_instances = {
    #     "relay1": mock_stem
    # }
    
    # # 执行测试并验证异常
    # with pytest.raises(RuntimeError, match="电路创建失败 \\(Tor 返回空 ID\\)"):
    #     await link_service.create_circuit(relay_fingerprints, "relay1")

    # 1. 模拟mock circuit
    mock_circuit = MagicMock()
    mock_circuit.circuit_id = "circuit-id1"
    link_service.create_circuit_with_link = AsyncMock(
        side_effect=RuntimeError("Runtime error")
    )
    
    # 2. 测试参数
    relay_fingerprints = ["fingerprint1", "fingerprint2", "fingerprint3"]
    client_relay_code = "CLIENT-RELAY-001"

    # 手动捕获异常并断言
    try:
        result_circuit = await link_service.create_circuit(
            relay_fingerprints=relay_fingerprints,
            client_relay_code=client_relay_code
        )
        # 如果没抛异常，标记测试失败
        pytest.fail("预期抛出 RuntimeError，但未抛出任何异常")
    except RuntimeError as e:
        # 直接断言异常信息完全相等
        assert str(e) == "Runtime error"


@pytest.mark.asyncio
async def test_link_create_circuit(link_service, mock_deps):
    """创建电路"""

    # # 准备测试数据
    # circuit_ids = [
    #     "circuit-id1",
    #     "circuit-id2"
    # ]

    # relay_fingerprints = ["fingerprint1", "fingerprint2", "fingerprint3"]
    
    # # 设置模拟环境
    # mock_stem1 = MagicMock()
    # mock_stem1.create_circuit = AsyncMock(return_value = circuit_ids[0])
    # mock_stem2 = MagicMock()
    # mock_stem2.create_circuit = AsyncMock(return_value = circuit_ids[1])
    
    # mock_deps['node_context'].stem2tor_instances = {
    #     "relay1": mock_stem1,
    #     "relay2": mock_stem2
    # }
    
    # # 执行测试
    # result = await link_service.create_circuit(relay_fingerprints, "relay1")
    
    # # 验证结果
    # assert result == circuit_ids[0]
    # mock_stem1.create_circuit.assert_awaited_once_with(relay_fingerprints)


    # 1. 模拟mock circuit
    mock_circuit = MagicMock()
    mock_circuit.circuit_id = "circuit-id1"
    link_service.create_circuit_with_link = AsyncMock(
        return_value=(mock_circuit, None)
    )
    
    # 2. 测试参数
    relay_fingerprints = ["fingerprint1", "fingerprint2", "fingerprint3"]
    client_relay_code = "CLIENT-RELAY-001"
    
    # 3. 调用测试方法
    result_circuit = await link_service.create_circuit(
        relay_fingerprints=relay_fingerprints,
        client_relay_code=client_relay_code
    )
    
    # 4. 核心断言
    # 验证返回值：仅返回电路对象（忽略 link）
    assert result_circuit is mock_circuit
    assert result_circuit.circuit_id == "circuit-id1"
    
    # 验证 create_circuit_with_link 被正确调用
    link_service.create_circuit_with_link.assert_awaited_once_with(
        relay_fingerprints=relay_fingerprints,
        client_relay_code=client_relay_code,
        set_as_default=False  # 新链路默认不激活，需 enable 入池
    )


@pytest.mark.asyncio
async def test_link_delete_circuit_relay_not_found(link_service, mock_deps):
    """删除电路，测试Relay不存在的情况"""
    
    # 准备测试数据
    relay_fingerprints = ["fingerprint1", "fingerprint2"]
    
    # 设置模拟环境，不包含请求的relay
    mock_deps['node_context'].stem2tor_instances = {
        "relay2": MagicMock()
    }
    
    # 执行测试并验证异常
    with pytest.raises(ValueError, match="Client Relay relay1 不存在"):
        await link_service.delete_circuit(relay_fingerprints, "relay1")


@pytest.mark.asyncio
async def test_link_delete_circuit(link_service, mock_deps):
    """删除电路"""

    # 准备测试数据
    circuit_ids = [
        "circuit-id1",
        "circuit-id2"
    ]

    # 设置模拟环境
    mock_stem1 = MagicMock()
    mock_stem1.delete_circuit = AsyncMock(return_value = True)
    mock_stem2 = MagicMock()
    mock_stem2.delete_circuit = AsyncMock(return_value = True)
    
    mock_deps['node_context'].stem2tor_instances = {
        "relay1": mock_stem1,
        "relay2": mock_stem2
    }
    mock_deps['node_context'].active_circuits = {
        circuit_ids[0]: MagicMock(link_id="link-1"),
    }
    manager = MagicMock()
    manager.get_circuit_for_link = MagicMock(return_value=circuit_ids[0])
    manager.find_link_by_circuit_id = MagicMock(return_value="link-1")
    manager.unregister_link = AsyncMock(return_value=True)
    link_service._circuit_managers["relay1"] = manager
    
    # 执行测试
    result = await link_service.delete_circuit("link-1", "relay1")
    
    # 验证结果
    assert result == True
    mock_stem1.delete_circuit.assert_awaited_once_with(circuit_ids[0])
    manager.mark_circuit_for_manual_close.assert_called_once_with(circuit_ids[0])


@pytest.mark.asyncio
async def test_link_delete_circuit_clears_map_when_already_gone(link_service, mock_deps):
    """电路已不在 active_circuits 时仍应 unregister_link 清 map/出池"""
    mock_stem = MagicMock()
    mock_stem.delete_circuit = AsyncMock(return_value=True)
    mock_deps["node_context"].stem2tor_instances = {"relay1": mock_stem}
    mock_deps["node_context"].active_circuits = {}  # 已因重建失败被 pop

    manager = MagicMock()
    manager.get_circuit_for_link = MagicMock(return_value="177")
    manager.unregister_link = AsyncMock(return_value=True)
    link_service._circuit_managers["relay1"] = manager

    result = await link_service.delete_circuit("2092502243530141696", "relay1")

    assert result is True
    manager.unregister_link.assert_awaited_once_with(
        "2092502243530141696", delete_circuit=False
    )
    mock_stem.delete_circuit.assert_not_awaited()
    manager.mark_circuit_for_manual_close.assert_not_called()


@pytest.mark.asyncio
async def test_delete_single_keeps_mptcp_when_multi_active(link_service, mock_deps):
    """有激活多时删未启用单，不得因 count==0+allow关 误切 direct"""
    mock_deps["node_context"].stem2tor_instances = {"client-1": MagicMock()}
    mock_deps["node_context"].active_circuits = {}
    manager = MagicMock()
    manager.get_circuit_for_link.return_value = None
    manager.unregister_link = AsyncMock(return_value=True)
    manager.get_active_multi_link_id.return_value = "multi-1"
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = False
    link_service._circuit_managers["client-1"] = manager
    link_service._allow_auto_circuit_by_relay["client-1"] = False

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        await link_service.delete_single_link("single-idle", "client-1")

    mock_direct.assert_not_awaited()
    mock_socks.assert_not_awaited()


@pytest.mark.asyncio
async def test_delete_single_last_allow_off_goes_direct(link_service, mock_deps):
    mock_deps["node_context"].stem2tor_instances = {"client-1": MagicMock()}
    mock_deps["node_context"].active_circuits = {}
    manager = MagicMock()
    manager.get_circuit_for_link.return_value = None
    manager.unregister_link = AsyncMock(return_value=True)
    manager.get_active_multi_link_id.return_value = None
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = False
    link_service._circuit_managers["client-1"] = manager
    link_service._allow_auto_circuit_by_relay["client-1"] = False

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        await link_service.delete_single_link("s1", "client-1")

    mock_direct.assert_awaited_once()
    mock_socks.assert_not_awaited()


@pytest.mark.asyncio
async def test_delete_active_multi_allow_on_goes_socks(link_service, mock_deps):
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = "multi-1"
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = True
    manager.clear_multi_active = MagicMock()
    link_service._circuit_managers["client-1"] = manager
    link_service._allow_auto_circuit_by_relay["client-1"] = True

    async def _stop(result, link_id, client_relay_code, delete_link_group=False):
        manager.get_active_multi_link_id.return_value = None
        manager.clear_multi_active()
        result["delete_old_link_results"] = {
            "results": [{"link_id": "sub-1", "success": True, "error": None}]
        }

    link_service.stop_client_bridge = AsyncMock(side_effect=_stop)

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        results = await link_service.delete_multi_link("multi-1", "client-1")

    assert results[0]["success"] is True
    mock_socks.assert_awaited_once()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_delete_active_multi_allow_off_goes_direct(link_service, mock_deps):
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = "multi-1"
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = False
    manager.clear_multi_active = MagicMock()
    link_service._circuit_managers["client-1"] = manager
    link_service._allow_auto_circuit_by_relay["client-1"] = False

    async def _stop(result, link_id, client_relay_code, delete_link_group=False):
        manager.get_active_multi_link_id.return_value = None
        manager.clear_multi_active()
        result["delete_old_link_results"] = {
            "results": [{"link_id": "sub-1", "success": True, "error": None}]
        }

    link_service.stop_client_bridge = AsyncMock(side_effect=_stop)

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        await link_service.delete_multi_link("multi-1", "client-1")

    mock_direct.assert_awaited_once()
    mock_socks.assert_not_awaited()


@pytest.mark.asyncio
async def test_stop_client_bridge_clears_multi_when_group_exists(link_service):
    group = MagicMock()
    group.client_bridge_code = None
    link_service.get_link_group = MagicMock(return_value=group)
    link_service.tun_bridge_service = None
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = "multi-1"
    link_service._circuit_managers["client-1"] = manager

    result = {}
    await link_service.stop_client_bridge(result, "multi-1", "client-1", delete_link_group=False)

    manager.clear_multi_active.assert_called_once()


def test_link_set_allow_auto_circuit_propagates_to_manager(link_service):
    """set_allow_auto_circuit should push to existing CircuitManager"""
    manager = MagicMock()
    link_service._circuit_managers["client-1"] = manager

    result = link_service.set_allow_auto_circuit(True, client_relay_code="client-1")

    assert result["allow_auto_circuit"] is True
    assert result["updated_relays"] == ["client-1"]
    manager.set_allow_auto_circuit.assert_called_once_with(True)


def test_link_set_allow_auto_circuit_all_managers(link_service):
    """without relay code, update default and all managers"""
    m1 = MagicMock()
    m2 = MagicMock()
    link_service._circuit_managers = {"c1": m1, "c2": m2}

    result = link_service.set_allow_auto_circuit(False)

    assert link_service._allow_auto_circuit_default is False
    assert result["updated_relays"] == ["c1", "c2"]
    m1.set_allow_auto_circuit.assert_called_once_with(False)
    m2.set_allow_auto_circuit.assert_called_once_with(False)


@pytest.mark.asyncio
async def test_sync_proxy_keeps_mptcp_when_multi_active(link_service):
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = "multi-1"
    manager.get_active_single_count.return_value = 0
    link_service._circuit_managers["client-1"] = manager

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        mode = await link_service.sync_proxy_for_client_relay("client-1")

    assert mode == "mptcp-tunnel"
    mock_socks.assert_not_awaited()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_sync_proxy_socks_when_single_active(link_service):
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = None
    manager.get_active_single_count.return_value = 1
    manager.allow_auto_circuit = False
    link_service._circuit_managers["client-1"] = manager
    link_service._allow_auto_circuit_by_relay["client-1"] = False

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        mode = await link_service.sync_proxy_for_client_relay("client-1")

    assert mode == "socks5"
    mock_socks.assert_awaited_once()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_sync_proxy_socks_when_allow_auto_and_pool_empty(link_service):
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = None
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = True
    link_service._circuit_managers["client-1"] = manager
    link_service._allow_auto_circuit_by_relay["client-1"] = True

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        mode = await link_service.sync_proxy_for_client_relay("client-1")

    assert mode == "socks5"
    mock_socks.assert_awaited_once()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_sync_proxy_direct_when_allow_off_and_pool_empty(link_service):
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = None
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = False
    link_service._circuit_managers["client-1"] = manager
    link_service._allow_auto_circuit_by_relay["client-1"] = False

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        mode = await link_service.sync_proxy_for_client_relay("client-1")

    assert mode == "direct"
    mock_direct.assert_awaited_once()
    mock_socks.assert_not_awaited()


@pytest.mark.asyncio
async def test_safe_proxy_by_active_pool_socks_when_allow(link_service):
    from config.config import SwitchType

    manager = MagicMock()
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = True
    manager.get_active_multi_link_id.return_value = None

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        await link_service._safe_proxy_by_active_pool(manager)
        await link_service._rollback_on_enable_failure(
            manager=manager,
            switch_type=SwitchType.NONE_TO_SINGLE,
            link_id="s1",
            newly_activated_single=True,
        )

    assert mock_socks.await_count >= 2
    mock_direct.assert_not_awaited()
    manager.deactivate_single.assert_called_with("s1")


@pytest.mark.asyncio
async def test_rollback_none_to_multi_uses_allow(link_service):
    from config.config import SwitchType

    manager = MagicMock()
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = True
    manager.get_active_multi_link_id.return_value = "m1"

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        await link_service._rollback_on_enable_failure(
            manager=manager,
            switch_type=SwitchType.NONE_TO_MULTI,
            link_id="m1",
        )

    manager.clear_multi_active.assert_called_once()
    mock_socks.assert_awaited_once()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_rollback_multi_to_single_direct_when_allow_off(link_service):
    from config.config import SwitchType

    manager = MagicMock()
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = False

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        await link_service._rollback_on_enable_failure(
            manager=manager,
            switch_type=SwitchType.MULTI_TO_SINGLE,
            link_id="s1",
        )

    manager.deactivate_single.assert_called_with("s1")
    mock_direct.assert_awaited_once()
    mock_socks.assert_not_awaited()


@pytest.mark.asyncio
async def test_disable_multi_socks_when_allow_true(link_service):
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = "multi-1"
    manager.get_active_single_pool.return_value = []
    manager.get_circuit_for_link.return_value = None
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = True
    link_service._circuit_managers["client-1"] = manager
    link_service.get_link_group = MagicMock(return_value=None)
    link_service.stop_client_bridge = AsyncMock()

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        result = await link_service._disable_link(
            link_id="multi-1",
            client_relay_code="client-1",
        )

    assert result["success"] is True
    manager.clear_multi_active.assert_called_once()
    mock_socks.assert_awaited_once()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_disable_multi_direct_when_allow_false(link_service):
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = "multi-1"
    manager.get_active_single_pool.return_value = []
    manager.get_circuit_for_link.return_value = None
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = False
    link_service._circuit_managers["client-1"] = manager
    link_service.get_link_group = MagicMock(return_value=None)
    link_service.stop_client_bridge = AsyncMock()

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        result = await link_service._disable_link(
            link_id="multi-1",
            client_relay_code="client-1",
        )

    assert result["success"] is True
    mock_direct.assert_awaited_once()
    mock_socks.assert_not_awaited()


@pytest.mark.asyncio
async def test_disable_last_single_explicit_socks_when_allow_true(link_service):
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = None
    manager.get_active_single_pool.return_value = ["s1"]
    manager.get_circuit_for_link.return_value = "circ-1"
    manager.deactivate_single.return_value = True
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = True
    manager.get_enabled_parent_link_ids.return_value = []
    link_service._circuit_managers["client-1"] = manager
    link_service.get_link_group = MagicMock(return_value=None)

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        result = await link_service._disable_link(
            link_id="s1",
            client_relay_code="client-1",
        )

    assert result["success"] is True
    mock_socks.assert_awaited_once()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_disable_last_single_direct_when_allow_false(link_service):
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = None
    manager.get_active_single_pool.return_value = ["s1"]
    manager.get_circuit_for_link.return_value = "circ-1"
    manager.deactivate_single.return_value = True
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = False
    manager.get_enabled_parent_link_ids.return_value = []
    link_service._circuit_managers["client-1"] = manager
    link_service.get_link_group = MagicMock(return_value=None)

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        result = await link_service._disable_link(
            link_id="s1",
            client_relay_code="client-1",
        )

    assert result["success"] is True
    mock_direct.assert_awaited_once()
    mock_socks.assert_not_awaited()


@pytest.mark.asyncio
async def test_disable_single_exception_restores_and_socks(link_service):
    """方案甲：停单异常时尽量加回池，池非空 → socks。"""
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = None
    manager.get_active_single_pool.return_value = ["s1", "s2"]
    manager.get_circuit_for_link.return_value = "circ-1"
    manager.deactivate_single.side_effect = RuntimeError("boom")
    manager.get_active_single_count.return_value = 2
    manager.allow_auto_circuit = False
    manager.get_enabled_parent_link_ids.return_value = ["s2"]
    link_service._circuit_managers["client-1"] = manager
    link_service.get_link_group = MagicMock(return_value=None)

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        result = await link_service._disable_link(
            link_id="s1",
            client_relay_code="client-1",
        )

    assert result["success"] is False
    assert result["switch_result"].get("rolled_back") is True
    manager.activate_single.assert_not_called()  # 未成功出池，不必再 activate
    mock_socks.assert_awaited_once()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_disable_last_single_exception_restores_then_socks(link_service):
    """方案甲：最后一单已出池后切 proxy 失败 → 加回池 → socks（不按 allow 切 direct）。"""
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = None
    manager.get_active_single_pool.return_value = ["s1"]
    manager.get_circuit_for_link.return_value = "circ-1"
    manager.deactivate_single.return_value = True
    # 出池后 count=0 触发切 proxy；切 socks 抛错；回滚 activate 后 count=1
    manager.get_active_single_count.side_effect = [0, 1]
    manager.allow_auto_circuit = False
    manager.get_enabled_parent_link_ids.return_value = ["s1"]
    link_service._circuit_managers["client-1"] = manager
    link_service.get_link_group = MagicMock(return_value=None)

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        # allow=False 且 count=0 时成功路径会走 direct；模拟切 direct 失败触发回滚
        mock_direct.side_effect = RuntimeError("direct fail")
        result = await link_service._disable_link(
            link_id="s1",
            client_relay_code="client-1",
        )

    assert result["success"] is False
    manager.activate_single.assert_called_once_with("s1")
    # 回滚后池非空 → socks（来自 _safe_proxy_by_active_pool）
    mock_socks.assert_awaited_once()
    mock_direct.assert_awaited_once()


@pytest.mark.asyncio
async def test_disable_last_single_exception_empty_pool_follows_allow(link_service):
    """方案甲：已出池且 activate 失败、池仍空 → 按 allow 收敛（关 → direct）。"""
    manager = MagicMock()
    manager.get_active_multi_link_id.return_value = None
    manager.get_active_single_pool.return_value = ["s1"]
    manager.get_circuit_for_link.return_value = "circ-1"
    manager.deactivate_single.return_value = True
    manager.get_active_single_count.return_value = 0
    manager.allow_auto_circuit = False
    manager.activate_single.side_effect = RuntimeError("activate fail")
    manager.get_enabled_parent_link_ids.return_value = []
    link_service._circuit_managers["client-1"] = manager
    link_service.get_link_group = MagicMock(return_value=None)

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        # 成功路径切 direct 失败 → 进入回滚
        mock_direct.side_effect = [RuntimeError("direct fail"), None]
        result = await link_service._disable_link(
            link_id="s1",
            client_relay_code="client-1",
        )

    assert result["success"] is False
    manager.activate_single.assert_called_once_with("s1")
    mock_socks.assert_not_awaited()
    assert mock_direct.await_count == 2  # 成功路径一次 + 回滚按 allow 再一次


def _circuit_manager_with_singles(link_ids: list[str], client_relay_code: str = "client-1"):
    from core.circuit_manager import CircuitManager

    manager = CircuitManager(MagicMock(), MagicMock(), MagicMock(), client_relay_code)
    for lid in link_ids:
        manager._link_circuit_map[lid] = f"circ-{lid}"
        manager.activate_single(lid)
    return manager


@pytest.mark.asyncio
async def test_rollback_single_to_multi_restore_ok_switches_socks(link_service):
    manager = _circuit_manager_with_singles(["s1", "s2"])
    manager.clear_all_singles()
    manager.set_multi_active("multi-1")
    switch_result: dict = {}

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        await link_service._rollback_single_to_multi_failure(
            manager=manager,
            link_id="multi-1",
            prev_singles=["s1", "s2"],
            switch_result=switch_result,
        )

    assert switch_result["restore_prev_singles_ok"] is True
    assert set(manager.get_enabled_parent_link_ids()) == {"s1", "s2"}
    mock_socks.assert_awaited_once()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_rollback_single_to_multi_restore_fail_uses_pool_allow(link_service):
    manager = _circuit_manager_with_singles([])
    manager.allow_auto_circuit = False
    manager.set_multi_active("multi-1")
    switch_result: dict = {}

    with patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        await link_service._rollback_single_to_multi_failure(
            manager=manager,
            link_id="multi-1",
            prev_singles=["s1"],
            switch_result=switch_result,
        )

    assert switch_result["restore_prev_singles_ok"] is False
    assert manager.get_enabled_parent_link_ids() == []
    mock_direct.assert_awaited_once()
    mock_socks.assert_not_awaited()


@pytest.mark.asyncio
async def test_single_to_multi_proxy_fail_restores_singles_and_enabled_ids(link_service):
    from config.config import SwitchType

    manager = _circuit_manager_with_singles(["s1"])
    link_service._circuit_managers["client-1"] = manager
    switch_result: dict = {"new_bridge_info": {"success": True}}

    async def _fake_start(result, link_id, client_relay_code, bridge_info):
        result["new_bridge_info"] = {"success": True}

    with patch.object(link_service, "start_client_bridge", side_effect=_fake_start), \
         patch.object(link_service, "stop_client_bridge", new_callable=AsyncMock), \
         patch.object(
             link_service,
             "_switch_proxy_mode",
             side_effect=RuntimeError("mptcp fail"),
         ), \
         patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        result = await link_service._enable_to_multi(
            switch_type=SwitchType.SINGLE_TO_MULTI,
            manager=manager,
            link_id="multi-1",
            client_relay_code="client-1",
            bridge_info={"tunnels": [], "server_tunnels": []},
            switch_result=switch_result,
        )

    assert result["success"] is False
    assert result["switch_result"].get("restore_prev_singles_ok") is True
    assert result["enabled_link_ids"] == ["s1"]
    assert manager.get_enabled_parent_link_ids() == ["s1"]
    mock_socks.assert_awaited_once()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_single_to_multi_outer_exception_restores_singles(link_service):
    from config.config import SwitchType

    manager = _circuit_manager_with_singles(["s1"])
    link_service._circuit_managers["client-1"] = manager
    switch_result: dict = {"new_bridge_info": {"success": True}}
    original_clear = manager.clear_all_singles

    def clear_then_raise():
        original_clear()
        raise RuntimeError("clear boom")

    manager.clear_all_singles = clear_then_raise

    async def _fake_start(result, link_id, client_relay_code, bridge_info):
        result["new_bridge_info"] = {"success": True}

    with patch.object(link_service, "start_client_bridge", side_effect=_fake_start), \
         patch.object(link_service, "stop_client_bridge", new_callable=AsyncMock), \
         patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks, \
         patch("services.link_service.switch_proxy_to_direct", new_callable=AsyncMock) as mock_direct:
        result = await link_service._enable_to_multi(
            switch_type=SwitchType.SINGLE_TO_MULTI,
            manager=manager,
            link_id="multi-1",
            client_relay_code="client-1",
            bridge_info={"tunnels": [], "server_tunnels": []},
            switch_result=switch_result,
        )

    assert result["success"] is False
    assert result["switch_result"].get("restore_prev_singles_ok") is True
    assert result["enabled_link_ids"] == ["s1"]
    assert manager.get_enabled_parent_link_ids() == ["s1"]
    mock_socks.assert_awaited_once()
    mock_direct.assert_not_awaited()


@pytest.mark.asyncio
async def test_switch_proxy_mode_always_mptcp(link_service):
    bridge_info = {
        "enable_mptcp": True,
        "aggregate": False,
        "tunnels": [
            {"tun_name": "tun1", "tun_addr_cidr": "10.0.1.2/24"},
            {"tun_name": "tun2", "tun_addr_cidr": "10.0.2.2/24"},
        ],
        "server_tunnels": [
            {"tun_addr_cidr": "10.0.1.1/24"},
            {"tun_addr_cidr": "10.0.2.1/24"},
        ],
    }
    with patch("services.link_service.derive_server_addrs", return_value=["10.0.1.1", "10.0.2.1"]), \
         patch("services.link_service.switch_proxy_to_mptcp", new_callable=AsyncMock) as mock_mptcp, \
         patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks:
        await link_service._switch_proxy_mode(bridge_info)

    mock_mptcp.assert_awaited_once_with(["10.0.1.1", "10.0.2.1"])
    mock_socks.assert_not_awaited()


@pytest.mark.asyncio
async def test_switch_proxy_mode_aggregate_mptcp(link_service):
    bridge_info = {
        "enable_mptcp": False,
        "aggregate": True,
        "tunnels": [{"tun_name": "tun1", "tun_addr_cidr": "10.0.1.2/24"}],
        "server_tunnels": [{"tun_addr_cidr": "10.0.1.1/24"}],
    }
    with patch("services.link_service.derive_server_addrs", return_value=["10.0.1.1"]), \
         patch("services.link_service.switch_proxy_to_mptcp", new_callable=AsyncMock) as mock_mptcp, \
         patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks:
        await link_service._switch_proxy_mode(bridge_info)

    mock_mptcp.assert_awaited_once_with(["10.0.1.1"])
    mock_socks.assert_not_awaited()


@pytest.mark.asyncio
async def test_switch_proxy_mode_single_path_socks(link_service):
    bridge_info = {
        "enable_mptcp": False,
        "aggregate": False,
        "tunnels": [{"tun_name": "tun1", "tun_addr_cidr": "10.0.1.2/24"}],
        "server_tunnels": [{"tun_addr_cidr": "10.0.1.1/24"}],
    }
    with patch("services.link_service.switch_proxy_to_mptcp", new_callable=AsyncMock) as mock_mptcp, \
         patch("services.link_service.switch_proxy_to_socks", new_callable=AsyncMock) as mock_socks:
        await link_service._switch_proxy_mode(bridge_info)

    mock_socks.assert_awaited_once()
    mock_mptcp.assert_not_awaited()


@pytest.mark.asyncio
async def test_switch_proxy_mode_raises_without_addrs(link_service):
    bridge_info = {
        "enable_mptcp": True,
        "aggregate": False,
        "tunnels": [
            {"tun_name": "tun1", "tun_addr_cidr": "10.0.1.2/24"},
            {"tun_name": "tun2", "tun_addr_cidr": "10.0.2.2/24"},
        ],
        "server_tunnels": [
            {"tun_addr_cidr": "10.0.1.1/24"},
            {"tun_addr_cidr": "10.0.2.1/24"},
        ],
    }
    with patch("services.link_service.derive_server_addrs", return_value=[]), \
         patch("services.link_service.derive_peer_addrs", return_value=[]):
        with pytest.raises(RuntimeError, match="无法推导 mptcp"):
            await link_service._switch_proxy_mode(bridge_info)
