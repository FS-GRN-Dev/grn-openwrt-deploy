import sys
import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch
from services.node_service import NodeService
from config.config import NodeConfig, GrpcConfig

from generated import vps_management_pb2


@pytest.fixture
def mock_deps():
    return {
        "node_context": MagicMock(),
        "state_reporter": AsyncMock(return_value = True)
    }

@pytest.fixture
def node_service(mock_deps):
    return NodeService(
        context = mock_deps['node_context'],
        reporter = mock_deps['state_reporter']
    )

@pytest.mark.asyncio
async def test_node_set_node_status(node_service, mock_deps):
    """设置节点状态"""

    mock_deps['state_reporter'].report_node_info.return_value = True
    result = await node_service.set_node_status(NodeConfig.DEFAULT_NODE_STATUS)

    assert result is True
    assert mock_deps['node_context'].node.status == NodeConfig.DEFAULT_NODE_STATUS

    mock_deps['state_reporter'].report_node_info.assert_called_once()


@pytest.mark.asyncio
async def test_node_destroy_node(node_service, mock_deps):
    """销毁节点 (自毁)"""

    mock_deps['node_context'].stem2tor_instances = {
        "relay1": MagicMock(stop_tor=AsyncMock(return_value = True)),
        "relay2": MagicMock(stop_tor=AsyncMock(return_value = True))
    }

    mock_delayed_exit = AsyncMock(name="_delayed_exit")
    node_service._delayed_exit = mock_delayed_exit

    with patch("asyncio.create_task") as create_task_mock:
        # 执行测试
        result = await node_service.destroy_node()

    assert result is True
    assert mock_deps['node_context'].node.status == vps_management_pb2.NodeStatus.NODE_DESTROYING

    mock_deps['state_reporter'].report_node_info.assert_called_once()
    mock_deps['state_reporter'].report_self_destruction_info.assert_called_once()

    for relay in mock_deps['node_context'].stem2tor_instances.values():
        relay.stop_tor.assert_awaited_once()

    create_task_mock.assert_called_once()

    call_args = create_task_mock.call_args[0][0]
    assert asyncio.iscoroutine(call_args)

    await asyncio.sleep(0)

    # 清空所有未完成的 task（彻底消除警告）
    for task in asyncio.all_tasks():
        if task is not asyncio.current_task():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass


@pytest.mark.asyncio
async def test_node_update_da_info(node_service, mock_deps):
    """更新 DA 信息"""
    # 准备测试数据
    da_info_list = [MagicMock(), MagicMock()]
    
    # 设置模拟环境
    mock_stem1 = MagicMock()
    mock_stem1.update_dir_auths = AsyncMock(return_value = True)
    mock_stem2 = MagicMock()
    mock_stem2.update_dir_auths = AsyncMock(return_value = True)
    
    mock_deps['node_context'].stem2tor_instances = {
        "relay1": mock_stem1,
        "relay2": mock_stem2
    }
    
    # 执行测试
    result = await node_service.update_da_info(da_info_list)
    
    # 验证结果
    assert result is True
    assert mock_deps['node_context'].dir_auth == da_info_list
    # mock_stem1.update_dir_auths.assert_awaited_once_with(da_info_list)
    # mock_stem2.update_dir_auths.assert_awaited_once_with(da_info_list)


@pytest.mark.asyncio
async def test_node_refresh_info(node_service, mock_deps):
    """刷新并上报所有信息"""
    
    # 设置模拟环境  
    mock_deps['state_reporter'].report_node_info.return_value = True
    mock_deps['state_reporter'].report_relay_info.return_value = True
    
    # 执行测试
    result = await node_service.refresh_info()

    # 验证结果
    assert result is True
    mock_deps['state_reporter'].report_node_info.assert_awaited_once()
    mock_deps['state_reporter'].report_relay_info.assert_awaited_once()


@pytest.mark.asyncio
async def test_node_delayed_exit(node_service):
    """延迟退出会先等待再调用 sys.exit / os._exit，测试中必须全部 mock。"""
    with patch("services.node_service.asyncio.sleep", new_callable=AsyncMock) as mock_sleep, \
         patch("services.node_service.sys.exit") as mock_sys_exit, \
         patch("services.node_service.os._exit") as mock_os_exit:
        await node_service._delayed_exit()

        mock_sleep.assert_awaited_once_with(GrpcConfig.EXIT_DELAY)
        mock_sys_exit.assert_called_once_with(0)
        mock_os_exit.assert_called_once_with(0)


@pytest.mark.asyncio
async def test_node_delayed_exit_core_logic(node_service):
    """测试 _delayed_exit 核心逻辑：等待 + 退出"""
    with patch("services.node_service.sys.exit") as mock_sys_exit, \
         patch("services.node_service.os._exit") as mock_os_exit, \
         patch("services.node_service.asyncio.sleep", new_callable=AsyncMock) as mock_async_sleep:
        original_exit_delay = GrpcConfig.EXIT_DELAY
        test_exit_delay = 1
        GrpcConfig.EXIT_DELAY = test_exit_delay
        try:
            await node_service._delayed_exit()
            mock_async_sleep.assert_awaited_once_with(test_exit_delay)
            mock_sys_exit.assert_called_once_with(0)
            mock_os_exit.assert_called_once_with(0)
        finally:
            GrpcConfig.EXIT_DELAY = original_exit_delay
