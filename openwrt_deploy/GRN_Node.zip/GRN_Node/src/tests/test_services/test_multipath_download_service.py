import os
from unittest.mock import MagicMock, patch

import pytest

from services.multipath_download_service import (
    MultipathDownloader,
    MultipathDownloadResult,
    PartDownloadResult,
)


def test_result_to_dict():
    part = PartDownloadResult(
        index=0, start=0, end=9, link_id="l1", part_path="p",
        http_code=206, bytes_downloaded=10, elapsed_ms=1, success=True,
    )
    result = MultipathDownloadResult(
        request_id="rid", url="http://x", output_path="out",
        total_size=10, parts=1, accept_ranges=None, elapsed_ms=2,
        success=True, error=None, part_results=[part],
    )
    data = result.to_dict()
    assert data["request_id"] == "rid"
    assert data["part_results"][0]["link_id"] == "l1"


def test_download_validation():
    downloader = MultipathDownloader("127.0.0.1", 9050)
    with pytest.raises(ValueError, match="parts"):
        downloader.download("http://x", "out", 0, ["l1"])
    with pytest.raises(ValueError, match="link_ids"):
        downloader.download("http://x", "out", 1, [])


def test_download_success_merge(tmp_path):
    downloader = MultipathDownloader("127.0.0.1", 9050, max_parallel=2)
    output = str(tmp_path / "out.bin")
    part_dir = str(tmp_path / "parts")

    def fake_head(url, link_id, pwd):
        return 6, None

    def fake_part(url, part_path, start, end, link_id, pwd):
        os.makedirs(os.path.dirname(part_path) or ".", exist_ok=True)
        payload = b"abcdef"[start:end + 1]
        with open(part_path, "wb") as fh:
            fh.write(payload)
        return PartDownloadResult(
            index=-1, start=start, end=end, link_id=link_id, part_path=part_path,
            http_code=206, bytes_downloaded=len(payload), elapsed_ms=1, success=True,
        )

    downloader._head = fake_head
    downloader._download_part = fake_part
    result = downloader.download(
        url="http://example.test/file",
        output_path=output,
        parts=2,
        link_ids=["l1", "l2"],
        request_id="rid",
        tmp_dir=part_dir,
    )
    assert result.success is True
    with open(output, "rb") as fh:
        assert fh.read() == b"abcdef"


def test_download_part_failure(tmp_path):
    downloader = MultipathDownloader("127.0.0.1", 9050)
    output = str(tmp_path / "out.bin")

    downloader._head = lambda *a, **k: (10, None)
    downloader._download_part = lambda *a, **k: PartDownloadResult(
        index=-1, start=0, end=4, link_id="l1", part_path="p",
        http_code=500, bytes_downloaded=0, elapsed_ms=1, success=False, error="http 500",
    )
    result = downloader.download("http://x", output, 1, ["l1"], request_id="rid", tmp_dir=str(tmp_path / "p"))
    assert result.success is False
    assert "failed" in result.error
