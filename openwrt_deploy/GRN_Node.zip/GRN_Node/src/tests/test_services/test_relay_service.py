import pytest
import utils.logger
from typing import Dict
from unittest.mock import MagicMock, AsyncMock, patch, call
from services.relay_service import RelayService

from generated import VPS_M_pb2, vps_management_pb2


@pytest.fixture
def mock_deps():
    """测试依赖的mock对象"""
    context = MagicMock()
    reporter = AsyncMock()
    factory = MagicMock()

    # 配置context的基本属性
    context.node_code = "node-123"
    context.ip_address = "192.168.1.1"
    context.dir_auth = ["dir_auth_info"]
    context.stem2tor_instances = {}
    context.relays = {}
    context.node = MagicMock()
    
    # 配置context的方法
    context._get_role = MagicMock(return_value="da")
   
    return {
        "context": context,
        "reporter": reporter,
        "factory": factory
    }

@pytest.fixture
def relay_service(mock_deps):
    """创建RelayService实例"""
    service = RelayService(
        context = mock_deps['context'],
        reporter = mock_deps['reporter'],
        factory = mock_deps['factory']

    )
    return service


@pytest.mark.asyncio
async def test_relay_create_relay_require_dir_auth(relay_service, mock_deps):
    """测试创建Relay角色的Relay，缺少dir_auth，创建失败"""
    # 准备测试数据
    relay_type = 1  # 假设1代表某种类型
    relay_role = 1  # 假设1代表DA角色
    
    # 配置mock
    mock_deps['context'].dir_auth = []
    mock_deps['context']._get_role.return_value = "relay"

    # 执行测试并验证异常
    with pytest.raises(ValueError, match="创建Relay失败: 缺少 dir_auth 信息"):
        await relay_service.create_relay(1, relay_type, relay_role)

    mock_deps['context']._get_role.assert_called_once()


@pytest.mark.asyncio
@pytest.mark.dependency()  # 标记为test_relay_destroy_relay, test_relay_update_relay依赖用例
async def test_relay_create_relay_success_da(relay_service, mock_deps)->Dict[str, any]:
    """测试成功创建DA角色的Relay"""
    # 准备测试数据
    relay_type = 1  # 假设1代表某种类型
    relay_role = 1  # 假设1代表DA角色
    
    # 配置mock
    mock_deps['context']._get_role.return_value = "da"
    
    mock_stem2tor = MagicMock()
    mock_stem2tor.container_name = "container_name_123"
    mock_stem2tor.start_tor = AsyncMock(return_value={
        "container_id": "container_123",
        "fingerprint": "fingerprint_123",
        "address": "192.168.1.1",
        "or_port": 9001,
        "dir_port": 9030,
        "bandwidth": "100KB",
        "published": True,
        "flags": ["Fast", "Stable"],
        "version": "0.4.7.0"
    })
    
    mock_deps['factory'].create.return_value = mock_stem2tor
    
    result = await relay_service.create_relay(1, relay_type, relay_role)
    
    expected_relay_id = "da-node-123-RELAY_ACCESS"
    assert result["relay_code"] == expected_relay_id
    
    # 验证调用
    mock_deps['factory'].create.assert_called_once()
    mock_stem2tor.start_tor.assert_awaited_once()
    
    # 验证状态更新
    assert expected_relay_id in mock_deps['context'].stem2tor_instances
    assert expected_relay_id in mock_deps['context'].relays
    
    # 验证上报
    mock_deps['context'].node.add_relay.assert_called_once()
    mock_deps['reporter'].report_node_info.assert_awaited_once()
    mock_deps['reporter'].push_relays.assert_awaited_once()
    mock_deps['reporter'].report_da_info.assert_awaited_once()

    return {"relay-id" : expected_relay_id, "stem2tor" : mock_stem2tor, "relay" : mock_deps['context'].relays[expected_relay_id]}


@pytest.mark.asyncio
async def test_relay_create_relay_failed_da(relay_service, mock_deps):
    """测试创建DA角色的Relay，创建失败"""
    # 准备测试数据
    relay_type = 1  # 假设1代表某种类型
    relay_role = 1  # 假设1代表DA角色
    
    # 配置mock
    mock_deps['context']._get_role.return_value = "da"
    
    mock_stem2tor = MagicMock()
    mock_stem2tor.container_name = "container_name_123"
    mock_stem2tor.start_tor = AsyncMock(return_value=None)
    
    mock_deps['factory'].create.return_value = mock_stem2tor
    
    # Mock VPS_M_pb2

    # 执行测试并验证异常
    with pytest.raises(RuntimeError, match="Relay容器 container_name_123 启动失败 \\(Tor未成功启动\\)"):
        await relay_service.create_relay(1, relay_type, relay_role)
    
    # 验证调用
    mock_deps['factory'].create.assert_called_once()
    mock_stem2tor.start_tor.assert_awaited_once()

    # 验证状态
    assert not mock_deps['context'].stem2tor_instances


@pytest.mark.asyncio
async def test_relay_destroy_relay_failed(relay_service, mock_deps):
    """测试销毁Relay失败，不存在relay id"""
    # 准备测试数据
    result_relay_id = "Not existed realay-id"

    # 执行测试
    result = await relay_service.destroy_relay(result_relay_id)

    # 验证结果：不存在的 Relay 视为已清理成功
    assert result is True


@pytest.mark.asyncio
@pytest.mark.dependency(depends=["test_relay_create_relay_success_da"])
async def test_relay_destroy_relay(relay_service, mock_deps):
    """测试销毁Relay"""
    # 准备测试数据
    relay_result = await test_relay_create_relay_success_da(relay_service, mock_deps)

    relay_id = relay_result["relay-id"]
    mock_stem2tor = relay_result["stem2tor"]
    relay = relay_result["relay"]

    utils.logger.get_logger("test_relay_destroy_relay").info(f"{relay_id}:{mock_stem2tor}")
    mock_stem2tor.stop_tor = AsyncMock(return_value=True)

    # 执行测试
    result = await relay_service.destroy_relay(relay_id)

    # 验证结果
    assert result == True
    
    # 验证调用
    mock_stem2tor.stop_tor.assert_awaited_once()
    
    # 验证状态更新
    assert relay_id not in mock_deps['context'].stem2tor_instances
    assert relay_id not in mock_deps['context'].relays
    
    # 验证上报
    mock_deps['context'].node.remove_relay.assert_called_once()
    mock_deps['reporter'].report_node_info.await_count >= 1
    mock_deps['reporter'].report_relay_info.assert_awaited_once()


@pytest.mark.asyncio
async def test_relay_update_relay_failed(relay_service, mock_deps):
    """测试更新Relay失败，不存在relay id"""
    # 准备测试数据
    result_relay_id = "Not existed realay-id"
    config_dict = {"nickname" : "da90c787510", "bandwidth" : 10, "exit_policy" : ""}

    # 执行测试
    result = await relay_service.update_relay(result_relay_id, config_dict)

    # 验证结果
    assert result == False


@pytest.mark.asyncio
@pytest.mark.dependency(depends=["test_relay_create_relay_success_da"])
async def test_relay_update_relay(relay_service, mock_deps):
    """测试销毁Relay"""
    # 准备测试数据
    relay_result = await test_relay_create_relay_success_da(relay_service, mock_deps)

    relay_id = relay_result["relay-id"]
    mock_stem2tor = relay_result["stem2tor"]
    relay = relay_result["relay"]

    utils.logger.get_logger("test_relay_destroy_relay").info(f"{relay_id}:{mock_stem2tor}")
    config_dict = {"nickname" : "da90c787510", "bandwidth" : 10, "exit_policy" : ""}

    # 执行测试
    result = await relay_service.update_relay(relay_id, config_dict)

    # 验证结果
    assert result == True
    assert relay.nickname == config_dict['nickname']
    assert relay.bandwidth == config_dict['bandwidth']
    assert relay.exit_policy == config_dict['exit_policy']
    
    # 验证上报
    mock_deps['reporter'].push_relays.await_count >= 1


@pytest.mark.asyncio
async def test_set_allow_auto_circuit_syncs_proxy(relay_service, mock_deps):
    relay = MagicMock()
    relay.relay_role = vps_management_pb2.RelayRole.ROLE_CLIENT
    mock_deps["context"].relays = {"client-1": relay}

    link_service = MagicMock()
    link_service.get_allow_auto_circuit.return_value = True
    link_service.set_allow_auto_circuit.return_value = {
        "allow_auto_circuit": False,
        "client_relay_code": "client-1",
        "updated_relays": ["client-1"],
    }
    link_service.sync_proxy_for_client_relay = AsyncMock(return_value="direct")
    relay_service.link_service = link_service

    result = await relay_service.set_allow_auto_circuit(
        allow=False, client_relay_code="client-1"
    )

    link_service.get_allow_auto_circuit.assert_called_once_with("client-1")
    link_service.set_allow_auto_circuit.assert_called_once_with(
        allow=False, client_relay_code="client-1"
    )
    link_service.sync_proxy_for_client_relay.assert_awaited_once_with("client-1")
    assert result["proxy_mode"] == "direct"


@pytest.mark.asyncio
async def test_set_allow_auto_circuit_rolls_back_allow_on_proxy_failure(
    relay_service, mock_deps
):
    relay = MagicMock()
    relay.relay_role = vps_management_pb2.RelayRole.ROLE_CLIENT
    mock_deps["context"].relays = {"client-1": relay}

    link_service = MagicMock()
    link_service.get_allow_auto_circuit.return_value = True
    link_service.set_allow_auto_circuit.return_value = {
        "allow_auto_circuit": False,
        "client_relay_code": "client-1",
        "updated_relays": ["client-1"],
    }
    link_service.sync_proxy_for_client_relay = AsyncMock(
        side_effect=RuntimeError("failed to switch sing-box selector to direct")
    )
    relay_service.link_service = link_service

    with pytest.raises(RuntimeError, match="failed to switch"):
        await relay_service.set_allow_auto_circuit(
            allow=False, client_relay_code="client-1"
        )

    link_service.set_allow_auto_circuit.assert_has_calls(
        [
            call(allow=False, client_relay_code="client-1"),
            call(allow=True, client_relay_code="client-1"),
        ]
    )


@pytest.mark.asyncio
async def test_set_allow_auto_circuit_rejects_non_client(relay_service, mock_deps):
    relay = MagicMock()
    relay.relay_role = vps_management_pb2.RelayRole.ROLE_RELAY
    mock_deps["context"].relays = {"relay-1": relay}
    relay_service.link_service = MagicMock()

    with pytest.raises(ValueError, match="目标不是 CLIENT 角色中继"):
        await relay_service.set_allow_auto_circuit(
            allow=True, client_relay_code="relay-1"
        )

    relay_service.link_service.set_allow_auto_circuit.assert_not_called()