import pytest
from unittest.mock import MagicMock, AsyncMock, patch
from stem import ControllerError, StreamStatus
from stem.control import EventType, Controller
from stem.descriptor.router_status_entry import RouterStatusEntryV3
from services.tor_controller_service import TorControllerService
from typing import Optional, List, Dict, Union, Callable, Any
from config.tor_node_config import TorNodeConfig
from config.config import StemConfig, ContainerConfig

from generated import VPS_M_pb2

import time


@pytest.fixture
def mock_config():
    """创建模拟配置对象"""
    config = MagicMock(spec=TorNodeConfig)
    config.role = "relay"
    config.nick = "da90c787510"
    config.pwd = StemConfig.DEFAULT_TOR_PASSWORD
    config.or_port = StemConfig.DEFAULT_OR_PORT
    config.socks_port = StemConfig.DEFAULT_SOCKS_PORT
    config.control_port = StemConfig.DEFAULT_CONTROL_PORT
    config.dir_port = StemConfig.DEFAULT_DIR_PORT
    config.outer_ip_addr = "192.168.1.100"
    config.dir_auths = None
    config.image = ContainerConfig.DEFAULT_IMAGE
    config.network_mode = ContainerConfig.DEFAULT_NETWORK_MODE
    return config


@pytest.fixture
def tor_controller(mock_config):
    """创建 TorControllerService 实例"""
    service = TorControllerService(mock_config)
    return service


@pytest.mark.asyncio
async def test_controller_connect_success(tor_controller):
    """connect 接口, 测试连接成功"""
    with patch("stem.control.Controller.from_port") as mock_from_port:
        mock_controller = MagicMock()
        mock_controller.authenticate = MagicMock()
        mock_from_port.return_value = mock_controller
        
        # 执行测试
        result = await tor_controller.connect()
        
        # 验证结果
        assert result is True
        mock_controller.authenticate.assert_called_once_with(password=StemConfig.DEFAULT_TOR_PASSWORD)


@pytest.mark.asyncio
async def test_controller_connect_failure_then_success(tor_controller):
    """connect 接口, 测试先尝试连接失败，后连接成功"""
    with patch("stem.control.Controller.from_port", side_effect=[
        Exception("Fail 1"),
        Exception("Fail 2"),
        MagicMock()
    ]) as mock_from_port:
        mock_controller = MagicMock()
        mock_controller.authenticate = MagicMock()
        mock_from_port.return_value = mock_controller

        with patch("services.tor_controller_service.asyncio.sleep", new_callable=AsyncMock):
            result = await tor_controller.connect(max_retries=5)

        assert result is True
        mock_from_port.call_count == 3
        mock_controller.authenticate.call_count == 3


@pytest.mark.asyncio
async def test_controller_connect_all_attempts_fail(tor_controller):
    """connect 接口, 测试多次尝试连接均失败"""
    with patch("stem.control.Controller.from_port", side_effect=Exception("Always fails")) as mock_from_port:
        mock_controller = MagicMock()
        mock_controller.authenticate = MagicMock()
        mock_from_port.return_value = mock_controller

        with patch("services.tor_controller_service.asyncio.sleep", new_callable=AsyncMock):
            result = await tor_controller.connect(max_retries=6)

        assert result is False
        mock_from_port.call_count == 6
        mock_controller.authenticate.call_count == 6


def test_controller_close_success(tor_controller):
    """close 接口, 测试关闭控制器成功"""
    mock_controller = MagicMock()
    mock_controller.close = MagicMock()
    tor_controller.controller = mock_controller
    
    # 执行测试
    tor_controller.close()
    
    # 验证结果
    mock_controller.close.assert_called_once()
    assert tor_controller.controller is None


def test_controller_close_exception_handling(tor_controller):
    """close 接口, 测试关闭控制器失败"""
    mock_controller = MagicMock()
    mock_controller.close = MagicMock(side_effect=Exception("Close error"))
    tor_controller.controller = mock_controller

    # 执行测试
    tor_controller.close()
    
    # 验证结果
    assert tor_controller.controller is None


def test_controller_close_when_not_connected(tor_controller):
    """close 接口, 测试不会触发关闭控制器操作"""
    tor_controller.controller = None

    # 执行测试
    tor_controller.close()  # Should not raise exception

    # 验证结果
    assert tor_controller.controller is None


def test_controller_get_controller_when_connected(tor_controller):
    """_get_controller 接口, 测试获取控制器实例成功"""
    mock_controller = MagicMock()
    tor_controller.controller = mock_controller
    
    # 执行测试
    result = tor_controller._get_controller()
    
    # 验证结果
    assert result == mock_controller


def test_controller_get_controller_when_not_connected(tor_controller):
    """_get_controller 接口, 测试获取空控制器实例时，抛出异常"""
    tor_controller.controller = None
    
    # # 步骤1：定义预期错误信息
    # expected_msg = "控制器未连接。请先调用 connect() 并确保连接成功。"
    # # 步骤2：用 re.escape() 转义正则特殊字符（()、. 等）
    # escaped_msg = re.escape(expected_msg)
    
    # # 步骤3：传入转义后的字符串作为 match 参数
    # with pytest.raises(RuntimeError, match=escaped_msg):
    #     tor_controller._get_controller()

    # 手动捕获异常并断言
    try:
        tor_controller._get_controller()
        # 如果没抛异常，标记测试失败
        pytest.fail("预期抛出 RuntimeError，但未抛出任何异常")
    except RuntimeError as e:
        # 直接断言异常信息完全相等
        assert str(e) == "控制器未连接。请先调用 connect() 并确保连接成功。"



# -------------- create_circuit 接口，测试用例 --------------
class TestTorControllerServiceCreateCircuit:
    async def test_controller_create_circuit_with_no_controller(self, tor_controller):
        """测试控制器未连接时调用 create_circuit 抛出 RuntimeError"""
        # 确保控制器未初始化
        tor_controller.controller = None
        
        # 调用方法应触发 _get_controller 的异常
        with pytest.raises(RuntimeError, match=r"控制器未连接。请先调用 connect\(\) 并确保连接成功。"):
            await tor_controller.create_circuit(path=["relay1", "relay2"])


    @pytest.mark.asyncio
    async def test_controller_create_circuit_success(self, tor_controller):
        """测试正常创建电路返回有效的 circuit ID"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 new_circuit 方法返回有效 ID
        mock_circuit_id = "CIR123456"
        mock_ctrl.new_circuit.return_value = mock_circuit_id
        
        # 3. 调用测试方法
        path = ["relay1", "relay2", "relay3"]
        result = await tor_controller.create_circuit(path)
        
        # 4. 断言结果
        assert result == mock_circuit_id

        # 验证 new_circuit 被正确调用
        mock_ctrl.new_circuit.assert_called_once_with(path, purpose="controller", await_build=True)


    @pytest.mark.asyncio
    async def test_controller_create_circuit_controller_error(self, tor_controller):
        """测试创建电路触发 ControllerError 时返回 None"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 new_circuit 抛出 ControllerError
        mock_error = ControllerError("创建电路失败：网络错误")
        mock_ctrl.new_circuit.side_effect = mock_error
        
        # 3. 调用测试方法
        path = ["relay1"]
        result = await tor_controller.create_circuit(path)
        
        # 4. 断言结果
        assert result is None

        # 验证 new_circuit 被调用
        mock_ctrl.new_circuit.assert_called_once_with(path, purpose="controller", await_build=True)


    @pytest.mark.asyncio
    async def test_controller_create_circuit_empty_path(self, tor_controller):
        """测试空路径创建电路（边界场景）"""
        # 模拟控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        mock_ctrl.new_circuit.return_value = "CIR789"
        
        # 调用空路径
        result = await tor_controller.create_circuit(path=[])
        
        assert result == "CIR789"
        mock_ctrl.new_circuit.assert_called_once_with([], purpose="controller", await_build=True)


    @pytest.mark.asyncio
    async def test_controller_create_circuit_waits_until_fingerprint_visible(self, tor_controller):
        """指纹 hop 首次不可见时会等待，可见后才创建电路"""
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        fingerprint = "A" * 40
        mock_ctrl.new_circuit.return_value = "CIR-FP"
        mock_ctrl.get_network_status.side_effect = [Exception("missing"), MagicMock()]

        with patch("services.tor_controller_service.asyncio.sleep", new_callable=AsyncMock) as mock_sleep, \
             patch("services.tor_controller_service.time.time", side_effect=[0, 0, 1, 1]):
            result = await tor_controller.create_circuit([fingerprint])

        assert result == "CIR-FP"
        mock_sleep.assert_awaited()
        mock_ctrl.new_circuit.assert_called_once_with(
            [f"${fingerprint}"], purpose="controller", await_build=True
        )


    @pytest.mark.asyncio
    async def test_controller_create_circuit_fingerprint_still_missing(self, tor_controller):
        """指纹 hop 超时仍不可见时返回 None，不调用 new_circuit"""
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        fingerprint = "B" * 40
        mock_ctrl.get_network_status.side_effect = Exception("missing")
        mock_ctrl.get_network_statuses.return_value = []
        mock_ctrl.get_info.return_value = "NOTICE BOOTSTRAP PROGRESS=50"

        with patch("services.tor_controller_service.asyncio.sleep", new_callable=AsyncMock), \
             patch("services.tor_controller_service.time.time", side_effect=[0, 120, 120]):
            result = await tor_controller.create_circuit([f"${fingerprint.lower()}"])

        assert result is None
        mock_ctrl.new_circuit.assert_not_called()



# -------------- delete_circuit 接口，测试用例 --------------
class TestTorControllerServiceDeleteCircuit:
    @pytest.mark.asyncio
    async def test_controller_delete_circuit_with_no_controller(self, tor_controller):
        """测试控制器未连接时调用 delete_circuit 抛出 RuntimeError"""
        # 确保控制器未初始化
        tor_controller.controller = None
        
        # 调用方法应触发 _get_controller 的异常
        with pytest.raises(RuntimeError, match=r"控制器未连接。请先调用 connect\(\) 并确保连接成功。"):
            await tor_controller.delete_circuit(cir_id="CIR123456")


    @pytest.mark.asyncio
    async def test_controller_delete_circuit_success(self, tor_controller):
        """测试正常删除电路返回 True"""
        # 1. 模拟已连接的控制器（spec=Controller 约束方法存在性）
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 close_circuit 方法正常执行（无异常）
        mock_ctrl.close_circuit.return_value = None
        
        # 3. 调用测试方法
        cir_id = "CIR123456"
        result = await tor_controller.delete_circuit(cir_id=cir_id)
        
        # 4. 断言结果
        assert result is True  # 验证返回值

        # 验证 close_circuit 被正确调用（参数匹配）
        mock_ctrl.close_circuit.assert_called_once_with(cir_id)


    @pytest.mark.asyncio
    async def test_controller_delete_circuit_controller_error(self, tor_controller):
        """测试删除电路触发 ControllerError 时返回 False"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 close_circuit 抛出 ControllerError
        test_cir_id = "CIR654321"
        mock_error = ControllerError(f"关闭电路失败：{test_cir_id} 不存在")
        mock_ctrl.close_circuit.side_effect = mock_error
        
        # 3. 调用测试方法
        result = await tor_controller.delete_circuit(cir_id=test_cir_id)
        
        # 4. 断言结果
        assert result is False  # 验证返回值

        # 验证 close_circuit 被调用（确保方法执行到了关键逻辑）
        mock_ctrl.close_circuit.assert_called_once_with(test_cir_id)


    @pytest.mark.asyncio
    async def test_controller_delete_circuit_empty_cir_id(self, tor_controller):
        """测试空字符串 circuit ID 的边界场景"""
        # 模拟控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 调用空 ID
        result = await tor_controller.delete_circuit(cir_id="")
        
        # 断言：方法应执行 close_circuit（即使 ID 为空，逻辑由业务层处理）
        assert result is True
        mock_ctrl.close_circuit.assert_called_once_with("")


# -------------- get_circuit_info 接口，测试用例 --------------
class TestTorControllerServiceGetCircuitInfo:
    @pytest.mark.asyncio
    async def test_controller_get_circuit_info_with_no_controller(self, tor_controller):
        """测试控制器未连接时调用 get_circuit_info 抛出 RuntimeError"""
        # 确保控制器未初始化
        tor_controller.controller = None
        
        # 调用方法（不传 cir_id）应触发 _get_controller 的异常
        with pytest.raises(RuntimeError, match=r"控制器未连接。请先调用 connect\(\) 并确保连接成功。"):
            await tor_controller.get_circuit_info()


    @pytest.mark.asyncio
    async def test_controller_get_circuit_info_by_cir_id_success(self, tor_controller):
        """测试指定 cir_id 成功获取单个电路信息"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl

        mock_stem_circuit = MagicMock()

        # 2. 模拟 get_circuit 返回单个电路对象
        test_cir_id = "CIR123456"
        mock_ctrl.get_circuit.return_value = mock_stem_circuit
        
        # 3. 调用测试方法（指定 cir_id）
        result = await tor_controller.get_circuit_info(cir_id=test_cir_id)
        
        # 4. 断言结果（验证格式化后的数据结构）
        assert isinstance(result, Dict)
        assert result == {
            'id': mock_stem_circuit.id,
            'status': mock_stem_circuit.status,
            'purpose': mock_stem_circuit.purpose,
            'path': [(hop[0], hop[1]) for hop in mock_stem_circuit.path],
            'hs_state': mock_stem_circuit.hs_state,
            'rend_query': mock_stem_circuit.rend_query,
            'created': mock_stem_circuit.created,
            'reason': mock_stem_circuit.reason,
            'remote_reason': mock_stem_circuit.remote_reason,
            'socks_username': mock_stem_circuit.socks_username,
            'socks_password': mock_stem_circuit.socks_password
        }
        # 验证 get_circuit 被正确调用
        mock_ctrl.get_circuit.assert_called_once_with(test_cir_id)


    @pytest.mark.asyncio
    async def test_controller_get_circuit_info_all_success(self, tor_controller):
        """测试不指定 cir_id 成功获取所有电路信息列表"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl

        mock_circuit1 = MagicMock()
        mock_circuit1.id = "CIR123456"
        mock_circuit1.status = "RUNNING"
        mock_circuit1.purpose = "RELAY"
        mock_circuit1.path = [("relay1", "127.0.0.1:6688")]
        mock_circuit1.hs_state = "ESTABLISHED"
        mock_circuit1.rend_query = "test_query"
        mock_circuit1.created = 1735689700
        mock_circuit1.reason = "REQUESTED"
        mock_circuit1.remote_reason = ""
        mock_circuit1.socks_username = "test_user1"
        mock_circuit1.socks_password = "test_pwd1"
        
        # 2. 模拟 get_circuits 返回多个电路对象（创建第二个模拟电路）
        mock_circuit2 = MagicMock()
        mock_circuit2.id = "CIR654321"
        mock_circuit2.status = "CLOSING"
        mock_circuit2.purpose = "HS_CLIENT"
        mock_circuit2.path = [("relay3", "127.0.0.1:9003")]
        mock_circuit2.hs_state = "ESTABLISHED"
        mock_circuit2.rend_query = "test_query"
        mock_circuit2.created = 1735689700
        mock_circuit2.reason = "REQUESTED"
        mock_circuit2.remote_reason = ""
        mock_circuit2.socks_username = "test_user2"
        mock_circuit2.socks_password = "test_pwd2"
        
        mock_ctrl.get_circuits.return_value = [mock_circuit1, mock_circuit2]
        
        # 3. 调用测试方法（不传 cir_id）
        result = await tor_controller.get_circuit_info()
        
        # 4. 断言结果
        assert isinstance(result, List)
        assert len(result) == 2

        # 验证第一个电路的格式化数据
        assert result[0]['id'] == mock_circuit1.id
        assert result[0]['status'] == mock_circuit1.status

        # 验证第二个电路的格式化数据
        assert result[1]['id'] == mock_circuit2.id
        assert result[1]['hs_state'] == mock_circuit2.hs_state

        # 验证 get_circuits 被调用（无参数）
        mock_ctrl.get_circuits.assert_called_once()


    @pytest.mark.asyncio
    async def test_controller_get_circuit_info_controller_error(self, tor_controller):
        """测试获取电路信息触发 ControllerError 时返回 None"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 get_circuit 抛出 ControllerError（指定 cir_id 场景）
        test_cir_id = "CIR999999"
        mock_error = ControllerError(f"获取电路{test_cir_id}失败：ID不存在")
        mock_ctrl.get_circuit.side_effect = mock_error
        
        # 3. 调用测试方法
        result = await tor_controller.get_circuit_info(cir_id=test_cir_id)
        
        # 4. 断言结果
        assert result is None

        # 验证 get_circuit 被调用
        mock_ctrl.get_circuit.assert_called_once_with(test_cir_id)


    @pytest.mark.asyncio
    async def test_controller_get_circuit_info_empty_cir_id(self, tor_controller):
        """测试空字符串 cir_id 的边界场景"""
        # 模拟控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        mock_ctrl.get_circuits.return_value = []

        # 调用空 cir_id
        result = await tor_controller.get_circuit_info(cir_id="")
        
        # 断言：返回格式化的电路信息（空ID由业务层/底层处理）
        assert result == []
        mock_ctrl.get_circuits.assert_called_once()


@pytest.fixture
def mock_stem_network_status():
    """创建模拟的 RouterStatusEntryV3 对象（模拟真实节点状态数据）"""
    mock_ns = MagicMock(spec=RouterStatusEntryV3)
    mock_ns.nickname = "RelayTest01"
    mock_ns.fingerprint = "1234567890ABCDEF1234567890ABCDEF12345678"
    mock_ns.address = "192.168.1.100"
    mock_ns.or_port = 9001
    mock_ns.dir_port = 9030
    mock_ns.flags = {"Fast", "Stable", "Guard"}  # 集合类型
    mock_ns.bandwidth = 1024 * 1024  # 1MB/s
    mock_ns.version = "0.4.7.13"
    mock_ns.published = "2025-1-1 12::00::00"  # 发布时间
    return mock_ns


# -------------- get_network_statuses 接口，测试用例 --------------
class TestTorControllerServiceGetNetworkStatuses:
    @pytest.mark.asyncio
    async def test_controller_get_network_statuses_with_no_controller(self, tor_controller):
        """测试控制器未连接时调用 get_network_statuses 抛出 RuntimeError"""
        # 确保控制器未初始化
        tor_controller.controller = None
        
        # 调用方法（不传 fingerprint）应触发 _get_controller 的异常
        with pytest.raises(RuntimeError, match=r"控制器未连接。请先调用 connect\(\) 并确保连接成功。"):
            await tor_controller.get_network_statuses()


    @pytest.mark.asyncio
    async def test_controller_get_network_statuses_by_fingerprint_success(self, tor_controller, mock_stem_network_status):
        """测试指定 fingerprint 成功获取单个节点网络状态"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 get_network_status 返回单个 NetworkStatus 对象
        test_fingerprint = "1234567890ABCDEF1234567890ABCDEF12345678"
        mock_ctrl.get_network_status.return_value = mock_stem_network_status
        
        # 3. 调用测试方法（指定 fingerprint）
        result = await tor_controller.get_network_statuses(fingerprint=test_fingerprint)
        
        # 4. 断言结果（验证格式化后的数据结构）
        assert isinstance(result, Dict)
        assert result == {
            'nickname': mock_stem_network_status.nickname,
            'fingerprint': mock_stem_network_status.fingerprint,
            'address': mock_stem_network_status.address,
            'or_port': mock_stem_network_status.or_port,
            'dir_port': mock_stem_network_status.dir_port,
            'flags': list(mock_stem_network_status.flags),  # 集合转列表
            'bandwidth': mock_stem_network_status.bandwidth,
            'version': str(mock_stem_network_status.version),  # Version对象转字符串
            'published': str(mock_stem_network_status.published)  # datetime转字符串
        }
        # 验证 get_network_status 被正确调用
        mock_ctrl.get_network_status.assert_called_once_with(test_fingerprint)


    @pytest.mark.asyncio
    async def test_controller_get_network_statuses_all_success(self, tor_controller, mock_stem_network_status):
        """测试不指定 fingerprint 成功获取所有节点网络状态列表"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 get_network_statuses 返回多个 RouterStatusEntryV3 对象
        # 创建第二个模拟节点
        mock_ns2 = MagicMock(spec=RouterStatusEntryV3)
        mock_ns2.nickname = "RelayTest02"
        mock_ns2.fingerprint = "876543210FEDCBA0876543210FEDCBA087654321"
        mock_ns2.address = "192.168.1.101"
        mock_ns2.or_port = 9002
        mock_ns2.dir_port = 0  # 无目录端口
        mock_ns2.flags = {"Exit", "Fast"}
        mock_ns2.bandwidth = 2 * 1024 * 1024
        mock_ns2.version = None  # 模拟版本为空
        mock_ns2.published =  "2025-1-2 10::00::00"  # 发布时间
        
        mock_ctrl.get_network_statuses.return_value = [mock_stem_network_status, mock_ns2]
        
        # 3. 调用测试方法（不传 fingerprint）
        result = await tor_controller.get_network_statuses()
        
        # 4. 断言结果
        assert isinstance(result, List)
        assert len(result) == 2
        
        # 验证第一个节点的格式化数据
        assert result[0]['nickname'] == mock_stem_network_status.nickname
        assert result[0]['version'] == str(mock_stem_network_status.version)
        
        # 验证第二个节点的格式化数据（覆盖version为空的场景）
        assert result[1]['nickname'] == mock_ns2.nickname
        assert result[1]['version'] == "Unknown"  # 空version转为Unknown
        assert result[1]['dir_port'] == 0
        
        # 验证 get_network_statuses 被调用（无参数）
        mock_ctrl.get_network_statuses.assert_called_once()


    @pytest.mark.asyncio
    async def test_controller_get_network_statuses_controller_error(self, tor_controller):
        """测试获取网络状态触发 ControllerError 时返回 None"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 get_network_status 抛出 ControllerError（指定 fingerprint 场景）
        test_fingerprint = "FFFFFFFFFFFFFFF1234567890ABCDEF12345678"
        mock_error = ControllerError(f"获取节点{test_fingerprint}状态失败：指纹不存在")
        mock_ctrl.get_network_status.side_effect = mock_error
        
        # 3. 调用测试方法
        result = await tor_controller.get_network_statuses(fingerprint=test_fingerprint)
        
        # 4. 断言结果
        assert result is None

        # 验证 get_network_status 被调用
        mock_ctrl.get_network_status.assert_called_once_with(test_fingerprint)


    @pytest.mark.asyncio
    async def test_controller_get_network_statuses_empty_fingerprint(self, tor_controller, mock_stem_network_status):
        """测试空字符串 fingerprint 的边界场景"""
        # 模拟控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        mock_ctrl.get_network_status.return_value = mock_stem_network_status
        
        # 调用空 fingerprint
        result = await tor_controller.get_network_statuses(fingerprint="test")
        
        # 断言：返回格式化的节点信息（空指纹由业务层/底层处理）
        assert isinstance(result, Dict)

        assert result['fingerprint'] == mock_stem_network_status.fingerprint
        mock_ctrl.get_network_status.assert_called_once_with("test")


    @pytest.mark.asyncio
    async def test_controller_get_network_statuses_none_fingerprint(self, tor_controller, mock_stem_network_status):
        """测试 fingerprint 为 None 的场景（默认值）"""
        # 模拟控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        mock_ctrl.get_network_statuses.return_value = [mock_stem_network_status]
        
        # 调用时不传参数（等价于 fingerprint=None）
        result = await tor_controller.get_network_statuses()
        
        # 断言：返回列表且包含单个节点
        assert isinstance(result, List)
        assert len(result) == 1
        assert result[0]['nickname'] == mock_stem_network_status.nickname
        mock_ctrl.get_network_statuses.assert_called_once()


@pytest.fixture
def mock_stem_stream():
    """创建模拟的 Stream 对象（模拟真实流数据）"""
    # 模拟 Stream 实例
    mock_stream = MagicMock()
    # 为 Stream 设置属性（匹配格式化字段）
    mock_stream.id = 123
    mock_stream.status = "NEW"
    mock_stream.circ_id = "CIR123456"
    mock_stream.target = "192.168.1.100:8080"
    mock_stream.purpose = "USER"
    mock_stream.source = "127.0.0.1:54321"
    
    return mock_stream


# -------------- get_streams 接口，测试用例 --------------
class TestTorControllerServiceGetStreams:
    @pytest.mark.asyncio
    async def test_controller_get_streams_with_no_controller(self, tor_controller):
        """测试控制器未连接时调用 get_streams 抛出 RuntimeError"""
        # 确保控制器未初始化
        tor_controller.controller = None
        
        # 调用方法应触发 _get_controller 的异常
        with pytest.raises(RuntimeError, match=r"控制器未连接。请先调用 connect\(\) 并确保连接成功。"):
            await tor_controller.get_streams()


    @pytest.mark.asyncio
    async def test_controller_get_streams_success(self, tor_controller, mock_stem_stream):
        """测试成功获取流信息列表"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 get_streams 返回多个 Stream 对象
        # 创建第二个模拟流
        mock_stream2 = MagicMock()
        mock_stream2.id = 456
        mock_stream2.status = "SUCCEEDED"
        mock_stream2.circ_id = "CIR654321"
        mock_stream2.target = "10.0.0.1:443"
        mock_stream2.purpose = "HS_CLIENT"
        mock_stream2.source = "127.0.0.1:67890"
        
        mock_ctrl.get_streams.return_value = [mock_stem_stream, mock_stream2]
        
        # 3. 调用测试方法
        result = await tor_controller.get_streams()
        
        # 4. 断言结果
        assert isinstance(result, List)
        assert len(result) == 2
        
        # 验证第一个流的格式化数据
        assert result[0] == {
            'id': mock_stem_stream.id,
            'status': mock_stem_stream.status,
            'circuit_id': mock_stem_stream.circ_id,
            'target': mock_stem_stream.target,
            'purpose': mock_stem_stream.purpose,
            'source': mock_stem_stream.source
        }
        
        # 验证第二个流的格式化数据
        assert result[1]['id'] == mock_stream2.id
        assert result[1]['status'] == mock_stream2.status
        assert result[1]['purpose'] == mock_stream2.purpose
        
        # 验证 get_streams 被调用（无参数）
        mock_ctrl.get_streams.assert_called_once()


    @pytest.mark.asyncio
    async def test_controller_get_streams_empty_list(self, tor_controller):
        """测试获取到空流列表的边界场景"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 get_streams 返回空列表
        mock_ctrl.get_streams.return_value = []
        
        # 3. 调用测试方法
        result = await tor_controller.get_streams()
        
        # 4. 断言结果：返回空列表（而非 None）
        assert isinstance(result, List)

        assert len(result) == 0
        mock_ctrl.get_streams.assert_called_once()


    @pytest.mark.asyncio
    async def test_controller_get_streams_controller_error(self, tor_controller):
        """测试获取流信息触发 ControllerError 时返回 None"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 get_streams 抛出 ControllerError
        mock_error = ControllerError("获取流信息失败：控制器连接超时")
        mock_ctrl.get_streams.side_effect = mock_error
        
        # 3. 调用测试方法
        result = await tor_controller.get_streams()
        
        # 4. 断言结果
        assert result is None

        # 验证 get_streams 被调用
        mock_ctrl.get_streams.assert_called_once()


@pytest.fixture
def mock_built_circuit():
    """模拟已建立（BUILT）的电路对象"""
    mock_circuit = MagicMock()
    mock_circuit.id = "CIR123456"
    mock_circuit.status = "BUILT"  # 关键：电路状态为已建立
    return mock_circuit

@pytest.fixture
def mock_unbuilt_circuit():
    """模拟未建立的电路对象"""
    mock_circuit = MagicMock()
    mock_circuit.id = "CIR654321"
    mock_circuit.status = "CLOSING"  # 非BUILT状态
    return mock_circuit


# -------------- start_global_stream_listener 接口，测试用例 --------------
class TestTorControllerServiceStartGlobalStreamListener:
    @pytest.mark.asyncio
    async def test_controller_start_listener_no_controller(self, tor_controller):
        """测试控制器未连接时调用方法抛出 RuntimeError"""
        # 确保控制器未初始化
        tor_controller.controller = None
        
        # 调用方法应触发 _get_controller 的异常
        with pytest.raises(RuntimeError, match=r"控制器未连接。请先调用 connect\(\) 并确保连接成功。"):
            await tor_controller.start_global_stream_listener(circuit_id="CIR123456")


    @pytest.mark.asyncio
    async def test_controller_start_listener_circuit_not_exist(self, tor_controller):
        """测试电路不存在时返回 False"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 get_circuit 返回 None（电路不存在）
        test_cir_id = "CIR999999"
        mock_ctrl.get_circuit.return_value = None
        
        # 3. 调用测试方法
        result = await tor_controller.start_global_stream_listener(circuit_id=test_cir_id)
        
        # 4. 断言结果
        assert result is False

        # 验证 get_circuit 被调用
        mock_ctrl.get_circuit.assert_called_once_with(test_cir_id)
        # 验证未执行后续逻辑（如 set_conf）
        mock_ctrl.set_conf.assert_not_called()


    @pytest.mark.asyncio
    async def test_controller_start_listener_circuit_not_built(self, tor_controller, mock_unbuilt_circuit):
        """测试电路存在但未建立时返回 False """
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 get_circuit 返回非BUILT状态的电路
        test_cir_id = mock_unbuilt_circuit.id
        mock_ctrl.get_circuit.return_value = mock_unbuilt_circuit
        
        # 3. 调用测试方法
        result = await tor_controller.start_global_stream_listener(circuit_id=test_cir_id)
        
        # 4. 断言结果
        assert result is False

        mock_ctrl.get_circuit.assert_called_once_with(test_cir_id)
        mock_ctrl.set_conf.assert_not_called()


    @pytest.mark.asyncio
    async def test_controller_start_listener_get_circuit_exception(self, tor_controller):
        """测试获取电路信息抛异常时返回 False"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 get_circuit 抛异常
        test_cir_id = "CIR111111"
        mock_error = ControllerError("获取电路信息超时")
        mock_ctrl.get_circuit.side_effect = mock_error
        
        # 3. 调用测试方法
        result = await tor_controller.start_global_stream_listener(circuit_id=test_cir_id)
        
        # 4. 断言结果
        assert result is False

        mock_ctrl.get_circuit.assert_called_once_with(test_cir_id)
        mock_ctrl.set_conf.assert_not_called()


    @pytest.mark.asyncio
    async def test_controller_start_listener_already_running_same_circuit(self, tor_controller, mock_built_circuit):
        """测试监听器已启动（同电路）时直接返回 True"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl

        tor_controller.stop_global_stream_listener = MagicMock()
        
        # 2. 模拟 get_circuit 返回BUILT状态的电路
        test_cir_id = mock_built_circuit.id
        mock_ctrl.get_circuit.return_value = mock_built_circuit

        # 2. 模拟监听器已启动且电路ID匹配
        tor_controller._global_stream_listener = MagicMock()  # 模拟已启动的监听器
        tor_controller._global_circuit_id = mock_built_circuit.id
        
        # 3. 调用测试方法（传入相同电路ID）
        result = await tor_controller.start_global_stream_listener(circuit_id=mock_built_circuit.id)
        
        # 4. 断言结果
        assert result is True

        # 验证未执行任何后续逻辑（如 get_circuit、set_conf、停止监听器）
        mock_ctrl.get_circuit.assert_called_once_with(test_cir_id)
        mock_ctrl.set_conf.assert_not_called()
        tor_controller.stop_global_stream_listener.assert_not_called()


    @pytest.mark.asyncio
    async def test_controller_start_listener_already_running_diff_circuit(self, tor_controller, mock_built_circuit):
        """测试监听器已启动（不同电路）时先停止旧监听器，再启动新的"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl

        tor_controller.stop_global_stream_listener = MagicMock()
        
        # 2. 模拟监听器已启动但电路ID不同
        tor_controller._global_stream_listener = MagicMock()  # 旧监听器
        tor_controller._global_circuit_id = "GLOBAL_CIR000000"
        mock_ctrl.get_circuit.return_value = mock_built_circuit
        
        # 3. 调用测试方法（传入新电路ID）
        new_cir_id = mock_built_circuit.id
        result = await tor_controller.start_global_stream_listener(circuit_id=new_cir_id)
        
        # 4. 断言结果
        assert result is True

        # 验证先停止旧监听器
        tor_controller.stop_global_stream_listener.assert_called_once()

        # 验证设置配置
        mock_ctrl.set_conf.assert_called_once_with('__LeaveStreamsUnattached', '1')

        # 验证全局变量更新
        assert tor_controller._global_circuit_id == new_cir_id


    @pytest.mark.asyncio
    async def test_controller_start_listener_success(self, tor_controller, mock_built_circuit):
        """测试正常启动全局流监听器"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        tor_controller.stop_global_stream_listener = MagicMock()
        
        # 2. 模拟获取到已建立的电路
        test_cir_id = mock_built_circuit.id
        mock_ctrl.get_circuit.return_value = mock_built_circuit
        
        # 3. 确保全局监听器未启动
        tor_controller._global_stream_listener = None
        tor_controller._global_circuit_id = None
        
        # 4. 调用测试方法
        result = await tor_controller.start_global_stream_listener(circuit_id=test_cir_id)
        
        # 5. 断言结果
        assert result is True

        # 验证 get_circuit 被调用
        mock_ctrl.get_circuit.assert_called_once_with(test_cir_id)
        # 验证设置 __LeaveStreamsUnattached 配置
        mock_ctrl.set_conf.assert_called_once_with('__LeaveStreamsUnattached', '1')

        # 验证全局电路ID更新
        assert tor_controller._global_circuit_id == test_cir_id

        # 验证未调用停止监听器方法
        tor_controller.stop_global_stream_listener.assert_not_called()


    @pytest.mark.asyncio
    async def test_controller_start_listener_set_conf_failed(self, tor_controller, mock_built_circuit):
        """测试设置 __LeaveStreamsUnattached 配置失败时返回 False"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟获取到已建立的电路，但 set_conf 抛异常
        test_cir_id = mock_built_circuit.id
        mock_ctrl.get_circuit.return_value = mock_built_circuit
        mock_error = ControllerError("设置配置失败：权限不足")
        mock_ctrl.set_conf.side_effect = mock_error
        
        # 3. 调用测试方法
        result = await tor_controller.start_global_stream_listener(circuit_id=test_cir_id)
        
        # 4. 断言结果
        assert result is False

        # 验证 set_conf 被调用
        mock_ctrl.set_conf.assert_called_once_with('__LeaveStreamsUnattached', '1')

        # 验证全局电路ID未更新
        assert tor_controller._global_circuit_id is None
        assert tor_controller._global_circuit_listener is None
        assert tor_controller._global_stream_listener is None


    @pytest.mark.asyncio
    async def test_controller_start_listener_assign_listeners(self, tor_controller, mock_built_circuit):
        """测试启动监听器时正确赋值 _global_stream_listener 和 _global_circuit_listener"""
        # 1. 模拟依赖
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 add_event_listener 返回具体的监听器对象（便于后续断言）
        mock_stream_listener = MagicMock(name="stream_listener")
        mock_circuit_listener = MagicMock(name="circuit_listener")

        # 模拟 add_event_listener 第一次调用返回流监听器，第二次返回电路监听器
        mock_ctrl.add_event_listener.side_effect = [mock_stream_listener, mock_circuit_listener]
        
        # 3. 模拟电路检查通过
        mock_ctrl.get_circuit.return_value = mock_built_circuit
        mock_ctrl.set_conf.return_value = None
        
        # 4. 确保初始变量为 None
        tor_controller._global_stream_listener = None
        tor_controller._global_circuit_listener = None

        # 5. 调用测试方法
        test_cir_id = mock_built_circuit.id
        result = await tor_controller.start_global_stream_listener(circuit_id=test_cir_id)
        
        # 6. 核心断言：验证变量被正确赋值
        assert result is True

        # 获取 add_event_listener 的所有调用参数
        call_args_list = mock_ctrl.add_event_listener.call_args_list
        
        # 第一个调用是流监听器
        stream_listener_arg = call_args_list[0][0][0]
        assert stream_listener_arg is tor_controller._global_stream_listener
        
        # 第二个调用是电路监听器
        circuit_listener_arg = call_args_list[1][0][0]
        assert circuit_listener_arg is tor_controller._global_circuit_listener


        # 同时验证电路ID赋值（关联校验）
        assert tor_controller._global_circuit_id == test_cir_id
        
        # 7. 额外验证：add_event_listener 被正确调用（可选）
        assert mock_ctrl.add_event_listener.call_count == 2

        # 验证第一次调用（流事件监听器）
        mock_ctrl.add_event_listener.assert_any_call(
            tor_controller._global_stream_listener, EventType.STREAM
        )
        # 验证第二次调用（电路事件监听器）
        mock_ctrl.add_event_listener.assert_any_call(
            tor_controller._global_circuit_listener, EventType.CIRC
        )


@pytest.fixture
def mock_listeners():
    """创建模拟的流/电路监听器对象（可调用的函数/对象）"""
    mock_stream_listener = MagicMock(name="stream_listener", spec=callable)
    mock_circuit_listener = MagicMock(name="circuit_listener", spec=callable)
    return mock_stream_listener, mock_circuit_listener


# -------------- stop_global_stream_listener 接口，测试用例 --------------
class TestTorControllerServiceStopGlobalStreamListener:
    def test_controller_stop_listener_no_controller(self, tor_controller):
        """测试控制器未连接时调用方法抛出 RuntimeError"""
        # 确保控制器未初始化
        tor_controller.controller = None
        
        # 调用方法应触发 _get_controller 的异常
        with pytest.raises(RuntimeError, match=r"控制器未连接。请先调用 connect\(\) 并确保连接成功。"):
            tor_controller.stop_global_stream_listener()


    def test_controller_stop_listener_with_listeners(self, tor_controller, mock_listeners):
        """测试监听器已存在时正常停止（移除监听器+重置配置+清空变量）"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟全局监听器已赋值（启动后的状态）
        mock_stream_listener, mock_circuit_listener = mock_listeners
        tor_controller._global_stream_listener = mock_stream_listener
        tor_controller._global_circuit_listener = mock_circuit_listener
        tor_controller._global_circuit_id = "CIR123456"
        
        # 3. 调用测试方法
        tor_controller.stop_global_stream_listener()
        
        # 4. 核心断言
        # 验证1：移除流监听器方法被调用
        mock_ctrl.remove_event_listener.assert_any_call(mock_stream_listener)
        # 验证2：移除电路监听器方法被调用
        mock_ctrl.remove_event_listener.assert_any_call(mock_circuit_listener)
        # 验证3：重置 __LeaveStreamsUnattached 配置为 0
        mock_ctrl.set_conf.assert_called_once_with('__LeaveStreamsUnattached', '0')

        # 验证4：全局变量被清空
        assert tor_controller._global_stream_listener is None
        assert tor_controller._global_circuit_listener is None
        assert tor_controller._global_circuit_id is None


    def test_controller_stop_listener_no_listeners(self, tor_controller):
        """测试监听器不存在时跳过移除逻辑（仅重置配置+清空变量）"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟全局监听器未赋值（初始状态）
        tor_controller._global_stream_listener = None
        tor_controller._global_circuit_listener = None
        tor_controller._global_circuit_id = "CIR654321"
        
        # 3. 调用测试方法
        tor_controller.stop_global_stream_listener()
        
        # 4. 核心断言
        # 验证1：未调用移除监听器方法
        mock_ctrl.remove_event_listener.assert_not_called()
        # 验证2：仍调用重置配置方法
        mock_ctrl.set_conf.assert_called_once_with('__LeaveStreamsUnattached', '0')
        # 验证3：全局变量被清空
        assert tor_controller._global_stream_listener is None
        assert tor_controller._global_circuit_listener is None
        assert tor_controller._global_circuit_id is None


    def test_controller_stop_listener_remove_listener_exception(self, tor_controller, mock_listeners):
        """测试移除监听器抛异常时仍继续执行（捕获异常+清空变量）"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟移除监听器时抛异常
        mock_stream_listener, mock_circuit_listener = mock_listeners
        mock_ctrl.remove_event_listener.side_effect = ControllerError("移除监听器失败：不存在")
        
        # 3. 模拟全局监听器已赋值
        tor_controller._global_stream_listener = mock_stream_listener
        tor_controller._global_circuit_listener = mock_circuit_listener
        tor_controller._global_circuit_id = "CIR999999"
        
        # 4. 调用测试方法（不会抛异常）
        tor_controller.stop_global_stream_listener()
        
        # 5. 核心断言
        # 验证1：移除监听器方法仍被调用（即使抛异常）
        assert mock_ctrl.remove_event_listener.call_count == 2
        mock_ctrl.remove_event_listener.assert_any_call(mock_stream_listener)
        mock_ctrl.remove_event_listener.assert_any_call(mock_circuit_listener)
        # 验证2：仍调用重置配置方法
        mock_ctrl.set_conf.assert_called_once_with('__LeaveStreamsUnattached', '0')

        # 验证3：全局变量仍被清空（异常不影响最终状态）
        assert tor_controller._global_stream_listener is None
        assert tor_controller._global_circuit_listener is None
        assert tor_controller._global_circuit_id is None


    def test_controller_stop_listener_set_conf_exception(self, tor_controller, mock_listeners):
        """测试重置配置抛异常时仍清空变量"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟 set_conf 抛异常，移除监听器正常
        mock_ctrl.set_conf.side_effect = ControllerError("设置配置失败：权限不足")
        
        # 3. 模拟全局监听器已赋值
        mock_stream_listener, mock_circuit_listener = mock_listeners
        tor_controller._global_stream_listener = mock_stream_listener
        tor_controller._global_circuit_listener = mock_circuit_listener
        tor_controller._global_circuit_id = "CIR111111"
        
        # 4. 调用测试方法（不会抛异常）
        tor_controller.stop_global_stream_listener()
        
        # 5. 核心断言
        # 验证1：移除监听器方法正常调用
        mock_ctrl.remove_event_listener.assert_any_call(mock_stream_listener)
        mock_ctrl.remove_event_listener.assert_any_call(mock_circuit_listener)
        # 验证2：重置配置方法被调用（即使抛异常）
        mock_ctrl.set_conf.assert_called_once_with('__LeaveStreamsUnattached', '0')

        # 验证3：全局变量仍被清空
        assert tor_controller._global_stream_listener is None
        assert tor_controller._global_circuit_listener is None
        assert tor_controller._global_circuit_id is None


    def test_controller_stop_listener_partial_listeners(self, tor_controller, mock_listeners):
        """测试仅存在一个监听器时的边界场景（只移除存在的监听器）"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl
        
        # 2. 模拟仅流监听器存在，电路监听器不存在
        mock_stream_listener, mock_circuit_listener = mock_listeners
        tor_controller._global_stream_listener = mock_stream_listener
        tor_controller._global_circuit_listener = None
        tor_controller._global_circuit_id = "CIR222222"
        
        # 3. 调用测试方法
        tor_controller.stop_global_stream_listener()
        
        # 4. 核心断言
        # 验证1：仅移除流监听器
        mock_ctrl.remove_event_listener.assert_called_once_with(mock_stream_listener)
        # 验证2：重置配置方法被调用
        mock_ctrl.set_conf.assert_called_once_with('__LeaveStreamsUnattached', '0')

        # 验证3：全局变量全部清空
        assert tor_controller._global_stream_listener is None
        assert tor_controller._global_circuit_listener is None
        assert tor_controller._global_circuit_id is None


# -------------- wait_for_tor_node 接口，测试用例 --------------
class TestTorControllerServiceWaitForTorNode:
    @pytest.mark.asyncio
    async def test_controller_wait_for_tor_node_client_role(self, tor_controller):
        """测试角色为 Client 时直接返回固定格式数据"""

        """创建模拟配置对象"""
        # 1. 配置为 client 角色
        mock_config = MagicMock(spec=TorNodeConfig)
        mock_config.role = "client"
        mock_config.nick = "da90c787510"
        mock_config.pwd = StemConfig.DEFAULT_TOR_PASSWORD
        mock_config.or_port = 9002
        mock_config.socks_port = 9060
        mock_config.control_port = 9061
        mock_config.dir_port = 9040
        mock_config.outer_ip_addr = "10.0.0.1"
        mock_config.dir_auths = None
        mock_config.image = ContainerConfig.DEFAULT_IMAGE
        mock_config.network_mode = ContainerConfig.DEFAULT_NETWORK_MODE

        """创建 TorControllerService 实例"""
        tor_controller = TorControllerService(mock_config)

        # 2. 模拟已连接的控制器
        tor_controller._get_controller = MagicMock(spec=Controller)
        
        # 3. 调用测试方法
        nickname = "test-client"
        container_id = "container-123"
        result = await tor_controller.wait_for_tor_node(
            nickname=nickname,
            container_id=container_id
        )
        
        # 4. 核心断言
        assert result == {
            'nickname': nickname,
            'fingerprint': '',
            'address': mock_config.outer_ip_addr,
            'or_port': mock_config.or_port,
            'dir_port': None,
            'flags': [],
            'bandwidth': None,
            'version': '',
            'published': '',
            'container_id': container_id
        }

        # 验证未执行后续逻辑（如 _get_controller、循环）
        assert tor_controller._get_controller.call_count == 0


    @pytest.mark.asyncio
    async def test_controller_wait_for_tor_node_success_immediate(self, tor_controller):
        """测试非Client角色，首次尝试就获取到节点信息"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl

        nickname = "test-relay"
        container_id = "container-456"
        
        # 2. 模拟 Controller 返回数据
        mock_fingerprint = "1234567890ABCDEF1234567890ABCDEF12345678"
        mock_version = "0.4.7.13"
        mock_ctrl.get_info.side_effect = [
            "BOOTSTRAP PROGRESS=100",  # status/bootstrap-phase
            mock_fingerprint,           # fingerprint
            mock_version                # version
        ]
        
        # 3. 补丁 time.time 固定时间（避免超时判断干扰）
        with patch("time.time") as mock_time, \
            patch("asyncio.sleep") as mock_sleep:
            mock_time.return_value = 1000.0  # 起始时间
            # 调用测试方法
            result = await tor_controller.wait_for_tor_node(
                nickname=nickname,
                container_id=container_id,
                max_wait_time=30,
                check_interval=1
            )
        
        # 4. 核心断言
        assert result == {
            'nickname': nickname,
            'fingerprint': mock_fingerprint,
            'address': tor_controller.config.outer_ip_addr,
            'or_port': int(tor_controller.config.or_port),
            'dir_port': int(tor_controller.config.dir_port),
            'flags': [],
            'bandwidth': None,
            'version': mock_version,
            'published': time.strftime("%Y-%m-%d %H:%M:%S"),
            'container_id': container_id
        }

        # 验证 get_info 调用
        assert mock_ctrl.get_info.call_count == 3
        mock_ctrl.get_info.assert_any_call("status/bootstrap-phase")
        mock_ctrl.get_info.assert_any_call("fingerprint", None)
        mock_ctrl.get_info.assert_any_call("version", "Unknown")

        # 验证未调用 asyncio.sleep（首次就成功）
        assert mock_sleep.call_count == 0


    @pytest.mark.asyncio
    async def test_controller_wait_for_tor_node_retry_fingerprint_empty(self, tor_controller):
        """测试指纹为空时重试，第二次获取到指纹"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl

        nickname = "test-relay-retry"
        container_id = "container-789"
        
        # 2. 模拟 get_info 第一次返回空指纹，第二次返回有效指纹
        mock_fingerprint = "876543210FEDCBA0876543210FEDCBA087654321"
        # side_effect 按调用顺序返回：bootstrap状态 → 空指纹 → bootstrap状态 → 有效指纹 → 版本
        mock_ctrl.get_info.side_effect = [
            "BOOTSTRAP PROGRESS=50", None,
            "BOOTSTRAP PROGRESS=100", mock_fingerprint, "0.4.7.13"
        ]
        
        # 3. 补丁 time.time 和 asyncio.sleep
        with patch("time.time") as mock_time, \
             patch("asyncio.sleep", new=AsyncMock()) as mock_sleep:
            # 模拟时间递增（避免超时）
            current_time = 1000.0
            def mock_time_func():
                nonlocal current_time
                # 每次调用返回当前时间，然后轻微递增（模拟时间流逝）
                ret = current_time
                current_time += 0.1
                return ret
            
            mock_time.side_effect = mock_time_func

            # 调用测试方法
            result = await tor_controller.wait_for_tor_node(
                nickname=nickname,
                container_id=container_id,
                max_wait_time=30,
                check_interval=1
            )
        
        # 验证结果
        assert result["fingerprint"] == mock_fingerprint
        assert result["nickname"] == nickname

        # 4. 核心断言
        # 验证 sleep 被调用一次（重试间隔）
        mock_sleep.assert_called_once_with(1)
        
        # 验证 get_info 调用次数（两次循环，共 2*2 +1=5 次？实际按调用顺序：

        assert mock_ctrl.get_info.call_count == 5
        # 第一次循环：bootstrap → 空指纹；第二次循环：bootstrap → 有效指纹 → 版本


    @pytest.mark.asyncio
    async def test_controller_wait_for_tor_node_timeout(self, tor_controller):
        """测试等待超时后返回默认数据"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl

        nickname = "test-relay-timeout"
        container_id = "container-000"
        
        # 2. 模拟指纹始终为空
        mock_ctrl.get_info.side_effect = [
            "BOOTSTRAP PROGRESS=80", None  # 每次循环都返回空指纹
        ]
        
        # 3. 补丁 time.time 模拟超时
        with patch("time.time") as mock_time, \
             patch("asyncio.sleep", new=AsyncMock()) as mock_sleep:
            
            call_count = [0]  # 用列表存储，实现可变状态
            start_time_val = 1000.0
            timeout_time_val = start_time_val + 5  # max_wait_time=5

            def mock_time_func():
                if call_count[0] == 0:
                    # 第一次调用：返回开始时间
                    call_count[0] += 1
                    return start_time_val
                else:
                    # 后续所有调用：返回超时时间
                    return timeout_time_val + 1.0
            
            mock_time.side_effect = mock_time_func

            # 调用测试方法（max_wait_time=5，check_interval=3）
            result = await tor_controller.wait_for_tor_node(
                nickname=nickname,
                container_id=container_id,
                max_wait_time=5,
                check_interval=3
            )
        
        # 4. 核心断言
        assert result == {
            'nickname': nickname,
            'fingerprint': '',
            'address': tor_controller.config.outer_ip_addr,
            'or_port': tor_controller.config.or_port,
            'dir_port': None,
            'flags': [],
            'bandwidth': None,
            'version': '',
            'published': '',
            'container_id': container_id
        }


    @pytest.mark.asyncio
    async def test_controller_wait_for_tor_node_exception_retry(self, tor_controller):
        """测试捕获异常后重试，最终成功"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl

        nickname = "test-relay-exception"
        container_id = "container-111"
        
        # 2. 模拟第一次调用抛异常，第二次成功
        mock_fingerprint = "11223344556677889900AABBCCDDEEFF11223344"
        # 第一次调用抛异常，第二次返回正常控制器
        mock_get_controller = MagicMock(side_effect=[
            ControllerError("连接失败"),  # 第一次调用 _get_controller 抛异常
            mock_ctrl                     # 第二次调用返回正常控制器
        ])
        # 覆盖 service 的 _get_controller 方法为 Mock 对象
        tor_controller._get_controller = mock_get_controller

        mock_ctrl.get_info.side_effect = [
            "BOOTSTRAP PROGRESS=100", mock_fingerprint, "0.4.7.13"
        ]
        
        # 3. 补丁 time.time 和 asyncio.sleep
        with patch("time.time") as mock_time, \
             patch("asyncio.sleep", new=AsyncMock()) as mock_sleep:
                        
            call_count = [0]  # 用列表存储，实现可变状态
            start_time_val = 1000.0
            timeout_time_val = start_time_val + 5  # max_wait_time=5

            def mock_time_func():
                if call_count[0] == 0:
                    # 第一次调用：返回开始时间
                    call_count[0] += 1
                    return start_time_val
                else:
                    # 后续所有调用：返回超时时间
                    return timeout_time_val + 1.0
            
            mock_time.side_effect = mock_time_func
            
            # 调用测试方法
            result = await tor_controller.wait_for_tor_node(
                nickname=nickname,
                container_id=container_id,
                check_interval=1
            )
        
        # 4. 核心断言
        assert result['fingerprint'] == mock_fingerprint
        
        # 验证 sleep 被调用一次（异常后重试）
        mock_sleep.assert_called_once_with(1)


    @pytest.mark.asyncio
    async def test_controller_wait_for_tor_node_address_fallback(self, tor_controller):
        """测试 outer_ip_addr 为空时，从控制器获取地址"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl

        # 设置 outer_ip_addr 为空
        tor_controller.config.outer_ip_addr = None
        nickname = "test-relay-addr"
        container_id = "container-222"
        
        # 2. 模拟从控制器获取地址
        mock_fingerprint = "556677889900AABBCCDDEEFF11223344556677"
        mock_address = "10.0.0.2"
        mock_ctrl.get_info.side_effect = [
            "BOOTSTRAP PROGRESS=100",  # bootstrap
            mock_fingerprint,          # fingerprint
            mock_address,              # address
            "0.4.7.13"                 # version
        ]
        
        # 3. 调用测试方法
        with patch("time.time") as mock_time:
            mock_time.return_value = 1000.0
            result = await tor_controller.wait_for_tor_node(
                nickname=nickname,
                container_id=container_id
            )
        
        # 4. 核心断言
        assert result['address'] == mock_address
        mock_ctrl.get_info.assert_any_call("address", None)


    @pytest.mark.asyncio
    async def test_controller_wait_for_tor_node_bootstrap_exception(self, tor_controller):
        """测试获取 bootstrap 状态抛异常，不影响后续逻辑"""
        # 1. 模拟已连接的控制器
        mock_ctrl = MagicMock(spec=Controller)
        tor_controller.controller = mock_ctrl

        nickname = "test-relay-bootstrap-ex"
        container_id = "container-333"
        
        # 2. 模拟获取 bootstrap 状态抛异常，其他正常
        mock_ctrl.get_info.side_effect = [
            ControllerError("获取bootstrap失败"),  # 第一次 get_info(bootstrap)
            "1234567890ABCDEF1234567890ABCDEF12345678",  # fingerprint
            "0.4.7.13"  # version
        ]
        
        # 3. 调用测试方法
        with patch("time.time") as mock_time:
            mock_time.return_value = 1000.0
            result = await tor_controller.wait_for_tor_node(
                nickname=nickname,
                container_id=container_id
            )
        
        # 4. 核心断言
        assert result['fingerprint'] is not None  # 仍成功获取指纹