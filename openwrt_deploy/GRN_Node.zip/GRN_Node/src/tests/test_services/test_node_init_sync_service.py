import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from generated import vps_management_pb2
from services.node_init_sync_service import (
    NodeInitSyncService,
    LINK_STATUS_NORMAL,
    LINK_STATUS_CREATING,
    LINK_STATUS_DESTROYING,
)


@pytest.fixture
def deps():
    context = MagicMock()
    context.node_code = "node-1"
    context.relays = {}
    context.dir_auth = []
    reporter = AsyncMock()
    node_service = AsyncMock()
    relay_service = AsyncMock()
    link_service = MagicMock()
    link_service.active_link_ids = MagicMock(return_value=[])
    link_service.find_client_relay_for_link = MagicMock(return_value=None)
    link_service.has_local_link = MagicMock(return_value=False)
    link_service.local_link_matches = MagicMock(return_value=False)
    link_service.delete_circuit = AsyncMock()
    link_service.create_circuit_with_link = AsyncMock(return_value=(None, None))
    return {
        "context": context,
        "reporter": reporter,
        "node_service": node_service,
        "relay_service": relay_service,
        "link_service": link_service,
    }


@pytest.fixture
def service(deps):
    svc = NodeInitSyncService(
        deps["context"],
        deps["reporter"],
        deps["node_service"],
        deps["relay_service"],
        deps["link_service"],
    )
    svc.logger = MagicMock()
    return svc


class TestNodeInitSyncService:
    def test_da_info_to_dir_auth(self, service):
        da = MagicMock(
            nick="n1",
            ip_address="1.1.1.1",
            or_port=9001,
            v3_ident="v3",
            fingerprint="fp",
        )
        assert service._da_info_to_dir_auth(da)["nick"] == "n1"

    def test_is_da_consistent(self, service):
        local = [{"nick": "a", "ip_address": "1.1.1.1", "or_port": 1, "v3_ident": "v", "fingerprint": "f"}]
        remote = [{"nick": "a", "address": "1.1.1.1", "orport": 1, "v3ident": "v", "fingerprint": "f"}]
        assert service._is_da_consistent(local, remote) is True
        assert service._is_da_consistent(local, []) is False

    def test_collect_expected_link_ids(self, service):
        parent = MagicMock(link_id="1")
        sub = MagicMock(link_id="2")
        parent.sub_links = [sub]
        assert service._collect_expected_link_ids([parent]) == {"1", "2"}

    def test_should_destroy_local_relay(self, service):
        assert service._should_destroy_local_relay("r1", None) is True
        expected = MagicMock(status=vps_management_pb2.RelayStatus.RELAY_DESTROYING)
        assert service._should_destroy_local_relay("r1", expected) is True
        expected.status = vps_management_pb2.RelayStatus.RELAY_RUNNING
        assert service._should_destroy_local_relay("r1", expected) is False

    def test_relay_attributes_mismatch(self, service):
        local = MagicMock(fingerprint="aa", relay_code="r1")
        expected = MagicMock(fingerprint="AA")
        assert service._relay_attributes_mismatch(local, expected) is False
        expected.fingerprint = "BB"
        assert service._relay_attributes_mismatch(local, expected) is True

    def test_attach_local_link_ids(self, service, deps):
        deps["link_service"].active_link_ids.return_value = ["10", "bad", "11"]
        request = MagicMock()
        request.local_link_ids = []
        service._attach_local_link_ids(request)
        assert list(request.local_link_ids) == [10, 11]

    @pytest.mark.asyncio
    async def test_sync_after_reconnect_rpc_failure(self, service):
        stub = MagicMock()
        stub.InitNodeSync = AsyncMock(side_effect=RuntimeError("down"))
        assert await service.sync_after_reconnect(stub) is False

    @pytest.mark.asyncio
    async def test_sync_after_reconnect_unsuccessful(self, service):
        stub = MagicMock()
        resp = MagicMock(success=False, message="no")
        stub.InitNodeSync = AsyncMock(return_value=resp)
        assert await service.sync_after_reconnect(stub) is False

    @pytest.mark.asyncio
    async def test_sync_after_reconnect_success(self, service, deps):
        stub = MagicMock()
        resp = MagicMock(
            success=True,
            message="ok",
            sync_at="t",
            da_list=[],
            expected_relays=[],
            links=[],
        )
        stub.InitNodeSync = AsyncMock(return_value=resp)
        with patch.object(service, "_reconcile_da", new=AsyncMock()) as rec_da, \
             patch.object(service, "_reconcile_relays", new=AsyncMock()) as rec_relays:
            ok = await service.sync_after_reconnect(stub)
        assert ok is True
        rec_da.assert_awaited_once()
        rec_relays.assert_awaited_once()
        deps["reporter"].report_relay_info.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_reconcile_relays_destroys_mismatch(self, service, deps):
        local = MagicMock(fingerprint="AA", relay_code="r-old")
        deps["context"].relays = {"r-old": local}
        expected = MagicMock(
            relay_code="r-old",
            fingerprint="BB",
            status=vps_management_pb2.RelayStatus.RELAY_RUNNING,
        )
        await service._reconcile_relays([expected])
        deps["relay_service"].destroy_relay.assert_awaited_once_with("r-old")

    @pytest.mark.asyncio
    async def test_ensure_single_link_skips_without_client(self, service, deps):
        await service._ensure_single_link("1", "", ["fp"])
        deps["link_service"].create_circuit_with_link.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_ensure_single_link_creates(self, service, deps):
        circuit = MagicMock(circuit_id="c1")
        deps["link_service"].create_circuit_with_link.return_value = (circuit, "1")
        await service._ensure_single_link("1", "client-1", ["fp"])
        deps["link_service"].create_circuit_with_link.assert_awaited_once()
        deps["reporter"].report_circuit_rebuilt_info.assert_awaited_once()
