import asyncio
import os
import struct
from unittest.mock import patch

import pytest

from services.tun_device import TunConfig, TunDevice
from services.tun_tunnel import LengthPrefixedFraming
from services.multi_tun_bridge import SingleTunnelConfig, MultiTunBridgeConfig


def test_length_prefixed_framing_pack():
    packed = LengthPrefixedFraming.pack(b"abc")
    length = struct.unpack(">I", packed[:4])[0]
    assert length == 3
    assert packed[4:] == b"abc"


@pytest.mark.asyncio
async def test_length_prefixed_framing_read_frame():
    payload = LengthPrefixedFraming.pack(b"hello")
    reader = asyncio.StreamReader()
    reader.feed_data(payload)
    reader.feed_eof()
    frame = await LengthPrefixedFraming.read_frame(reader)
    assert frame == b"hello"


@pytest.mark.asyncio
async def test_length_prefixed_framing_invalid_length():
    reader = asyncio.StreamReader()
    reader.feed_data(struct.pack(">I", 2 * 1024 * 1024) + b"x")
    reader.feed_eof()
    with pytest.raises(ValueError, match="invalid frame length"):
        await LengthPrefixedFraming.read_frame(reader, max_frame=8)


def test_tun_device_open_not_supported_on_non_posix():
    if os.name == "posix":
        pytest.skip("仅验证非 POSIX 平台拒绝创建 TUN")
    device = TunDevice(TunConfig(name="tun0", addr_cidr="10.0.1.1/24"))
    with pytest.raises(RuntimeError, match="only supported on Linux"):
        device.open()


def test_tun_device_open_linux_path_mocked():
    """不依赖真实 /dev/net/tun，Windows / Linux 都可验证 open 流程。"""
    device = TunDevice(TunConfig(name="tun0", addr_cidr="10.0.1.1/24"))
    ifr_res = struct.pack("16sH", b"tun0", 0)
    with patch("services.tun_device.os.name", "posix"), \
         patch("services.tun_device.os.path.exists", return_value=True), \
         patch("services.tun_device.os.open", return_value=7) as mock_open, \
         patch("services.tun_device.fcntl.ioctl", return_value=ifr_res) as mock_ioctl:
        ifname = device.open()
    assert ifname == "tun0"
    assert device.fd == 7
    mock_open.assert_called_once()
    mock_ioctl.assert_called()


def test_multi_tun_bridge_config_dataclass():
    cfg = MultiTunBridgeConfig(
        proxy_host="127.0.0.1",
        proxy_port=9050,
        endpoint_host="1.1.1.1",
        endpoint_port=19000,
        tunnels=[SingleTunnelConfig(tun_name="tun0", tun_addr_cidr="10.0.1.2/24", link_id="l1")],
    )
    assert cfg.tunnels[0].tun_name == "tun0"
    assert cfg.mtu == 1300
