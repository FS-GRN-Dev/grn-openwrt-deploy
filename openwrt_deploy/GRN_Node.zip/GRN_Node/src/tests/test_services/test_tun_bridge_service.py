import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from services.tun_bridge_service import TunBridgeService, make_json_response


@pytest.fixture
def context():
    ctx = MagicMock()
    stem = MagicMock()
    stem.socks_port = 9050
    ctx.stem2tor_instances = {"client-1": stem}
    return ctx


@pytest.fixture
def service(context):
    svc = TunBridgeService(context)
    svc.logger = MagicMock()
    return svc


class TestTunBridgeService:
    def test_serialize_and_new_code(self, service):
        code = service._new_bridge_code()
        assert code.startswith("bridge-")
        data = service._serialize_bridge("b1", {"mode": "server", "listen_port": 9, "tunnels": []})
        assert data["bridge_code"] == "b1"
        assert data["listen_port"] == 9

    @pytest.mark.asyncio
    async def test_get_bridge_info_missing(self, service):
        assert await service.get_bridge_info("nope") is None

    @pytest.mark.asyncio
    async def test_update_bridge_metadata(self, service):
        async with service._lock:
            service._bridges["b1"] = {"mode": "client", "link_id": ""}
        await service.update_bridge_metadata("b1", link_id="x")
        assert service._bridges["b1"]["link_id"] == "x"
        await service.update_bridge_metadata("missing", link_id="y")

    @pytest.mark.asyncio
    async def test_start_server_validation(self, service):
        with pytest.raises(ValueError, match="listen_port"):
            await service.start_server({"tunnels": [{"tun_name": "tun0", "tun_addr_cidr": "10.0.1.1/24"}]})
        with pytest.raises(ValueError, match="tunnel"):
            await service.start_server({"listen_port": 19000, "tunnels": []})
        with pytest.raises(ValueError, match="tun_name"):
            await service.start_server({
                "listen_port": 19000,
                "tunnels": [{"tun_name": "", "tun_addr_cidr": "10.0.1.1/24"}],
            })

    @pytest.mark.asyncio
    async def test_start_server_success(self, service):
        fake_server = AsyncMock()
        fake_server.get_ifnames = MagicMock(return_value={"tun0": "tun0"})
        fake_proxy = AsyncMock()
        with patch("services.tun_bridge_service.TunTunnelServer", return_value=fake_server), \
             patch("services.tun_bridge_service.start_server_singbox_proxy", new=AsyncMock(return_value=fake_proxy)), \
             patch("services.tun_bridge_service.mptcp_config.ip_from_cidr", side_effect=lambda cidr: cidr.split("/")[0]), \
             patch("services.tun_bridge_service.mptcp_config.ensure_mptcp_enabled"), \
             patch("services.tun_bridge_service.mptcp_config.flush_endpoints"), \
             patch("services.tun_bridge_service.mptcp_config.set_limits"), \
             patch("services.tun_bridge_service.mptcp_config.configure_scheduler"), \
             patch.object(service, "_best_effort_cleanup_tun_names") as mock_cleanup:
            code = await service.start_server({
                "listen_port": 19000,
                "relay_code": "exit-1",
                "tunnels": [{"tun_name": "tun0", "tun_addr_cidr": "10.0.1.1/24", "link_id": ""}],
            })
        info = await service.get_bridge_info(code)
        assert info["mode"] == "server"
        assert info["listen_port"] == 19000
        fake_server.start.assert_awaited_once()
        mock_cleanup.assert_called()

    @pytest.mark.asyncio
    async def test_start_server_rolls_back_on_proxy_failure(self, service):
        fake_server = AsyncMock()
        fake_server.get_ifnames = MagicMock(return_value={"tun0": "tun0"})
        with patch("services.tun_bridge_service.TunTunnelServer", return_value=fake_server), \
             patch(
                 "services.tun_bridge_service.start_server_singbox_proxy",
                 new=AsyncMock(side_effect=OSError(16, "Device or resource busy")),
             ), \
             patch("services.tun_bridge_service.mptcp_config.ip_from_cidr", side_effect=lambda cidr: cidr.split("/")[0]), \
             patch.object(service, "_best_effort_cleanup_tun_names") as mock_cleanup:
            with pytest.raises(OSError, match="Device or resource busy"):
                await service.start_server({
                    "listen_port": 19000,
                    "relay_code": "exit-1",
                    "tunnels": [{"tun_name": "tun0", "tun_addr_cidr": "10.0.1.1/24", "link_id": ""}],
                })
        fake_server.stop.assert_awaited()
        assert await service.status() == []
        assert mock_cleanup.call_count >= 2

    @pytest.mark.asyncio
    async def test_start_client_validation(self, service):
        with pytest.raises(ValueError, match="client_relay_code"):
            await service.start_client({"endpoint_host": "1.1.1.1", "endpoint_port": 1})
        with pytest.raises(ValueError, match="endpoint_host"):
            await service.start_client({"client_relay_code": "client-1", "endpoint_port": 1})
        with pytest.raises(ValueError, match="endpoint_port"):
            await service.start_client({"client_relay_code": "client-1", "endpoint_host": "1.1.1.1"})
        with pytest.raises(ValueError, match="tunnel"):
            await service.start_client({
                "client_relay_code": "client-1",
                "endpoint_host": "1.1.1.1",
                "endpoint_port": 19000,
                "proxy_host": "127.0.0.1",
                "proxy_port": 9050,
                "tunnels": [],
            })

    @pytest.mark.asyncio
    async def test_start_and_stop_client(self, service):
        fake_bridge = AsyncMock()
        fake_bridge.get_ifnames = MagicMock(return_value={"tun0": "tun0"})
        fake_bridge.get_ok_tunnel_names = MagicMock(return_value={"tun0"})
        with patch("services.tun_bridge_service.MultiTunBridge", return_value=fake_bridge), \
             patch.object(service, "_best_effort_cleanup_tun_names"):
            code = await service.start_client({
                "client_relay_code": "client-1",
                "endpoint_host": "1.1.1.1",
                "endpoint_port": 19000,
                "tunnels": [{
                    "tun_name": "tun0",
                    "tun_addr_cidr": "10.0.1.2/24",
                    "link_id": "link-1",
                }],
            })
        status = await service.status()
        assert status[0]["bridge_code"] == code
        assert await service.stop(code) is True
        fake_bridge.stop.assert_awaited_once()
        assert await service.stop("missing") is False

    def test_best_effort_cleanup_skips_owned_tuns(self, service):
        service._bridges["b1"] = {
            "mode": "server",
            "tunnels": [{"tun_name": "tun1", "tun_addr_cidr": "10.0.1.1/24"}],
        }
        with patch("services.tun_device.TunDevice") as mock_tun_cls:
            service._best_effort_cleanup_tun_names(["tun1", "tun2"])
        # tun1 owned by active bridge--->skip; tun2 cleaned
        assert mock_tun_cls.call_count == 1
        mock_tun_cls.return_value._best_effort_delete_iface.assert_called_once_with("tun2")

    def test_make_json_response(self):
        raw = make_json_response(bridge_code="b1", bridges=[{"bridge_code": "b1"}])
        assert "b1" in raw
