from generated import vps_management_pb2
from config import config as default_config
from config import config_one_path_multiplex as opm


def test_shared_classes_match_default_config():
    assert opm.NodeConfig.DEFAULT_NODE_STATUS == vps_management_pb2.NodeStatus.NODE_ONLINE
    assert opm.StemConfig.DEFAULT_CONTROL_PORT == default_config.StemConfig.DEFAULT_CONTROL_PORT
    assert opm.ContainerConfig.DEFAULT_IMAGE == default_config.ContainerConfig.DEFAULT_IMAGE
    assert opm.GrpcConfig.DEFAULT_SERVER_ADDR == default_config.GrpcConfig.DEFAULT_SERVER_ADDR
    assert opm.ObserverConfig.NODE_INFO_INTERVAL == default_config.ObserverConfig.NODE_INFO_INTERVAL
    assert opm.SystemConfig.RISK_LEVEL_CRITICAL == default_config.SystemConfig.RISK_LEVEL_CRITICAL
    assert opm.LinkType.MULTI_LINK == default_config.LinkType.MULTI_LINK
    assert opm.SwitchType.MULTI_TO_SINGLE == default_config.SwitchType.MULTI_TO_SINGLE
    assert opm.TunBridgeConfig.DEFAULT_LISTEN_PORT == default_config.TunBridgeConfig.DEFAULT_LISTEN_PORT
    assert opm.LocalServiceConfig.DEFAULT_MAX_MSG_LEN == default_config.LocalServiceConfig.DEFAULT_MAX_MSG_LEN


def test_singbox_one_path_uses_single_mptcp_tunnel_tag():
    cfg = opm.SingBoxConfig
    assert cfg.BINARY == "sing-box"
    assert cfg.CLIENT_TEMPLATE_PATH.endswith("client_singbox.json")
    assert cfg.SERVER_TEMPLATE_PATH.endswith("server_singbox.json")
    assert cfg.MPTCP_OUTBOUND_TAG == "mptcp-tunnel"
    assert cfg.SELECTOR_TAG == "out-select"
    assert cfg.CLIENT_INBOUND_TAG == "redirect-in"
    assert cfg.SERVER_INBOUND_TAG == "mptcp-path-"
    assert cfg.DEFAULT_CONNECT_TIMEOUT == "5s"
    assert cfg.clash_api_url() == f"http://{cfg.CLASH_API_HOST}:{cfg.CLASH_API_PORT}"
    assert not hasattr(cfg, "MPTCP_PATH_TAG_PREFIX")
    assert not hasattr(cfg, "MPTCP_GROUP_TYPE")


def test_one_path_grpc_and_observer_timeouts():
    assert opm.GrpcConfig.CHANNEL_READY_TIMEOUT_SEC == 30
    assert opm.GrpcConfig.STREAM_READ_TIMEOUT_SEC == 0
    assert opm.ObserverConfig.CONSENSUS_INFO_INTERVAL == 30
    assert opm.CommandConfig.RELAY_STARTUP_WAIT == 10
    assert opm.LinkEnableAction.ENABLE == "enable"
