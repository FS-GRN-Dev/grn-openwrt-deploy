from config.config import ContainerConfig, StemConfig
from config.tor_node_config import TorNodeConfig


def test_tor_node_config_defaults():
    cfg = TorNodeConfig(role="relay", nick="n1")
    assert cfg.role == "relay"
    assert cfg.nick == "n1"
    assert cfg.pwd == StemConfig.DEFAULT_TOR_PASSWORD
    assert cfg.or_port == StemConfig.DEFAULT_OR_PORT
    assert cfg.socks_port == StemConfig.DEFAULT_SOCKS_PORT
    assert cfg.control_port == StemConfig.DEFAULT_CONTROL_PORT
    assert cfg.dir_port == StemConfig.DEFAULT_DIR_PORT
    assert cfg.outer_ip_addr is None
    assert cfg.dir_auths is None
    assert cfg.image == ContainerConfig.DEFAULT_IMAGE
    assert cfg.network_mode == ContainerConfig.DEFAULT_NETWORK_MODE


def test_tor_node_config_overrides():
    auths = [{"nick": "da1"}]
    cfg = TorNodeConfig(
        role="client",
        nick="c1",
        pwd="secret",
        or_port=19001,
        socks_port=19050,
        control_port=19051,
        dir_port=None,
        outer_ip_addr="10.0.0.8",
        dir_auths=auths,
        image="custom-tor",
        network_mode="host",
    )
    assert cfg.role == "client"
    assert cfg.pwd == "secret"
    assert cfg.or_port == 19001
    assert cfg.dir_port is None
    assert cfg.outer_ip_addr == "10.0.0.8"
    assert cfg.dir_auths == auths
    assert cfg.image == "custom-tor"
    assert cfg.network_mode == "host"
