import json
from pathlib import Path

from config.config import SingBoxConfig

REPO_ROOT = Path(__file__).resolve().parents[3]
SINGBOX_DIR = REPO_ROOT / "src" / "config" / "singbox"


def _load(name: str) -> dict:
    path = SINGBOX_DIR / name
    assert path.is_file(), f"missing template: {path}"
    return json.loads(path.read_text(encoding="utf-8"))


def test_singbox_template_paths_from_config_exist():
    assert (REPO_ROOT / SingBoxConfig.CLIENT_TEMPLATE_PATH).is_file()
    assert (REPO_ROOT / SingBoxConfig.SERVER_TEMPLATE_PATH).is_file()
    assert (SINGBOX_DIR / "client_singbox_one_path_multiplex.json").is_file()


def test_client_singbox_multipath_template():
    cfg = _load("client_singbox.json")
    assert cfg["inbounds"][0]["tag"] == SingBoxConfig.CLIENT_INBOUND_TAG
    assert cfg["inbounds"][0]["listen_port"] == SingBoxConfig.CLIENT_LISTEN_PORT
    assert cfg["inbounds"][0]["sniff"] is True
    assert cfg["inbounds"][0]["sniff_override_destination"] is True
    assert cfg["inbounds"][0]["sniff_timeout"] == SingBoxConfig.CLIENT_SNIFF_TIMEOUT
    by_tag = {item["tag"]: item for item in cfg["outbounds"]}
    assert by_tag[SingBoxConfig.SELECTOR_TAG]["type"] == "selector"
    tunnel = by_tag[SingBoxConfig.MPTCP_OUTBOUND_TAG]
    assert tunnel["type"] == SingBoxConfig.MPTCP_GROUP_TYPE
    assert tunnel["url"] == SingBoxConfig.MPTCP_URLTEST_URL
    path_tags = [
        tag
        for tag in by_tag
        if tag.startswith(SingBoxConfig.MPTCP_PATH_TAG_PREFIX) and tag != SingBoxConfig.MPTCP_OUTBOUND_TAG
    ]
    assert path_tags
    for tag in path_tags:
        assert by_tag[tag]["type"] == "vless"
        assert by_tag[tag]["uuid"] == "UUID"
        assert by_tag[tag]["tcp_multi_path"] is True
    assert by_tag[SingBoxConfig.SOCKS_OUTBOUND_TAG]["server_port"] == SingBoxConfig.DEFAULT_SOCKS_PORT


def test_client_singbox_one_path_multiplex_template():
    cfg = _load("client_singbox_one_path_multiplex.json")
    inbound = cfg["inbounds"][0]
    assert inbound["sniff"] is True
    assert inbound["sniff_override_destination"] is True
    assert inbound["sniff_timeout"] == SingBoxConfig.CLIENT_SNIFF_TIMEOUT
    by_tag = {item["tag"]: item for item in cfg["outbounds"]}
    selector = by_tag[SingBoxConfig.SELECTOR_TAG]
    assert selector["outbounds"] == ["direct", "mptcp-tunnel", "socks5"]
    tunnel = by_tag[SingBoxConfig.MPTCP_OUTBOUND_TAG]
    assert tunnel["type"] == "vless"
    assert tunnel["tcp_multi_path"] is True
    assert tunnel["uuid"] == "UUID"
    assert tunnel["server"] == "10.0.1.1"
    assert tunnel["server_port"] == SingBoxConfig.SERVER_LISTEN_PORT
    assert "mptcp-path-1" not in by_tag
    clash = cfg["experimental"]["clash_api"]
    assert clash["external_controller"] == f"{SingBoxConfig.CLASH_API_HOST}:{SingBoxConfig.CLASH_API_PORT}"
    assert clash["secret"] == SingBoxConfig.CLASH_API_SECRET


def test_server_singbox_template():
    cfg = _load("server_singbox.json")
    assert cfg["route"]["final"] == "direct"
    inbounds = cfg["inbounds"]
    assert len(inbounds) >= 1
    for inbound in inbounds:
        assert inbound["type"] == "vless"
        assert inbound["listen_port"] == SingBoxConfig.SERVER_LISTEN_PORT
        assert inbound["tcp_multi_path"] is True
        assert inbound["users"][0]["uuid"] == "UUID"
        assert inbound["tag"].startswith(SingBoxConfig.SERVER_INBOUND_TAG)
    assert cfg["outbounds"][0]["tag"] == SingBoxConfig.DIRECT_OUTBOUND_TAG
