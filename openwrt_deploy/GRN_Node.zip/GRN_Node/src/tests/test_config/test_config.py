from generated import vps_management_pb2
from config.config import (
    CommandConfig,
    ContainerConfig,
    GrpcConfig,
    LinkEnableAction,
    LinkType,
    LocalServiceConfig,
    NodeConfig,
    ObserverConfig,
    SingBoxConfig,
    StemConfig,
    SwitchType,
    SystemConfig,
    TunBridgeConfig,
)


def test_node_config_defaults():
    assert NodeConfig.DEFAULT_NODE_STATUS == vps_management_pb2.NodeStatus.NODE_ONLINE
    assert NodeConfig.DEFAULT_RISK_LEVEL == 0
    assert NodeConfig.DEFAULT_TRAFFIC_IN == 0
    assert NodeConfig.DEFAULT_TRAFFIC_OUT == 0
    assert NodeConfig.DEFAULT_RELAY_COUNT == 0
    assert NodeConfig.DEFAULT_MAX_RELAY_CAPACITY == 2


def test_stem_config_defaults():
    assert StemConfig.DEFAULT_DIR_PORT == "9030"
    assert StemConfig.DEFAULT_OR_PORT == 9001
    assert StemConfig.DEFAULT_SOCKS_PORT == 9050
    assert StemConfig.DEFAULT_CONTROL_PORT == 9051
    assert StemConfig.DEFAULT_TOR_PASSWORD == "torpassword"
    assert StemConfig.DEFAULT_EXIT_POLICY == "reject *:*"
    assert StemConfig.DEFAULT_PLATFORM == "Linux"
    assert StemConfig.DEFAULT_ADDR == "localhost"
    assert StemConfig.DEFAULT_MAX_RETRIES == 10
    assert StemConfig.DEFAULT_NODE_WAIT_TIME == 30
    assert StemConfig.DEFAULT_CHECK_INTERVAL == 2.0


def test_container_config_defaults():
    assert ContainerConfig.DEFAULT_IMAGE == "grn-tor"
    assert ContainerConfig.DEFAULT_NETWORK_MODE == "bridge"


def test_grpc_config_defaults():
    assert GrpcConfig.DEFAULT_SERVER_ADDR == "localhost:50051"
    assert GrpcConfig.RETRY_INTERVAL == 5
    assert GrpcConfig.HEARTBEAT_INTERVAL == 30
    assert GrpcConfig.EXIT_DELAY == 10
    assert GrpcConfig.DEFAULT_CA_CERT_PATH.endswith("ca.crt")
    assert GrpcConfig.DEFAULT_VERIFY_HOSTNAME is True
    assert GrpcConfig.SERVER_HOST_OVERRIDE == "localhost"
    assert GrpcConfig.CHANNEL_READY_TIMEOUT_SEC == 30
    assert GrpcConfig.STREAM_READ_TIMEOUT_SEC == 0
    assert GrpcConfig.RECONNECT_MAX_BACKOFF_SEC == 60
    assert GrpcConfig.CHANNEL_REBUILD_AFTER_FAILURES == 3


def test_observer_config_intervals():
    assert ObserverConfig.NODE_INFO_INTERVAL == 60
    assert ObserverConfig.NODE_INFO_EXCEPTION_INTERVAL == 5
    assert ObserverConfig.RELAY_INFO_INTERVAL == 600
    assert ObserverConfig.RELAY_INFO_EXCEPTION_INTERVAL == 30
    assert ObserverConfig.SITUATION_AWARENESS_INTERVAL == 600
    assert ObserverConfig.DA_INFO_INTERVAL == 600
    assert ObserverConfig.CONSENSUS_INFO_INTERVAL == 30
    assert ObserverConfig.CONSENSUS_INFO_EXCEPTION_INTERVAL == 5


def test_system_config_risk_levels():
    assert SystemConfig.DEFAULT_CPU_USAGE == 30.5
    assert SystemConfig.DEFAULT_MEMORY_USAGE == 40.0
    assert SystemConfig.RISK_THRESHOLD_CRITICAL > SystemConfig.RISK_THRESHOLD_HIGH
    assert SystemConfig.RISK_THRESHOLD_HIGH > SystemConfig.RISK_THRESHOLD_MEDIUM
    assert SystemConfig.RISK_THRESHOLD_MEDIUM > SystemConfig.RISK_THRESHOLD_LOW
    assert SystemConfig.RISK_LEVEL_CRITICAL == 9
    assert SystemConfig.RISK_LEVEL_MINIMAL == 1


def test_command_and_link_enums():
    assert CommandConfig.RELAY_STARTUP_WAIT == 10
    assert LinkType.UNKNOWN_LINK == 0
    assert LinkType.SINGLE_LINK == 1
    assert LinkType.MULTI_LINK == 2
    assert LinkEnableAction.ENABLE == "enable"
    assert LinkEnableAction.DISABLE == "disable"
    assert SwitchType.SINGLE_TO_SINGLE == 1
    assert SwitchType.NONE_TO_MULTI == 6


def test_tun_bridge_config():
    assert TunBridgeConfig.DEFAULT_LISTEN_HOST == "0.0.0.0"
    assert TunBridgeConfig.DEFAULT_LISTEN_PORT == 19000
    assert TunBridgeConfig.DEFAULT_MTU == 1300
    assert TunBridgeConfig.DEFAULT_CONNECT_TIMEOUT_SEC == 60
    assert TunBridgeConfig.DEFAULT_ENABLE_MPTCP is False
    assert TunBridgeConfig.DEFAULT_TUNNEL_COUNT == 2


def test_singbox_config_and_clash_url():
    assert SingBoxConfig.BINARY == "sing-box"
    assert SingBoxConfig.CLIENT_TEMPLATE_PATH.endswith("client_singbox.json")
    assert SingBoxConfig.SERVER_TEMPLATE_PATH.endswith("server_singbox.json")
    assert SingBoxConfig.CLIENT_LISTEN_PORT == 11090
    assert SingBoxConfig.CLIENT_SNIFF_ENABLED is True
    assert SingBoxConfig.CLIENT_SNIFF_OVERRIDE_DESTINATION is True
    assert SingBoxConfig.CLIENT_SNIFF_TIMEOUT == "300ms"
    assert SingBoxConfig.SERVER_LISTEN_PORT == 11091
    assert SingBoxConfig.SELECTOR_TAG == "out-select"
    assert SingBoxConfig.MPTCP_OUTBOUND_TAG == "mptcp-tunnel"
    assert SingBoxConfig.MPTCP_PATH_TAG_PREFIX == "mptcp-path-"
    assert SingBoxConfig.MPTCP_GROUP_TYPE == "urltest"
    assert SingBoxConfig.clash_api_url() == (
        f"http://{SingBoxConfig.CLASH_API_HOST}:{SingBoxConfig.CLASH_API_PORT}"
    )


def test_local_service_config():
    assert LocalServiceConfig.DEFAULT_LOCAL_SOCKET_PATH.endswith("local_ipc.sock")
    assert LocalServiceConfig.DEFAULT_MAX_MSG_LEN == 1024
