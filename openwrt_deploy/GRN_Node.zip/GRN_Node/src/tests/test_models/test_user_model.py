import json
from models.user import LocalMsgType, UserMsg
from generated import VPS_M_pb2


def test_user_constructor():
    json_data = {
        "msg_type" : 1,
        "data" : {
            "field1" : "content1",
            "field2" : "content2"
        }
    }
    json_str = json.dumps(json_data)

    model = UserMsg(
        LocalMsgType.MT_NONE,
        json_str
    )
    
    assert model.type == LocalMsgType.MT_NONE
    assert model.data == json_str