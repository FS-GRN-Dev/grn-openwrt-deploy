from models.circuit import Circuit
from generated import vps_management_pb2
import time


def test_circuit_to_db():
    model = Circuit(
        circuit_id="c1",
        relay_fingerprints=["fp1", "fp2"],
        status="BUILT",
        purpose="GENERAL",
        build_flags=["OneHop"],
    )
    model_dict = model.to_db()
    assert model_dict["circuit_id"] == "c1"
    assert model_dict["fingerprints"] == ["fp1", "fp2"]
    assert model_dict["client_relay_code"] == ""
    assert model_dict["node_code"] == ""


def test_circuit_from_dict():
    model = Circuit.from_db({
        "circuit_id": "",
        "fingerprints": [],
        "created_at": "",
        "status": "BUILT",
        "purpose": "GENERAL",
        "client_relay_code": "ri-123456",
        "node_code": "n1",
    })
    assert model.client_relay_code == "ri-123456"
    assert model.node_code == "n1"


def test_circuit_from_stem_circuit_info():
    model = Circuit.from_stem_circuit_info(
        "c1",
        {
            "status": "BUILT",
            "purpose": "GENERAL",
            "hs_state": "NORMAL",
            "rend_query": "unknown",
            "reason": "test",
            "socks_username": "circuit",
            "socks_password": "circuit-passwd",
        },
        ["fp1", "fp2"],
        client_relay_code="cr1",
        node_code="n1",
    )
    assert model.circuit_id == "c1"
    assert model.client_relay_code == "cr1"
    assert model.node_code == "n1"
    assert model.socks_username == "circuit"


def test_circuit_to_proto():
    model = Circuit(
        circuit_id="c1",
        relay_fingerprints=["fp1", "fp2"],
        status="BUILT",
        purpose="GENERAL",
        build_flags=["OneHop"],
        link_id="l1",
        client_relay_code="cr1",
    )
    proto = model.to_proto()
    assert proto.circuit_code == "c1"
    assert list(proto.circuit_fingerprint_path) == ["fp1", "fp2"]
    assert proto.status == 1
    assert proto.link_id == "l1"
    assert proto.client_relay_code == "cr1"


def test_circuit_from_proto():
    proto = vps_management_pb2.Circuit(
        circuit_code="c1",
        status=1,
        purpose="GENERAL",
        created=time.strftime("%Y-%m-%d %H:%M:%S"),
        link_id="l1",
        client_relay_code="cr1",
    )
    model = Circuit.from_proto(proto, "ignored", "n1")
    assert model.circuit_id == "c1"
    assert model.node_code == "n1"
    assert model.link_id == "l1"


def test_circuit_to_json_response():
    model = Circuit(
        circuit_id="c1",
        status="BUILT",
        purpose="GENERAL",
        reason="test",
        socks_username="circuit",
        socks_password="circuit-passwd",
        relay_fingerprints=["fp1", "fp2"],
        link_id="l1",
    )
    model_dict = model.to_json_response()
    assert model_dict["circuit_id"] == "c1"
    assert model_dict["link_id"] == "l1"
