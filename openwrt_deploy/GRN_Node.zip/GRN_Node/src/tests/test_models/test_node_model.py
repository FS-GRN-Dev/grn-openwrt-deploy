from models.node import Node
from generated import vps_management_pb2
import time


def test_node_update_resource_usage():
    node = Node("n1-123456", "1.1.1.1")
    node.update_resource_usage(8.2, 25.3, 20, 30, 0.1)

    assert node.node_code == "n1-123456"
    assert node.ip_address == "1.1.1.1"
    assert node.status == vps_management_pb2.NodeStatus.NODE_ONLINE
    assert node.cpu_usage == 8.2
    assert node.memory_usage == 25.3
    assert node.traffic_in == 20
    assert node.traffic_out == 30
    assert node.tcp_retrans_rate == 0.1


def test_node_to_proto():
    model = Node(
        node_code="n1-123456",
        ip_address="1.1.1.1",
        status=vps_management_pb2.NodeStatus.NODE_ONLINE,
        risk_level=5,
        cpu_usage=20.2,
        memory_usage=18.3,
        traffic_in=35,
        traffic_out=42,
        relay_count=3,
        max_relay_capacity=4,
    )
    proto = model.to_proto()
    assert proto.node_code == "n1-123456"
    assert proto.ip_address == "1.1.1.1"
    assert proto.status == vps_management_pb2.NodeStatus.NODE_ONLINE
    assert proto.risk_level == 5
    assert proto.relay_count == 3
    assert proto.anonymous_relay_code == ""
    assert proto.access_relay_code == ""


def test_node_from_proto():
    proto = vps_management_pb2.Node(
        node_code="c1-123456",
        ip_address="1.1.1.1",
        status=vps_management_pb2.NodeStatus.NODE_OFFLINE,
        risk_level=5,
        cpu_usage=20.2,
        memory_usage=18.3,
        traffic_in=35,
        traffic_out=42,
        created_at=time.strftime("%Y-%m-%d %H:%M:%S"),
        last_heartbeat=time.strftime("%Y-%m-%d %H:%M:%S"),
        relay_count=3,
        max_relay_capacity=6,
    )
    model = Node.from_proto(proto)
    assert model.node_code == "c1-123456"
    assert model.status == vps_management_pb2.NodeStatus.NODE_OFFLINE
    assert model.relay_count == 3
    assert model.max_relay_capacity == 6


def test_node_add_and_remove_relay():
    node = Node("n1-123456", "1.1.1.1")
    node.add_relay("adfadf123456", vps_management_pb2.RelayType.RELAY_ANONYMOUS, 2)
    assert node.relay_count == 2
    assert node.anonymous_relay_code == "adfadf123456"
    node.remove_relay("adfadf123456", 1)
    assert node.relay_count == 1
    assert node.anonymous_relay_code == ""
