from models.relay import Relay
from generated import vps_management_pb2


def test_relay_to_proto():
    model = Relay(
        relay_code="r1-123456",
        nickname="da90c787510",
        fingerprint="6AC76F470754BE48B01F57D85D41C8A09DD56B76",
        ip_address="1.1.1.1",
        or_port=9001,
        dir_port=9030,
        bandwidth=10,
        exit_policy="",
        published="",
        node_code="n1-123456",
        container_id="34fa7fa76237",
        container_name="da-da90c787510",
        server_relay_id=88,
    )
    proto = model.to_proto()
    assert proto.relay_code == "r1-123456"
    assert proto.nickname == "da90c787510"
    assert proto.node_code == "n1-123456"
    assert proto.relay_id == 88
    assert proto.status == vps_management_pb2.RelayStatus.RELAY_CREATING
    assert proto.relay_type == vps_management_pb2.RelayType.RELAY_ANONYMOUS
    assert proto.relay_role == vps_management_pb2.RelayRole.ROLE_RELAY


def test_relay_from_proto():
    proto = vps_management_pb2.Relay(
        relay_code="r1-123456",
        nickname="da90c787510",
        fingerprint="6AC76F470754BE48B01F57D85D41C8A09DD56B76",
        ip_address="1.1.1.1",
        or_port=9001,
        dir_port=9030,
        bandwidth=10,
        exit_policy="",
        published="",
        node_code="n1-123456",
        container_id="34fa7fa76237",
        container_name="da-da90c787510",
        status=vps_management_pb2.RelayStatus.RELAY_RUNNING,
        relay_type=vps_management_pb2.RelayType.RELAY_ANONYMOUS,
        relay_role=vps_management_pb2.RelayRole.ROLE_RELAY,
        relay_id=7,
    )
    model = Relay.from_proto(proto)
    assert model.relay_code == "r1-123456"
    assert model.node_code == "n1-123456"
    assert model.status == vps_management_pb2.RelayStatus.RELAY_RUNNING
    assert model.platform == ""


def test_relay_update_from_tor_info():
    model = Relay(
        relay_code="r1",
        nickname="",
        fingerprint="",
        ip_address="",
        or_port=9001,
        dir_port=9030,
        bandwidth=10,
        exit_policy="",
        published="",
        node_code="n1",
        container_id="",
        container_name="",
    )
    model.update_from_tor_info({
        "nickname": "da90c787510",
        "fingerprint": "6AC76F470754BE48B01F57D85D41C8A09DD56B76",
        "address": "1.1.1.1",
        "or_port": 9001,
        "dir_port": 9030,
        "bandwidth": 10,
        "published": "",
        "flags": ["Fast", "Stable"],
        "version": "1.0",
    })
    assert model.nickname == "da90c787510"
    assert model.flags == ["Fast", "Stable"]
    assert model.status == vps_management_pb2.RelayStatus.RELAY_BOOTSTRAPPED
