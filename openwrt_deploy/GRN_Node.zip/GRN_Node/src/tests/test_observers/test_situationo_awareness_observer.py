import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from observers.situation_awareness_observer import SituationAwarenessObserver
from config.config import ObserverConfig



# ===================== SituationAwarenessObserver 测试类 =====================
class TestSituationAwarenessObserver:
    """SituationAwarenessObserver 测试类"""

    @pytest.fixture(autouse=True)
    def setup(self):
        """每个测试方法执行前自动初始化依赖"""
        # 1. Mock 核心依赖：reporter（模拟上报接口）
        self.mock_reporter = MagicMock()

        # 模拟异步方法 report_situation_awareness，默认返回True
        self.mock_reporter.report_situation_awareness = AsyncMock(return_value=True)
        
        # 2. 初始化 SituationAwarenessObserver 实例
        self.observer = SituationAwarenessObserver(reporter=self.mock_reporter)
        

    # -------------------- 基础方法测试（同步） --------------------
    def test_situation_get_interval(self):
        """测试 get_interval 方法：返回正确的态势感知信息观察间隔"""
        # 执行 + 断言
        assert self.observer.get_interval() == ObserverConfig.SITUATION_AWARENESS_INTERVAL


    def test_situation_get_exception_interval(self):
        """测试 get_exception_interval 方法：返回正确的异常场景间隔"""
        # 执行 + 断言
        assert self.observer.get_exception_interval() == ObserverConfig.SITUATION_AWARENESS_EXCEPTION_INTERVAL


    def test_situation_get_name(self):
        """测试 get_name 方法：返回正确的观察者名称"""
        # 执行 + 断言
        assert self.observer.get_name() == "SituationAwareness"


    # -------------------- 核心方法 update 测试（异步） --------------------
    @pytest.mark.asyncio
    async def test_situation_update_success(self):
        """测试 update 方法：report_situation_awareness 上报成功的场景"""
        # 准备：模拟上报成功返回True
        self.mock_reporter.report_situation_awareness.return_value = True
        
        # 执行核心方法
        result = await self.observer.update()
        
        # 多层断言验证
        # 1. 返回值符合预期
        assert result is True
        
        # 2. 上报接口被调用且仅调用一次
        self.mock_reporter.report_situation_awareness.assert_called_once()


    @pytest.mark.asyncio
    async def test_situation_update_failure(self):
        """测试 update 方法：report_situation_awareness 上报失败的场景"""
        # 准备：模拟上报失败返回False
        self.mock_reporter.report_situation_awareness.return_value = False
        
        # 执行核心方法
        result = await self.observer.update()
        
        # 断言
        assert result is False
        self.mock_reporter.report_situation_awareness.assert_called_once()


    @pytest.mark.asyncio
    async def test_situation_update_raise_exception(self):
        """测试 update 方法：report_situation_awareness 抛出异常的边界场景"""
        # 准备：模拟上报接口抛出异常
        mock_exception = RuntimeError("态势感知数据采集失败，数据源连接超时")
        self.mock_reporter.report_situation_awareness.side_effect = mock_exception
        
        # 执行 + 断言异常（原代码未捕获异常，需验证异常传播）
        with pytest.raises(RuntimeError) as exc_info:
            await self.observer.update()
        
        # 1. 异常类型和信息匹配
        assert str(exc_info.value) == "态势感知数据采集失败，数据源连接超时"

        # 2. 上报接口确实被调用
        self.mock_reporter.report_situation_awareness.assert_called_once()