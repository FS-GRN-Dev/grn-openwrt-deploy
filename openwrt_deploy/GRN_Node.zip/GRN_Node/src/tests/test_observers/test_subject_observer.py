import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

from observers.subject import StateSubject
from test_base_observer import MockObserver

from generated import VPS_M_pb2


# ===================== StateSubject 测试类 =====================
class TestStateSubject:
    """StateSubject 类的测试类"""

    @pytest.fixture(autouse=True)
    def setup(self):
        """每个测试方法执行前的初始化"""
        self.mock_reporter = MagicMock()
        self.subject = StateSubject()


    @pytest.mark.asyncio
    async def test_subject_run_observer_success(self):
        """测试 _run_observer 方法：update 成功的场景"""
        # 准备
        observer = MockObserver(self.mock_reporter, update_success=True)
        
        # 执行：控制循环避免无限执行
        task = asyncio.create_task(self.subject._run_observer(observer))
        await asyncio.sleep(0.5)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        # 断言
        assert observer.update_called_count >= 1


    @pytest.mark.asyncio
    async def test_subject_run_observer_failure(self):
        """测试 _run_observer 方法：update 失败的场景"""
        # 准备
        observer = MockObserver(self.mock_reporter, update_success=False)
        
        # 执行
        task = asyncio.create_task(self.subject._run_observer(observer))
        await asyncio.sleep(0.5)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        # 断言
        assert observer.update_called_count >= 1


    @pytest.mark.asyncio
    async def test_subject_run_observer_exception(self):
        """测试 _run_observer 方法：update 抛出异常的场景"""
        # 准备
        observer = MockObserver(self.mock_reporter, raise_exception=True)
        
        # 执行
        task = asyncio.create_task(self.subject._run_observer(observer))
        await asyncio.sleep(0.5)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        # 断言
        assert observer.update_called_count >= 1


    @pytest.mark.asyncio
    async def test_subject_start_all(self):
        """测试 start_all 方法：启动所有观察者"""
        # 准备
        observer1 = MockObserver(self.mock_reporter, update_success=True)
        observer2 = MockObserver(self.mock_reporter, update_success=True)
        self.subject.attach(observer1)
        self.subject.attach(observer2)

        # 执行
        task = asyncio.create_task(self.subject.start_all())
        await asyncio.sleep(0.5)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass

        # 断言
        assert observer1.update_called_count >= 1
        assert observer2.update_called_count >= 1
