import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from observers.consensus_observer import ConcensusObserver

from generated import VPS_M_pb2


# ===================== ConcensusObserver 测试类 =====================
class TestConcensusObserver:
    """ConcensusObserver 类的测试类"""

    @pytest.fixture(autouse=True)
    def setup(self):
        """每个测试方法执行前的初始化（pytest fixture）"""
        # Mock context 对象
        self.mock_context = MagicMock()
        self.mock_context.relays = {}
        self.mock_context.stem2tor_instances = {}

        # Mock reporter 对象
        self.mock_reporter = MagicMock()
        self.mock_reporter.push_relays = AsyncMock(return_value=True)

        # 初始化观察者实例
        self.observer = ConcensusObserver(self.mock_reporter, self.mock_context)


    @pytest.mark.asyncio
    async def test_consensus_update_no_relays(self):
        """测试 update 方法：无relays的场景"""
        # 执行
        result = await self.observer.update()
        
        # 断言
        assert result is True


    @pytest.mark.asyncio
    async def test_consensus_update_relay_no_fingerprint(self):
        """测试 update 方法：relay无fingerprint的场景"""
        # 准备
        mock_relay = MagicMock()
        mock_relay.fingerprint = None
        mock_relay.status = VPS_M_pb2.RelayStatus.RELAY_CREATING
        self.mock_context.relays = {"relay_1": mock_relay}
        
        # 执行
        result = await self.observer.update()
        
        # 断言
        assert result is True


    @pytest.mark.asyncio
    async def test_consensus_update_relay_wrong_status(self):
        """测试 update 方法：relay状态非CREATING/BOOTSTRAPPED的场景"""
        # 准备
        mock_relay = MagicMock()
        mock_relay.fingerprint = "1234567890ABCDEF"
        mock_relay.status = VPS_M_pb2.RelayStatus.RELAY_RUNNING
        self.mock_context.relays = {"relay_1": mock_relay}
        
        # 执行
        result = await self.observer.update()
        
        # 断言
        assert result is True


    @pytest.mark.asyncio
    async def test_consensus_update_no_stem2tor(self):
        """测试 update 方法：无stem2tor实例的场景"""
        # 准备
        mock_relay = MagicMock()
        mock_relay.fingerprint = "1234567890ABCDEF"
        mock_relay.status = VPS_M_pb2.RelayStatus.RELAY_CREATING
        self.mock_context.relays = {"relay_1": mock_relay}
        self.mock_context.stem2tor_instances = {}
        
        # 执行
        result = await self.observer.update()
        
        # 断言
        assert result is True


    @pytest.mark.asyncio
    async def test_consensus_update_relay_not_in_consensus(self):
        """测试 update 方法：relay未进入共识的场景"""
        # 准备
        mock_relay = MagicMock()
        mock_relay.fingerprint = "1234567890ABCDEF"
        mock_relay.nickname = "test_relay"
        mock_relay.status = VPS_M_pb2.RelayStatus.RELAY_CREATING
        
        # Mock stem2tor实例
        mock_stem2tor = MagicMock()
        mock_stem2tor.get_network_statuses = AsyncMock(return_value=None)
        self.mock_context.relays = {"relay_1": mock_relay}
        self.mock_context.stem2tor_instances = {"relay_1": mock_stem2tor}
        
        # 执行
        result = await self.observer.update()
        
        # 断言
        assert result is True
        assert mock_relay.status == VPS_M_pb2.RelayStatus.RELAY_CREATING
        self.mock_reporter.push_relays.assert_not_called()


    @pytest.mark.asyncio
    async def test_consensus_update_relay_in_consensus(self):
        """测试 update 方法：relay进入共识的场景"""
        # 准备
        mock_relay = MagicMock()
        mock_relay.fingerprint = "1234567890ABCDEF"
        mock_relay.nickname = "test_relay"
        mock_relay.status = VPS_M_pb2.RelayStatus.RELAY_CREATING
        
        # Mock stem2tor实例
        mock_stem2tor = MagicMock()
        mock_stem2tor.get_network_statuses = AsyncMock(
            return_value={"flags": ["Running", "Valid"]}
        )
        self.mock_context.relays = {"relay_1": mock_relay}
        self.mock_context.stem2tor_instances = {"relay_1": mock_stem2tor}
        
        # 执行
        result = await self.observer.update()
        
        # 断言
        assert result is True
        assert mock_relay.status == VPS_M_pb2.RelayStatus.RELAY_RUNNING
        self.mock_reporter.push_relays.assert_called_once_with([mock_relay])


    @pytest.mark.asyncio
    async def test_consensus_update_get_network_status_exception(self):
        """测试 update 方法：查询网络状态抛出异常的场景"""
        # 准备
        mock_relay = MagicMock()
        mock_relay.fingerprint = "1234567890ABCDEF"
        mock_relay.nickname = "test_relay"
        mock_relay.status = VPS_M_pb2.RelayStatus.RELAY_CREATING
        
        # Mock stem2tor实例（抛出异常）
        mock_stem2tor = MagicMock()
        mock_stem2tor.get_network_statuses = AsyncMock(
            side_effect=RuntimeError("Query failed")
        )
        self.mock_context.relays = {"relay_1": mock_relay}
        self.mock_context.stem2tor_instances = {"relay_1": mock_stem2tor}
        
        # 执行
        result = await self.observer.update()
        
        # 断言
        assert result is True
        assert mock_relay.status == VPS_M_pb2.RelayStatus.RELAY_CREATING
        self.mock_reporter.push_relays.assert_not_called()