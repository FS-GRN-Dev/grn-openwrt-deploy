import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from observers.da_info_observer import DAInfoObserver
from config.config import ObserverConfig


# ===================== DAInfoObserver 测试类 =====================
class TestDAInfoObserver:
    """DAInfoObserver 测试类"""

    @pytest.fixture(autouse=True)
    def setup(self):
        """每个测试方法执行前的初始化"""
        # Mock 依赖：reporter（核心依赖）
        self.mock_reporter = MagicMock()

        # 模拟 report_da_info 异步方法（成功返回True）
        self.mock_reporter.report_da_info = AsyncMock(return_value=True)
        
        # 初始化 DAInfoObserver 实例
        self.observer = DAInfoObserver(reporter=self.mock_reporter)


    # -------------------- 基础属性/方法测试 --------------------
    def test_da_get_interval(self):
        """测试 get_interval 方法：返回正确的观察间隔"""
        # 执行 + 断言
        assert self.observer.get_interval() == ObserverConfig.DA_INFO_INTERVAL


    def test_da_get_exception_interval(self):
        """测试 get_exception_interval 方法：返回正确的异常间隔"""
        # 执行 + 断言
        assert self.observer.get_exception_interval() == ObserverConfig.DA_INFO_EXCEPTION_INTERVAL


    def test_da_get_name(self):
        """测试 get_name 方法：返回正确的观察者名称"""
        # 执行 + 断言
        assert self.observer.get_name() == "DAInfo"


    # -------------------- 核心方法 update 测试 --------------------
    @pytest.mark.asyncio
    async def test_da_update_success(self):
        """测试 update 方法：report_da_info 成功的场景"""
        # 准备：模拟 report_da_info 返回 True
        self.mock_reporter.report_da_info.return_value = True
        
        # 执行
        result = await self.observer.update()
        
        # 断言
        # 1. 返回值正确
        assert result is True

        # 2. 调用了 reporter.report_da_info 方法
        self.mock_reporter.report_da_info.assert_called_once()


    @pytest.mark.asyncio
    async def test_da_update_failure(self):
        """测试 update 方法：report_da_info 失败的场景"""
        # 准备：模拟 report_da_info 返回 False
        self.mock_reporter.report_da_info.return_value = False
        
        # 执行
        result = await self.observer.update()
        
        # 断言
        assert result is False
        self.mock_reporter.report_da_info.assert_called_once()


    @pytest.mark.asyncio
    async def test_da_update_raise_exception(self):
        """测试 update 方法：report_da_info 抛出异常的场景（边界场景）"""
        # 准备：模拟 report_da_info 抛出异常
        mock_exception = RuntimeError("DA信息上报失败")
        self.mock_reporter.report_da_info.side_effect = mock_exception
        
        # 执行 + 断言（验证异常被抛出，因为原代码未捕获异常）
        with pytest.raises(RuntimeError) as exc_info:
            await self.observer.update()
        
        # 1. 异常类型和信息正确
        assert str(exc_info.value) == "DA信息上报失败"

        # 2. 确实调用了 report_da_info 方法
        self.mock_reporter.report_da_info.assert_called_once()