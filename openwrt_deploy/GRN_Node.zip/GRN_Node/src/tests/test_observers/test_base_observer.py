import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from observers.base import StateObserver
from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2


# ===================== 基础 Mock 类 =====================
class MockObserver(StateObserver):
    """用于测试的 Mock 观察者类"""
    def __init__(self, reporter, update_success=True, raise_exception=False):
        super().__init__(reporter)
        self.update_success = update_success
        self.raise_exception = raise_exception
        self.update_called_count = 0  # 记录update调用次数

    async def update(self) -> bool:
        self.update_called_count += 1
        if self.raise_exception:
            raise RuntimeError("Mock update exception")
        return self.update_success

    def get_interval(self) -> int:
        return 1  # 短间隔便于测试

    def get_exception_interval(self) -> int:
        return 1  # 短间隔便于测试

    def get_name(self) -> str:
        return "MockObserver"