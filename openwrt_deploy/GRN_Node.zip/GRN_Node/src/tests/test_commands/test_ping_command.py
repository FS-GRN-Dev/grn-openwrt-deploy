import pytest
from unittest.mock import MagicMock

from commands.ping_command import PingCommand
from generated import VPS_M_pb2


@pytest.fixture
def command():
    context = MagicMock()
    context.node_id = "node-ping"
    context.node_code = "node-ping"
    context.ip_address = "10.0.0.8"
    cmd = PingCommand(context, MagicMock(), MagicMock())
    cmd.logger = MagicMock()
    return cmd


class TestPingCommand:
    def test_get_command_type(self, command):
        if not hasattr(VPS_M_pb2.CommandType, "PING"):
            pytest.skip("当前 proto 未定义 CommandType.PING")
        assert command.get_command_type() == VPS_M_pb2.CommandType.PING

    @pytest.mark.asyncio
    async def test_execute_echo_payload(self, command):
        response = await command.execute({"echo": "seq-42"}, "ping-1")
        assert response.success is True
        assert response.command_id == "ping-1"
        assert response.message == "seq-42"
        assert response.node_id == "node-ping"
        assert response.ip_address == "10.0.0.8"
        assert response.type == VPS_M_pb2.ClientMessageType.COMMAND_RESPONSE

    @pytest.mark.asyncio
    async def test_execute_missing_echo(self, command):
        response = await command.execute({}, "ping-2")
        assert response.success is True
        assert response.message == ""
