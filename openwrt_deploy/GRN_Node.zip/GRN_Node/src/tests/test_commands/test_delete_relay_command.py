import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from commands.destroy_relay_command import DestroyRelayCommand
from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2, vps_management_pb2



# ========== 测试 Fixture 定义 ==========
@pytest.fixture
def mock_context():
    """Mock NodeContext 实例（提供基础节点数据）"""
    context = MagicMock()
    context.node_code = "test_node_001"
    context.ip_address = "192.168.1.100"
    context.relays = {}
    return context


@pytest.fixture
def mock_reporter():
    """Mock StateReporter 实例"""
    return MagicMock()


@pytest.fixture
def mock_service():
    """Mock Service 实例（核心依赖：destroy_relay 异步方法）"""
    service = MagicMock()
    # 默认 Mock 销毁成功，返回 True
    service.destroy_relay = AsyncMock(return_value=True)
    return service


@pytest.fixture
def destroy_relay_command(mock_context, mock_reporter, mock_service):
    """初始化 DestroyRelayCommand 实例"""
    command = DestroyRelayCommand(
        context=mock_context,
        reporter=mock_reporter,
        service=mock_service
    )

    return command


# ========== 测试类 ==========
class TestDestroyRelayCommand:
    """DestroyRelayCommand 测试类"""

    # -------------------- 基础方法测试 --------------------
    def test_destroy_relay_get_command_type(self, destroy_relay_command):
        """测试 get_command_type 返回正确的命令类型"""
        # 执行 + 断言
        assert destroy_relay_command.get_command_type() == VPS_M_pb2.CommandType.DESTROY_RELAY


    # -------------------- 核心 execute 方法测试 --------------------
    @pytest.mark.asyncio
    async def test_destroy_relay_execute_relay_id_none(self, destroy_relay_command, mock_service):
        """测试 execute：relay_id 为空（None），调用服务方法并返回失败响应"""
        # 准备测试数据：无 relay_id / relay_id 为 None
        msg_data = {}  # 无 relay_id
        command_id = "cmd_destroy_relay_001"

        mock_service.destroy_relay.return_value = False

        # 执行命令
        response = await destroy_relay_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证：relay_id 为 None 仍传递给服务层
        mock_service.destroy_relay.assert_awaited_once_with(None)

        # 2. 响应消息验证（销毁失败）
        assert isinstance(response, vps_management_pb2.ClientMessage)
        assert response.success is False
        assert response.command_id == command_id
        assert "销毁中继: None，销毁失败" in response.message
        assert response.type == VPS_M_pb2.ClientMessageType.COMMAND_RESPONSE
        assert response.message_type == "DESTROYRELAYCOMMAND_RESPONSE"


    @pytest.mark.asyncio
    async def test_destroy_relay_execute_destroy_relay_success(self, destroy_relay_command, mock_service):
        """测试 execute：Relay 销毁成功，返回成功响应"""
        # 准备测试数据
        relay_code = "relay_12345"
        msg_data = {"relay_code": relay_code}
        command_id = "cmd_destroy_relay_002"

        # 执行命令
        response = await destroy_relay_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证
        mock_service.destroy_relay.assert_awaited_once_with(relay_code)

        # 2. 响应消息验证
        assert response.success is True
        assert f"销毁中继: {relay_code}" in response.message


    @pytest.mark.asyncio
    async def test_destroy_relay_execute_destroy_relay_failure(self, destroy_relay_command, mock_service):
        """测试 execute：Relay 销毁失败（destroy_relay 返回 False），返回失败响应"""
        # 模拟 service 返回 False
        mock_service.destroy_relay.return_value = False
        # 测试数据
        relay_code = "relay_67890"
        msg_data = {"relay_code": relay_code}
        command_id = "cmd_destroy_relay_003"

        # 执行命令
        response = await destroy_relay_command.execute(msg_data, command_id)

        # 断言
        # 1. 服务方法调用验证
        mock_service.destroy_relay.assert_awaited_once_with(relay_code)

        # 2. 响应消息验证
        assert response.success is False
        assert f"销毁中继: {relay_code}，销毁失败" in response.message


    @pytest.mark.asyncio
    async def test_destroy_relay_execute_destroy_relay_exception(self, destroy_relay_command, mock_service):
        """测试 execute：销毁过程抛出异常，返回失败响应"""
        # 模拟 service 抛出通用异常
        mock_error = Exception("Relay 进程占用，无法销毁")
        mock_service.destroy_relay.side_effect = mock_error
        # 测试数据
        relay_code = "relay_67890"
        msg_data = {"relay_code": relay_code}
        command_id = "cmd_destroy_relay_004"

        # 执行命令
        response = await destroy_relay_command.execute(msg_data, command_id)

        # 断言
        # 1. 响应消息验证
        assert response.success is False
        assert f"销毁中继失败: {mock_error}" in response.message

        # 2. 服务方法调用验证
        mock_service.destroy_relay.assert_awaited_once_with(relay_code)


    # -------------------- 边界场景测试 --------------------
    @pytest.mark.asyncio
    async def test_destroy_relay_execute_invalid_relay_id_type(self, destroy_relay_command, mock_service):
        """测试 execute：relay_id 为非字符串类型（如数字），仍调用服务方法"""
        # 测试数据：relay_id 为数字
        relay_code = 12345
        msg_data = {"relay_code": relay_code}
        command_id = "cmd_destroy_relay_005"

        # 执行命令
        await destroy_relay_command.execute(msg_data, command_id)

        # 断言：参数按原类型传递给服务层（类型校验由服务层处理）
        mock_service.destroy_relay.assert_awaited_once_with(relay_code)