import json
import pytest
from unittest.mock import MagicMock, AsyncMock

from commands.set_allow_auto_circuit_command import SetAllowAutoCircuitCommand
from generated import vps_management_pb2


@pytest.fixture
def mock_service():
    service = MagicMock()
    service.get_allow_auto_circuit = MagicMock(return_value=False)
    service.set_allow_auto_circuit = AsyncMock(return_value={"updated": ["client-1"]})
    return service


@pytest.fixture
def command(mock_service):
    context = MagicMock()
    context.node_code = "node-1"
    context.ip_address = "10.0.0.3"
    context.relays = {}
    cmd = SetAllowAutoCircuitCommand(context, MagicMock(), mock_service)
    cmd.logger = MagicMock()
    return cmd


class TestSetAllowAutoCircuitCommand:
    def test_get_command_type(self, command):
        assert command.get_command_type() == vps_management_pb2.CommandType.SET_ALLOW_AUTO_CIRCUIT

    def test_build_response_data_int_relay_id(self, command):
        data = command._build_response_data("88", "client-1", True)
        assert data["relay_id"] == 88
        assert data["allow_auto_circuit"] is True

    def test_build_response_data_non_int_relay_id(self, command):
        data = command._build_response_data("relay-x", "client-1", False)
        assert data["relay_id"] == "relay-x"

    @pytest.mark.asyncio
    async def test_execute_missing_allow_flag(self, command, mock_service):
        response = await command.execute(
            {"client_relay_code": "client-1", "relay_id": 9},
            "cmd-miss",
        )
        assert response.success is False
        assert "allow_auto_circuit" in response.message
        payload = json.loads(response.data)
        assert payload["allow_auto_circuit"] is False
        mock_service.set_allow_auto_circuit.assert_not_called()

    @pytest.mark.asyncio
    async def test_execute_success(self, command, mock_service):
        response = await command.execute(
            {
                "allow_auto_circuit": True,
                "client_relay_code": "client-1",
                "relay_id": 9,
            },
            "cmd-ok",
        )
        assert response.success is True
        payload = json.loads(response.data)
        assert payload["allow_auto_circuit"] is True
        assert payload["relay_id"] == 9
        mock_service.set_allow_auto_circuit.assert_awaited_once_with(
            allow=True, client_relay_code="client-1"
        )

    @pytest.mark.asyncio
    async def test_execute_service_error(self, command, mock_service):
        mock_service.set_allow_auto_circuit.side_effect = ValueError("目标不是 CLIENT 角色中继")
        mock_service.get_allow_auto_circuit.return_value = False
        response = await command.execute(
            {"allow_auto_circuit": True, "client_relay_code": "client-1"},
            "cmd-err",
        )
        assert response.success is False
        assert "目标不是 CLIENT 角色中继" in response.message
        payload = json.loads(response.data)
        assert payload["allow_auto_circuit"] is False
