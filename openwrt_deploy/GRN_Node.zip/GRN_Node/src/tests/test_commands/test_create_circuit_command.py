import json
import pytest
from unittest.mock import MagicMock, AsyncMock

from commands.create_circuit_command import CreateCircuitCommand
from config.config import LinkType
from generated import vps_management_pb2


@pytest.fixture
def mock_context():
    context = MagicMock()
    context.node_code = "node_123"
    context.ip_address = "192.168.1.100"
    context.relays = {}
    return context


@pytest.fixture
def mock_service():
    service = MagicMock()
    mock_circuit = MagicMock()
    mock_circuit.circuit_id = "circuit-id1"
    mock_circuit.to_json_response = MagicMock(return_value={"circuit_id": "circuit-id1"})
    service.create_circuit_with_link = AsyncMock(return_value=(mock_circuit, "link_456"))
    service.create_link = AsyncMock(return_value={
        "link_id": "parent-1",
        "results": [{"success": True}],
    })
    return service


@pytest.fixture
def create_circuit_command(mock_context, mock_service):
    return CreateCircuitCommand(mock_context, MagicMock(), mock_service)


class TestCreateCircuitCommand:
    def test_create_circuit_get_command_type(self, create_circuit_command):
        assert create_circuit_command.get_command_type() == vps_management_pb2.CommandType.CREATE_CIRCUIT

    @pytest.mark.asyncio
    async def test_create_circuit_execute_missing_client_relay_code(self, create_circuit_command):
        response = await create_circuit_command.execute(
            {"relay_fingerprints": ["fp1", "fp2"], "link_id": "l1"},
            "cmd_001",
        )
        assert isinstance(response, vps_management_pb2.ClientMessage)
        assert response.success is False
        assert "client_relay_code" in response.message

    @pytest.mark.asyncio
    async def test_create_circuit_execute_missing_relay_fingerprints(self, create_circuit_command):
        response = await create_circuit_command.execute(
            {"client_relay_code": "relay_001", "link_id": "l1"},
            "cmd_002",
        )
        assert response.success is False
        assert "relay_fingerprints" in response.message

    @pytest.mark.asyncio
    async def test_create_circuit_execute_missing_link_id(self, create_circuit_command):
        response = await create_circuit_command.execute(
            {"client_relay_code": "relay_001", "relay_fingerprints": ["fp1"]},
            "cmd_002b",
        )
        assert response.success is False
        assert "link_id" in response.message

    @pytest.mark.asyncio
    async def test_create_circuit_execute_create_circuit_success(self, create_circuit_command, mock_service):
        mock_circuit = MagicMock()
        mock_circuit.circuit_id = "789"
        mock_circuit.to_json_response = MagicMock(return_value={"circuit_id": "789"})
        mock_service.create_circuit_with_link.return_value = (mock_circuit, "link_456")
        response = await create_circuit_command.execute(
            {
                "client_relay_code": "relay_001",
                "relay_fingerprints": ["fp1", "fp2"],
                "link_id": "link_456",
                "set_as_default": True,
            },
            "cmd_003",
        )
        mock_service.create_circuit_with_link.assert_awaited_once_with(
            relay_fingerprints=["fp1", "fp2"],
            client_relay_code="relay_001",
            link_id="link_456",
            set_as_default=True,
        )
        assert response.success is True
        payload = json.loads(response.data)
        assert payload["circuit_code"] == 789
        assert payload["link_id"] == "link_456"

    @pytest.mark.asyncio
    async def test_create_circuit_execute_create_circuit_failure(self, create_circuit_command, mock_service):
        mock_service.create_circuit_with_link.return_value = (None, None)
        response = await create_circuit_command.execute(
            {
                "client_relay_code": "relay_001",
                "relay_fingerprints": ["fp1", "fp2"],
                "link_id": "l1",
            },
            "cmd_004",
        )
        assert response.success is False
        assert "创建电路失败" in response.message

    @pytest.mark.asyncio
    async def test_create_circuit_execute_create_circuit_exception(self, create_circuit_command, mock_service):
        mock_service.create_circuit_with_link.side_effect = RuntimeError("Tor 节点连接超时")
        response = await create_circuit_command.execute(
            {
                "client_relay_code": "relay_001",
                "relay_fingerprints": ["fp1", "fp2"],
                "link_id": "l1",
            },
            "cmd_005",
        )
        assert response.success is False
        assert "创建电路时发生异常" in response.message

    @pytest.mark.asyncio
    async def test_create_circuit_multi_link(self, create_circuit_command, mock_service):
        response = await create_circuit_command.execute(
            {
                "path_type": LinkType.MULTI_LINK,
                "client_relay_code": "relay_001",
                "link_id": "parent-1",
                "link_list": [{"relay_fingerprints": ["fp1"]}],
            },
            "cmd_multi",
        )
        mock_service.create_link.assert_awaited_once()
        assert response.success is True
