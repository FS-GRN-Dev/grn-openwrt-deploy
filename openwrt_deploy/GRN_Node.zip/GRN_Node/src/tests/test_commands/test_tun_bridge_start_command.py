import json
import pytest
from unittest.mock import MagicMock, AsyncMock

from commands.tun_bridge_start_command import TunBridgeStartCommand
from generated import VPS_M_pb2


@pytest.fixture
def mock_service():
    service = MagicMock()
    service.start_server = AsyncMock(return_value="bridge-server-1")
    service.start_client = AsyncMock(return_value="bridge-client-1")
    service.get_bridge_info = AsyncMock(return_value={
        "bridge_code": "bridge-server-1",
        "mode": "server",
        "listen_port": 19000,
    })
    return service


@pytest.fixture
def command(mock_service):
    context = MagicMock()
    context.node_code = "node-1"
    context.ip_address = "10.0.0.4"
    context.relays = {}
    cmd = TunBridgeStartCommand(context, MagicMock(), mock_service)
    cmd.logger = MagicMock()
    return cmd


class TestTunBridgeStartCommand:
    def test_get_command_type(self, command):
        if not hasattr(VPS_M_pb2.CommandType, "TUN_BRIDGE_START"):
            pytest.skip("当前 proto 未定义 TUN_BRIDGE_START")
        assert command.get_command_type() == VPS_M_pb2.CommandType.TUN_BRIDGE_START

    @pytest.mark.asyncio
    async def test_execute_invalid_mode(self, command, mock_service):
        response = await command.execute({"mode": "other"}, "cmd-1")
        assert response.success is False
        assert "mode" in response.message
        mock_service.start_server.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_execute_start_server(self, command, mock_service):
        response = await command.execute(
            {
                "mode": "server",
                "listen_host": "0.0.0.0",
                "listen_port": 19000,
                "tunnels": [{"tun_name": "tun0", "tun_addr_cidr": "10.0.1.1/24"}],
            },
            "cmd-server",
        )
        assert response.success is True
        json_part = response.message.split("命令cmd-server-", 1)[-1]
        payload = json.loads(json_part)
        assert payload["bridge_code"] == "bridge-server-1"
        mock_service.start_server.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_execute_start_client(self, command, mock_service):
        mock_service.get_bridge_info.return_value = {
            "bridge_code": "bridge-client-1",
            "mode": "client",
        }
        response = await command.execute(
            {
                "mode": "client",
                "client_relay_code": "client-1",
                "endpoint_host": "1.2.3.4",
                "endpoint_port": 19000,
            },
            "cmd-client",
        )
        assert response.success is True
        mock_service.start_client.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_execute_start_failure(self, command, mock_service):
        mock_service.start_server.side_effect = ValueError("listen_port 必须 > 0")
        response = await command.execute({"mode": "server"}, "cmd-fail")
        assert response.success is False
        assert "启动失败" in response.message
