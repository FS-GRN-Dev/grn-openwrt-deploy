import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from commands.set_node_status_command import SetNodeStatusCommand
from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2, vps_management_pb2



# ========== 测试 Fixture 定义 ==========
@pytest.fixture
def mock_context():
    """Mock NodeContext 实例（提供基础节点数据）"""
    context = MagicMock()
    context.node_code = "test_node_001"
    context.ip_address = "192.168.1.100"
    context.relays = {}
    return context


@pytest.fixture
def mock_reporter():
    """Mock StateReporter 实例"""
    return MagicMock()


@pytest.fixture
def mock_service():
    """Mock Service 实例（核心依赖：set_node_status 异步方法）"""
    service = MagicMock()
    # 默认 Mock 设置成功，返回 True
    service.set_node_status = AsyncMock(return_value=True)
    return service


@pytest.fixture
def set_node_status_command(mock_context, mock_reporter, mock_service):
    """初始化 SetNodeStatusCommand 实例"""
    command = SetNodeStatusCommand(
        context=mock_context,
        reporter=mock_reporter,
        service=mock_service
    )

    return command

# ========== 测试类 ==========
class TestSetNodeStatusCommand:
    """SetNodeStatusCommand 测试类"""

    # -------------------- 基础方法测试 --------------------
    def test_set_node_status_get_command_type(self, set_node_status_command):
        """测试 get_command_type 返回正确的命令类型"""
        # 执行 + 断言
        assert set_node_status_command.get_command_type() == VPS_M_pb2.CommandType.SET_NODE_STATUS


    # -------------------- 核心 execute 方法测试 --------------------
    @pytest.mark.asyncio
    async def test_set_node_status_execute_missing_new_status_field(self, set_node_status_command):
        """测试 execute：消息中缺少'new_status'字段，返回失败响应+错误日志"""
        # 准备测试数据：无 new_status 字段
        msg_data = {"other_field": "test"}  # 非 new_status 字段
        command_id = "cmd_set_status_001"

        # 执行命令
        response = await set_node_status_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 响应消息验证
        assert isinstance(response, vps_management_pb2.ClientMessage)
        assert response.success is False
        assert response.command_id == command_id
        assert response.message == f"命令{command_id}-命令消息缺少 'new_status' 字段"
        assert response.type == VPS_M_pb2.ClientMessageType.COMMAND_RESPONSE
        assert response.message_type == "SETNODESTATUSCOMMAND_RESPONSE"

        # 2. 未调用服务方法
        set_node_status_command.service.set_node_status.assert_not_awaited()


    @pytest.mark.asyncio
    async def test_set_node_status_execute_set_node_status_success(self, set_node_status_command, mock_service):
        """测试 execute：包含'new_status'字段且设置成功，返回成功响应+info日志"""
        # 准备测试数据（模拟合法状态值）
        new_status = vps_management_pb2.NodeStatus.NODE_ONLINE
        msg_data = {"new_status": new_status}
        command_id = "cmd_set_status_002"

        # 确保服务方法返回 True
        mock_service.set_node_status.return_value = True

        # 执行命令
        response = await set_node_status_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证：参数正确传递
        mock_service.set_node_status.assert_awaited_once_with(new_status)

        # 2. 响应消息验证
        assert response.success is True
        assert response.message == f"命令{command_id}-节点状态变更推送成功: {new_status}"


    @pytest.mark.asyncio
    async def test_set_node_status_execute_set_node_status_failure(self, set_node_status_command, mock_service):
        """测试 execute：包含'new_status'字段但设置失败，返回失败响应"""
        # 准备测试数据
        new_status = vps_management_pb2.NodeStatus.NODE_OFFLINE
        msg_data = {"new_status": new_status}
        command_id = "cmd_set_status_003"

        # 模拟服务方法返回 False
        mock_service.set_node_status.return_value = False

        # 执行命令
        response = await set_node_status_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证
        mock_service.set_node_status.assert_awaited_once_with(new_status)

        # 2. 响应消息验证
        assert response.success is False
        assert response.message == f"命令{command_id}-节点状态更新失败"


    @pytest.mark.asyncio
    async def test_set_node_status_execute_set_node_status_exception(self, set_node_status_command, mock_service):
        """测试 execute：包含'new_status'字段但设置抛异常，返回失败响应"""
        # 准备测试数据
        new_status = "INVALID_STATUS"  # 模拟非法状态值
        msg_data = {"new_status": new_status}
        command_id = "cmd_set_status_004"

        # 模拟服务方法抛出异常
        mock_error = Exception("非法的节点状态值，不支持 INVALID_STATUS")
        mock_service.set_node_status.side_effect = mock_error

        # 执行命令
        response = await set_node_status_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证
        mock_service.set_node_status.assert_awaited_once_with(new_status)

        # 2. 响应消息验证
        assert response.success is False
        assert response.message == f"命令{command_id}-节点状态变更推送失败: {mock_error}"


    # -------------------- 边界场景测试 --------------------
    @pytest.mark.asyncio
    async def test_set_node_status_execute_new_status_empty_value(self, set_node_status_command, mock_service):
        """测试 execute：new_status 为空值（如空字符串），仍调用服务方法"""
        # 准备测试数据：new_status 为空字符串
        new_status = ""
        msg_data = {"new_status": new_status}
        command_id = "cmd_set_status_005"

        # 执行命令
        await set_node_status_command.execute(msg_data, command_id)

        # 断言：服务方法仍被调用（空值的合法性由服务层校验）
        mock_service.set_node_status.assert_awaited_once_with(new_status)
