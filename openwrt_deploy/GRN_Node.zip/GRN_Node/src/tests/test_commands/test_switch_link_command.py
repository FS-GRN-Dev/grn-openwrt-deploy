import json
import pytest
from unittest.mock import MagicMock, AsyncMock

from commands.switch_link_command import SwitchLinkCommand
from generated import vps_management_pb2


@pytest.fixture
def mock_context():
    context = MagicMock()
    context.node_code = "test_node_001"
    context.ip_address = "192.168.1.100"
    context.relays = {}
    return context


@pytest.fixture
def mock_service():
    service = MagicMock()
    service.snapshot_enabled_link_ids = MagicMock(return_value=[101])
    service.apply_link_enable_action = AsyncMock(return_value={
        "success": True,
        "action": "enable",
        "link_id": 202,
        "switch_type": 1,
        "enabled_link_ids": [202],
        "switch_result": {"rolled_back": False},
        "message": "启用/停用链路成功",
    })
    return service


@pytest.fixture
def command(mock_context, mock_service):
    cmd = SwitchLinkCommand(mock_context, MagicMock(), mock_service)
    cmd.logger = MagicMock()
    return cmd


class TestSwitchLinkCommand:
    def test_get_command_type(self, command):
        assert command.get_command_type() == vps_management_pb2.CommandType.SWITCH_LINK

    def test_link_id_for_response(self):
        assert SwitchLinkCommand._link_id_for_response("12") == 12
        assert SwitchLinkCommand._link_id_for_response("abc") == "abc"
        assert SwitchLinkCommand._link_id_for_response("") == "0"

    @pytest.mark.asyncio
    async def test_execute_missing_action(self, command, mock_service):
        response = await command.execute(
            {"link_id": "1", "client_relay_code": "client-1"},
            "cmd-1",
        )
        assert response.success is False
        assert "缺少必要参数: action" in response.message
        payload = json.loads(response.data)
        assert payload["enabled_link_ids"] == [101]
        mock_service.apply_link_enable_action.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_execute_missing_link_id(self, command):
        response = await command.execute(
            {"action": "enable", "client_relay_code": "client-1", "switch_type": 1},
            "cmd-2",
        )
        assert response.success is False
        assert "link_id 和 client_relay_code" in response.message

    @pytest.mark.asyncio
    async def test_execute_enable_missing_switch_type(self, command):
        response = await command.execute(
            {"action": "enable", "link_id": "2", "client_relay_code": "client-1"},
            "cmd-3",
        )
        assert response.success is False
        assert "switch_type" in response.message

    @pytest.mark.asyncio
    async def test_execute_success(self, command, mock_service):
        response = await command.execute(
            {
                "action": "enable",
                "link_id": "202",
                "client_relay_code": "client-1",
                "switch_type": 1,
            },
            "cmd-ok",
        )
        assert response.success is True
        payload = json.loads(response.data)
        assert payload["enabled_link_ids"] == [202]
        assert payload["link_id"] == 202
        mock_service.apply_link_enable_action.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_execute_service_exception(self, command, mock_service):
        mock_service.apply_link_enable_action.side_effect = RuntimeError("boom")
        response = await command.execute(
            {
                "action": "disable",
                "link_id": "9",
                "client_relay_code": "client-1",
            },
            "cmd-err",
        )
        assert response.success is False
        assert "启用/停用链路异常" in response.message
        payload = json.loads(response.data)
        assert payload["enabled_link_ids"] == [101]
