import json
import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from commands.multipath_download_command import MultipathDownloadCommand
from generated import VPS_M_pb2


class DummyResult:
    def __init__(self, success=True):
        self.success = success

    def to_dict(self):
        return {"success": self.success, "parts": 2}


@pytest.fixture
def mock_context():
    context = MagicMock()
    context.node_code = "node-1"
    context.ip_address = "10.0.0.7"
    context.relays = {}
    stem = MagicMock()
    stem.socks_port = 9050
    context.stem2tor_instances = {"client-1": stem}
    return context


@pytest.fixture
def mock_service():
    service = MagicMock()
    circuit = MagicMock()
    circuit.circuit_id = "c1"
    service.create_circuit_with_link = AsyncMock(return_value=(circuit, "link-1"))
    service.delete_circuit = AsyncMock(return_value=True)
    return service


@pytest.fixture
def command(mock_context, mock_service):
    cmd = MultipathDownloadCommand(mock_context, MagicMock(), mock_service)
    cmd.logger = MagicMock()
    return cmd


def _base_msg(**extra):
    data = {
        "url": "http://example.test/file.bin",
        "output_path": "downloaded.bin",
        "parts": 2,
        "client_relay_code": "client-1",
        "cleanup": False,
    }
    data.update(extra)
    return data


class TestMultipathDownloadCommand:
    def test_get_command_type(self, command):
        if not hasattr(VPS_M_pb2.CommandType, "MULTIPATH_DOWNLOAD"):
            pytest.skip("当前 proto 未定义 MULTIPATH_DOWNLOAD")
        assert command.get_command_type() == VPS_M_pb2.CommandType.MULTIPATH_DOWNLOAD

    @pytest.mark.asyncio
    async def test_missing_url(self, command):
        response = await command.execute(_base_msg(url=""), "cmd-1")
        assert response.success is False
        assert "url" in response.message

    @pytest.mark.asyncio
    async def test_missing_output_path(self, command):
        msg = _base_msg()
        msg.pop("output_path")
        response = await command.execute(msg, "cmd-2")
        assert response.success is False
        assert "output_path" in response.message

    @pytest.mark.asyncio
    async def test_invalid_parts(self, command):
        response = await command.execute(_base_msg(parts=0), "cmd-3")
        assert response.success is False
        assert "parts" in response.message

    @pytest.mark.asyncio
    async def test_missing_client_relay(self, command):
        response = await command.execute(_base_msg(client_relay_code=""), "cmd-4")
        assert response.success is False
        assert "client_relay_code" in response.message

    @pytest.mark.asyncio
    async def test_unknown_client_relay(self, command, mock_context):
        mock_context.stem2tor_instances = {}
        response = await command.execute(_base_msg(), "cmd-5")
        assert response.success is False
        assert "不存在" in response.message

    @pytest.mark.asyncio
    async def test_missing_paths(self, command):
        response = await command.execute(_base_msg(), "cmd-6")
        assert response.success is False
        assert "paths" in response.message or "relay_fingerprints" in response.message

    @pytest.mark.asyncio
    async def test_download_with_link_ids(self, command, tmp_path):
        output = str(tmp_path / "out.bin")
        dummy = DummyResult(True)
        with patch(
            "commands.multipath_download_command.MultipathDownloader"
        ) as mock_downloader_cls, patch(
            "commands.multipath_download_command.asyncio.to_thread",
            new=AsyncMock(return_value=dummy),
        ):
            mock_downloader_cls.return_value.download = MagicMock(return_value=dummy)
            response = await command.execute(
                _base_msg(output_path=output, link_ids=["l1", "l2"]),
                "cmd-ok",
            )
        assert response.success is True
        payload = json.loads(response.message.split("命令cmd-ok-", 1)[-1])
        assert payload["result"]["success"] is True
        assert payload["proxy"]["port"] == 9050
