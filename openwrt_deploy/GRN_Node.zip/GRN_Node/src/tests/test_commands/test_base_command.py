import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

from commands.command import Command
from typing import Optional, List, Dict, Union, Callable, Any

from generated import vps_management_pb2


# ========== 测试 Fixture 定义 ==========
@pytest.fixture
def mock_deps():
    mock_context = MagicMock()
    mock_context.node_code = "test_node_001"
    mock_context.ip_address = "10.0.0.1"
    mock_context.relays = {}

    return {
        "node_context": mock_context,
        "state_reporter": MagicMock(),
        "service": MagicMock()
    }


@pytest.fixture
def mock_command(mock_deps):
    return Command(
        context = mock_deps['node_context'],
        reporter = mock_deps['state_reporter'],
        service = mock_deps['service']
    )


# ========== 测试类 ==========
class TestCommandBaseClass:
    """Command 抽象基类测试类"""

    # -------------------- 初始化逻辑测试 --------------------
    def test_command_initialization(self, mock_deps):
        """测试 Command 基类初始化：属性正确赋值"""
        # 定义测试子类（必须实现抽象方法才能实例化）
        class TestCommand(Command):

            async def execute(self, msg_data: dict[str, Any], command_id: str) -> vps_management_pb2.ClientMessage:
                pass

            def get_command_type(self) -> vps_management_pb2.CommandType:
                return vps_management_pb2.CommandType.UNKNOWN
        
        # 实例化子类
        test_command = TestCommand(
            context=mock_deps["node_context"],
            reporter=mock_deps["state_reporter"],
            service=mock_deps["service"],
        )

        # 断言初始化属性
        assert test_command.context == mock_deps["node_context"]
        assert test_command.reporter == mock_deps["state_reporter"]
        assert test_command.service == mock_deps["service"]


    # -------------------- 抽象方法约束测试 --------------------
    def test_command_abstract_methods_constraint(self, mock_deps):
        """测试未实现抽象方法的子类无法实例化，或调用时抛出 NotImplementedError"""
        # 场景1：未实现任何抽象方法的子类 -> 无法实例化（TypeError）
        with pytest.raises(TypeError) as exc_info:
            class InvalidCommand1(Command):
                pass

            # 尝试实例化会触发抽象方法检查
            InvalidCommand1(mock_deps["node_context"], mock_deps["state_reporter"], mock_deps["service"])
        
        assert "Can't instantiate abstract class InvalidCommand1" in str(exc_info.value)

        # 场景2：仅实现部分抽象方法 -> 仍无法实例化
        with pytest.raises(TypeError):
            class InvalidCommand2(Command):
                def get_command_type(self) -> vps_management_pb2.CommandType:
                    return vps_management_pb2.CommandType.UNKNOWN
                
            InvalidCommand2(mock_deps["node_context"], mock_deps["state_reporter"], mock_deps["service"])


        # 场景3：实现所有抽象方法但未覆盖逻辑（调用时无报错，仅验证约束）
        class ValidCommand(Command):
            async def execute(self, msg_data: dict[str, Any], command_id: str) -> vps_management_pb2.ClientMessage:
                # 未实现逻辑，调用时可自定义行为
                raise NotImplementedError("execute not implemented")
            def get_command_type(self) -> vps_management_pb2.CommandType:
                raise NotImplementedError("get_command_type not implemented")
        
        # 实例化成功（抽象方法已声明）
        valid_command = ValidCommand(mock_deps["node_context"], mock_deps["state_reporter"], mock_deps["service"])
        
        # 调用抽象方法会抛出自定义的 NotImplementedError
        with pytest.raises(NotImplementedError) as exc_info:
            valid_command.get_command_type()
        assert str(exc_info.value) == "get_command_type not implemented"

        # 异步方法调用
        @pytest.mark.asyncio
        async def test_execute_not_implemented():
            with pytest.raises(NotImplementedError):
                await valid_command.execute({}, "cmd_001")

        asyncio.run(test_execute_not_implemented())


    # -------------------- 通用方法 _create_response 测试 --------------------
    def test_command_create_response_generic_logic(self, mock_deps):
        """测试基类 _create_response 方法：生成的响应消息符合通用规范"""
        # 定义测试子类
        class TestCommand(Command):
            async def execute(self, msg_data: dict[str, Any], command_id: str) -> vps_management_pb2.ClientMessage:
                pass
            def get_command_type(self) -> vps_management_pb2.CommandType:
                return vps_management_pb2.CommandType.CREATE_CIRCUIT
        
        test_command = TestCommand(mock_deps["node_context"], mock_deps["state_reporter"], mock_deps["service"])
        
        # 测试数据
        command_id = "test_cmd_001"
        success = True
        message = "操作成功"

        # 执行 _create_response
        with patch("time.strftime") as mock_strftime:
            # Mock 时间戳，避免每次测试结果不同
            mock_strftime.return_value = "2025-12-31 12:00:00"
            response = test_command._create_response(command_id, success, message)

        # 核心断言：通用响应规范
        assert isinstance(response, vps_management_pb2.ClientMessage)

        # 1. 节点标识字段（来自 context）
        assert response.node_code == mock_deps["node_context"].node_code
        assert response.ip_address == mock_deps["node_context"].ip_address

        # 2. 命令相关字段
        assert response.command_id == command_id
        assert response.success == success
        assert response.message == f"命令{command_id}-{message}"

        # 3. 通用类型字段
        assert response.type == vps_management_pb2.ClientMessageType.COMMAND_RESPONSE
        assert response.message_type == "TESTCOMMAND_RESPONSE"  # 类名大写 + _RESPONSE

        # 4. 时间戳（Mock 后的值）
        assert response.timestamp == "2025-12-31 12:00:00"
        mock_strftime.assert_called_once_with("%Y-%m-%d %H:%M:%S")


    def test_command_create_response_failure_scenario(self, mock_deps):
        """测试 _create_response 失败场景：字段正确赋值"""
        class TestCommand(Command):
            async def execute(self, msg_data: dict[str, Any], command_id: str) -> vps_management_pb2.ClientMessage:
                pass
            def get_command_type(self) -> vps_management_pb2.CommandType:
                return vps_management_pb2.CommandType.DELETE_CIRCUIT
        
        test_command = TestCommand(mock_deps["node_context"], mock_deps["state_reporter"], mock_deps["service"])
        
        # 失败场景数据
        command_id = "test_cmd_002"
        success = False
        message = "参数错误"

        response = test_command._create_response(command_id, success, message)

        # 断言失败响应
        assert response.success is False
        assert response.message == f"命令{command_id}-参数错误"
        assert response.message_type == "TESTCOMMAND_RESPONSE"
        assert response.type == vps_management_pb2.ClientMessageType.COMMAND_RESPONSE