import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from commands.inform_da_info_command import InformDAInfoCommand
from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2, vps_management_pb2



# ========== 测试 Fixture 定义 ==========
@pytest.fixture
def mock_context():
    """Mock NodeContext 实例（提供基础节点数据）"""
    context = MagicMock()
    context.node_code = "test_node_001"
    context.ip_address = "192.168.1.100"
    context.relays = {}
    return context


@pytest.fixture
def mock_reporter():
    """Mock StateReporter 实例"""
    return MagicMock()


@pytest.fixture
def mock_service():
    """Mock Service 实例（核心依赖：update_da_info 异步方法）"""
    service = MagicMock()
    # 默认 Mock 更新成功，返回 True
    service.update_da_info = AsyncMock(return_value=True)
    return service


@pytest.fixture
def inform_da_info_command(mock_context, mock_reporter, mock_service):
    """初始化 InformDAInfoCommand 实例"""
    command = InformDAInfoCommand(
        context=mock_context,
        reporter=mock_reporter,
        service=mock_service
    )

    return command


# ========== 测试类 ==========
class TestInformDAInfoCommand:
    """InformDAInfoCommand 测试类"""

    # -------------------- 基础方法测试 --------------------
    def test_inform_da_info_get_command_type(self, inform_da_info_command):
        """测试 get_command_type 返回正确的命令类型"""
        # 执行 + 断言
        assert inform_da_info_command.get_command_type() == VPS_M_pb2.CommandType.INFORM_DA_INFO


    # -------------------- 核心 execute 方法测试 --------------------
    @pytest.mark.asyncio
    async def test_inform_da_info_execute_missing_da_info_field(self, inform_da_info_command):
        """测试 execute：消息中缺少'da_info'字段，返回失败响应+错误日志"""
        # 准备测试数据：无 da_info 字段
        msg_data = {"other_field": "test"}  # 非 da_info 字段
        command_id = "cmd_inform_da_001"

        # 执行命令
        response = await inform_da_info_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 响应消息验证
        assert isinstance(response, vps_management_pb2.ClientMessage)
        assert response.success is False
        assert response.command_id == command_id
        assert response.message == f"命令{command_id}-消息中缺少'da_info'字段"
        assert response.type == VPS_M_pb2.ClientMessageType.COMMAND_RESPONSE
        assert response.message_type == "INFORMDAINFOCOMMAND_RESPONSE"

        # 2. 未调用服务方法
        inform_da_info_command.service.update_da_info.assert_not_awaited()


    @pytest.mark.asyncio
    async def test_inform_da_info_execute_update_da_info_success(self, inform_da_info_command, mock_service):
        """测试 execute：包含'da_info'字段且更新成功，返回成功响应"""
        # 准备测试数据
        da_info = {
            "dir_auth_ip": "10.0.0.1",
            "dir_auth_port": 9030,
            "fingerprint": "DA1234567890ABCDEF"
        }
        msg_data = {"da_info": da_info}
        command_id = "cmd_inform_da_002"

        # 确保服务方法返回 True
        mock_service.update_da_info.return_value = True

        # 执行命令
        response = await inform_da_info_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证：参数正确传递
        mock_service.update_da_info.assert_awaited_once_with(da_info)

        # 2. 响应消息验证
        assert response.success is True
        assert response.message == f"命令{command_id}-DA信息处理成功"


    @pytest.mark.asyncio
    async def test_inform_da_info_execute_update_da_info_failure(self, inform_da_info_command, mock_service):
        """测试 execute：包含'da_info'字段但更新失败，返回失败响应"""
        # 准备测试数据
        da_info = {"dir_auth_ip": "10.0.0.2"}
        msg_data = {"da_info": da_info}
        command_id = "cmd_inform_da_003"

        # 模拟服务方法返回 False
        mock_service.update_da_info.return_value = False

        # 执行命令
        response = await inform_da_info_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证
        mock_service.update_da_info.assert_awaited_once_with(da_info)

        # 2. 响应消息验证
        assert response.success is False
        assert response.message == f"命令{command_id}-DA信息更新失败"


    @pytest.mark.asyncio
    async def test_inform_da_info_execute_update_da_info_exception(self, inform_da_info_command, mock_service):
        """测试 execute：包含'da_info'字段但更新抛异常，返回失败响应"""
        # 准备测试数据
        da_info = {"dir_auth_ip": "invalid_ip"}
        msg_data = {"da_info": da_info}
        command_id = "cmd_inform_da_004"

        # 模拟服务方法抛出异常
        mock_error = Exception("DA信息格式错误，IP地址不合法")
        mock_service.update_da_info.side_effect = mock_error

        # 执行命令
        response = await inform_da_info_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证
        mock_service.update_da_info.assert_awaited_once_with(da_info)

        # 2. 响应消息验证
        assert response.success is False
        assert response.message == f"命令{command_id}-处理DA信息时发生异常: {mock_error}"


    # -------------------- 边界场景测试 --------------------
    @pytest.mark.asyncio
    async def test_inform_da_info_execute_da_info_empty_dict(self, inform_da_info_command, mock_service):
        """测试 execute：da_info 为空字典，仍调用服务方法"""
        # 准备测试数据：da_info 为空字典
        da_info = {}
        msg_data = {"da_info": da_info}
        command_id = "cmd_inform_da_005"

        # 执行命令
        await inform_da_info_command.execute(msg_data, command_id)

        # 断言：服务方法仍被调用（空字典的合法性由服务层校验）
        mock_service.update_da_info.assert_awaited_once_with(da_info)
