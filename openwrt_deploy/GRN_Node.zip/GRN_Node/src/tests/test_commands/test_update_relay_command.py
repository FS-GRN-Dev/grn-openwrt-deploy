import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from commands.update_relay_command import UpdateRelayCommand
from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2, vps_management_pb2



# ========== 测试 Fixture 定义 ==========
@pytest.fixture
def mock_context():
    """Mock NodeContext 实例（提供基础节点数据）"""
    context = MagicMock()
    context.node_code = "test_node_001"
    context.ip_address = "192.168.1.100"
    context.relays = {}
    return context


@pytest.fixture
def mock_reporter():
    """Mock StateReporter 实例"""
    return MagicMock()


@pytest.fixture
def mock_service():
    """Mock Service 实例（核心依赖：update_relay 异步方法）"""
    service = MagicMock()
    # 默认 Mock 更新成功，返回 True
    service.update_relay = AsyncMock(return_value=True)
    return service


@pytest.fixture
def update_relay_command(mock_context, mock_reporter, mock_service):
    """初始化 UpdateRelayCommand 实例"""
    command = UpdateRelayCommand(
        context=mock_context,
        reporter=mock_reporter,
        service=mock_service
    )

    return command

# ========== 测试类 ==========
class TestUpdateRelayCommand:
    """UpdateRelayCommand 测试类"""

    # -------------------- 基础方法测试 --------------------
    def test_update_relay_get_command_type(self, update_relay_command):
        """测试 get_command_type 返回正确的命令类型"""
        # 执行 + 断言
        assert update_relay_command.get_command_type() == VPS_M_pb2.CommandType.UPDATE_RELAY


    # -------------------- 核心 execute 方法测试 --------------------
    @pytest.mark.asyncio
    @pytest.mark.parametrize("msg_data", [
        {"relay_id": "relay_123"},
        {"config_info": {"port": 9001}},    # 缺少 config
        {}
    ])
    async def test_update_relay_execute_missing_required_fields(self, update_relay_command, msg_data):
        """测试 execute：消息中缺少'relay_id'或'config'字段，返回失败响应"""
        command_id = "cmd_update_relay_001"

        # 执行命令
        response = await update_relay_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 响应消息验证
        assert isinstance(response, vps_management_pb2.ClientMessage)
        assert response.success is False
        assert response.command_id == command_id
        assert response.message == f"命令{command_id}-命令消息缺少'relay_id'或'config'字段"
        assert response.type == VPS_M_pb2.ClientMessageType.COMMAND_RESPONSE
        assert response.message_type == "UPDATERELAYCOMMAND_RESPONSE"

        # 2. 未调用服务方法
        update_relay_command.service.update_relay.assert_not_awaited()


    @pytest.mark.asyncio
    async def test_update_relay_execute_update_relay_success(self, update_relay_command, mock_service):
        """测试 execute：包含'relay_id'和'config'且更新成功，返回成功响应"""
        # 准备测试数据
        relay_id = "relay_123"
        config = {
            "port": 9001,
            "bandwidth_limit": "100MB",
            "enable": True
        }
        msg_data = {"relay_id": relay_id, "config": config}
        command_id = "cmd_update_relay_002"

        # 确保服务方法返回 True
        mock_service.update_relay.return_value = True

        # 执行命令
        response = await update_relay_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证：参数顺序和值正确
        mock_service.update_relay.assert_awaited_once_with(relay_id, config)

        # 2. 响应消息验证
        assert response.success is True
        assert response.message == f"命令{command_id}-Relay {relay_id} 配置更新成功"


    @pytest.mark.asyncio
    async def test_update_relay_execute_update_relay_not_exist(self, update_relay_command, mock_service):
        """测试 execute：Relay不存在（update_relay返回False），返回失败响应"""
        # 准备测试数据
        relay_id = "relay_456"
        config = {"port": 9002}
        msg_data = {"relay_id": relay_id, "config": config}
        command_id = "cmd_update_relay_003"

        # 模拟服务方法返回 False（Relay不存在）
        mock_service.update_relay.return_value = False

        # 执行命令
        response = await update_relay_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证
        mock_service.update_relay.assert_awaited_once_with(relay_id, config)

        # 2. 响应消息验证
        assert response.success is False
        assert response.message == f"命令{command_id}-Relay {relay_id} 不存在"


    @pytest.mark.asyncio
    async def test_update_relay_execute_update_relay_exception(self, update_relay_command, mock_service):
        """测试 execute：更新过程抛异常，返回失败响应"""
        # 准备测试数据
        relay_id = "relay_789"
        config = {"invalid_key": "invalid_value"}
        msg_data = {"relay_id": relay_id, "config": config}
        command_id = "cmd_update_relay_004"

        # 模拟服务方法抛出异常
        mock_error = Exception("配置格式错误：bandwidth_limit 必须为数字")
        mock_service.update_relay.side_effect = mock_error

        # 执行命令
        response = await update_relay_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证
        mock_service.update_relay.assert_awaited_once_with(relay_id, config)

        # 2. 响应消息验证
        assert response.success is False
        assert response.message == f"命令{command_id}-更新Relay {relay_id} 配置时出错: {mock_error}"


    # -------------------- 边界场景测试 --------------------
    @pytest.mark.asyncio
    async def test_update_relay_execute_config_empty_dict(self, update_relay_command, mock_service):
        """测试 execute：config 为空字典，仍调用服务方法"""
        # 准备测试数据：config 为空字典
        relay_id = "relay_000"
        config = {}
        msg_data = {"relay_id": relay_id, "config": config}
        command_id = "cmd_update_relay_005"

        # 执行命令
        await update_relay_command.execute(msg_data, command_id)

        # 断言：服务方法仍被调用（空配置的合法性由服务层校验）
        mock_service.update_relay.assert_awaited_once_with(relay_id, config)