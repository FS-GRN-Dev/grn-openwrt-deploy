import json
import pytest
from unittest.mock import MagicMock, AsyncMock

from commands.delete_circuit_command import DeleteCircuitCommand
from config.config import LinkType
from generated import vps_management_pb2


@pytest.fixture
def mock_context():
    context = MagicMock()
    context.node_code = "test_node_001"
    context.ip_address = "192.168.1.100"
    context.relays = {}
    return context


@pytest.fixture
def mock_service():
    service = MagicMock()
    service.delete_unified_link = AsyncMock(return_value={
        "results": [{"success": True, "link_id": "l1"}],
    })
    return service


@pytest.fixture
def delete_circuit_command(mock_context, mock_service):
    command = DeleteCircuitCommand(mock_context, MagicMock(), mock_service)
    command.logger = MagicMock()
    return command


class TestDeleteCircuitCommand:
    def test_delete_circuit_get_command_type(self, delete_circuit_command):
        assert delete_circuit_command.get_command_type() == vps_management_pb2.CommandType.DELETE_CIRCUIT

    @pytest.mark.asyncio
    async def test_delete_circuit_execute_missing_params(self, delete_circuit_command):
        response = await delete_circuit_command.execute({"circuit_id": "circuit_123"}, "cmd_delete_001")
        assert response.success is False
        assert "缺少必要参数" in response.message

    @pytest.mark.asyncio
    async def test_delete_circuit_execute_success(self, delete_circuit_command, mock_service):
        response = await delete_circuit_command.execute(
            {
                "client_relay_code": "client-1",
                "path_type": LinkType.SINGLE_LINK,
                "link_id": "11",
            },
            "cmd_ok",
        )
        mock_service.delete_unified_link.assert_awaited_once_with(
            LinkType.SINGLE_LINK, "11", "client-1"
        )
        assert response.success is True
        payload = json.loads(response.data)
        assert payload["link_id"] == "11"

    @pytest.mark.asyncio
    async def test_delete_circuit_execute_all_failed(self, delete_circuit_command, mock_service):
        mock_service.delete_unified_link.return_value = {"results": [{"success": False}]}
        response = await delete_circuit_command.execute(
            {
                "client_relay_code": "client-1",
                "path_type": LinkType.SINGLE_LINK,
                "link_id": "11",
            },
            "cmd_fail",
        )
        assert response.success is False

    @pytest.mark.asyncio
    async def test_delete_circuit_execute_exception(self, delete_circuit_command, mock_service):
        mock_service.delete_unified_link.side_effect = RuntimeError("tor down")
        response = await delete_circuit_command.execute(
            {
                "client_relay_code": "client-1",
                "path_type": LinkType.SINGLE_LINK,
                "link_id": "11",
            },
            "cmd_err",
        )
        assert response.success is False
        assert "销毁链路时出错" in response.message
