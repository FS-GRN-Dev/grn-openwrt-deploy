import pytest
from unittest.mock import MagicMock

from commands.heart_beat_response_command import HeartBeatResponseCommand
from generated import vps_management_pb2


@pytest.fixture
def command():
    context = MagicMock()
    context.node_code = "node-1"
    context.ip_address = "10.0.0.1"
    context.relays = {}
    cmd = HeartBeatResponseCommand(context, MagicMock(), MagicMock())
    cmd.logger = MagicMock()
    return cmd


class TestHeartBeatResponseCommand:
    def test_get_command_type(self, command):
        assert command.get_command_type() == vps_management_pb2.CommandType.HEART_BEAT_RESPONSE

    @pytest.mark.asyncio
    async def test_execute_logs_and_returns_none(self, command):
        result = await command.execute({}, "hb-1")
        assert result is None
        command.logger.info.assert_called()
