import json
import pytest
from unittest.mock import MagicMock, AsyncMock

from commands.tun_bridge_stop_command import TunBridgeStopCommand
from generated import VPS_M_pb2


@pytest.fixture
def mock_service():
    service = MagicMock()
    service.get_bridge_info = AsyncMock(return_value={"bridge_code": "bridge-1", "mode": "client"})
    service.stop = AsyncMock(return_value=True)
    return service


@pytest.fixture
def command(mock_service):
    context = MagicMock()
    context.node_code = "node-1"
    context.ip_address = "10.0.0.5"
    context.relays = {}
    cmd = TunBridgeStopCommand(context, MagicMock(), mock_service)
    cmd.logger = MagicMock()
    return cmd


class TestTunBridgeStopCommand:
    def test_get_command_type(self, command):
        if not hasattr(VPS_M_pb2.CommandType, "TUN_BRIDGE_STOP"):
            pytest.skip("当前 proto 未定义 TUN_BRIDGE_STOP")
        assert command.get_command_type() == VPS_M_pb2.CommandType.TUN_BRIDGE_STOP

    @pytest.mark.asyncio
    async def test_execute_missing_bridge_code(self, command, mock_service):
        response = await command.execute({}, "cmd-1")
        assert response.success is False
        assert "bridge_code" in response.message
        mock_service.stop.assert_not_awaited()

    @pytest.mark.asyncio
    async def test_execute_not_found(self, command, mock_service):
        mock_service.stop.return_value = False
        response = await command.execute({"bridge_code": "missing"}, "cmd-2")
        assert response.success is False
        assert "不存在" in response.message

    @pytest.mark.asyncio
    async def test_execute_success(self, command):
        response = await command.execute({"bridge_code": "bridge-1"}, "cmd-ok")
        assert response.success is True
        payload = json.loads(response.message.split("命令cmd-ok-", 1)[-1])
        assert payload["stopped"] is True
        assert payload["bridge_code"] == "bridge-1"

    @pytest.mark.asyncio
    async def test_execute_exception(self, command, mock_service):
        mock_service.stop.side_effect = RuntimeError("stop error")
        response = await command.execute({"bridge_code": "bridge-1"}, "cmd-err")
        assert response.success is False
        assert "停止失败" in response.message
