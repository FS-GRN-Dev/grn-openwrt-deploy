import json
import pytest
from unittest.mock import MagicMock, AsyncMock

from commands.cleanup_data_command import CleanupDataCommand
from generated import vps_management_pb2


@pytest.fixture
def mock_context():
    context = MagicMock()
    context.node_code = "node-clean"
    context.ip_address = "10.0.0.2"
    context.relays = {}
    return context


@pytest.fixture
def mock_service():
    service = MagicMock()
    service.cleanup_data = AsyncMock(return_value=(
        True,
        ["relay-a", "relay-b"],
        {"skipped": False, "deleted_circuits_count": 3, "success": True},
    ))
    return service


@pytest.fixture
def command(mock_context, mock_service):
    cmd = CleanupDataCommand(mock_context, MagicMock(), mock_service)
    cmd.logger = MagicMock()
    return cmd


class TestCleanupDataCommand:
    def test_get_command_type(self, command):
        assert command.get_command_type() == vps_management_pb2.CommandType.CLEANUP_DATA

    @pytest.mark.asyncio
    async def test_execute_success(self, command):
        response = await command.execute({}, "cmd-clean")
        assert response.success is True
        assert "已销毁 2 个中继" in response.message
        assert "已清理 3 条电路" in response.message
        payload = json.loads(response.data)
        assert payload["destroyed_relays"] == ["relay-a", "relay-b"]
        assert payload["node_code"] == "node-clean"

    @pytest.mark.asyncio
    async def test_execute_partial_failure(self, command, mock_service):
        mock_service.cleanup_data.return_value = (
            False,
            ["relay-a"],
            {"skipped": True, "success": False},
        )
        response = await command.execute({"action": "cleanup_data"}, "cmd-partial")
        assert response.success is False
        assert "部分失败" in response.message

    @pytest.mark.asyncio
    async def test_execute_exception(self, command, mock_service):
        mock_service.cleanup_data.side_effect = RuntimeError("disk error")
        response = await command.execute({}, "cmd-err")
        assert response.success is False
        assert "清理数据失败: disk error" in response.message
