import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from commands.refresh_info_command import RefreshInfoCommand
from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2, vps_management_pb2



# ========== 测试 Fixture 定义 ==========
@pytest.fixture
def mock_context():
    """Mock NodeContext 实例（提供基础节点数据）"""
    context = MagicMock()
    context.node_code = "test_node_001"
    context.ip_address = "192.168.1.100"
    context.relays = {}
    return context


@pytest.fixture
def mock_reporter():
    """Mock StateReporter 实例"""
    return MagicMock()


@pytest.fixture
def mock_service():
    """Mock Service 实例（核心依赖：refresh_info 异步方法）"""
    service = MagicMock()
    # 默认 Mock 刷新成功，返回 True
    service.refresh_info = AsyncMock(return_value=True)
    return service


@pytest.fixture
def refresh_info_command(mock_context, mock_reporter, mock_service):
    """初始化 RefreshInfoCommand 实例"""
    command = RefreshInfoCommand(
        context=mock_context,
        reporter=mock_reporter,
        service=mock_service
    )

    return command


# ========== 测试类 ==========
class TestRefreshInfoCommand:
    """RefreshInfoCommand 测试类"""

    # -------------------- 基础方法测试 --------------------
    def test_refresh_info_get_command_type(self, refresh_info_command):
        """测试 get_command_type 返回正确的命令类型"""
        # 执行 + 断言
        assert refresh_info_command.get_command_type() == VPS_M_pb2.CommandType.REFRESH_INFO


    # -------------------- 核心 execute 方法测试 --------------------
    @pytest.mark.asyncio
    async def test_refresh_info_execute_refresh_info_success(self, refresh_info_command, mock_service):
        """测试 execute：节点信息刷新成功，返回成功响应"""
        # 准备测试数据（该命令无需 msg_data 入参，传空字典即可）
        msg_data = {}
        command_id = "cmd_refresh_001"

        # 确保服务方法返回 True
        mock_service.refresh_info.return_value = True

        # 执行命令
        response = await refresh_info_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证：无参数调用 refresh_info
        mock_service.refresh_info.assert_awaited_once()

        # 2. 响应消息验证
        assert isinstance(response, vps_management_pb2.ClientMessage)
        assert response.success is True
        assert response.command_id == command_id
        assert response.message == f"命令{command_id}-节点信息刷新成功"
        assert response.type == VPS_M_pb2.ClientMessageType.COMMAND_RESPONSE
        assert response.message_type == "REFRESHINFOCOMMAND_RESPONSE"

        # 通用字段验证
        assert response.node_code == "test_node_001"
        assert response.ip_address == "192.168.1.100"


    @pytest.mark.asyncio
    async def test_refresh_info_execute_refresh_info_failure(self, refresh_info_command, mock_service):
        """测试 execute：节点信息刷新失败，返回失败响应"""
        # 准备测试数据
        msg_data = {"extra_param": "test"}  # 模拟带额外参数的场景
        command_id = "cmd_refresh_002"

        # 模拟服务方法返回 False
        mock_service.refresh_info.return_value = False

        # 执行命令
        response = await refresh_info_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证
        mock_service.refresh_info.assert_awaited_once()

        # 2. 响应消息验证
        assert response.success is False
        assert response.message == f"命令{command_id}-节点信息刷新失败"


    @pytest.mark.asyncio
    async def test_refresh_info_execute_refresh_info_exception(self, refresh_info_command, mock_service):
        """测试 execute：刷新过程抛出异常，返回失败响应"""
        # 准备测试数据
        msg_data = {}
        command_id = "cmd_refresh_003"

        # 模拟服务方法抛出通用异常
        mock_error = Exception("获取节点状态超时，刷新失败")
        mock_service.refresh_info.side_effect = mock_error

        # 执行命令
        response = await refresh_info_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证
        mock_service.refresh_info.assert_awaited_once()

        # 2. 响应消息验证
        assert response.success is False
        assert response.message == f"命令{command_id}-节点信息刷新异常: {mock_error}"


    # -------------------- 边界场景测试 --------------------
    @pytest.mark.asyncio
    async def test_refresh_info_execute_msg_data_with_params(self, refresh_info_command, mock_service):
        """测试 execute：msg_data 带额外参数，不影响刷新逻辑"""
        # 准备测试数据：带任意额外参数
        msg_data = {
            "unrelated_param1": "value1",
            "unrelated_param2": 123
        }
        command_id = "cmd_refresh_004"

        # 执行命令
        await refresh_info_command.execute(msg_data, command_id)

        # 断言：服务方法仍正常调用，不受额外参数影响
        mock_service.refresh_info.assert_awaited_once()
