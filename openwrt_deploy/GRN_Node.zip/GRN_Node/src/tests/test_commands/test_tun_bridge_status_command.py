import json
import pytest
from unittest.mock import MagicMock, AsyncMock

from commands.tun_bridge_status_command import TunBridgeStatusCommand
from generated import VPS_M_pb2


@pytest.fixture
def command():
    context = MagicMock()
    context.node_code = "node-1"
    context.ip_address = "10.0.0.6"
    context.relays = {}
    service = MagicMock()
    service.status = MagicMock(return_value=[{"bridge_code": "b1", "mode": "server"}])
    cmd = TunBridgeStatusCommand(context, MagicMock(), service)
    cmd.logger = MagicMock()
    cmd._service = service
    return cmd


class TestTunBridgeStatusCommand:
    def test_get_command_type(self, command):
        if not hasattr(VPS_M_pb2.CommandType, "TUN_BRIDGE_STATUS"):
            pytest.skip("当前 proto 未定义 TUN_BRIDGE_STATUS")
        assert command.get_command_type() == VPS_M_pb2.CommandType.TUN_BRIDGE_STATUS

    @pytest.mark.asyncio
    async def test_execute_sync_status(self, command):
        response = await command.execute({}, "cmd-st")
        assert response.success is True
        payload = json.loads(response.message.split("命令cmd-st-", 1)[-1])
        assert payload["bridges"][0]["bridge_code"] == "b1"

    @pytest.mark.asyncio
    async def test_execute_async_status(self, command):
        command.service.status = AsyncMock(return_value=[{"bridge_code": "b2"}])
        response = await command.execute({}, "cmd-async")
        assert response.success is True
        payload = json.loads(response.message.split("命令cmd-async-", 1)[-1])
        assert payload["bridges"][0]["bridge_code"] == "b2"

    @pytest.mark.asyncio
    async def test_execute_exception(self, command):
        command.service.status = MagicMock(side_effect=RuntimeError("status fail"))
        response = await command.execute({}, "cmd-err")
        assert response.success is False
        assert "获取状态失败" in response.message
