import pytest
from unittest.mock import MagicMock, AsyncMock, patch

from commands.destroy_node_command import DestroyNodeCommand
from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2, vps_management_pb2



# ========== 测试 Fixture 定义 ==========
@pytest.fixture
def mock_context():
    """Mock NodeContext 实例（提供基础节点数据）"""
    context = MagicMock()
    context.node_code = "test_node_001"
    context.ip_address = "192.168.1.100"
    context.relays = {}
    return context


@pytest.fixture
def mock_reporter():
    """Mock StateReporter 实例"""
    return MagicMock()


@pytest.fixture
def mock_service():
    """Mock Service 实例（核心依赖：destroy_node 异步方法）"""
    service = MagicMock()
    # 默认 Mock 销毁成功，返回 True
    service.destroy_node = AsyncMock(return_value=True)
    return service


@pytest.fixture
def mock_node_client():
    """Mock NodeClient 实例（提供 node_id 校验）"""
    node_client = MagicMock()
    node_client.node_id = "test_node_001"  # 当前节点ID
    return node_client


@pytest.fixture
def destroy_node_command(mock_context, mock_reporter, mock_service, mock_node_client):
    """初始化 DestroyNodeCommand 实例"""
    command = DestroyNodeCommand(
        context=mock_context,
        reporter=mock_reporter,
        service=mock_service
    )
    # 补充 node_client 属性（命令类依赖）
    command.node_client = mock_node_client

    return command

# ========== 测试类 ==========
class TestDestroyNodeCommand:
    """DestroyNodeCommand 测试类"""

    # -------------------- 基础方法测试 --------------------
    def test_destroy_node_get_command_type(self, destroy_node_command):
        """测试 get_command_type 返回正确的命令类型"""
        # 执行 + 断言
        assert destroy_node_command.get_command_type() == VPS_M_pb2.CommandType.DESTROY_NODE


    # -------------------- 核心 execute 方法测试 --------------------
    @pytest.mark.asyncio
    async def test_destroy_node_execute_node_id_mismatch(self, destroy_node_command, mock_service):
        """测试 execute：目标节点ID与当前节点不匹配，跳过销毁逻辑"""
        # 准备测试数据：目标节点ID≠当前节点ID
        msg_data = {"node_code": "test_node_002"}
        command_id = "cmd_destroy_001"

        # 执行命令（注意：原代码未处理ID不匹配的返回值，需补充默认返回或验证逻辑）
        response = await destroy_node_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 未调用销毁服务方法
        mock_service.destroy_node.assert_not_awaited()

        # 2. 响应消息验证
        assert isinstance(response, vps_management_pb2.ClientMessage)
        assert response.success is False
        assert response.command_id == command_id
        assert response.message == f"命令{command_id}-销毁目标节点ID不存在"
        assert response.type == VPS_M_pb2.ClientMessageType.COMMAND_RESPONSE
        assert response.message_type == "DESTROYNODECOMMAND_RESPONSE"


    @pytest.mark.asyncio
    async def test_destroy_node_execute_destroy_node_success(self, destroy_node_command, mock_service):
        """测试 execute：目标节点ID匹配，节点销毁成功"""
        # 准备测试数据：目标节点ID=当前节点ID
        msg_data = {"node_code": "test_node_001"}
        command_id = "cmd_destroy_002"

        # 执行命令
        response = await destroy_node_command.execute(msg_data, command_id)

        # 核心断言
        # 1. 服务方法调用验证
        mock_service.destroy_node.assert_awaited_once()

        # 2. 响应消息验证
        assert isinstance(response, vps_management_pb2.ClientMessage)
        assert response.success is True
        assert response.command_id == command_id
        assert response.message == f"命令{command_id}-销毁节点，销毁成功"
        assert response.type == VPS_M_pb2.ClientMessageType.COMMAND_RESPONSE
        assert response.message_type == "DESTROYNODECOMMAND_RESPONSE"


    @pytest.mark.asyncio
    async def test_destroy_node_execute_destroy_node_failure(self, destroy_node_command, mock_service):
        """测试 execute：目标节点ID匹配，节点销毁失败（destroy_node 返回 False）"""
        # 模拟 service 返回 False
        mock_service.destroy_node.return_value = False

        # 测试数据
        msg_data = {"node_code": "test_node_001"}
        command_id = "cmd_destroy_003"

        # 执行命令
        response = await destroy_node_command.execute(msg_data, command_id)

        # 断言
        # 1. 服务方法调用验证
        mock_service.destroy_node.assert_awaited_once()

        # 2. 响应消息验证
        assert response.success is False
        assert response.message == f"命令{command_id}-节点销毁失败"


    @pytest.mark.asyncio
    async def test_destroy_node_execute_destroy_node_exception(self, destroy_node_command, mock_service):
        """测试 execute：目标节点ID匹配，销毁过程抛出异常"""
        # 模拟 service 抛出通用异常
        mock_error = Exception("销毁Relay时出错，进程无法终止")
        mock_service.destroy_node.side_effect = mock_error

        # 测试数据
        msg_data = {"node_code": "test_node_001"}
        command_id = "cmd_destroy_004"

        # 执行命令
        response = await destroy_node_command.execute(msg_data, command_id)

        # 断言
        # 1. 服务方法调用验证
        mock_service.destroy_node.assert_awaited_once()

        # 2. 响应消息验证
        assert response.success is False
        assert response.message == f"命令{command_id}-节点销毁过程中出现错误: {mock_error}"


    # -------------------- 边界场景测试 --------------------
    @pytest.mark.asyncio
    async def test_destroy_node_execute_missing_node_id(self, destroy_node_command, mock_service):
        """测试 execute：缺少 node_id 参数，跳过销毁逻辑"""
        # 测试数据：无 node_id
        msg_data = {}
        command_id = "cmd_destroy_005"

        # 执行命令
        response = await destroy_node_command.execute(msg_data, command_id)

        # 断言
        mock_service.destroy_node.assert_not_awaited()

        # 响应消息验证
        assert isinstance(response, vps_management_pb2.ClientMessage)
        assert response.success is False
        assert response.command_id == command_id
        assert response.message == f"命令{command_id}-销毁目标节点ID不存在"
        assert response.type == VPS_M_pb2.ClientMessageType.COMMAND_RESPONSE
        assert response.message_type == "DESTROYNODECOMMAND_RESPONSE"
