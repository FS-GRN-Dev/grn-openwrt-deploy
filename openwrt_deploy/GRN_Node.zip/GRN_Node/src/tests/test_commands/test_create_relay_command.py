import json
import pytest
from unittest.mock import MagicMock, AsyncMock

from commands.create_relay_command import CreateRelayCommand
from generated import vps_management_pb2


@pytest.fixture
def mock_context():
    context = MagicMock()
    context.node_code = "test_node_001"
    context.ip_address = "192.168.1.100"
    context.relays = {}
    return context


@pytest.fixture
def mock_service():
    service = MagicMock()
    service.create_relay = AsyncMock(return_value={
        "relay_code": "relay_12345",
        "server_bridge_code": "",
    })
    return service


@pytest.fixture
def create_relay_command(mock_context, mock_service):
    command = CreateRelayCommand(mock_context, MagicMock(), mock_service)
    command.logger = MagicMock()
    return command


class TestCreateRelayCommand:
    def test_create_relay_get_command_type(self, create_relay_command):
        assert create_relay_command.get_command_type() == vps_management_pb2.CommandType.CREATE_RELAY

    @pytest.mark.asyncio
    async def test_create_relay_execute_create_relay_success(self, create_relay_command, mock_service):
        msg_data = {
            "relay_type": vps_management_pb2.RelayType.RELAY_ACCESS,
            "relay_role": vps_management_pb2.RelayRole.ROLE_RELAY,
            "relay_id": 100,
        }
        response = await create_relay_command.execute(msg_data, "cmd_create_relay_001")
        mock_service.create_relay.assert_awaited_once()
        args, kwargs = mock_service.create_relay.await_args
        assert args[0] == 100
        assert args[1] == vps_management_pb2.RelayType.RELAY_ACCESS
        assert args[2] == vps_management_pb2.RelayRole.ROLE_RELAY
        assert isinstance(response, vps_management_pb2.ClientMessage)
        assert response.success is True
        assert "relay_12345" in response.message
        payload = json.loads(response.data)
        assert payload["relay_code"] == "relay_12345"

    @pytest.mark.asyncio
    async def test_create_relay_execute_create_relay_default_params(self, create_relay_command, mock_service):
        await create_relay_command.execute({}, "cmd_create_relay_002")
        args, kwargs = mock_service.create_relay.await_args
        assert args[1] is None
        assert args[2] is None

    @pytest.mark.asyncio
    async def test_create_relay_execute_create_relay_value_error(self, create_relay_command, mock_service):
        mock_error = ValueError("relay_type 无效：不支持的类型")
        mock_service.create_relay.side_effect = mock_error
        response = await create_relay_command.execute(
            {"relay_type": 999, "relay_role": vps_management_pb2.RelayRole.ROLE_RELAY},
            "cmd_create_relay_003",
        )
        assert response.success is False
        assert "参数错误" in response.message

    @pytest.mark.asyncio
    async def test_create_relay_execute_create_relay_runtime_error(self, create_relay_command, mock_service):
        mock_service.create_relay.side_effect = RuntimeError("Tor 进程启动失败，无法创建 Relay")
        response = await create_relay_command.execute(
            {"relay_type": vps_management_pb2.RelayType.RELAY_ANONYMOUS},
            "cmd_create_relay_004",
        )
        assert response.success is False
        assert "创建失败" in response.message

    @pytest.mark.asyncio
    async def test_create_relay_execute_create_relay_unknown_exception(self, create_relay_command, mock_service):
        mock_service.create_relay.side_effect = Exception("网络异常")
        response = await create_relay_command.execute(
            {"relay_role": vps_management_pb2.RelayRole.ROLE_EXIT},
            "cmd_create_relay_005",
        )
        assert response.success is False
        assert "未知错误" in response.message
