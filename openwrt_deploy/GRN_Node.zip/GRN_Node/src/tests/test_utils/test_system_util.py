from config.config import SystemConfig
from utils.system import calculate_risk_level


def test_system_calculate_risk_level():
    risk_list = [SystemConfig.RISK_LEVEL_CRITICAL, SystemConfig.RISK_LEVEL_HIGH, SystemConfig.RISK_LEVEL_MEDIUM, SystemConfig.RISK_LEVEL_LOW, SystemConfig.RISK_LEVEL_MINIMAL]
    assert calculate_risk_level() in risk_list