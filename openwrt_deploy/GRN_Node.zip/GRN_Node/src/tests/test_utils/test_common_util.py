import json
from types import SimpleNamespace
from utils.common import create_general_message


def test_common_create_general_message():
    node_client = SimpleNamespace(node_code="node-1", ip_address="127.0.0.1")
    command_id = "cmd-create-1766565565"
    message = json.dumps({"action": "create_relay"})
    client_message = create_general_message(node_client, command_id, True, message)

    assert client_message.node_code == "node-1"
    assert client_message.ip_address == "127.0.0.1"
    assert client_message.message_type == "GENERAL_COMMAND_RESPONSE"
    assert client_message.command_id == command_id
    assert client_message.success is True
    assert client_message.message == message
