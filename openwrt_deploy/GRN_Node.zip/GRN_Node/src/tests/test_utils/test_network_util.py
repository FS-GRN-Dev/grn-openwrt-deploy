from utils.network import is_valid_ipv4, extract_provider, get_network_info
import utils.logger



def test_network_is_valid_ipv4():
    assert is_valid_ipv4("127.0.0") == False
    assert is_valid_ipv4("127.0.0.1.1") == False
    assert is_valid_ipv4("127.0.0.a") == False
    assert is_valid_ipv4("127.366.0.1") == False
    assert is_valid_ipv4("127.0.0.1") == True

def test_network_extract_provider():
    assert extract_provider("") == ""  
    assert extract_provider("Alibaba") == "阿里云"  
    assert extract_provider("AS24445 Aliyun") == "阿里云"
    assert extract_provider("Tencent") == "腾讯云"
    assert extract_provider("AS24445 Amazon") == "AWS"
    assert extract_provider("AS24445 Google") == "GCP"
    assert extract_provider("AS24445 Azure") == "Azure"
    assert extract_provider("AS24445 Baidu") == "百度云"
    assert extract_provider("AS24445 Huawei") == "华为云"
    assert extract_provider("AS24445 China Telecom") == "中国电信"
    assert extract_provider("AS24445 China Unicom") == "中国联通"
    assert extract_provider("AS24445 China Mobile") == "中国移动"
    assert extract_provider("Education and Research") == "and Research"
    assert extract_provider("Education") == "Education"
    assert extract_provider("Research") == "Research"

def test_network_get_network_info():
    logger = utils.logger.get_logger(f"test_network_util")

    ip, geo, provider, lat, lon = get_network_info(logger, "127.0.0.1")
    assert ip == "127.0.0.1"
    assert geo == ""
    assert provider == ""
    assert lat == 0.0
    assert lon == 0.0

    ip, geo, provider, lat, lon = get_network_info(logger, "127.0.0.1", "test")
    assert ip != "127.0.0.1"
    assert geo == ""
    assert provider == ""

    ip, geo, provider, lat, lon = get_network_info(logger, "")
    assert ip != ""