from utils.converters import get_role, classify_weight
from generated import VPS_M_pb2


def test_converters_get_role():
    role_list = [VPS_M_pb2.RelayRole.ROLE_DA, VPS_M_pb2.RelayRole.ROLE_RELAY, VPS_M_pb2.RelayRole.ROLE_EXIT,
                 VPS_M_pb2.RelayRole.ROLE_CLIENT, VPS_M_pb2.RelayRole.ROLE_HS, 5]
    
    assert get_role(role_list[0]) == "da"
    assert get_role(role_list[1]) == "relay"
    assert get_role(role_list[2]) == "exit"
    assert get_role(role_list[3]) == "client"
    assert get_role(role_list[4]) == "hs"

    try:
        get_role(role_list[5])
    except ValueError as e:
        assert str(e) == "未知的节点角色: 5"
    else:
        assert False, "未抛出异常"

def test_converters_classify_weight():
    cw_list = [30001, 20000, 14999]

    assert classify_weight(cw_list[0]) == "Guard"
    assert classify_weight(cw_list[1]) == "Exit"
    assert classify_weight(cw_list[2]) == "Middle"
