from config.config import LinkType
from utils.command_payloads import (
    _coalesce,
    _normalize_list,
    normalize_link_entries,
    normalize_create_circuit_payload,
    normalize_switch_link_payload,
    normalize_tunnels,
    normalize_tun_bridge_payload,
    normalize_client_bridge_config,
    normalize_server_bridge_config,
    normalize_create_relay_payload,
)


def test_coalesce_prefers_first_present_key():
    data = {"b": None, "c": "ok"}
    assert _coalesce(data, "a", "b", "c", default="x") == "ok"
    assert _coalesce({}, "a", default=3) == 3


def test_normalize_list_variants():
    assert _normalize_list(None) == []
    assert _normalize_list("a, b, ,c") == ["a", "b", "c"]
    assert _normalize_list(["x", " y ", ""]) == ["x", "y"]
    assert _normalize_list(123) == []


def test_normalize_link_entries():
    entries = normalize_link_entries(
        [
            {"client_relay_code": "c1", "relay_codes": "fp1,fp2", "link_id": 9},
            "skip-me",
            {"relay_fingerprints": ["fp3"]},
        ],
        default_client_relay_code="default-c",
    )
    assert entries[0]["client_relay_code"] == "c1"
    assert entries[0]["relay_fingerprints"] == ["fp1", "fp2"]
    assert entries[0]["link_id"] == "9"
    assert entries[1]["client_relay_code"] == "default-c"
    assert entries[1]["relay_fingerprints"] == ["fp3"]
    assert normalize_link_entries(None) == []


def test_normalize_create_circuit_payload():
    payload = normalize_create_circuit_payload(
        {
            "client_relay_code": "client-1",
            "parent_link_id": "p1",
            "path_type": LinkType.MULTI_LINK,
            "linkList": [{"relay_codes": ["fp1"]}],
            "set_as_default": True,
        }
    )
    assert payload["link_id"] == "p1"
    assert payload["path_type"] == LinkType.MULTI_LINK
    assert payload["set_as_default"] is True
    assert len(payload["link_list"]) == 1


def test_normalize_switch_link_payload():
    payload = normalize_switch_link_payload(
        {
            "action": " ENABLE ",
            "link_id": 12,
            "client_relay_code": "c1",
            "switch_type": "2",
            "bridge_info": {"endpoint_host": "1.1.1.1", "endpoint_port": 9},
        }
    )
    assert payload["action"] == "enable"
    assert payload["link_id"] == "12"
    assert payload["switch_type"] == 2
    assert payload["bridge_info"]["endpoint_host"] == "1.1.1.1"

    invalid = normalize_switch_link_payload({"switch_type": "abc"})
    assert invalid["switch_type"] is None


def test_normalize_tunnels_and_bridge_payload():
    assert normalize_tunnels(None) == []
    tunnels = normalize_tunnels(
        [{"tun_name": "tun0", "tun_addr_cidr": "10.0.1.1/24", "link_id": 1}, "bad"]
    )
    assert tunnels == [{"tun_name": "tun0", "tun_addr_cidr": "10.0.1.1/24", "link_id": "1"}]

    payload = normalize_tun_bridge_payload(
        {
            "mode": "SERVER",
            "listen_port": "19000",
            "enable_mptcp": False,
            "tunnels": tunnels,
        }
    )
    assert payload["mode"] == "server"
    assert payload["listen_port"] == 19000
    assert payload["enable_mptcp"] is False
    assert payload["tunnels"] == tunnels


def test_normalize_bridge_configs_and_create_relay():
    assert normalize_client_bridge_config("nope") == {}
    client_cfg = normalize_client_bridge_config({"endpoint_host": "8.8.8.8"})
    assert "mode" not in client_cfg
    assert client_cfg["endpoint_host"] == "8.8.8.8"

    server_cfg = normalize_server_bridge_config({"listen_port": 1})
    assert server_cfg["listen_port"] == 1

    relay = normalize_create_relay_payload(
        {
            "relay_type": 1,
            "relay_role": 3,
            "relay_code": "r1",
            "da_info": [{"nick": "da"}],
            "bridge_info": {"listen_port": 9},
        }
    )
    assert relay["relay_id"] == "r1"
    assert relay["dir_auths"] == [{"nick": "da"}]
    assert relay["server_bridge"]["listen_port"] == 9
