import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

from core.stem_api import Stem2Tor
from services.tor_container_service import TorContainerService
from services.tor_controller_service import TorControllerService

from config.config import StemConfig
from config.tor_node_config import TorNodeConfig

from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2




# -------------------------- 基础测试夹具 --------------------------
@pytest.fixture
def mock_tor_config():
    """模拟 TorNodeConfig 配置对象"""
    config = MagicMock(spec=TorNodeConfig)
    # 基础配置
    config.role = "client"
    config.nick = "test-tor-node"
    config.pwd = "test-password"
    config.or_port = 9001
    config.socks_port = 9050
    config.control_port = 9051
    config.dir_port = "9030"
    config.dir_auths = "test-dir-auths"
    config.outer_ip_addr = "192.168.1.100"
    config.network_mode = "bridge"
    # 容器相关配置
    config.container_name = "test-tor-container"
    return config


@pytest.fixture
def mock_container_service(mock_tor_config):
    """模拟 TorContainerService"""
    service = AsyncMock(spec=TorContainerService)
    service.config = mock_tor_config
    service.container = MagicMock()
    service.container_name = mock_tor_config.container_name
    service.container_ip_addr = "172.17.0.2"
    service.start_container = MagicMock(return_value="test-container-id-001")
    service.stop_container = MagicMock(return_value=True)
    service.wait_for_port = MagicMock(return_value=True)
    service.get_dir_auths = AsyncMock(return_value=[
        {"nick": "test-da", "address": "192.168.1.1", "orport": 9001}
    ])
    service.update_dir_auths = AsyncMock(return_value=True)
    return service


@pytest.fixture
def mock_controller_service(mock_tor_config):
    """模拟 TorControllerService"""
    service = AsyncMock(spec=TorControllerService)
    service.config = mock_tor_config
    service.connect = AsyncMock(return_value=True)
    service.controller = MagicMock()  # 模拟 stem.Controller 实例
    service.wait_for_tor_node = AsyncMock(return_value={
        "fingerprint": "test-fp-001",
        "nickname": "test-tor-node",
        "address": "172.17.0.2"
    })
    service.create_circuit = AsyncMock(return_value="test-circuit-id-001")
    service.delete_circuit = AsyncMock(return_value=True)
    service.get_circuit_info = AsyncMock(return_value=[{"id": "001", "path": ["node1", "node2"]}])
    return service


@pytest.fixture
def stem2tor(mock_tor_config, mock_container_service, mock_controller_service):
    """创建 Stem2Tor 实例（Mock 外部服务）"""
    # 替换真实的服务初始化，使用 Mock 实例
    with patch("core.stem_api.TorContainerService", return_value=mock_container_service), \
         patch("core.stem_api.TorControllerService", return_value=mock_controller_service):
        
        stem2tor = Stem2Tor(config=mock_tor_config)

        return stem2tor


# -------------------------- 测试用例 --------------------------
class TestStem2Tor:
    def test_stem2tor_init(self, stem2tor, mock_tor_config, mock_container_service, mock_controller_service):
        """测试 Stem2Tor 初始化逻辑"""
        # 验证属性初始化
        assert stem2tor.config == mock_tor_config
        assert stem2tor.container_service == mock_container_service
        assert stem2tor.controller_service == mock_controller_service
        assert stem2tor.container_id is None
        assert stem2tor.container_name == mock_container_service.container_name
        assert stem2tor.container_ip_addr is None
        assert stem2tor.controller is None

        # 验证兼容性属性（property）
        assert stem2tor.role == mock_tor_config.role
        assert stem2tor.nick == mock_tor_config.nick
        assert stem2tor.pwd == mock_tor_config.pwd
        assert stem2tor.or_port == mock_tor_config.or_port
        assert stem2tor.socks_port == mock_tor_config.socks_port
        assert stem2tor.control_port == mock_tor_config.control_port
        assert stem2tor.dir_port == mock_tor_config.dir_port
        assert stem2tor.dir_auths == mock_tor_config.dir_auths
        assert stem2tor.outer_ip_addr == mock_tor_config.outer_ip_addr
        assert stem2tor.container_handler == mock_container_service.container


    @pytest.mark.asyncio
    async def test_stem2tor_start_tor_success(self, stem2tor, mock_container_service, mock_controller_service):
        """测试启动 Tor 节点成功场景"""
        # 执行启动
        tor_info = await stem2tor.start_tor()

        # 断言核心逻辑
        # 1. 验证容器启动
        mock_container_service.start_container.assert_called_once()
        assert stem2tor.container_id == "test-container-id-001"
        assert stem2tor.container_ip_addr == mock_container_service.container_ip_addr

        # 2. 验证控制器连接
        mock_controller_service.connect.assert_awaited_once_with(address="172.17.0.2")
        assert stem2tor.controller == mock_controller_service.controller

        # 3. 验证等待 Tor 节点注册
        mock_controller_service.wait_for_tor_node.assert_awaited_once_with(
            "test-tor-node", "test-container-id-001"
        )

        # 4. 验证返回值和日志
        assert tor_info == {"fingerprint": "test-fp-001", "nickname": "test-tor-node", "address": "172.17.0.2"}


    @pytest.mark.asyncio
    async def test_stem2tor_start_tor_host_network_mode(self, stem2tor, mock_tor_config, mock_controller_service):
        """测试 host 网络模式下的启动逻辑"""
        # 修改网络模式为 host
        mock_tor_config.network_mode = "host"
        mock_controller_service.connect.reset_mock()

        # 执行启动
        await stem2tor.start_tor()

        # 验证控制器连接地址为 127.0.0.1
        mock_controller_service.connect.assert_awaited_once_with(address="127.0.0.1")


    @pytest.mark.asyncio
    async def test_stem2tor_start_tor_controller_connect_failed(self, stem2tor, mock_container_service, mock_controller_service):
        """测试控制器连接失败场景"""
        # Mock 连接失败
        mock_controller_service.connect = AsyncMock(return_value=False)

        # 执行启动
        tor_info = await stem2tor.start_tor()

        # 断言
        assert tor_info is None
        # 验证容器启动后被停止
        mock_container_service.start_container.assert_called_once()
        mock_controller_service.close.assert_called_once()
        mock_container_service.stop_container.assert_called_once()


    @pytest.mark.asyncio
    async def test_stem2tor_start_tor_missing_dir_auths(self, stem2tor, mock_tor_config):
        """测试非 DA 角色但缺少 dir_auths 的场景"""
        # 修改配置：非 DA 角色 + 空 dir_auths
        mock_tor_config.role = "relay"
        mock_tor_config.dir_auths = ""

        # 执行启动
        tor_info = await stem2tor.start_tor()

        # 断言
        assert tor_info is None


    @pytest.mark.asyncio
    async def test_stem2tor_stop_tor(self, stem2tor, mock_container_service, mock_controller_service):
        """测试停止 Tor 节点"""
        # 先启动，再停止
        await stem2tor.start_tor()
        result = await stem2tor.stop_tor()

        # 断言
        assert result is True

        # 验证控制器关闭
        mock_controller_service.close.assert_called_once()
        assert stem2tor.controller is None

        # 验证容器停止
        mock_container_service.stop_container.assert_called_once()


    @pytest.mark.asyncio
    async def test_stem2tor_tor_circuit_operations(self, stem2tor, mock_controller_service):
        """测试电路（circuit）相关操作"""
        # 1. 创建电路
        circuit_id = await stem2tor.create_circuit(path=["node1", "node2"])
        assert circuit_id == "test-circuit-id-001"
        mock_controller_service.create_circuit.assert_awaited_once_with(["node1", "node2"])

        # 2. 删除电路
        delete_result = await stem2tor.delete_circuit(cir_id="test-circuit-id-001")
        assert delete_result is True
        mock_controller_service.delete_circuit.assert_awaited_once_with("test-circuit-id-001")

        # 3. 获取电路信息（兼容 int 类型 cir_id）
        circuit_info = await stem2tor.get_circuit_info(cir_id=1)
        assert circuit_info == [{"id": "001", "path": ["node1", "node2"]}]
        mock_controller_service.get_circuit_info.assert_awaited_once_with("1")  # 验证 int 转 str


    @pytest.mark.asyncio
    async def test_stem2tor_tor_network_info_operations(self, stem2tor, mock_controller_service):
        """测试网络状态、流相关操作"""
        # 1. 获取网络状态
        network_status = await stem2tor.get_network_statuses(fingerprint="test-fp-001")
        mock_controller_service.get_network_statuses.assert_awaited_once_with("test-fp-001")

        # 2. 获取流信息
        streams = await stem2tor.get_streams()
        mock_controller_service.get_streams.assert_awaited_once()

        # 3. 启动/停止全局流监听器
        listener_result = await stem2tor.start_global_stream_listener(circuit_id="001")
        mock_controller_service.start_global_stream_listener.assert_awaited_once_with("001")

        stem2tor.stop_global_stream_listener()
        mock_controller_service.stop_global_stream_listener.assert_called_once()


    def test_stem2tor_compatibility_methods(self, stem2tor, mock_container_service):
        """测试兼容旧接口的方法"""
        # 1. wait_for_port
        result = stem2tor.wait_for_port(port=9051, timeout=5)
        assert result is True
        mock_container_service.wait_for_port.assert_called_once_with(9051, 5)

        # 2. start_tor_container（兼容旧接口）
        # 传入与配置不一致的 network_mode，验证警告
        container_id = stem2tor.start_tor_container(network_mode="host")
        assert container_id == "test-container-id-001"

        # 3. 进程启停
        stem2tor.stop_tor_process()
        mock_container_service.stop_tor_process.assert_called_once()

        stem2tor.start_tor_process()
        mock_container_service.start_tor_process.assert_called_once()


    @pytest.mark.asyncio
    async def test_stem2tor_dir_auth_operations(self, stem2tor, mock_container_service):
        """测试目录权威（dir_auth）相关操作"""
        # 1. 获取 dir_auths
        dir_auths = await stem2tor.get_dir_auths()
        assert dir_auths == [{"nick": "test-da", "address": "192.168.1.1", "orport": 9001}]
        mock_container_service.get_dir_auths.assert_awaited_once()

        # 2. 更新 dir_auths
        update_result = await stem2tor.update_dir_auths(dir_auths=["new-da-001"])
        assert update_result is True
        mock_container_service.update_dir_auths.assert_awaited_once_with(["new-da-001"])


    @pytest.mark.asyncio
    async def test_stem2tor_with_controller(self, stem2tor, mock_controller_service):
        """测试 _with_controller 封装逻辑"""
        # 定义测试函数
        def test_func(controller, arg1, arg2):
            return f"{controller}: {arg1} + {arg2}"

        # 执行封装调用
        result = await stem2tor._with_controller(test_func, 1, 2)

        # 断言
        assert result == f"{mock_controller_service._get_controller()}: 1 + 2"
        # 验证使用线程池执行同步函数
        with patch("asyncio.get_event_loop") as mock_loop:
            mock_executor = MagicMock()
            mock_loop.return_value.run_in_executor = mock_executor


    @pytest.mark.asyncio
    async def test_stem2tor_wait_for_tor_node(self, stem2tor, mock_controller_service):
        """测试 wait_for_tor_node 代理逻辑"""
        # 执行
        tor_info = await stem2tor.wait_for_tor_node(
            nickname="test-node",
            container_id="test-container-001",
            max_wait_time=10,
            check_interval=1.0
        )

        # 断言
        mock_controller_service.wait_for_tor_node.assert_awaited_once_with(
            "test-node", "test-container-001", 10, 1.0
        )
        assert tor_info == mock_controller_service.wait_for_tor_node.return_value
