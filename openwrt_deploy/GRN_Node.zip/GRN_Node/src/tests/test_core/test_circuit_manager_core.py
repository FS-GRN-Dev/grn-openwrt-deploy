import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

from stem import StreamStatus
from stem.control import EventType

from core.circuit_manager import CircuitManager
from config.config import StemConfig


from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2



# -------------------------- 基础测试夹具 --------------------------
@pytest.fixture
def mock_stem2tor():
    """模拟 Stem2Tor 实例"""
    stem2tor = AsyncMock()
    # 核心方法 Mock
    stem2tor.create_circuit = AsyncMock(return_value="test-circuit-001")
    stem2tor.delete_circuit = AsyncMock(return_value=True)
    stem2tor._get_controller = MagicMock(return_value=MagicMock())  # 模拟 Tor 控制器
    return stem2tor


@pytest.fixture
def circuit_manager(mock_stem2tor):
    """创建 CircuitManager 实例"""
    reporter = MagicMock()
    reporter.report_circuit_rebuilt_info = AsyncMock(return_value=True)
    manager = CircuitManager(
        context=MagicMock(),
        reporter=reporter,
        stem2tor=mock_stem2tor,
        client_relay_code="client-relay-test",
    )
    return manager


# -------------------------- 辅助工具函数 --------------------------
def create_mock_stream(
    stream_id="1",
    status=StreamStatus.NEW,
    socks_username=None,
    target="example.com:80",
    purpose="USER",
    reason=None,
    remote_reason=None,
    raw_content=None
):
    """创建模拟的 Stem Stream 对象"""
    stream = MagicMock()
    stream.id = stream_id
    stream.status = status
    stream.socks_username = socks_username
    stream.target = target
    stream.purpose = purpose
    stream.reason = reason
    stream.remote_reason = remote_reason
    # Mock raw_content 方法（用于解析原始事件）
    if raw_content:
        stream.raw_content = MagicMock(return_value=raw_content)
    else:
        stream.raw_content = MagicMock(return_value=f"STREAM {status} ID={stream_id} TARGET={target} PURPOSE={purpose}")
    return stream


def create_mock_circuit(circuit_id="1", status="CLOSED"):
    """创建模拟的 Stem Circuit 对象"""
    circuit = MagicMock()
    circuit.id = circuit_id
    circuit.status = status
    return circuit


# -------------------------- 测试用例 --------------------------
class TestCircuitManager:
    def test_circuit_manager_init(self, circuit_manager, mock_stem2tor):
        """测试 CircuitManager 初始化"""
        # 验证属性初始化
        assert circuit_manager.stem2tor == mock_stem2tor
        assert circuit_manager._link_circuit_map == {}
        assert circuit_manager._link_path_map == {}
        assert circuit_manager._default_link_id is None
        assert circuit_manager._is_running is False
        assert circuit_manager._ignore_closed_circuits == set()
        assert circuit_manager._event_loop is None
        assert circuit_manager.allow_auto_circuit is False


    def test_circuit_manager_generate_link_id(self, circuit_manager):
        """测试生成唯一 LinkID"""
        link_id1 = circuit_manager.generate_link_id()
        link_id2 = circuit_manager.generate_link_id()
        
        # 验证格式
        assert link_id1.startswith("link-")
        
        # 验证唯一性
        assert link_id1 != link_id2


    @pytest.mark.asyncio
    async def test_circuit_manager_register_link_success(self, circuit_manager, mock_stem2tor):
        """测试注册链路并创建电路成功"""
        link_id = "test-link-001"
        path = ["fp1", "fp2", "fp3"]
        
        # 执行注册
        circuit_id = await circuit_manager.register_link(
            link_id=link_id,
            path=path,
            set_as_default=True
        )

        # 断言核心逻辑
        assert circuit_id == "test-circuit-001"
        # 验证路径配置保存
        assert circuit_manager._link_path_map[link_id] == path
        # 验证映射关系
        assert circuit_manager._link_circuit_map[link_id] == circuit_id
        # 验证默认链路设置
        assert circuit_manager._default_link_id == link_id
        # 验证电路创建调用
        mock_stem2tor.create_circuit.assert_awaited_once_with(path)


    @pytest.mark.asyncio
    async def test_circuit_manager_register_link_failure(self, circuit_manager, mock_stem2tor):
        """测试注册链路失败（电路创建失败）"""
        # Mock 电路创建失败
        mock_stem2tor.create_circuit = AsyncMock(return_value=None)
        link_id = "test-link-001"
        path = ["fp1", "fp2"]
        
        # 执行注册
        circuit_id = await circuit_manager.register_link(link_id=link_id, path=path)

        # 断言
        assert circuit_id is None
        # 验证映射未建立
        assert link_id not in circuit_manager._link_circuit_map


    @pytest.mark.asyncio
    async def test_circuit_manager_unregister_link(self, circuit_manager, mock_stem2tor):
        """测试注销链路"""
        # 先注册链路
        link_id = "test-link-001"
        await circuit_manager.register_link(link_id=link_id, path=["fp1"], set_as_default=True)
        
        # 执行注销
        result = await circuit_manager.unregister_link(link_id=link_id, delete_circuit=True)

        # 断言
        assert result is True
        # 验证电路删除
        mock_stem2tor.delete_circuit.assert_awaited_once_with("test-circuit-001")
        # 验证映射删除
        assert link_id not in circuit_manager._link_circuit_map
        assert link_id not in circuit_manager._link_path_map
        # 验证默认链路重置
        assert circuit_manager._default_link_id is None


    def test_circuit_manager_find_link_by_circuit_id(self, circuit_manager):
        """测试通过 circuit_id 反查 link_id"""
        # 预设映射
        circuit_manager._link_circuit_map = {
            "link1": "circuit1",
            "link2": "circuit2"
        }
        
        # 查找存在的 circuit_id
        assert circuit_manager.find_link_by_circuit_id("circuit1") == "link1"
        # 查找不存在的 circuit_id
        assert circuit_manager.find_link_by_circuit_id("circuit3") is None


    def test_circuit_manager_mark_circuit_for_manual_close(self, circuit_manager):
        """测试标记手动关闭的电路"""
        circuit_manager.mark_circuit_for_manual_close("circuit1")
        assert "circuit1" in circuit_manager._ignore_closed_circuits
        
        # 验证去重
        circuit_manager.mark_circuit_for_manual_close("circuit1")
        assert len(circuit_manager._ignore_closed_circuits) == 1


    @pytest.mark.asyncio
    async def test_circuit_manager_start_success(self, circuit_manager, mock_stem2tor):
        """测试启动 CircuitManager 成功"""
        # Mock 控制器配置
        ctrl = mock_stem2tor._get_controller()
        ctrl.set_conf = MagicMock()
        
        # 在 asyncio 事件循环中执行
        async def run_start():
            return await circuit_manager.start()
        
        result = await run_start()

        # 断言
        assert result is True
        assert circuit_manager._is_running is True
        # 验证 Tor 配置设置
        ctrl.set_conf.assert_called_once_with('__LeaveStreamsUnattached', '1')

        # 获取 add_event_listener 的所有调用参数
        call_args_list = ctrl.add_event_listener.call_args_list
        
        # 第一个调用是流监听器
        stream_listener_arg = call_args_list[0][0][0]
        assert stream_listener_arg is circuit_manager._stream_listener
        
        # 第二个调用是电路监听器
        circuit_listener_arg = call_args_list[1][0][0]
        assert circuit_listener_arg is circuit_manager._circuit_listener

        # 7. 额外验证：add_event_listener 被正确调用（可选）
        assert ctrl.add_event_listener.call_count == 2

        # 验证第一次调用（流事件监听器）
        ctrl.add_event_listener.assert_any_call(
            circuit_manager._stream_listener, EventType.STREAM
        )
        # 验证第二次调用（电路事件监听器）
        ctrl.add_event_listener.assert_any_call(
            circuit_manager._circuit_listener, EventType.CIRC
        )


    @pytest.mark.asyncio
    async def test_circuit_manager_start_no_event_loop(self, circuit_manager):
        """测试在无事件循环时启动失败"""
        # 模拟无运行中的事件循环
        with patch("asyncio.get_running_loop", side_effect=RuntimeError):
            result = await circuit_manager.start()
        
        assert result is False


    @pytest.mark.asyncio
    async def test_circuit_manager_stop(self, circuit_manager, mock_stem2tor):
        """测试停止 CircuitManager"""
        # 先启动
        await circuit_manager.start()
        ctrl = mock_stem2tor._get_controller()
        
        # 执行停止
        await circuit_manager.stop()

        # 断言
        assert circuit_manager._is_running is False
        
        # 验证监听器移除
        # 获取 remove_event_listener 的所有调用参数
        call_args_list = ctrl.remove_event_listener.call_args_list
        
        # 流监听器被移除
        assert circuit_manager._stream_listener is None
        
        # 电路监听器被移除
        assert circuit_manager._circuit_listener is None

        # 7. remove_event_listener 被正确调用（可选）
        assert ctrl.remove_event_listener.call_count == 2

        # 验证配置恢复
        ctrl.set_conf.assert_any_call('__LeaveStreamsUnattached', '0')
        # 验证属性重置
        assert circuit_manager._event_loop is None


    @pytest.mark.asyncio
    async def test_circuit_manager_handle_new_stream_with_socks_username(self, circuit_manager, mock_stem2tor):
        """测试处理带 socks_username 的新流"""
        # 预设链路映射
        link_id = "test-link-001"
        circuit_manager._link_circuit_map = {link_id: "test-circuit-001"}
        # 启动管理器（初始化 event_loop）
        await circuit_manager.start()
        
        # 创建模拟流
        stream = create_mock_stream(
            stream_id="1",
            status=StreamStatus.NEW,
            socks_username=link_id,
            target="example.com:80"
        )
        ctrl = mock_stem2tor._get_controller()
        ctrl.attach_stream = MagicMock()

        # 处理流事件
        await circuit_manager._handle_new_stream(stream)

        # 断言
        # 验证流附加到指定电路
        ctrl.attach_stream.assert_called_once_with("1", "test-circuit-001")


    @pytest.mark.asyncio
    async def test_circuit_manager_handle_new_stream_use_active_pool(self, circuit_manager, mock_stem2tor):
        """无 socks_username 时，从激活单链路池轮询附加"""
        default_link = "default-link"
        circuit_manager._link_circuit_map = {default_link: "default-circuit"}
        assert circuit_manager.activate_single(default_link) is True
        await circuit_manager.start()

        stream = create_mock_stream(
            stream_id="2",
            status=StreamStatus.NEW,
            socks_username=None,
            target="google.com:80"
        )
        ctrl = mock_stem2tor._get_controller()
        ctrl.attach_stream = MagicMock()

        await circuit_manager._handle_new_stream(stream)

        ctrl.attach_stream.assert_called_once_with("2", "default-circuit")

    @pytest.mark.asyncio
    async def test_circuit_manager_round_robin_starts_from_last_success(
        self, circuit_manager, mock_stem2tor
    ):
        """轮询从上次成功索引开始，失败则继续试下一跳"""
        circuit_manager._link_circuit_map = {
            "a": "circ-a",
            "b": "circ-b",
            "c": "circ-c",
        }
        assert circuit_manager.activate_single("a")
        assert circuit_manager.activate_single("b")
        assert circuit_manager.activate_single("c")
        circuit_manager._last_success_index = 1  # 上次成功 b，下次从 c 开始

        ctrl = MagicMock()
        ctrl.attach_stream = MagicMock(
            side_effect=[Exception("fail-c"), None]
        )
        stream = create_mock_stream(stream_id="10", socks_username=None)

        ok = circuit_manager.try_attach_round_robin(ctrl, stream)
        assert ok is True
        assert ctrl.attach_stream.call_args_list[0].args == ("10", "circ-c")
        assert ctrl.attach_stream.call_args_list[1].args == ("10", "circ-a")
        assert circuit_manager._last_success_index == 0

    @pytest.mark.asyncio
    async def test_circuit_manager_round_robin_all_fail_returns_false(
        self, circuit_manager, mock_stem2tor
    ):
        circuit_manager._link_circuit_map = {"a": "circ-a", "b": "circ-b"}
        circuit_manager.activate_single("a")
        circuit_manager.activate_single("b")
        ctrl = MagicMock()
        ctrl.attach_stream = MagicMock(side_effect=Exception("fail"))
        stream = create_mock_stream(stream_id="11", socks_username=None)

        ok = circuit_manager.try_attach_round_robin(ctrl, stream)
        assert ok is False
        assert ctrl.attach_stream.call_count == 2

    def test_activate_deactivate_and_enabled_ids(self, circuit_manager):
        circuit_manager._link_circuit_map = {"1": "c1", "2": "c2"}
        assert circuit_manager.activate_single("1")
        assert circuit_manager.activate_single("2")
        assert circuit_manager.get_enabled_parent_link_ids() == ["1", "2"]
        circuit_manager.deactivate_single("1")
        assert circuit_manager.get_enabled_parent_link_ids() == ["2"]
        circuit_manager.set_multi_active("99")
        # set_multi_active 不自动清单池；业务层会先 clear_all_singles
        circuit_manager.clear_all_singles()
        circuit_manager.set_multi_active("99")
        assert circuit_manager.get_enabled_parent_link_ids() == ["99"]
        circuit_manager.clear_multi_active()
        assert circuit_manager.get_enabled_parent_link_ids() == []

    def test_deactivate_single_preserves_last_success_link(self, circuit_manager):
        """出池后 _last_success_index 仍指向同一条上次成功链路。"""
        circuit_manager._link_circuit_map = {"a": "ca", "b": "cb", "c": "cc"}
        circuit_manager.activate_single("a")
        circuit_manager.activate_single("b")
        circuit_manager.activate_single("c")
        circuit_manager._last_success_index = 2  # c

        # 删除中间项 b：c 应从 index 2 左移到 1
        circuit_manager.deactivate_single("b")
        assert circuit_manager.get_active_single_pool() == ["a", "c"]
        assert circuit_manager._last_success_index == 1
        assert circuit_manager.get_active_single_pool()[
            circuit_manager._last_success_index
        ] == "c"

        # 删除上次成功链路本身：钳位到合法下标
        circuit_manager.deactivate_single("c")
        assert circuit_manager.get_active_single_pool() == ["a"]
        assert circuit_manager._last_success_index == 0

        # 删空
        circuit_manager.deactivate_single("a")
        assert circuit_manager.get_active_single_pool() == []
        assert circuit_manager._last_success_index == 0

    @pytest.mark.asyncio
    async def test_circuit_manager_handle_new_stream_pool_fallback_close(
        self, circuit_manager, mock_stem2tor
    ):
        """池整圈失败后按 allow_auto_circuit=False 关闭流"""
        circuit_manager._link_circuit_map = {"a": "circ-a"}
        circuit_manager.activate_single("a")
        await circuit_manager.start()
        stream = create_mock_stream(stream_id="12", socks_username=None)
        ctrl = mock_stem2tor._get_controller()
        ctrl.attach_stream = MagicMock(side_effect=Exception("fail"))
        ctrl.close_stream = MagicMock()

        await circuit_manager._handle_new_stream(stream)

        ctrl.close_stream.assert_called_once_with("12")


    @pytest.mark.asyncio
    async def test_circuit_manager_handle_new_stream_no_link(self, circuit_manager, mock_stem2tor):
        """无映射电路且禁止自动建路时，关闭流"""
        await circuit_manager.start()
        stream = create_mock_stream(stream_id="3", socks_username=None)
        ctrl = mock_stem2tor._get_controller()
        ctrl.attach_stream = MagicMock()
        ctrl.close_stream = MagicMock()

        await circuit_manager._handle_new_stream(stream)

        ctrl.close_stream.assert_called_once_with("3")
        ctrl.attach_stream.assert_not_called()

    @pytest.mark.asyncio
    async def test_circuit_manager_handle_new_stream_no_link_allow_auto(
        self, circuit_manager, mock_stem2tor
    ):
        """无映射电路且允许自动建路时，attach_stream(0)"""
        circuit_manager.set_allow_auto_circuit(True)
        await circuit_manager.start()
        stream = create_mock_stream(stream_id="3", socks_username=None)
        ctrl = mock_stem2tor._get_controller()
        ctrl.attach_stream = MagicMock()
        ctrl.close_stream = MagicMock()

        await circuit_manager._handle_new_stream(stream)

        ctrl.attach_stream.assert_called_once_with("3", 0)
        ctrl.close_stream.assert_not_called()

    @pytest.mark.asyncio
    async def test_circuit_manager_attach_failure_fallback_close(
        self, circuit_manager, mock_stem2tor
    ):
        """attach 到目标电路失败时，禁止自动建路则 close_stream"""
        link_id = "test-link-001"
        circuit_manager._link_circuit_map = {link_id: "test-circuit-001"}
        await circuit_manager.start()
        stream = create_mock_stream(stream_id="5", socks_username=link_id)
        ctrl = mock_stem2tor._get_controller()
        ctrl.attach_stream = MagicMock(
            side_effect=Exception("Unable to attach stream")
        )
        ctrl.close_stream = MagicMock()

        await circuit_manager._handle_new_stream(stream)

        ctrl.close_stream.assert_called_once_with("5")

    @pytest.mark.asyncio
    async def test_circuit_manager_attach_failure_fallback_allow_auto(
        self, circuit_manager, mock_stem2tor
    ):
        """attach 到目标电路失败时，允许自动建路则 attach(0)"""
        link_id = "test-link-001"
        circuit_manager.set_allow_auto_circuit(True)
        circuit_manager._link_circuit_map = {link_id: "test-circuit-001"}
        await circuit_manager.start()
        stream = create_mock_stream(stream_id="6", socks_username=link_id)
        ctrl = mock_stem2tor._get_controller()
        ctrl.attach_stream = MagicMock(
            side_effect=[Exception("Unable to attach stream"), None]
        )
        ctrl.close_stream = MagicMock()

        await circuit_manager._handle_new_stream(stream)

        assert ctrl.attach_stream.call_args_list[-1] == (("6", 0),)
        ctrl.close_stream.assert_not_called()


    @pytest.mark.asyncio
    async def test_circuit_manager_handle_new_stream_failed(self, circuit_manager):
        """测试处理 FAILED 状态的流"""
        # 启动管理器
        await circuit_manager.start()
        # 创建失败流
        stream = create_mock_stream(
            stream_id="4",
            status=StreamStatus.FAILED,
            reason="CONNECT_FAILED",
            remote_reason="TIMEOUT"
        )

        # 处理流事件
        await circuit_manager._handle_new_stream(stream)


    @pytest.mark.asyncio
    async def test_circuit_manager_handle_circuit_closed_auto_rebuild(self, circuit_manager, mock_stem2tor):
        """测试电路关闭触发自动重建"""
        # 预设链路映射
        link_id = "test-link-001"
        circuit_manager._link_circuit_map = {link_id: "closed-circuit"}
        circuit_manager._link_path_map = {link_id: ["fp1", "fp2"]}
        # Mock 重建电路返回新 ID
        mock_stem2tor.create_circuit = AsyncMock(return_value="new-circuit-001")

        # 创建关闭的电路事件
        circuit = create_mock_circuit(circuit_id="closed-circuit", status="CLOSED")

        # 处理电路关闭事件
        await circuit_manager._handle_circuit_closed(circuit)

        # 断言
        # 验证重建调用
        mock_stem2tor.create_circuit.assert_awaited_once_with(["fp1", "fp2"])
        # 验证映射更新
        assert circuit_manager._link_circuit_map[link_id] == "new-circuit-001"


    @pytest.mark.asyncio
    async def test_circuit_manager_handle_circuit_closed_manual_ignore(self, circuit_manager):
        """测试忽略手动关闭的电路重建"""
        # 标记为手动关闭
        circuit_id = "manual-close-circuit"
        circuit_manager.mark_circuit_for_manual_close(circuit_id)
        # 预设映射
        circuit_manager._link_circuit_map = {"link1": circuit_id}

        # 处理电路关闭事件
        circuit = create_mock_circuit(circuit_id=circuit_id, status="CLOSED")
        await circuit_manager._handle_circuit_closed(circuit)

        # 断言：未触发重建
        assert circuit_id not in circuit_manager._ignore_closed_circuits  # 已移除


    @pytest.mark.asyncio
    async def test_circuit_manager_rebuild_circuit_failure(self, circuit_manager, mock_stem2tor):
        """测试电路重建失败"""
        link_id = "test-link-001"
        circuit_manager._link_path_map = {link_id: ["fp1", "fp2"]}
        # Mock 电路创建失败
        mock_stem2tor.create_circuit = AsyncMock(return_value=None)

        # 执行重建
        result = await circuit_manager._rebuild_circuit(link_id)

        # 断言
        assert result is False
