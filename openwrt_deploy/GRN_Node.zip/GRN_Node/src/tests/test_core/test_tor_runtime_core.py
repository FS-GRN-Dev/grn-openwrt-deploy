import pytest
import asyncio
from abc import ABC
from unittest.mock import MagicMock, AsyncMock, patch

from core.tor_runtime import TorRuntimeFactory, ITorRuntime
from config.config import StemConfig

from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2




# ======================== 测试 ITorRuntime 抽象接口 ========================
def test_itor_runtime_abstract_methods():
    """验证 ITorRuntime 抽象接口的所有方法和属性都被正确定义"""
    # 1. 检查抽象类标识
    assert ABC in ITorRuntime.__bases__
    
    # 2. 验证抽象属性
    abstract_properties = ['role', 'container_name', 'container_id']
    for prop_name in abstract_properties:
        # 验证属性是抽象的
        prop = getattr(ITorRuntime, prop_name)
        assert hasattr(prop, '__isabstractmethod__')
        assert prop.__isabstractmethod__ is True
    
    # 3. 验证抽象方法
    abstract_methods = [
        'start_tor', 'stop_tor', 'create_circuit', 'delete_circuit',
        'get_circuit_info', 'get_streams', 'get_network_statuses',
        'start_global_stream_listener', 'stop_global_stream_listener',
        'wait_for_port', 'wait_for_tor_node', 'get_dir_auths', 'update_dir_auths'
    ]
    
    for method_name in abstract_methods:
        method = getattr(ITorRuntime, method_name)
        # 验证方法是抽象的
        assert hasattr(method, '__isabstractmethod__')
        assert method.__isabstractmethod__ is True
        
        # 验证异步方法标识（async 方法）
        if method_name not in ['stop_global_stream_listener', 'wait_for_port']:
            # 除了两个同步方法外，其余都是 async 方法
            assert asyncio.iscoroutinefunction(method)


# ======================== 测试 TorRuntimeFactory ========================
@pytest.fixture
def tor_runtime_factory():
    """创建 TorRuntimeFactory 实例"""
    return TorRuntimeFactory()


@pytest.fixture
def default_create_params():
    """默认的 create 方法参数"""
    return {
        "role": "relay",
        "nick": "test-node-001",
        "pwd": "test-password",
        "or_port": "9001",
        "socks_port": "9050",
        "control_port": "9051",
        "dir_port": "9030",
        "dir_auths": [{"id": "1", "address": "192.168.1.1"}],
        "outer_ip_addr": "10.0.0.1"
    }


def test_tor_runtime_factory_create_with_full_params(tor_runtime_factory, default_create_params):
    """测试工厂类使用完整参数创建实例"""
    # 1. Mock Stem2Tor 和 TorNodeConfig，避免实际导入和初始化
    with patch('core.tor_runtime.TorNodeConfig') as mock_config_cls, \
         patch('core.stem_api.Stem2Tor') as mock_stem2tor_cls:
        
        # 2. 配置 Mock 返回值
        mock_config = MagicMock()
        mock_config_cls.return_value = mock_config
        mock_stem2tor_instance = MagicMock()
        mock_stem2tor_cls.return_value = mock_stem2tor_instance
        
        # 3. 调用 create 方法
        result = tor_runtime_factory.create(**default_create_params)
        
        # 4. 验证 TorNodeConfig 初始化参数
        mock_config_cls.assert_called_once_with(
            role=default_create_params["role"],
            nick=default_create_params["nick"],
            pwd=default_create_params["pwd"],
            or_port=default_create_params["or_port"],
            socks_port=default_create_params["socks_port"],
            control_port=default_create_params["control_port"],
            dir_port=default_create_params["dir_port"],
            outer_ip_addr=default_create_params["outer_ip_addr"],
            dir_auths=default_create_params["dir_auths"]
        )
        
        # 5. 验证 Stem2Tor 被正确初始化并返回
        mock_stem2tor_cls.assert_called_once_with(mock_config)
        assert result == mock_stem2tor_instance


def test_tor_runtime_factory_create_with_default_params(tor_runtime_factory):
    """测试工厂类使用默认参数创建实例（部分参数省略）"""
    # 1. 仅传入必要参数
    minimal_params = {
        "role": "client",
        "nick": "minimal-node",
        "pwd": "minimal-pwd"
    }
    
    # 2. Mock 依赖
    with patch('core.tor_runtime.TorNodeConfig') as mock_config_cls, \
         patch('core.stem_api.Stem2Tor'):
        
        # 3. 调用 create 方法
        tor_runtime_factory.create(**minimal_params)
        
        # 4. 验证默认参数被正确使用
        mock_config_cls.assert_called_once_with(
            role=minimal_params["role"],
            nick=minimal_params["nick"],
            pwd=minimal_params["pwd"],
            or_port=StemConfig.DEFAULT_OR_PORT,
            socks_port=StemConfig.DEFAULT_SOCKS_PORT,
            control_port=StemConfig.DEFAULT_CONTROL_PORT,
            dir_port=StemConfig.DEFAULT_DIR_PORT,
            outer_ip_addr=None,  # 未传入则为 None
            dir_auths=None       # 未传入则为 None
        )


def test_tor_runtime_factory_create_with_empty_string_params(tor_runtime_factory):
    """测试工厂类处理空字符串参数（使用默认值）"""
    # 1. 传入空字符串参数
    empty_params = {
        "role": "dir_auth",
        "nick": "empty-param-node",
        "pwd": "empty-pwd",
        "or_port": "",
        "socks_port": "",
        "control_port": "",
        "dir_port": ""
    }
    
    # 2. Mock 依赖
    with patch('core.tor_runtime.TorNodeConfig') as mock_config_cls, \
         patch('core.stem_api.Stem2Tor'):
        
        # 3. 调用 create 方法
        tor_runtime_factory.create(**empty_params)
        
        # 4. 验证空字符串参数被替换为默认值
        mock_config_cls.assert_called_once_with(
            role=empty_params["role"],
            nick=empty_params["nick"],
            pwd=empty_params["pwd"],
            or_port=StemConfig.DEFAULT_OR_PORT,  # 空字符串 → 默认值
            socks_port=StemConfig.DEFAULT_SOCKS_PORT,
            control_port=StemConfig.DEFAULT_CONTROL_PORT,
            dir_port=StemConfig.DEFAULT_DIR_PORT,
            outer_ip_addr=None,
            dir_auths=None
        )


# ======================== 边界场景测试 ========================
def test_tor_runtime_factory_create_with_none_params(tor_runtime_factory):
    """测试工厂类处理 None 参数"""
    # 1. 传入 None 参数
    none_params = {
        "role": "bridge",
        "nick": "none-param-node",
        "pwd": "none-pwd",
        "or_port": None,
        "socks_port": None,
        "control_port": None,
        "dir_port": None,
        "dir_auths": None,
        "outer_ip_addr": None
    }
    
    # 2. Mock 依赖
    with patch('core.tor_runtime.TorNodeConfig') as mock_config_cls, \
         patch('core.stem_api.Stem2Tor'):
        
        # 3. 调用 create 方法
        tor_runtime_factory.create(**none_params)
        
        # 4. 验证 None 参数被替换为默认值
        mock_config_cls.assert_called_once_with(
            role=none_params["role"],
            nick=none_params["nick"],
            pwd=none_params["pwd"],
            or_port=StemConfig.DEFAULT_OR_PORT,  # None → 默认值
            socks_port=StemConfig.DEFAULT_SOCKS_PORT,
            control_port=StemConfig.DEFAULT_CONTROL_PORT,
            dir_port=StemConfig.DEFAULT_DIR_PORT,
            outer_ip_addr=None,
            dir_auths=None
        )

@pytest.mark.asyncio
async def test_itor_runtime_method_signatures():
    """验证 ITorRuntime 方法的参数和返回值签名（异步方法）"""
    # 1. 创建实现所有抽象方法的测试类
    class TestTorRuntime(ITorRuntime):
        @property
        def role(self) -> str:
            return "test"
        
        @property
        def container_name(self) -> str:
            return "test-container"
        
        @property
        def container_id(self) -> Optional[str]:
            return None
        
        async def start_tor(self) -> Optional[Dict]:
            return {}
        
        async def stop_tor(self) -> bool:
            return True
        
        async def create_circuit(self, path) -> Optional[str]:
            return "circuit-123"
        
        async def delete_circuit(self, cir_id) -> bool:
            return True
        
        async def get_circuit_info(self, cir_id: Optional[int] = None) -> Dict | list[Dict] | None:
            return [{"id": 1}]
        
        async def get_streams(self) -> Optional[List[Dict]]:
            return [{"id": 1}]
        
        async def get_network_statuses(self, fingerprint: Optional[str] = None) -> Optional[Union[Dict, List[Dict]]]:
            return {"status": "ok"}
        
        async def start_global_stream_listener(self, circuit_id: str) -> bool:
            return True
        
        def stop_global_stream_listener(self) -> None:
            pass
        
        def wait_for_port(self, port: int, timeout: int = 10) -> bool:
            return True
        
        async def wait_for_tor_node(self, nickname: str, container_id: str,
                                    max_wait_time: int = 30, check_interval: float = 2.0) -> Optional[Dict]:
            return {"nickname": nickname}
        
        async def get_dir_auths(self) -> Optional[List[Dict[str, str]]]:
            return [{"id": "1", "addr": "192.168.1.1"}]
        
        async def update_dir_auths(self, dir_auths):
            pass
    
    # 2. 实例化并验证方法调用
    test_runtime = TestTorRuntime()
    
    # 验证同步属性
    assert isinstance(test_runtime.role, str)
    assert isinstance(test_runtime.container_name, str)
    assert test_runtime.container_id is None
    
    # 验证异步方法调用
    assert isinstance(await test_runtime.start_tor(), dict)
    assert isinstance(await test_runtime.stop_tor(), bool)
    assert isinstance(await test_runtime.create_circuit(["node1", "node2"]), str)
    assert isinstance(await test_runtime.delete_circuit("123"), bool)
    assert isinstance(await test_runtime.get_circuit_info(1), list)
    assert isinstance(await test_runtime.get_streams(), list)
    assert isinstance(await test_runtime.get_network_statuses("fp123"), dict)
    assert isinstance(await test_runtime.start_global_stream_listener("cir123"), bool)
    
    # 验证同步方法
    test_runtime.stop_global_stream_listener()  # 无返回值
    assert isinstance(test_runtime.wait_for_port(9001), bool)
    
    # 验证复杂异步方法
    node_info = await test_runtime.wait_for_tor_node("test-node", "cid123")
    assert node_info["nickname"] == "test-node"
    
    dir_auths = await test_runtime.get_dir_auths()
    assert isinstance(dir_auths, list)
    assert isinstance(dir_auths[0], dict)
    
    await test_runtime.update_dir_auths([{"id": "2"}])  # 无返回值
