import pytest
import socket
import json
import sys
import os
import asyncio
import platform

import logging

from unittest.mock import MagicMock, AsyncMock, patch
from core.open_wrt.local_ipc import LocalIpcServer, Connection

from models.user import LocalMsgType
from models.user import UserMsg

from typing import Optional, List, Dict, Union, Callable, Any




# ======================== 平台适配配置 ========================
# ======================== 基础Fixture ========================

@pytest.fixture
def ipc_config(tmp_path):
    """按平台构造 IPC 配置。Linux 必须用已存在目录下的临时 socket，不能绑 /opt/local。"""
    config = MagicMock()
    config.DEFAULT_MAX_MSG_LEN = 4096

    if platform.system() == "Windows":
        config.DEFAULT_LOCAL_SOCKET_PATH = ""
        config.DEFAULT_LOCAL_PORT = 0
        config.TCP_HOST = "127.0.0.1"
    else:
        sock_dir = tmp_path / "local_ipc"
        sock_dir.mkdir()
        config.DEFAULT_LOCAL_SOCKET_PATH = str(sock_dir / "local_ipc.sock")

    yield config

    socket_path = getattr(config, "DEFAULT_LOCAL_SOCKET_PATH", "")
    if socket_path and os.path.exists(socket_path):
        try:
            os.unlink(socket_path)
        except OSError:
            pass


@pytest.fixture
async def ipc_server(ipc_config):
    """创建 LocalIpcServer，并 patch 其实际引用的 LocalServiceConfig。"""
    with patch("core.open_wrt.local_ipc.LocalServiceConfig", ipc_config):
        server = LocalIpcServer()
        yield server

        try:
            if server.running:
                await server.stop_server()
                if hasattr(server, "accept_task") and server.accept_task and not server.accept_task.done():
                    server.accept_task.cancel()
                    try:
                        await server.accept_task
                    except asyncio.CancelledError:
                        pass
            if platform.system() != "Windows" and os.path.exists(ipc_config.DEFAULT_LOCAL_SOCKET_PATH):
                try:
                    os.unlink(ipc_config.DEFAULT_LOCAL_SOCKET_PATH)
                except OSError:
                    pass
        except Exception as e:
            pytest.fail(f"清理ipc_server资源失败: {e}")


# ======================== 测试用例 ========================
class TestLocalIpcServer:
    @pytest.mark.asyncio
    async def test_local_ipc_server_start_and_cleanup(self, ipc_server, ipc_config):
        """测试服务器启动和资源清理"""
         # 配置日志（确保输出）
        logger = logging.getLogger("test_local_ipc_server_start_and_cleanup")
        logger.setLevel(logging.DEBUG)
        
        await ipc_server.start_server()
        logger.info("✅ start_server执行完成，服务器已启动")
        
        # 验证启动状态
        assert ipc_server.running is True
        assert ipc_server.server_socket is not None
        logger.info("✅ 服务器启动状态验证通过")
        
        # 停止服务器（主动取消accept_task）
        await ipc_server.stop_server()
        logger.info("✅ stop_server执行完成，服务器已停止")
        
        # 验证清理结果
        assert ipc_server.running is False
        assert len(ipc_server.connections) == 0
        assert ipc_server.server_socket is None
        logger.info("✅ 服务器资源清理验证通过")
        
        # 验证Unix Socket文件清理（非Windows）
        if platform.system() != "Windows":
            assert not os.path.exists(ipc_config.DEFAULT_LOCAL_SOCKET_PATH)

        logger.info("✅ 所有验证通过")


    @pytest.mark.asyncio
    async def test_local_ipc_client_connection_and_message(self, ipc_server, ipc_config):
        """测试客户端连接和消息收发"""
        logger = logging.getLogger("test_local_ipc_client_connection_and_message")
        logger.setLevel(logging.DEBUG)  # 强制设置级别（覆盖全局）

        # 启动服务器（后台任务）
        await ipc_server.start_server()
        assert ipc_server.running
        logger.info("服务器启动成功")
        
        client_socket = None
        try:
            if platform.system() == "Windows":
                client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

                # 缩短超时时间（快速发现问题）+ 设为非阻塞
                client_socket.setblocking(False)  # 适配服务器的非阻塞Socket
                client_socket.settimeout(3.0)  # 设置超时时间3秒
                logger.info("设置客户端socket超时为3秒")

                server_addr = ipc_server.server_socket.getsockname()
                logger.info(f"Windows平台，连接服务器地址: {server_addr}")
                client_socket.connect(server_addr)
                logger.info("Windows connect成功")
            else:
                client_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                # 缩短超时时间（快速发现问题）+ 设为非阻塞
                client_socket.setblocking(False)  # 适配服务器的非阻塞Socket
                client_socket.settimeout(3.0)  # 设置超时时间3秒
                logger.info("设置客户端socket超时为3秒")

                # 适配Linux下非阻塞Unix Socket的connect
                try:
                    client_socket.connect(ipc_config.DEFAULT_LOCAL_SOCKET_PATH)
                except BlockingIOError:
                    # 非阻塞connect会抛BlockingIOError（正常，连接在后台建立）
                    # 等待连接完成（最多3秒）
                    import select
                    ready = select.select([], [client_socket], [], 3.0)
                    if not ready[1]:
                        raise TimeoutError("Unix Socket连接超时")
                logger.info(f"Unix客户端连接Socket路径成功: {ipc_config.DEFAULT_LOCAL_SOCKET_PATH}")

            # 发送测试消息
            test_msg = {
                "msg_type": LocalMsgType.MT_UPDATE_CONFIG.value,
                "data": {"key": "test_value"}
            }
            msg_bytes = json.dumps(test_msg).encode("utf-8")

            # 分批发送（适配非阻塞Socket）
            sent = 0
            while sent < len(msg_bytes):
                sent += client_socket.send(msg_bytes[sent:])
            logger.info("client_socket send message over.")

            # 给服务器足够的处理时间
            await asyncio.sleep(0.5)  # 等待服务器处理消息并返回响应

            # 接收服务器响应（处理非阻塞Socket的BlockingIOError）
            logger.info("开始接收服务器响应...")
            response = None
            retry_count = 0
            while retry_count < 3:  # 重试3次，适配异步响应延迟
                try:
                    response = client_socket.recv(ipc_config.DEFAULT_MAX_MSG_LEN).decode("utf-8")
                    if response:
                        break
                except BlockingIOError:
                    await asyncio.sleep(0.1)
                    retry_count += 1
                except socket.timeout:
                    await asyncio.sleep(0.1)
                    retry_count += 1

            if not response:
                raise TimeoutError("多次重试仍未收到服务器响应")

            logger.info(f"client_socket recv one message: {response}")
            assert response == "Hello client, I'm server.", f"响应不匹配：{response}"
            logger.info("message communication ok.")

            # 验证连接被记录（加延时，确保异步更新）
            await asyncio.sleep(0.1)
            assert len(ipc_server.connections) >= 1  # 用>=1避免并发计数问题
            logger.info(f"连接数验证通过：{len(ipc_server.connections)}")

        except socket.timeout as e:
            logger.error("❌ recv超时！服务器未返回响应：%s", str(e), exc_info=True)
            raise  # 抛出异常，不静默吞掉
        except Exception as e:
            logger.error("❌ 测试出错：%s", str(e), exc_info=True)
            raise
        finally:
            if client_socket:
                client_socket.close()
                logger.info("客户端socket已关闭")

            # 停止服务器（使用服务器自身的stop方法）
            await ipc_server.stop_server()
            logger.info("服务器已停止并清理资源")


    @pytest.mark.asyncio
    async def test_local_ipc_connection_close(self, ipc_server, ipc_config):
        """测试客户端断开连接后的资源清理"""
        logger = logging.getLogger("test_local_ipc_connection_close")
        logger.setLevel(logging.DEBUG)

        # 1. 直接await启动服务器
        await ipc_server.start_server()
        assert ipc_server.running, "服务器启动失败"
        
        client_socket = None
        try:
            # 2. 创建客户端连接
            if platform.system() == "Windows":
                client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

                # 缩短超时时间（快速发现问题）+ 设为非阻塞
                client_socket.setblocking(False)  # 适配服务器的非阻塞Socket
                client_socket.settimeout(3.0)  # 设置超时时间3秒
                logger.info("设置客户端socket超时为3秒")

                server_addr = ipc_server.server_socket.getsockname()
                client_socket.connect(server_addr)
                logger.info(f"Windows客户端已连接到服务器: {server_addr}")
            else:
                client_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)

                # 缩短超时时间（快速发现问题）+ 设为非阻塞
                client_socket.setblocking(False)  # 适配服务器的非阻塞Socket
                client_socket.settimeout(3.0)  # 设置超时时间3秒
                logger.info("设置客户端socket超时为3秒")

                # 适配Linux下非阻塞Unix Socket的connect
                try:
                    client_socket.connect(ipc_config.DEFAULT_LOCAL_SOCKET_PATH)
                except BlockingIOError:
                    # 非阻塞connect会抛BlockingIOError（正常，连接在后台建立）
                    # 等待连接完成（最多3秒）
                    import select
                    ready = select.select([], [client_socket], [], 3.0)
                    if not ready[1]:
                        raise TimeoutError("Unix Socket连接超时")
                logger.info(f"Unix客户端已连接到服务器: {ipc_config.DEFAULT_LOCAL_SOCKET_PATH}")
            
            # 等待服务器完成连接接收和Connection创建（确保异步处理完成）
            await asyncio.sleep(0.2)
            
            # 3. 验证连接已被服务器记录
            assert len(ipc_server.connections) >= 1, f"服务器未记录连接，当前连接数: {len(ipc_server.connections)}"
            conn_id = list(ipc_server.connections.keys())[0]
            conn = ipc_server.connections[conn_id]

            assert conn.is_closed is False, "连接未初始化完成，已被标记为关闭"
            logger.info(f"验证通过：服务器已记录连接 {conn_id}，状态为未关闭")
            
            # 4. 关闭客户端连接（模拟断开）
            client_socket.close()
            client_socket = None  # 释放引用
            logger.info("客户端已主动关闭连接")
            
            # 等待服务器检测到连接断开并处理（非阻塞Socket需要时间检测）
            await asyncio.sleep(0.3)
            
            # 5. 验证连接被标记为关闭
            assert conn.is_closed is True, f"连接未被标记为关闭，当前状态: {conn.is_closed}"
            logger.info(f"验证通过：连接 {conn_id} 已被标记为关闭")
            
        finally:
            # 6. 兜底清理客户端Socket
            if client_socket:
                try:
                    client_socket.close()
                except Exception as e:
                    logger.warning(f"清理客户端Socket失败: {e}")
            
            # 7. 停止服务器（无需处理task，直接await）
            if ipc_server.running:
                await ipc_server.stop_server()
                logger.info("服务器已停止并清理资源")


    @pytest.mark.asyncio
    async def test_local_ipc_cleanup_existing_socket(self, ipc_server, ipc_config):
        """测试启动时清理已存在的Unix Socket文件"""
        logger = logging.getLogger("test_local_ipc_cleanup_existing_socket")
        logger.setLevel(logging.DEBUG)

        # 1. Windows跳过（仅测试Unix Socket场景）
        if platform.system() == "Windows":
            pytest.skip("Windows使用TCP Socket，无文件清理逻辑，跳过该测试")
        
        socket_path = ipc_config.DEFAULT_LOCAL_SOCKET_PATH
        test_sock = None

        try:
            # 2. 模拟真实的Unix Socket残留场景
            test_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            test_sock.bind(socket_path)
            logger.info(f"已创建残留Socket文件: {socket_path}")
            
            # 验证残留文件存在
            assert os.path.exists(socket_path), "残留Socket文件创建失败"
            
            # 关闭测试Socket（模拟进程退出后残留）
            test_sock.close()
            test_sock = None

            # 3. 直接await启动服务器
            await ipc_server.start_server()
            assert ipc_server.running, "服务器启动失败"

            # 4. 验证清理逻辑：旧文件被清理，新文件被创建
            assert os.path.exists(socket_path), "服务器未创建新的Socket文件"
            logger.info(f"服务器启动成功，Socket文件 {socket_path} 已重建")

        except Exception as e:
            logger.error(f"测试失败: {e}", exc_info=True)
            raise  # 重新抛出异常，标记测试失败
        finally:
            # 5. 强制清理资源（兜底）
            # 停止服务器（无需处理task，直接调用stop）
            if ipc_server.running:
                await ipc_server.stop_server()
            
            # 清理Socket文件
            if os.path.exists(socket_path):
                try:
                    os.unlink(socket_path)
                    logger.info(f"已清理测试残留Socket文件: {socket_path}")
                except OSError as e:
                    logger.warning(f"清理Socket文件失败: {e}")
            
            # 关闭测试Socket
            if test_sock:
                test_sock.close()


    @pytest.mark.asyncio
    async def test_local_ipc_get_socket_exception(self, ipc_server):
        """测试获取未初始化的socket时抛出异常"""
        # 服务器未启动，socket为None
        with pytest.raises(RuntimeError) as excinfo:
            ipc_server.get_socket()
        assert "socket未监听。请先调用 bind() 并确保监听成功。" in str(excinfo.value)


# ======================== Connection类测试 ========================
class TestConnection:
    @pytest.fixture
    def mock_socket(self):
        """Mock客户端socket"""
        mock_sock = MagicMock()
        mock_sock.recv.side_effect = [
            json.dumps({"msg_type": LocalMsgType.MT_SWITCH_LINK.value, "data": {}}).encode("utf-8"),
            b""  # 空数据表示连接关闭
        ]
        mock_sock.send.return_value = None
        return mock_sock


    @pytest.mark.asyncio
    async def test_local_ipc_connection_handle(self):
        """测试Connection的消息处理逻辑"""
        # 1. 创建Mock Socket并配置返回值
        mock_socket = MagicMock(spec=socket.socket)
        
        # 配置recv：先返回测试消息，再返回空数据（触发连接关闭）
        mock_socket.recv.side_effect = [
            json.dumps({"msg_type": 2, "data": {}}).encode('utf-8'),  # 第一次recv返回测试消息
            b""  # 第二次recv返回空，触发循环退出
        ]
        
        # 配置send：返回发送的字节数（模拟真实场景）
        mock_socket.send.return_value = len("Hello client, I'm server.".encode('utf-8'))

        # 2. 创建Connection实例
        conn = Connection(conn_id=1, conn_socket=mock_socket, addr="test_addr")
        
        # 3. 执行handle方法
        await conn.handle()
        
        # 4. 验证核心逻辑
        # 验证recv被调用（至少两次：一次收消息，一次收空）
        assert mock_socket.recv.call_count >= 1

        # 验证send被调用且参数正确
        mock_socket.send.assert_called_with("Hello client, I'm server.".encode('utf-8'))

        # 验证连接被标记为关闭
        assert conn.is_closed is True


    def test_local_ipc_connection_close(self, mock_socket):
        """测试Connection关闭逻辑"""
        conn = Connection(conn_id=1, conn_socket=mock_socket, addr="test_addr")
        conn.close()
        
        assert conn.is_closed is True
        mock_socket.close.assert_called_once()
