import pytest
import sys
import os
import asyncio
import signal
from unittest.mock import MagicMock, AsyncMock, patch


from core.base_node import AnonymousCommer
from core.open_wrt.client_node import ClientAccesser

from config.config import GrpcConfig
from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2


from observers.subject import StateSubject

# ========== 基础 Mock 类定义（隔离真实依赖） ==========
class MockNodeContext:
    """Mock 节点上下文，替代真实的 NodeContext"""
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
        self.stem2tor_instances = {}
    
    def get_latest_circuit_id(self): return None
    def get_active_circuit(self, circuit_id): return None
    def get_all_active_circuits(self): return []
    def get_relay(self, relay_id): return None
    def get_all_relays(self): return []
    def _create_node(self): return MagicMock()
    def _get_role(self, role_enum): return "test_role"


class MockCommandDispatcher:
    """Mock 命令分发器"""
    def __init__(self, commer):
        self.commer = commer


class MockGrpcHandler:
    """Mock GRPC处理器，包含异步方法"""
    def __init__(self, server_addr, context, dispatcher):
        self.server_addr = server_addr
        self.context = context
        self.dispatcher = dispatcher
        self.stub = MagicMock()
        self.channel = MagicMock()
    
        self.initialize = AsyncMock()
        self.register_node = AsyncMock()
        self.handle_commands = AsyncMock()
        self.close = AsyncMock()


class MockStateReporter:
    """Mock 状态上报器"""
    def __init__(self, context, grpc_handler):
        self.context = context
        self.grpc_handler = grpc_handler

        
class MockLocalIpcServer:
    """Mock 本地IPC server"""
    def __init__(self):
        self.start_server = AsyncMock()
        self.stop_server = AsyncMock()


# ========== 全局 Fixture（自动应用到所有测试用例） ==========
@pytest.fixture(autouse=True)
def mock_all_dependencies():
    """全局Mock所有外部依赖，阻止真实调用"""
    # 定义需要Mock的目标路径和替换对象
    mock_subject_instance = AsyncMock()
    mock_subject_instance.start_all = AsyncMock()  # 强制为AsyncMock
    mock_subject_instance.attach = MagicMock()

    patch_configs = [
        # 格式：(目标路径, patch类型, 入参值)
        # 基础依赖 Mock
        ("core.base_node.get_network_info", "return_value", ("127.0.0.1", "test_loc", "test_prov")),
        ("core.base_node.NodeContext", "new", MockNodeContext),
        ("core.base_node.CommandDispatcher", "new", MockCommandDispatcher),
        ("core.base_node.GrpcHandler", "new", MockGrpcHandler),
        ("core.base_node.StateReporter", "new", MockStateReporter),
        ("core.open_wrt.client_node.LocalIpcServer", "new", MockLocalIpcServer),
        ("utils.logger.get_logger", "return_value", MagicMock()),
        
        # 观察者模式相关 Mock
        ("core.open_wrt.client_node.StateSubject", "new", MagicMock(return_value=mock_subject_instance)),
        ("core.open_wrt.client_node.NodeInfoObserver", "new", MagicMock(autospec=True)),
        ("core.open_wrt.client_node.SituationAwarenessObserver", "new", MagicMock(autospec=True)),
        ("core.open_wrt.client_node.DAInfoObserver", "new", MagicMock(autospec=True)),
        ("core.open_wrt.client_node.RelayInfoObserver", "new", MagicMock(autospec=True)),
    ]

    # 2. 批量创建并启动patch
    mock_objects = {}
    started_patches = []

    def fake_container(*args, **kwargs):
        node_code = kwargs.get("node_code") or kwargs.get("node_id") or (args[0] if args else "node")
        context = MockNodeContext(
            node_id=node_code,
            node_code=node_code,
            ip_address=kwargs.get("ip_address"),
            geo_location=kwargs.get("geo_location"),
            cloud_provider=kwargs.get("cloud_provider"),
        )
        container = MagicMock()
        container.context = context
        container.dispatcher = MockCommandDispatcher(None)
        container.grpc_handler = MockGrpcHandler(kwargs.get("server_addr"), context, container.dispatcher)
        container.reporter = MockStateReporter(context, container.grpc_handler)
        mock_objects["container"] = container
        return container

    p_container = patch("core.base_node.ServiceContainer", side_effect=fake_container)
    p_container.start()
    started_patches.append(p_container)

    for target_path, patch_type, patch_value in patch_configs:
        # 根据类型创建patch
        if patch_type == "return_value":
            p = patch(target_path, return_value=patch_value)
        elif patch_type == "new":
            p = patch(target_path, new=patch_value, create=True)
        else:
            raise ValueError(f"不支持的patch类型: {patch_type}")
        
        # 启动patch并记录
        mock_obj = p.start()
        started_patches.append(p)
        
        # 记录关键mock对象（便于测试用例调用）
        if "StateSubject" in target_path:
            mock_objects["mock_subject_cls"] = mock_obj
            mock_objects["mock_subject_instance"] = mock_subject_instance  # 直接返回实例
        elif "GrpcHandler" in target_path:
            mock_objects["mock_grpc_handler_cls"] = patch_value  # MockGrpcHandler类
        elif "LocalIpcServer" in target_path:
            mock_objects["mock_ipc_server_cls"] = patch_value

    # 3. 提供mock对象给测试用例
    yield mock_objects

    # 4. 测试结束后清理所有patch
    for p in started_patches:
        p.stop()


@pytest.fixture
def client_accesser():
    """创建 VpsDispatcher 实例的 Fixture"""
    # 直接创建实例（使用测试模式）
    accesser = ClientAccesser(
        node_id="test-node-001",
        server_addr=GrpcConfig.DEFAULT_SERVER_ADDR,
        run_mode="test")
    # Mock stem2tor_instances 便于测试资源清理
    # dispatcher.stem2tor_instances = {}
    return accesser


# ========== 核心测试用例 ==========
class TestVpsDispatcher:
    def test_openwrt_node_initialization(self, client_accesser):
        """测试 VpsDispatcher 初始化逻辑"""
        # 验证继承自 AnonymousCommer 的属性
        assert client_accesser.mode == "test"
        assert client_accesser.server_addr == GrpcConfig.DEFAULT_SERVER_ADDR
        assert isinstance(client_accesser.context, MockNodeContext)
        assert isinstance(client_accesser.grpc_handler, MockGrpcHandler)
        assert client_accesser.node_id == "test-node-001"

       # 验证自身属性初始化
        assert isinstance(client_accesser.local_ipc_server, MockLocalIpcServer)


    @pytest.mark.asyncio
    async def test_openwrt_node_run_normal_execution(self, client_accesser, mock_all_dependencies):
        """测试 run() 方法正常执行路径"""
        # 1. 获取关键 Mock 对象
        mock_subject_instance = mock_all_dependencies["mock_subject_instance"]
        mock_subject_cls = mock_all_dependencies["mock_subject_cls"]
        mock_grpc = client_accesser.grpc_handler
        mock_ipc_server = client_accesser.local_ipc_server

        # 2. Mock 异步方法（避免阻塞）
        mock_grpc.initialize = AsyncMock()
        mock_grpc.register_node = AsyncMock()
        mock_grpc.handle_commands = AsyncMock()
        mock_ipc_server.start_server = AsyncMock()

        # 3. Mock 事件循环和信号处理
        mock_loop = MagicMock()
        mock_gather = AsyncMock(return_value=None)

        with patch("asyncio.get_event_loop", return_value=mock_loop), \
             patch("asyncio.gather", mock_gather):
            
            # 执行 run 方法
            await client_accesser.run()

            # 4. 验证核心逻辑
            # 验证 GRPC 初始化和注册
            mock_grpc.initialize.assert_awaited_once()
            mock_grpc.register_node.assert_awaited_once()

            # 验证 Subject 创建和观察者注册
            mock_subject_cls.assert_called_once()
            assert mock_subject_instance.attach.call_count == 5  # 4个常规观察者 + ConcensusObserver

            # 验证信号处理器添加
            mock_loop.add_signal_handler.assert_called_once_with(
                signal.SIGINT, client_accesser._sync_handle_interrupt
            )

            # 验证gather被调用（传入两个异步任务）
            mock_gather.assert_awaited_once()
            # 验证gather的参数是两个可等待对象
            gather_args = mock_gather.await_args[0]
            assert len(gather_args) == 3  # subject.start_all() 和 grpc.handle_commands() 和 mock_ipc_server.start_server()


    @pytest.mark.asyncio
    async def test_openwrt_node_run_windows_signal_handler(self, client_accesser):
        """测试 Windows 环境下信号处理的兼容逻辑"""
        # Mock 事件循环抛出 NotImplementedError（模拟Windows环境）
        mock_grpc = client_accesser.grpc_handler
        mock_grpc.initialize = AsyncMock()
        mock_grpc.register_node = AsyncMock()
        mock_grpc.handle_commands = AsyncMock()

        mock_ipc_server = client_accesser.local_ipc_server
        mock_ipc_server.start_server = AsyncMock()

        mock_loop = MagicMock()
        mock_loop.add_signal_handler.side_effect = NotImplementedError
        mock_gather = AsyncMock(return_value=None)

        with patch("asyncio.get_event_loop", return_value=mock_loop), \
             patch("asyncio.gather", mock_gather):
            
            # 执行 run 方法
            await client_accesser.run()

            # 验证信号处理异常被捕获，且日志被调用
            client_accesser.logger.info.assert_any_call(
                "当前环境不支持add_signal_handler，将使用默认信号处理"
            )


    @pytest.mark.asyncio
    @pytest.mark.filterwarnings("ignore::RuntimeWarning")  # 精准抑制警告
    async def test_openwrt_node_run_task_cancellation(self, client_accesser):
        """测试任务取消时的异常处理"""

        # Mock GRPC 方法抛出 CancelledError
        mock_grpc = client_accesser.grpc_handler
        mock_grpc.initialize = AsyncMock()
        mock_grpc.register_node = AsyncMock()

        async def raise_cancelled():
            raise asyncio.CancelledError("任务被取消")

        mock_loop = MagicMock()

        mock_ipc_server = client_accesser.local_ipc_server
        mock_ipc_server.start_server = MagicMock() # 设置成MagicMock（非AsyncMock），忽略协程未等待警告

        mock_grpc.handle_commands = AsyncMock(side_effect=raise_cancelled)
        mock_gather = AsyncMock()

        with patch("asyncio.get_event_loop", return_value=mock_loop), \
             patch("asyncio.gather", mock_gather):
            
            # 执行 run 方法（应正常退出，不抛异常）
            await client_accesser.run()

            # 验证异常被捕获，程序不崩溃
            assert True  # 只要不抛异常，测试通过

            # 验证所有 AsyncMock 都被 await
            mock_grpc.initialize.assert_awaited_once()
            mock_grpc.register_node.assert_awaited_once()
            mock_gather.assert_awaited_once()

            # 验证finally块执行（IPC Server停止）
            mock_ipc_server.stop_server.assert_awaited_once()


    def test_openwrt_node_sync_handle_interrupt(self, client_accesser):
        """测试中断信号处理方法"""
        # Mock 异步任务和事件循环
        mock_task1 = MagicMock()
        mock_task2 = MagicMock()
        with patch("asyncio.all_tasks", return_value=[mock_task1, mock_task2]), \
             patch("asyncio.current_task", return_value=mock_task1), \
             patch("asyncio.get_running_loop", return_value=MagicMock()):
            
            # 执行中断处理
            client_accesser._sync_handle_interrupt()

            # 验证只有非当前任务被取消
            mock_task1.cancel.assert_not_called()
            mock_task2.cancel.assert_called_once()
            
            # 验证日志
            client_accesser.logger.info.assert_called_with("收到中断信号，正在关闭...")
