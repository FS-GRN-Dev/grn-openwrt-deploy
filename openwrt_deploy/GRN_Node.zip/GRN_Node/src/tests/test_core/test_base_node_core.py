import pytest
import hashlib
from unittest.mock import MagicMock, AsyncMock, patch

from core.base_node import AnonymousCommer
from config.config import GrpcConfig
from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2



# ========== 测试 Fixture 定义 ==========
class MockNodeContext:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
        self.stem2tor_instances = {}
    def get_latest_circuit_id(self): return None
    def get_active_circuit(self, circuit_id): return None
    def get_all_active_circuits(self): return []
    def get_relay(self, relay_id): return None
    def get_all_relays(self): return []
    def _create_node(self): return MagicMock()
    def _get_role(self, role_enum): return "test_role"


class MockCommandDispatcher:
    def __init__(self, commer):
        self.commer = commer


class MockGrpcHandler:
    def __init__(self, server_addr, context, dispatcher):
        self.server_addr = server_addr
        self.context = context
        self.dispatcher = dispatcher
        self.stub = MagicMock()
        self.channel = MagicMock()
    async def initialize(self): pass
    async def register_node(self): pass
    async def handle_commands(self): pass
    async def close(self): pass


class MockStateReporter:
    def __init__(self, context, grpc_handler):
        self.context = context
        self.grpc_handler = grpc_handler

# class LocalIpcServer:
#     async def start_server(self): pass
#     async def stop_server(self): pass


def get_network_info(logger, ip_addr=None, mode=None):
    return ("127.0.0.1", "test_location", "test_provider")


def get_logger(name):
    import logging
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    return logger


NodeContext = MockNodeContext
CommandDispatcher = MockCommandDispatcher
GrpcHandler = MockGrpcHandler
StateReporter = MockStateReporter


@pytest.fixture(autouse=True)
def mock_all_dependencies():
    """全局 mock 外部依赖，阻止真实调用。"""

    def fake_container(*args, **kwargs):
        node_code = kwargs.get("node_code") or kwargs.get("node_id")
        if not node_code and args:
            node_code = args[0]
        context = MockNodeContext(
            node_id=node_code,
            node_code=node_code,
            ip_address=kwargs.get("ip_address"),
            geo_location=kwargs.get("geo_location"),
            cloud_provider=kwargs.get("cloud_provider"),
        )
        container = MagicMock()
        container.context = context
        container.dispatcher = MockCommandDispatcher(None)
        container.grpc_handler = MockGrpcHandler(
            kwargs.get("server_addr"), context, container.dispatcher
        )
        container.reporter = MockStateReporter(context, container.grpc_handler)
        return container

    patches = [
        patch(
            "core.base_node.get_network_info",
            return_value=("127.0.0.1", "test_location", "test_provider"),
        ),
        patch("core.base_node.ServiceContainer", side_effect=fake_container),
        patch("utils.logger.get_logger", return_value=MagicMock()),
    ]
    for p in patches:
        p.start()
    yield {
        "MockNodeContext": MockNodeContext,
        "MockCommandDispatcher": MockCommandDispatcher,
        "MockGrpcHandler": MockGrpcHandler,
        "MockStateReporter": MockStateReporter,
    }
    for p in patches:
        p.stop()



# ------------------------------
# AnonymousCommer 基类测试
# ------------------------------
class TestAnonymousCommer:
    def test_base_node_initialization_defaults(self, mock_all_dependencies):
        """测试默认参数初始化"""
        # AnonymousCommer是抽象类，使用子类测试
        class TestCommer(AnonymousCommer):
            async def run(self):
                pass
        
        commer = TestCommer()
        
        # 验证默认值
        assert commer.mode is None
        assert commer.server_addr == GrpcConfig.DEFAULT_SERVER_ADDR
        
        # 验证node_id生成
        expected_hash = hashlib.sha256("127.0.0.1".encode()).hexdigest()[:8]
        assert commer.node_id == f"node-{expected_hash}"
        
        # 验证依赖初始化
        assert isinstance(commer.context, mock_all_dependencies["MockNodeContext"])
        assert isinstance(commer.dispatcher, mock_all_dependencies["MockCommandDispatcher"])
        assert isinstance(commer.grpc_handler, mock_all_dependencies["MockGrpcHandler"])
        assert isinstance(commer.reporter, mock_all_dependencies["MockStateReporter"])


    def test_base_node_initialization_custom_params(self):
        """测试自定义参数初始化"""
        class TestCommer(AnonymousCommer):
            async def run(self):
                pass
        
        custom_node_id = "test-node-123"
        custom_server = "10.0.0.1:50051"
        custom_ip = "10.0.0.2"
        custom_geo = "Shanghai"
        custom_provider = "TencentCloud"
        custom_mode = "cloud"
        
        commer = TestCommer(
            node_id=custom_node_id,
            server_addr=custom_server,
            ip_addr=custom_ip,
            geo_location=custom_geo,
            cloud_provider=custom_provider,
            run_mode=custom_mode
        )
        
        # 验证自定义参数
        assert commer.node_id == custom_node_id
        assert commer.server_addr == custom_server
        assert commer.geo_location == custom_geo
        assert commer.cloud_provider == custom_provider
        assert commer.mode == custom_mode


    def test_base_node_delegation_properties(self):
        """测试属性委托"""
        class TestCommer(AnonymousCommer):
            async def run(self):
                pass
        
        commer = TestCommer()
        
        # 验证属性委托
        assert commer.node_id == commer.context.node_id
        assert commer.ip_address == commer.context.ip_address
        assert commer.geo_location == commer.context.geo_location
        assert commer.cloud_provider == commer.context.cloud_provider
        assert commer.stub == commer.grpc_handler.stub
        assert commer.channel == commer.grpc_handler.channel


    def test_base_node_delegation_methods(self):
        """测试方法委托"""
        class TestCommer(AnonymousCommer):
            async def run(self):
                pass
        
        commer = TestCommer()
        # Mock context方法
        commer.context.get_latest_circuit_id = MagicMock(return_value="circuit-123")
        commer.context.get_active_circuit = MagicMock(return_value="mock_circuit")
        commer.context.get_relay = MagicMock(return_value="mock_relay")
        
        # 验证方法委托
        assert commer._get_latest_circuit_id() == "circuit-123"
        assert commer._get_active_circuit("123") == "mock_circuit"
        assert commer._get_relay("456") == "mock_relay"


    @pytest.mark.asyncio
    async def test_base_node_delayed_exit(self):
        """测试延迟退出方法"""
        class TestCommer(AnonymousCommer):
            async def run(self):
                pass
        
        commer = TestCommer()

        with patch("sys.exit") as mock_exit, \
             patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep, \
             patch.object(commer.grpc_handler, "close", new_callable=AsyncMock) as mock_grpc_close:
            
            # 执行延迟退出方法
            await commer._delayed_exit()
            
            # 验证核心逻辑
            # 1. 验证sleep等待了指定的退出延迟时间
            mock_sleep.assert_awaited_once_with(GrpcConfig.EXIT_DELAY)
            
            # 2. 验证grpc通道被关闭
            mock_grpc_close.assert_awaited_once()

            # 3. 验证sys.exit被调用，参数为0
            mock_exit.assert_called_once_with(0)


    def test_base_node_sync_handle_interrupt(self):
        """测试中断信号处理"""
        class TestCommer(AnonymousCommer):
            async def run(self):
                pass
        
        commer = TestCommer()

        # 1. 模拟事件循环（解决no running event loop错误）
        mock_loop = MagicMock()
        # 让asyncio.all_tasks(loop)返回预设任务，无需真实事件循环
        mock_task1 = MagicMock()
        mock_task2 = MagicMock()
        mock_all_tasks_return = [mock_task1, mock_task2]
        
        # 2. 正确创建并启动patch（关键：必须start()才会生效）
        with patch("asyncio.all_tasks", return_value=mock_all_tasks_return), \
             patch("asyncio.current_task", return_value=mock_task1), \
             patch("asyncio.get_running_loop", return_value=mock_loop):
            
            # 执行中断处理方法
            commer._sync_handle_interrupt()
            
            # 3. 验证逻辑：只有非当前任务被取消
            mock_task1.cancel.assert_not_called()  # 当前任务不取消
            mock_task2.cancel.assert_called_once() # 非当前任务取消