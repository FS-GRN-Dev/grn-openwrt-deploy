import pytest
import asyncio
from abc import ABC
from unittest.mock import MagicMock, AsyncMock, patch

from core.node_context import NodeContext
from models.node import Node
from models.relay import Relay
from models.circuit import Circuit
from core.stem_api import Stem2Tor
from config.config import NodeConfig

from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2




# ======================== Fixtures ========================
@pytest.fixture
def base_context_params():
    """基础的 NodeContext 初始化参数"""
    return {
        "node_code": "node-123456",
        "ip_address": "192.168.1.100",
        "geo_location": "CN/Beijing",
        "cloud_provider": "aliyun",
        "run_role": "vps",
    }


@pytest.fixture
def node_context(base_context_params):
    """创建基础的 NodeContext 实例"""
    # Mock 工具函数，避免依赖系统信息
    with patch('core.node_context.get_cpu_usage', return_value=10.5), \
         patch('core.node_context.get_memory_usage', return_value=20.3), \
         patch('core.node_context.time.strftime', return_value="2024-01-01 12:00:00"):
        return NodeContext(**base_context_params)


@pytest.fixture
def context_with_data(base_context_params):
    """创建包含测试数据的 NodeContext 实例"""
    with patch('core.node_context.get_cpu_usage', return_value=10.5), \
         patch('core.node_context.get_memory_usage', return_value=20.3), \
         patch('core.node_context.time.strftime', return_value="2024-01-01 12:00:00"):
        context = NodeContext(**base_context_params)
        
        # 添加测试 Relay
        relay1 = MagicMock(spec=Relay, relay_id="relay-001")
        relay2 = MagicMock(spec=Relay, relay_id="relay-002")
        context.relays = {"relay-001": relay1, "relay-002": relay2}
        
        # 添加测试 Circuit
        circuit1 = MagicMock(spec=Circuit, circuit_id="circuit-001")
        circuit2 = MagicMock(spec=Circuit, circuit_id="circuit-002")
        circuit3 = MagicMock(spec=Circuit, circuit_id="circuit-003")
        context.active_circuits = {
            "circuit-001": circuit1,
            "circuit-002": circuit2,
            "circuit-003": circuit3
        }
        
        # 添加 Stem2Tor 实例
        stem1 = MagicMock(spec=Stem2Tor)
        context.stem2tor_instances = {"relay-001": stem1}
        
        # 设置目录认证信息
        context.dir_auth = [{"id": "auth-001", "address": "192.168.1.1"}]
        
        return context


# ======================== 核心测试用例 ========================
def test_node_context_initialization(base_context_params):
    """测试 NodeContext 初始化和 __post_init__ 逻辑"""
    # 1. Mock 依赖函数和时间
    mock_cpu_usage = 15.7
    mock_memory_usage = 25.9
    mock_time_str = "2024-01-01 10:00:00"
    
    with patch('core.node_context.get_cpu_usage', return_value=mock_cpu_usage), \
         patch('core.node_context.get_memory_usage', return_value=mock_memory_usage), \
         patch('core.node_context.time.strftime', return_value=mock_time_str):
        
        # 2. 创建实例
        context = NodeContext(**base_context_params)
        
        # 3. 验证基础属性
        assert context.node_code == base_context_params["node_code"]
        assert context.ip_address == base_context_params["ip_address"]
        assert context.geo_location == base_context_params["geo_location"]
        assert context.cloud_provider == base_context_params["cloud_provider"]
        
        # 4. 验证默认状态属性
        assert isinstance(context.relays, dict)
        assert len(context.relays) == 0
        assert isinstance(context.stem2tor_instances, dict)
        assert len(context.stem2tor_instances) == 0
        assert isinstance(context.active_circuits, dict)
        assert len(context.active_circuits) == 0
        assert context.dir_auth is None
        
        # 5. 验证 Node 对象创建
        assert context.node is not None
        assert isinstance(context.node, Node)
        
        # 6. 验证 Node 属性
        assert context.node.node_code == base_context_params["node_code"]
        assert context.node.ip_address == base_context_params["ip_address"]
        assert context.node.status == NodeConfig.DEFAULT_NODE_STATUS
        assert context.node.risk_level == NodeConfig.DEFAULT_RISK_LEVEL
        assert context.node.cpu_usage == mock_cpu_usage
        assert context.node.memory_usage == mock_memory_usage
        assert context.node.traffic_in == NodeConfig.DEFAULT_TRAFFIC_IN
        assert context.node.traffic_out == NodeConfig.DEFAULT_TRAFFIC_OUT
        assert context.node.geo_location == base_context_params["geo_location"]
        assert context.node.cloud_provider == base_context_params["cloud_provider"]
        assert context.node.created_at == mock_time_str
        assert context.node.last_heartbeat == mock_time_str
        assert context.node.relay_count == NodeConfig.DEFAULT_RELAY_COUNT
        assert context.node.max_relay_capacity == NodeConfig.DEFAULT_MAX_RELAY_CAPACITY
        assert context.node.anonymous_relay_code == ""
        assert context.node.access_relay_code == ""


def test_node_context_get_latest_circuit_id(context_with_data, node_context):
    """测试获取最新电路ID的方法"""
    # 1. 测试有活动电路的场景
    latest_circuit_id = context_with_data.get_latest_circuit_id()
    assert latest_circuit_id == "circuit-003"  # 最后一个key
    
    # 2. 测试无活动电路的场景
    assert node_context.get_latest_circuit_id() is None


def test_node_context_get_active_circuit(context_with_data, node_context):
    """测试获取指定ID的活动电路"""
    # 1. 测试存在的电路ID
    circuit = context_with_data.get_active_circuit("circuit-002")
    assert circuit is not None
    assert circuit.circuit_id == "circuit-002"
    
    # 2. 测试不存在的电路ID
    assert context_with_data.get_active_circuit("circuit-999") is None
    
    # 3. 测试空上下文
    assert node_context.get_active_circuit("any-id") is None


def test_node_context_get_all_active_circuits(context_with_data, node_context):
    """测试获取所有活动电路列表"""
    # 1. 测试有电路的场景
    circuits = context_with_data.get_all_active_circuits()
    assert isinstance(circuits, list)
    assert len(circuits) == 3
    # 验证包含所有电路对象
    circuit_ids = [c.circuit_id for c in circuits]
    assert "circuit-001" in circuit_ids
    assert "circuit-002" in circuit_ids
    assert "circuit-003" in circuit_ids
    
    # 2. 测试无电路的场景
    assert len(node_context.get_all_active_circuits()) == 0


def test_node_context_get_relay(context_with_data, node_context):
    """测试获取指定ID的Relay"""
    # 1. 测试存在的Relay ID
    relay = context_with_data.get_relay("relay-001")
    assert relay is not None
    assert relay.relay_id == "relay-001"
    
    # 2. 测试不存在的Relay ID
    assert context_with_data.get_relay("relay-999") is None
    
    # 3. 测试空上下文
    assert node_context.get_relay("any-id") is None


def test_node_context_get_all_relays(context_with_data, node_context):
    """测试获取所有Relay列表"""
    # 1. 测试有Relay的场景
    relays = context_with_data.get_all_relays()
    assert isinstance(relays, list)
    assert len(relays) == 2
    # 验证包含所有Relay对象
    relay_ids = [r.relay_id for r in relays]
    assert "relay-001" in relay_ids
    assert "relay-002" in relay_ids
    
    # 2. 测试无Relay的场景
    assert len(node_context.get_all_relays()) == 0


def test_node_context__get_role():
    """测试 _get_role 辅助方法"""
    # 1. 创建上下文实例
    with patch('core.node_context.get_cpu_usage'), \
         patch('core.node_context.get_memory_usage'), \
         patch('core.node_context.time.strftime'):
        context = NodeContext("node-1", "127.0.0.1", "CN/Shanghai", "tencent", "vps")
    
    # 2. Mock get_role 函数
    with patch('core.node_context.get_role') as mock_get_role:
        mock_role_enum = MagicMock()
        mock_get_role.return_value = "VPS"
        
        # 3. 调用方法
        result = context._get_role(mock_role_enum)
        
        # 4. 验证调用
        mock_get_role.assert_called_once_with(mock_role_enum)
        assert result == "VPS"


# ======================== 边界场景测试 ========================
def test_node_context_empty_initialization():
    """测试使用空字符串初始化 NodeContext"""
    empty_params = {
        "node_code": "",
        "ip_address": "",
        "geo_location": "",
        "cloud_provider": "",
        "run_role": "",
    }
    
    with patch('core.node_context.get_cpu_usage', return_value=0.0), \
         patch('core.node_context.get_memory_usage', return_value=0.0), \
         patch('core.node_context.time.strftime', return_value="2024-01-01 00:00:00"):
        # 验证不会抛出异常
        context = NodeContext(**empty_params)
        
        # 验证空参数被正确设置
        assert context.node_code == ""
        assert context.ip_address == ""
        assert context.node.node_code == ""
        assert context.node.ip_address == ""


def test_node_context_dynamic_data_update(context_with_data):
    """测试动态更新上下文数据"""
    # 1. 添加新的Relay
    new_relay = MagicMock(spec=Relay, relay_id="relay-003")
    context_with_data.relays["relay-003"] = new_relay
    
    # 验证获取方法能识别新数据
    assert len(context_with_data.get_all_relays()) == 3
    assert context_with_data.get_relay("relay-003") == new_relay
    
    # 2. 添加新的Circuit
    new_circuit = MagicMock(spec=Circuit, circuit_id="circuit-004")
    context_with_data.active_circuits["circuit-004"] = new_circuit
    
    # 验证最新电路ID更新
    assert context_with_data.get_latest_circuit_id() == "circuit-004"
    assert len(context_with_data.get_all_active_circuits()) == 4
    
    # 3. 删除数据
    del context_with_data.relays["relay-001"]
    del context_with_data.active_circuits["circuit-001"]
    
    assert len(context_with_data.get_all_relays()) == 2
    assert context_with_data.get_relay("relay-001") is None
    assert len(context_with_data.get_all_active_circuits()) == 3
    assert context_with_data.get_active_circuit("circuit-001") is None