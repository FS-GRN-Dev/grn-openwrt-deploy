import pytest
import asyncio
import json
import time
from unittest.mock import MagicMock, AsyncMock, patch

from core.state_reporter import StateReporter
from core.node_context import NodeContext
from core.grpc_handler import GrpcHandler
from config.config import SystemConfig

from utils.system import get_cpu_usage, get_memory_usage, get_network_traffic, calculate_risk_level

from typing import Optional, List, Dict, Union, Callable, Any

from generated import vps_management_pb2



# -------------------------- 基础测试夹具 --------------------------
@pytest.fixture
def mock_context():
    """模拟 NodeContext 对象（核心依赖）"""
    context = MagicMock()
    # 节点基础信息
    context.node_code = "test-node-001"
    context.ip_address = "127.0.0.1"
    context.node = MagicMock()
    context.node.to_proto = MagicMock(return_value=vps_management_pb2.Node(
        node_code=context.node_code,
        ip_address=context.ip_address
    ))
    context.relays = {
        "relay-001": MagicMock(
            relay_code="relay-001",
            nickname="test-relay",
            container_id="container-001",
            relay_role=vps_management_pb2.RelayRole.ROLE_DA,
            to_proto=MagicMock()
        )
    }
    # stem2tor 实例
    context.stem2tor_instances = {
        "relay-001": AsyncMock(
            wait_for_tor_node=AsyncMock(return_value={"fingerprint": "test-fp-001"}),
            get_dir_auths=AsyncMock(return_value=[{
                "nick": "test-da",
                "address": "192.168.1.1",
                "orport": 9001,
                "v3ident": "test-v3",
                "fingerprint": "test-fp-da"
            }]),
            role="client"
        )
    }
    return context


@pytest.fixture
def mock_grpc_handler():
    """模拟 GrpcHandler 对象"""
    grpc_handler = MagicMock()
    # Mock gRPC stub（异步方法）
    grpc_handler.stub = AsyncMock()
    # 预设各推送方法的成功响应
    grpc_handler.stub.PushNodeInfo = AsyncMock(return_value=MagicMock(success=True, message="节点信息推送成功"))
    grpc_handler.stub.PushRelayInfo = AsyncMock(return_value=MagicMock(success=True, message="Relay信息推送成功"))
    grpc_handler.stub.PushSituationAwarenessInfo = AsyncMock(return_value=MagicMock(success=True, message="态势感知推送成功"))
    grpc_handler.stub.PushDAInfo = AsyncMock(return_value=MagicMock(success=True, message="DA信息推送成功"))
    return grpc_handler


@pytest.fixture
def state_reporter(mock_context, mock_grpc_handler):
    """创建 StateReporter 实例"""
    reporter = StateReporter(
        context=mock_context,
        grpc_handler=mock_grpc_handler
    )

    return reporter

# -------------------------- 测试用例 --------------------------
class TestStateReporter:
    @pytest.mark.asyncio
    async def test_state_reporter_report_node_info_success(self, state_reporter, mock_context):
        """测试节点信息上报成功场景"""
        # Mock 系统资源获取函数
        with patch("core.state_reporter.get_network_traffic", return_value=(1024, 2048)), \
             patch("core.state_reporter.get_cpu_usage", return_value=50.0), \
             patch("core.state_reporter.get_memory_usage", return_value=60.0), \
             patch("core.state_reporter.get_tcp_retrans_rate", return_value=0.01):
            
            result = await state_reporter.report_node_info()

            assert result is True
            mock_context.node.update_resource_usage.assert_called_once_with(
                cpu=50.0,
                mem=60.0,
                traffic_in=1024,
                traffic_out=2048,
                tcp_retrans_rate=0.01,
            )
            mock_context.node.relay_count = len(mock_context.relays)
            state_reporter.stub.PushNodeInfo.assert_awaited_once()


    @pytest.mark.asyncio
    async def test_state_reporter_report_node_info_failure(self, state_reporter):
        """测试节点信息上报失败场景"""
        # Mock gRPC 调用抛异常
        state_reporter.stub.PushNodeInfo = AsyncMock(side_effect=Exception("连接失败"))

        # 执行上报
        result = await state_reporter.report_node_info()

        # 断言
        assert result is False


    @pytest.mark.asyncio
    async def test_state_reporter_report_relay_info_success(self, state_reporter, mock_context):
        """测试 Relay 信息上报成功场景"""

        # 1. 先构造合法的 RelayInfo 实例（包含 relay_id/nickname 等字段）
        mock_relay_info_proto = vps_management_pb2.Relay(
            relay_code="test-relay-001",
            nickname="test-nick-name",
            ip_address="127.0.0.1",
            container_id="container-001"
        )
        # 2. 让单个 Relay 对象的 to_proto() 返回合法的 RelayInfo
        mock_context.relays["relay-001"].to_proto = MagicMock(return_value=mock_relay_info_proto)

        # 3. PushRelayInfoRequest 只需要 relays 字段（RelayInfo 列表）
        expected_request = vps_management_pb2.PushRelayInfoRequest(relays=[mock_relay_info_proto])

        # 4. 正确 Mock stub（用 AsyncMock 而非 MagicMock，适配异步调用）
        mock_stub = AsyncMock()

        # 5. 定义返回逻辑
        async def push_relay_info_mock(*args, **kwargs):
            response = MagicMock()
            response.success = True
            response.message = "推送中继信息成功"
            return response

        # 给 PushNodeInfo 绑定异步 mock 函数
        mock_stub.PushRelayInfo = AsyncMock(side_effect=push_relay_info_mock)

        # 执行上报
        result = await state_reporter.report_relay_info()

        # 断言
        assert result is True
        # 验证 Tor 节点信息查询
        mock_context.stem2tor_instances["relay-001"].wait_for_tor_node.assert_awaited_once_with(
            "test-relay", "container-001"
        )
        # 验证 Relay 信息更新
        mock_context.relays["relay-001"].update_from_tor_info.assert_called_once_with(
            {"fingerprint": "test-fp-001"}
        )
        # 验证 gRPC 调用（推送 Relay proto 列表）
        state_reporter.stub.PushRelayInfo.assert_awaited_once_with(
            vps_management_pb2.PushRelayInfoRequest(
                relays=[mock_context.relays["relay-001"].to_proto()]
            )
        )


    @pytest.mark.asyncio
    async def test_state_reporter_report_relay_info_no_relays(self, state_reporter, mock_context):
        """测试无 Relay 信息时的上报逻辑"""
        # 清空 Relay 列表
        mock_context.relays = {}

        # 执行上报
        result = await state_reporter.report_relay_info()

        # 断言
        assert result is True


    @pytest.mark.asyncio
    async def test_state_reporter_report_relay_info_tor_node_timeout(self, state_reporter, mock_context):
        """测试 Tor 节点信息查询超时场景"""
       # 1. 先构造合法的 RelayInfo 实例（包含 relay_id/nickname 等字段）
        mock_relay_info_proto = vps_management_pb2.Relay(
            relay_code="test-relay-001",
            nickname="test-nick-name",
            ip_address="127.0.0.1",
            container_id="container-001"
        )
        # 2. 让单个 Relay 对象的 to_proto() 返回合法的 RelayInfo
        mock_context.relays["relay-001"].to_proto = MagicMock(return_value=mock_relay_info_proto)

        # 3. PushRelayInfoRequest 只需要 relays 字段（RelayInfo 列表）
        expected_request = vps_management_pb2.PushRelayInfoRequest(relays=[mock_relay_info_proto])

        # 4. 正确 Mock stub（用 AsyncMock 而非 MagicMock，适配异步调用）
        mock_stub = AsyncMock()

        # 5. 定义返回逻辑
        async def push_relay_info_mock(*args, **kwargs):
            response = MagicMock()
            response.success = False
            response.message = "推送中继信息超时"
            return response

        # 给 PushNodeInfo 绑定异步 mock 函数
        mock_stub.PushRelayInfo = AsyncMock(side_effect=push_relay_info_mock)


        # Mock Tor 节点查询返回空 fingerprint
        mock_context.stem2tor_instances["relay-001"].wait_for_tor_node = AsyncMock(
            return_value={"fingerprint": ""}
        )
        mock_context.stem2tor_instances["relay-001"].role = "server"

        # 执行上报
        result = await state_reporter.report_relay_info()

        # 断言
        # 即使单个节点超时，仍会推送其他 Relay 信息
        state_reporter.stub.PushRelayInfo.assert_awaited_once()


    @pytest.mark.asyncio
    async def test_state_reporter_push_relays_success(self, state_reporter):
        """测试增量推送 Relay 信息成功"""
        # 构造测试 Relay 列表
        test_relays = [MagicMock(to_proto=MagicMock(return_value=vps_management_pb2.Relay(relay_code="relay-002")))]
        
        # 执行推送
        result = await state_reporter.push_relays(test_relays)

        # 断言
        assert result is True
        state_reporter.stub.PushRelayInfo.assert_awaited_once_with(
            vps_management_pb2.PushRelayInfoRequest(
                relays=[test_relays[0].to_proto()]
            )
        )


    @pytest.mark.asyncio
    async def test_state_reporter_push_relays_empty(self, state_reporter):
        """测试增量推送空 Relay 列表"""
        result = await state_reporter.push_relays([])
        assert result is True
        state_reporter.stub.PushRelayInfo.assert_not_awaited()


    @pytest.mark.asyncio
    async def test_state_reporter_report_situation_awareness_success(self, state_reporter, mock_context):
        """测试态势感知信息上报成功"""
        # Mock 风险等级计算
        with patch("core.state_reporter.calculate_risk_level", return_value=SystemConfig.RISK_LEVEL_MINIMAL):
            # 执行上报
            result = await state_reporter.report_situation_awareness()

            # 断言
            assert result is True
          

    @pytest.mark.asyncio
    async def test_state_reporter_report_da_info_success(self, state_reporter, mock_context):
        """测试 DA 信息上报成功"""
        # 执行上报
        result = await state_reporter.report_da_info()

        # 断言
        assert result is True
        # 验证目录权威信息查询
        mock_context.stem2tor_instances["relay-001"].get_dir_auths.assert_awaited_once()
        # 验证每个 DA 信息都推送（这里返回1个，调用1次）
        state_reporter.stub.PushDAInfo.assert_awaited_once_with(
            vps_management_pb2.PushDAInfoRequest(
                da_info=vps_management_pb2.DAInfo(
                    node_code=mock_context.node_code,
                    relay_code="relay-001",
                    nick="test-da",
                    ip_address="192.168.1.1",
                    or_port=9001,
                    v3_ident="test-v3",
                    fingerprint="test-fp-da"
                )
            )
        )


    @pytest.mark.asyncio
    async def test_state_reporter_report_da_info_skip_non_da_relay(self, state_reporter, mock_context):
        """测试跳过非 DA 角色的 Relay"""
        # 修改 Relay 角色为非 DA
        mock_context.relays["relay-001"].relay_role = vps_management_pb2.RelayRole.ROLE_CLIENT

        # 执行上报
        result = await state_reporter.report_da_info()

        # 断言
        assert result is True
        # 验证 DA 推送未被调用
        state_reporter.stub.PushDAInfo.assert_not_awaited()


    @pytest.mark.asyncio
    async def test_state_reporter_report_da_info_failure(self, state_reporter):
        """测试 DA 信息上报失败"""
        # Mock DA 推送抛异常
        state_reporter.stub.PushDAInfo = AsyncMock(side_effect=Exception("DA推送失败"))

        # 执行上报
        result = await state_reporter.report_da_info()

        # 断言
        assert result is False
