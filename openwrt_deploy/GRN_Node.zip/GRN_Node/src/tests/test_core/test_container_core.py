import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

from core.container import ServiceContainer
from core.node_context import NodeContext
from core.state_reporter import StateReporter
from core.grpc_handler import GrpcHandler
from core.command_dispatcher import CommandDispatcher
from core.tor_runtime import TorRuntimeFactory
from config.config import GrpcConfig
from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2




# ======================== Fixtures ========================
@pytest.fixture
def base_test_config():
    """基础测试配置参数"""
    return {
        "node_code": "test-node-001",
        "ip_address": "192.168.1.100",
        "geo_location": "CN/Beijing",
        "longitude": 116.4,
        "latitude": 39.9,
        "cloud_provider": "aliyun",
        "run_role": "vps",
        "server_addr": "[::]:50051"
    }

@pytest.fixture
def mock_node_context(base_test_config):
    """Mock NodeContext 实例"""
    mock_context = MagicMock(spec=NodeContext)
    mock_context.node_code = base_test_config["node_code"]
    mock_context.ip_address = base_test_config["ip_address"]
    mock_context.geo_location = base_test_config["geo_location"]
    mock_context.cloud_provider = base_test_config["cloud_provider"]
    return mock_context


@pytest.fixture
def mock_tor_runtime_factory():
    """Mock TorRuntimeFactory 对象"""
    return MagicMock(spec=TorRuntimeFactory)


@pytest.fixture
def mock_dispatcher(mock_node_context):
    """Mock CommandDispatcher 实例"""
    mock_disp = MagicMock(spec=CommandDispatcher)
    mock_disp.context = mock_node_context
    # 模拟 Dispatcher 的注入方法
    mock_disp.set_reporter = MagicMock()
    mock_disp.set_relay_service = MagicMock()
    mock_disp.set_node_service = MagicMock()
    mock_disp.set_link_service = MagicMock()
    mock_disp.set_tun_bridge_service = MagicMock()
    mock_disp._check_init = MagicMock()
    return mock_disp



# ======================== Test Cases ========================
def test_container_initialization(base_test_config, mock_node_context, mock_tor_runtime_factory):
    """测试 ServiceContainer 完整初始化流程"""
    # 1. Mock 所有依赖类，避免实际初始化
    with patch('core.container.NodeContext', return_value=mock_node_context(base_test_config)) as mock_context_cls, \
         patch('core.container.StateReporter') as mock_reporter_cls, \
         patch('core.container.NodeService') as mock_node_service_cls, \
         patch('core.container.LinkService') as mock_link_service_cls, \
         patch('core.container.TorRuntimeFactory', return_value=mock_tor_runtime_factory()) as mock_tor_factory_cls, \
         patch('core.container.RelayService') as mock_relay_service_cls, \
         patch('core.container.CommandDispatcher') as mock_dispatcher_cls, \
         patch('core.container.GrpcHandler') as mock_grpc_handler_cls, \
         patch('core.container.TunBridgeService') as mock_tun_bridge_cls, \
         patch('core.container.NodeInitSyncService'):
        
        # 2. 配置 Mock 返回值
        mock_context = mock_context_cls.return_value
        mock_reporter = MagicMock()
        mock_reporter_cls.return_value = mock_reporter
        
        mock_node_service = MagicMock()
        mock_node_service_cls.return_value = mock_node_service
        
        mock_link_service = MagicMock()
        mock_link_service_cls.return_value = mock_link_service
        
        mock_tor_factory = mock_tor_factory_cls.return_value
        
        mock_relay_service = MagicMock()
        mock_relay_service_cls.return_value = mock_relay_service
        
        mock_dispatcher = MagicMock()
        mock_dispatcher_cls.return_value = mock_dispatcher
        
        mock_grpc_handler = MagicMock()
        mock_grpc_handler_cls.return_value = mock_grpc_handler
        
        # 3. 创建 ServiceContainer 实例
        container = ServiceContainer(
            node_code=base_test_config["node_code"],
            ip_address=base_test_config["ip_address"],
            geo_location=base_test_config["geo_location"],
            longitude=base_test_config["longitude"],
            latitude=base_test_config["latitude"],
            cloud_provider=base_test_config["cloud_provider"],
            run_role=base_test_config["run_role"],
            server_addr=base_test_config["server_addr"]
        )
        
        # 4. 验证核心对象初始化
        # 验证 NodeContext 创建
        mock_context_cls.assert_called_once_with(
            node_code=base_test_config["node_code"],
            ip_address=base_test_config["ip_address"],
            geo_location=base_test_config["geo_location"],
            longitude=base_test_config["longitude"],
            latitude=base_test_config["latitude"],
            cloud_provider=base_test_config["cloud_provider"],
            run_role=base_test_config["run_role"],
        )
        assert container.context == mock_context
        
        # 验证 TorRuntimeFactory 创建
        mock_tor_factory_cls.assert_called_once()
        assert container.tor_runtime_factory == mock_tor_factory
        
        # 验证 CommandDispatcher 创建
        mock_dispatcher_cls.assert_called_once_with(mock_context)
        assert container.dispatcher == mock_dispatcher
        
        # 验证 GrpcHandler 创建
        mock_grpc_handler_cls.assert_called_once_with(
            base_test_config["server_addr"], mock_context, mock_dispatcher
        )
        assert container.grpc_handler == mock_grpc_handler
        
        # 验证 StateReporter 创建
        mock_reporter_cls.assert_called_once_with(mock_context, mock_grpc_handler)
        assert container.reporter == mock_reporter
        
        # 5. 验证服务初始化（最终版本）
        # 验证 RelayService 创建（最终版本）
        mock_relay_service_cls.assert_called_with(
            mock_context,
            mock_reporter,
            mock_tor_factory,
            tun_bridge_service=container.tun_bridge_service,
            link_service=mock_link_service,
        )
        assert container.relay_service == mock_relay_service
        
        # 验证 NodeService 创建（最终版本）
        mock_node_service_cls.assert_called_with(mock_context, mock_reporter)
        assert container.node_service == mock_node_service
        
        # 验证 LinkService 创建（最终版本）
        mock_link_service_cls.assert_called_with(
            mock_context, mock_reporter, tun_bridge_service=container.tun_bridge_service
        )
        assert container.link_service == mock_link_service
        
        # 6. 验证循环依赖解决：Dispatcher 注入
        mock_dispatcher.set_reporter.assert_called_once_with(mock_reporter)
        mock_dispatcher.set_relay_service.assert_called_once_with(mock_relay_service)
        mock_dispatcher.set_node_service.assert_called_once_with(mock_node_service)
        mock_dispatcher.set_link_service.assert_called_once_with(mock_link_service)
        mock_dispatcher.set_tun_bridge_service.assert_called_once_with(container.tun_bridge_service)
        mock_dispatcher._check_init.assert_called_once()


def test_container_initialization_order(base_test_config):
    """测试 ServiceContainer 初始化顺序和对象创建"""
    # 1. Mock 所有依赖类，记录调用顺序
    with patch('core.container.NodeContext') as mock_context_cls, \
         patch('core.container.TorRuntimeFactory') as mock_tor_factory_cls, \
         patch('core.container.CommandDispatcher') as mock_dispatcher_cls, \
         patch('core.container.GrpcHandler') as mock_grpc_handler_cls, \
         patch('core.container.StateReporter') as mock_reporter_cls, \
         patch('core.container.RelayService') as mock_relay_service_cls, \
         patch('core.container.NodeService') as mock_node_service_cls, \
         patch('core.container.LinkService') as mock_link_service_cls:
        
        # 2. 配置 Mock 返回值
        mock_context = mock_context_cls.return_value
        mock_tor_factory = mock_tor_factory_cls.return_value
        mock_dispatcher = mock_dispatcher_cls.return_value
        mock_grpc_handler = mock_grpc_handler_cls.return_value
        mock_reporter = mock_reporter_cls.return_value
        mock_relay_service = mock_relay_service_cls.return_value
        mock_node_service = mock_node_service_cls.return_value
        mock_link_service = mock_link_service_cls.return_value
        
        # 3. 创建 ServiceContainer 实例
        container = ServiceContainer(**base_test_config)
        
        # 4. 验证初始化顺序（核心重点）
        # 获取所有 Mock 的调用顺序
        call_order = [
            mock_context_cls.call_args,          # 1. NodeContext
            mock_tor_factory_cls.call_args,      # 2. TorRuntimeFactory
            mock_dispatcher_cls.call_args,       # 3. CommandDispatcher
            mock_grpc_handler_cls.call_args,     # 4. GrpcHandler
            mock_reporter_cls.call_args,         # 5. StateReporter
            mock_relay_service_cls.call_args,    # 6. RelayService
            mock_node_service_cls.call_args,     # 7. NodeService
            mock_link_service_cls.call_args      # 8. LinkService
        ]
        
        # 5. 验证容器属性赋值
        assert container.context == mock_context
        assert container.tor_runtime_factory == mock_tor_factory
        assert container.dispatcher == mock_dispatcher
        assert container.grpc_handler == mock_grpc_handler
        assert container.reporter == mock_reporter
        assert container.relay_service == mock_relay_service
        assert container.node_service == mock_node_service
        assert container.link_service == mock_link_service
        
        # 6. 验证每个对象只创建一次（修正后无重复初始化）
        assert mock_context_cls.call_count == 1
        assert mock_tor_factory_cls.call_count == 1
        assert mock_dispatcher_cls.call_count == 1
        assert mock_grpc_handler_cls.call_count == 1
        assert mock_reporter_cls.call_count == 1
        assert mock_relay_service_cls.call_count == 1
        assert mock_node_service_cls.call_count == 1
        assert mock_link_service_cls.call_count == 1


def test_container_dispatcher_dependency_injection(base_test_config):
    """测试 Dispatcher 的依赖注入和 _check_init 调用"""
    # 1. Mock 依赖
    with patch('core.container.NodeContext'), \
         patch('core.container.TorRuntimeFactory'), \
         patch('core.container.CommandDispatcher') as mock_dispatcher_cls, \
         patch('core.container.GrpcHandler'), \
         patch('core.container.StateReporter') as mock_reporter_cls, \
         patch('core.container.RelayService') as mock_relay_service_cls, \
         patch('core.container.NodeService') as mock_node_service_cls, \
         patch('core.container.LinkService') as mock_link_service_cls:
        
        # 2. 配置 Mock
        mock_dispatcher = mock_dispatcher_cls.return_value
        mock_reporter = mock_reporter_cls.return_value
        mock_relay_service = mock_relay_service_cls.return_value
        mock_node_service = mock_node_service_cls.return_value
        mock_link_service = mock_link_service_cls.return_value
        
        # 3. 创建容器
        container = ServiceContainer(**base_test_config)
        
        # 4. 验证 Dispatcher 依赖注入
        # 验证注入顺序和参数
        mock_dispatcher.set_reporter.assert_called_once_with(mock_reporter)
        mock_dispatcher.set_relay_service.assert_called_once_with(mock_relay_service)
        mock_dispatcher.set_node_service.assert_called_once_with(mock_node_service)
        mock_dispatcher.set_link_service.assert_called_once_with(mock_link_service)
        
        # 验证 _check_init 被调用（触发命令初始化）
        mock_dispatcher._check_init.assert_called_once()
        
        # 验证注入的是容器实际的服务实例
        assert mock_dispatcher.set_reporter.call_args[0][0] == container.reporter
        assert mock_dispatcher.set_relay_service.call_args[0][0] == container.relay_service
        assert mock_dispatcher.set_node_service.call_args[0][0] == container.node_service
        assert mock_dispatcher.set_link_service.call_args[0][0] == container.link_service


def test_container_cyclic_dependency_resolution(base_test_config):
    """测试容器解决循环依赖的逻辑（GrpcHandler ↔ Dispatcher ↔ Reporter）"""
    # 1. Mock 核心依赖，模拟循环依赖场景
    with patch('core.container.NodeContext') as mock_context_cls, \
         patch('core.container.CommandDispatcher') as mock_dispatcher_cls, \
         patch('core.container.GrpcHandler') as mock_grpc_handler_cls, \
         patch('core.container.StateReporter') as mock_reporter_cls:
        
        # 2. 配置 Mock
        mock_context = mock_context_cls.return_value
        mock_dispatcher = mock_dispatcher_cls.return_value
        mock_grpc_handler = mock_grpc_handler_cls.return_value
        mock_reporter = mock_reporter_cls.return_value
        
        # 3. 创建容器
        container = ServiceContainer(**base_test_config)
        
        # 4. 验证循环依赖解决逻辑
        # Step 1: GrpcHandler 依赖 Dispatcher（先创建 Dispatcher）
        mock_grpc_handler_cls.assert_called_once_with(
            base_test_config["server_addr"], mock_context, mock_dispatcher
        )
        
        # Step 2: Reporter 依赖 GrpcHandler（再创建 Reporter）
        mock_reporter_cls.assert_called_once_with(mock_context, mock_grpc_handler)
        
        # Step 3: Dispatcher 注入 Reporter（最后解决循环依赖）
        mock_dispatcher.set_reporter.assert_called_once_with(mock_reporter)
        
        # 验证核心对象的依赖关系
        grpc_handler_call_args = mock_grpc_handler_cls.call_args[0]
        assert grpc_handler_call_args[2] == container.dispatcher  # 第三个参数是 dispatcher
        
        # 验证 Reporter 使用的是容器的 GrpcHandler
        reporter_call_args = mock_reporter_cls.call_args[0]
        assert reporter_call_args[1] == container.grpc_handler    # 第二个参数是 grpc_handler
        
        # 验证 Dispatcher 注入的是容器的 Reporter
        dispatcher_set_reporter_args = mock_dispatcher.set_reporter.call_args[0]
        assert dispatcher_set_reporter_args[0] == container.reporter  # 注入的是容器的 reporter


# ======================== 边界场景测试 ========================
def test_container_with_invalid_config_values():
    """测试容器使用无效配置值初始化（边界场景）"""
    # 1. 无效配置参数
    invalid_config = {
        "node_code": None,
        "ip_address": "256.256.256.256",
        "geo_location": "",
        "longitude": 0.0,
        "latitude": 0.0,
        "cloud_provider": 123,
        "run_role": "vps",
        "server_addr": None
    }
    
    # 2. Mock 所有依赖，确保不抛出异常
    with patch('core.container.NodeContext') as mock_context, \
         patch('core.container.TorRuntimeFactory'), \
         patch('core.container.CommandDispatcher'), \
         patch('core.container.GrpcHandler'), \
         patch('core.container.StateReporter'), \
         patch('core.container.RelayService'), \
         patch('core.container.NodeService'), \
         patch('core.container.LinkService'):
        
        # 3. 创建容器（验证不会抛出异常）
        container = ServiceContainer(**invalid_config)
        
        # 4. 验证核心对象都被初始化
        assert hasattr(container, 'context')
        assert hasattr(container, 'tor_runtime_factory')
        assert hasattr(container, 'dispatcher')
        assert hasattr(container, 'grpc_handler')
        assert hasattr(container, 'reporter')
        assert hasattr(container, 'relay_service')
        assert hasattr(container, 'node_service')
        assert hasattr(container, 'link_service')
        
        # 验证 NodeContext 接收了所有参数（包括无效值）
        mock_context.assert_called_once_with(
            node_code=None,
            ip_address="256.256.256.256",
            geo_location="",
            longitude=0.0,
            latitude=0.0,
            cloud_provider=123,
            run_role="vps",
        )


def test_container_mock_isolation(base_test_config):
    """测试 Mock 隔离性，确保不同测试用例互不影响"""
    # 第一次创建容器
    with patch('core.container.NodeContext') as mock_context_cls1:
        container1 = ServiceContainer(**base_test_config)
        call_count1 = mock_context_cls1.call_count
    
    # 第二次创建容器
    with patch('core.container.NodeContext') as mock_context_cls2:
        container2 = ServiceContainer(**base_test_config)
        call_count2 = mock_context_cls2.call_count
    
    # 验证两次创建相互隔离
    assert call_count1 == 1
    assert call_count2 == 1
    assert container1.context != container2.context
