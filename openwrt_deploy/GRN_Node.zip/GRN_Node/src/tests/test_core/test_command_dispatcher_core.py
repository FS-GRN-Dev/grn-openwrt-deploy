import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

from core.command_dispatcher import CommandDispatcher
from config.config import GrpcConfig
from typing import Optional, List, Dict, Union, Callable, Any

from generated import vps_management_pb2



# ======================== Fixtures ========================
@pytest.fixture
def mock_context():
    """创建模拟上下文对象"""
    context = MagicMock()
    context.node_code = "test-node-001"
    context.config = MagicMock()
    return context


@pytest.fixture
def mock_reporter():
    """创建模拟报告器对象"""
    reporter = MagicMock()
    reporter.send_response = MagicMock(return_value=None)
    return reporter


@pytest.fixture
def mock_relay_service():
    """创建模拟中继服务对象"""
    service = MagicMock()
    service.create_relay = MagicMock()
    service.destroy_relay = MagicMock()
    service.update_relay = MagicMock()
    return service


@pytest.fixture
def mock_node_service():
    """创建模拟节点服务对象"""
    service = MagicMock()
    service.set_status = MagicMock()
    service.destroy_node = MagicMock()
    service.inform_da_info = MagicMock()
    service.refresh_info = MagicMock()
    return service


@pytest.fixture
def mock_link_service():
    """创建模拟链路服务对象"""
    service = MagicMock()
    service.create_circuit = MagicMock()
    service.delete_circuit = MagicMock()
    return service


@pytest.fixture
def mock_tun_bridge_service():
    service = MagicMock()
    return service


@pytest.fixture
def mock_logger():
    """创建模拟日志对象"""
    logger = MagicMock()
    logger.warning = MagicMock()
    logger.error = MagicMock()
    logger.info = MagicMock()
    return logger


@pytest.fixture
def command_dispatcher(mock_context, mock_logger):
    """创建 CommandDispatcher 实例（基础版）"""
    with patch('utils.logger.get_logger', return_value=mock_logger):
        dispatcher = CommandDispatcher(mock_context)
        yield dispatcher


@pytest.fixture
def command_dispatcher_full(
    mock_context, 
    mock_reporter, 
    mock_relay_service, 
    mock_node_service, 
    mock_link_service,
    mock_tun_bridge_service,
    mock_logger
):
    """创建初始化完成的 CommandDispatcher 实例（完整版）"""
    with patch('utils.logger.get_logger', return_value=mock_logger):
        dispatcher = CommandDispatcher(mock_context)
        
        # 设置所有依赖服务
        dispatcher.set_reporter(mock_reporter)
        dispatcher.set_relay_service(mock_relay_service)
        dispatcher.set_node_service(mock_node_service)
        dispatcher.set_link_service(mock_link_service)
        dispatcher.set_tun_bridge_service(mock_tun_bridge_service)
        
        # 手动触发初始化（确保命令注册）
        dispatcher._check_init()
        
        yield dispatcher


# ======================== Test Cases ========================
def test_command_dispatcher_initialization(mock_context, mock_logger):
    """测试 CommandDispatcher 初始化状态"""
    # 执行测试
    with patch('utils.logger.get_logger', return_value=mock_logger):
        dispatcher = CommandDispatcher(mock_context)
        
        # 验证初始化状态
        assert dispatcher.context == mock_context
        assert dispatcher.reporter is None
        assert dispatcher.commands == {}
        assert dispatcher.logger == mock_logger
        # 验证服务属性初始状态
        assert not hasattr(dispatcher, 'relay_service')
        assert not hasattr(dispatcher, 'node_service')
        assert not hasattr(dispatcher, 'link_service')


def test_command_dispatcher_set_services(command_dispatcher, mock_reporter, mock_relay_service, mock_node_service, mock_link_service, mock_tun_bridge_service):
    """测试设置各类服务的方法"""
    command_dispatcher.set_reporter(mock_reporter)
    command_dispatcher.set_relay_service(mock_relay_service)
    command_dispatcher.set_node_service(mock_node_service)
    command_dispatcher.set_link_service(mock_link_service)
    command_dispatcher.set_tun_bridge_service(mock_tun_bridge_service)
    
    assert command_dispatcher.reporter == mock_reporter
    assert command_dispatcher.relay_service == mock_relay_service
    assert command_dispatcher.node_service == mock_node_service
    assert command_dispatcher.link_service == mock_link_service
    assert command_dispatcher.tun_bridge_service == mock_tun_bridge_service


def test_command_dispatcher_check_init(command_dispatcher, mock_reporter, mock_relay_service, mock_node_service, mock_link_service, mock_tun_bridge_service):
    """测试 _check_init 方法的命令初始化逻辑"""
    command_dispatcher.set_reporter(mock_reporter)
    command_dispatcher.set_relay_service(mock_relay_service)
    command_dispatcher.set_node_service(mock_node_service)
    command_dispatcher.set_link_service(mock_link_service)
    command_dispatcher.set_tun_bridge_service(mock_tun_bridge_service)
    command_dispatcher._check_init()

    assert len(command_dispatcher.commands) == 13
    assert vps_management_pb2.CommandType.CREATE_RELAY in command_dispatcher.commands
    assert vps_management_pb2.CommandType.CREATE_CIRCUIT in command_dispatcher.commands
    assert vps_management_pb2.CommandType.SWITCH_LINK in command_dispatcher.commands
    assert vps_management_pb2.CommandType.CLEANUP_DATA in command_dispatcher.commands
    assert vps_management_pb2.CommandType.SET_ALLOW_AUTO_CIRCUIT in command_dispatcher.commands
    assert vps_management_pb2.CommandType.HEART_BEAT_RESPONSE in command_dispatcher.commands


@pytest.mark.asyncio
async def test_command_dispatcher_dispatch_valid_command(command_dispatcher_full):
    """测试分发有效命令类型"""
    # 1. 准备测试数据
    test_command_type = vps_management_pb2.CommandType.CREATE_RELAY
    test_msg_data = {"relay_id": "relay-001", "config": {"port": 9001}}
    test_command_id = "cmd-123456"
    
    # 2. Mock 命令执行方法
    mock_command_handler = command_dispatcher_full.commands[test_command_type]
    mock_command_handler.execute = AsyncMock(return_value={"status": "success"})
    
    # 3. 执行分发
    result = await command_dispatcher_full.dispatch(test_command_type, test_msg_data, test_command_id)
    
    # 4. 验证结果
    assert result == {"status": "success"}
    mock_command_handler.execute.assert_called_once_with(test_msg_data, test_command_id)


@pytest.mark.asyncio
async def test_command_dispatcher_dispatch_uninitialized_commands(command_dispatcher):
    """测试命令未初始化时的分发逻辑"""
    # 1. 确保命令字典为空
    command_dispatcher.commands = {}
    
    # 2. 执行分发
    result = await command_dispatcher.dispatch(
        vps_management_pb2.CommandType.CREATE_RELAY,
        {},
        "cmd-789"
    )
    
    # 3. 验证结果
    assert result is None
    command_dispatcher.logger.warning.assert_called_once_with("命令尚未初始化 (Reporter missing)")


@pytest.mark.asyncio
async def test_command_dispatcher_dispatch_unknown_command(command_dispatcher_full):
    """测试分发未知命令类型时抛出异常"""
    # 1. 准备未知命令类型（使用不存在的枚举值）
    unknown_command_type = 9999  # 假设这是不存在的命令类型
    test_msg_data = {}
    test_command_id = "cmd-999"
    
    # 2. Mock CommandType.Name 方法
    with patch.object(vps_management_pb2.CommandType, 'Name', return_value="UNKNOWN_COMMAND"):
        # 3. 验证异常抛出
        with pytest.raises(Exception) as excinfo:
            await command_dispatcher_full.dispatch(unknown_command_type, test_msg_data, test_command_id)
        
        # 4. 验证异常信息
        assert "未知命令类型: UNKNOWN_COMMAND" in str(excinfo.value)



# ======================== 边界场景测试 ========================
@pytest.mark.asyncio
async def test_command_dispatcher_dispatch_with_invalid_params(command_dispatcher_full):
    """测试分发命令时传入无效参数的异常处理"""
    # 1. Mock 命令执行抛出异常
    test_command_type = vps_management_pb2.CommandType.SET_NODE_STATUS
    mock_handler = command_dispatcher_full.commands[test_command_type]
    mock_handler.execute = MagicMock(side_effect=Exception("Invalid node status"))
    
    # 2. 执行分发并验证异常传播
    with pytest.raises(Exception) as excinfo:
        await command_dispatcher_full.dispatch(
            test_command_type,
            {"status": "invalid"},
            "cmd-456"
        )
    
    assert "Invalid node status" in str(excinfo.value)
    mock_handler.execute.assert_called_once_with({"status": "invalid"}, "cmd-456")
