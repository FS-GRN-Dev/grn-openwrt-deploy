import pytest
import asyncio
import json
import time
from unittest.mock import MagicMock, AsyncMock, patch

from core.grpc_handler import GrpcHandler
from core.node_context import NodeContext
from config.config import GrpcConfig

from typing import Optional, List, Dict, Union, Callable, Any

from generated import vps_management_pb2, vps_management_pb2_grpc



# 基础测试夹具
@pytest.fixture
def node_context():
    """模拟 NodeContext 对象"""
    context = MagicMock(spec=NodeContext)
    context.node_code = "test-node-001"
    context.ip_address = "127.0.0.1"
    context.relays = {}
    context.node = MagicMock()
    context.node.to_proto = MagicMock(return_value=vps_management_pb2.Node(
        node_code="test-node-001",
        ip_address="127.0.0.1",
    ))
    return context


@pytest.fixture
def command_dispatcher():
    """模拟命令分发器"""
    dispatcher = AsyncMock()
    # 模拟正常分发返回的响应
    mock_response = vps_management_pb2.ClientMessage(
        node_code="test-node-001",
        ip_address="127.0.0.1",
        timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
        message_type="GENERAL_RESPONSE",
        success=True,
        message="处理成功",
        command_id="cmd-001"
    )
    dispatcher.dispatch = AsyncMock(return_value=mock_response)
    return dispatcher


@pytest.fixture
def grpc_handler(node_context, command_dispatcher):
    """创建 GrpcHandler 实例"""
    handler = GrpcHandler(
        server_addr="localhost:50051",
        context=node_context,
        command_dispatcher=command_dispatcher
    )

    return handler


# 测试用例
class TestGrpcHandler:
    @pytest.mark.asyncio
    async def test_grpc_handler_initialize(self, grpc_handler):
        """测试初始化 gRPC 通道和 stub"""
        # Mock aio.insecure_channel 和 stub
        with patch("core.grpc_handler.aio.insecure_channel") as mock_channel:
            mock_channel_instance = AsyncMock()
            mock_channel_instance.channel_ready = AsyncMock()
            mock_channel.return_value = mock_channel_instance
            
            mock_stub = MagicMock()
            with patch(
                "core.grpc_handler.vps_management_pb2_grpc.VpsManagementServiceStub",
                return_value=mock_stub,
            ) as mock_stub_cls:
                await grpc_handler.initialize()
                
                assert grpc_handler.channel == mock_channel_instance
                assert grpc_handler.stub == mock_stub
                mock_channel.assert_called_once()
                assert mock_channel.call_args.kwargs["target"] == "localhost:50051"
                mock_stub_cls.assert_called_once_with(mock_channel_instance)
                mock_channel_instance.channel_ready.assert_awaited()


    @pytest.mark.asyncio
    async def test_grpc_handler_close(self, grpc_handler):
        """测试关闭 gRPC 通道"""
        # 场景1：通道未初始化
        await grpc_handler.close()  # 不应报错
        
        # 场景2：通道已初始化
        mock_channel = AsyncMock()
        grpc_handler.channel = mock_channel
        await grpc_handler.close()
        mock_channel.close.assert_awaited_once()


    @pytest.mark.asyncio
    async def test_grpc_handler_register_node_success(self, grpc_handler):
        """测试节点注册失败重试场景"""

        mock_node_proto = vps_management_pb2.Node(
            node_code="test-node-001",
            ip_address="127.0.0.1"
        )
        grpc_handler.context.node.to_proto = MagicMock(return_value=mock_node_proto)

        mock_stub = AsyncMock()

        async def push_node_info_mock(*args, **kwargs):
            response = MagicMock()
            response.success = True
            response.message = "注册成功"
            return response

        mock_stub.PushNodeInfo = AsyncMock(side_effect=push_node_info_mock)
        grpc_handler.stub = mock_stub

        await grpc_handler.register_node()

        assert mock_stub.PushNodeInfo.await_count == 1


    @pytest.mark.asyncio
    async def test_grpc_handler_register_node_retry(self, grpc_handler):
        """测试节点注册成功场景"""
        mock_node_proto = vps_management_pb2.Node(
            node_code="test-node-001",
            ip_address="127.0.0.1"
        )
        # 让 context.node.to_proto() 返回合法实例
        grpc_handler.context.node.to_proto = MagicMock(return_value=mock_node_proto)

        # 2. 正确 Mock stub（用 AsyncMock 而非 MagicMock，适配异步调用）
        mock_stub = AsyncMock()

        # 3. 定义计数和返回逻辑（解决多次调用的分支问题）
        call_count = 0
        async def push_node_info_mock(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # 第一次调用抛异常
                raise Exception("连接失败")
            # 第二次调用返回带 success=True 的响应（用 MagicMock 而非 AsyncMock）
            response = MagicMock()
            response.success = True  # 显式设置，确保 break 循环
            response.message = "注册成功"
            return response

        # 给 PushNodeInfo 绑定异步 mock 函数
        mock_stub.PushNodeInfo = AsyncMock(side_effect=push_node_info_mock)
        grpc_handler.stub = mock_stub

        # 4. Mock asyncio.sleep 避免实际等待（否则超时前执行不完第二次调用）
        with patch("core.grpc_handler.asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            try:
                # 5. 超时控制（2秒足够完成两次调用）
                await asyncio.wait_for(grpc_handler.register_node(), timeout=2)
            except asyncio.TimeoutError:
                pass

            # 6. 断言
            assert mock_stub.PushNodeInfo.await_count == 2

            # 验证 sleep 被调用1次（失败后重试的等待）
            mock_sleep.assert_awaited_once_with(GrpcConfig.RETRY_INTERVAL)
            

    @pytest.mark.asyncio
    async def test_grpc_handler_process_command_success(self, grpc_handler, command_dispatcher):
        """测试处理命令成功场景"""
        # 构造测试命令
        test_command = MagicMock(
            command_type=vps_management_pb2.CommandType.CREATE_RELAY,
            command_id="cmd-001",
            message=json.dumps({"action": "test", "data": "123"})
        )

        await grpc_handler._process_command(test_command)

        command_dispatcher.dispatch.assert_awaited_once_with(
            vps_management_pb2.CommandType.CREATE_RELAY,
            {"action": "test", "data": "123"},
            "cmd-001"
        )
        response = grpc_handler.response_queue.get_nowait()
        assert isinstance(response, vps_management_pb2.ClientMessage)


    @pytest.mark.asyncio
    async def test_grpc_handler_process_command_json_error(self, grpc_handler):
        """测试命令消息JSON解析失败场景"""
        # 构造无效JSON的命令
        test_command = MagicMock(
            command_type=vps_management_pb2.CommandType.CREATE_RELAY,
            command_id="cmd-002",
            message="invalid json"
        )

        await grpc_handler._process_command(test_command)
        response = grpc_handler.response_queue.get_nowait()

        assert response.success is False
        assert "命令cmd-002-消息格式错误，无法解析JSON" in response.message
        assert response.command_id == "cmd-002"


    @pytest.mark.asyncio
    async def test_grpc_handler_process_command_general_error(self, grpc_handler, command_dispatcher):
        """测试命令处理过程中抛出通用异常场景"""
        # 模拟分发器抛出异常
        command_dispatcher.dispatch = AsyncMock(side_effect=Exception("业务处理失败"))
        
        # 构造有效JSON的命令
        test_command = MagicMock(
            command_type=vps_management_pb2.CommandType.CREATE_RELAY,
            command_id="cmd-003",
            message=json.dumps({"action": "test"})
        )

        await grpc_handler._process_command(test_command)
        response = grpc_handler.response_queue.get_nowait()

        assert response.success is False
        assert "命令cmd-003-处理失败: 业务处理失败" in response.message


    @pytest.mark.asyncio
    async def test_grpc_handler_create_error_response(self, grpc_handler):
        """测试创建错误响应方法"""
        # 执行方法
        response = grpc_handler._create_error_response("cmd-004", "测试错误")

        # 断言响应属性
        assert response.node_code == "test-node-001"
        assert response.ip_address == "127.0.0.1"
        assert response.success is False
        assert response.message == "命令cmd-004-测试错误"
        assert response.command_id == "cmd-004"
        assert response.message_type == "GENERAL_RESPONSE"