import pytest
import asyncio
from unittest.mock import MagicMock, AsyncMock, patch

from core.main import main

from typing import Optional, List, Dict, Union, Callable, Any

from generated import VPS_M_pb2




# ======================== 核心测试用例 ========================
def test_main_setup_logging_and_parse_args():
    """测试 main 函数的日志初始化和参数解析"""
    # 1. Mock 所有依赖
    with patch('utils.logger.setup_logging') as mock_setup_logging, \
         patch('core.main.parse_args') as mock_parse_args, \
         patch('core.main.VpsDispatcher'), \
         patch('core.main.ClientAccesser'), \
         patch('asyncio.run'), \
         patch('builtins.print') as mock_print:
        
        # 2. 配置 Mock
        mock_args = MagicMock()
        mock_args.role = None
        mock_parse_args.return_value = mock_args
        
        # 3. 执行 main 函数
        main()
        
        # 4. 验证日志初始化
        mock_setup_logging.assert_called_once_with("INFO")
        
        # 5. 验证参数解析
        mock_parse_args.assert_called_once()
        
        # 6. 验证 role 被覆盖为 "OpenWrt"
        assert mock_args.role == "OpenWrt"
        
        # 7. 验证 print 输出 role
        mock_print.assert_any_call("OpenWrt")


def test_main_vps_role_branch():
    """测试 main 函数中 role = VPS 分支逻辑"""
    
    # 1. 创建模拟的参数对象（包含所有必要属性）
    mock_args = MagicMock()
    mock_args.server_addr = "[::]:50051"
    mock_args.address = "192.168.1.100"
    mock_args.geo_location = "CN/Beijing"
    mock_args.cloud_provider = "aliyun"
    mock_args.mode = "production"
    mock_args.role = "VPS"  # 预先设置为 VPS


    # 2. Mock 依赖
    with patch('utils.logger.setup_logging'), \
         patch('core.main.parse_args', return_value=mock_args), \
         patch('core.main.ClientAccesser') as mock_client_accesser, \
         patch('core.main.VpsDispatcher') as mock_vps_dispatcher, \
         patch('asyncio.run'), \
         patch('builtins.print'):
        
        # 3. 强制设置 role 为 VPS（覆盖 main 函数的赋值）
        mock_args.role = "VPS"
        
        # 4. 执行 main 函数
        main()
        
        # 5. 验证 VpsDispatcher 被实例化
        mock_client_accesser.assert_called_once_with(
            "",  # 第一个空字符串参数
            server_addr=mock_args.server_addr,
            ip_addr=mock_args.address,
            geo_location=mock_args.geo_location,
            cloud_provider=mock_args.cloud_provider,
            run_mode=mock_args.mode
        )
        
        # 6. 验证 ClientAccesser 未被调用
        mock_vps_dispatcher.assert_not_called()
        
        # 7. 验证 asyncio.run
        asyncio.run.assert_called_once()


def test_main_keyboard_interrupt_handling():
    """测试 main 函数处理 KeyboardInterrupt 异常"""

    # 1. 创建模拟的参数对象（包含所有必要属性）
    mock_args = MagicMock()
    mock_args.server_addr = "[::]:50051"
    mock_args.address = "192.168.1.100"
    mock_args.geo_location = "CN/Beijing"
    mock_args.cloud_provider = "aliyun"
    mock_args.mode = "production"
    mock_args.role = "VPS"  # 预先设置为 VPS

    # 1. Mock 依赖
    with patch('utils.logger.setup_logging'), \
         patch('core.main.parse_args', return_value=mock_args), \
         patch('core.main.ClientAccesser') as mock_client_cls, \
         patch('asyncio.run') as mock_async_run, \
         patch('builtins.print') as mock_print:
        
        # 2. 模拟 asyncio.run 抛出 KeyboardInterrupt
        mock_async_run.side_effect = KeyboardInterrupt
        
        # 3. 执行 main 函数（不会崩溃）
        main()
        
        # 4. 验证异常被捕获，打印终止信息
        mock_print.assert_any_call("程序终止")
        
        # 5. 验证 ClientAccesser 仍被正常初始化
        mock_client_cls.assert_called()