from .base import StateObserver
import time

from generated import vps_management_pb2
from config.config import ObserverConfig

class DAInfoObserver(StateObserver):
    """Tor DA信息类"""
    
    async def update(self):
        """更新节点信息状态"""
        success = await self.reporter.report_da_info()
        self.logger.info(f"DA信息已更新: {success}")
        return success
    
    def get_interval(self) -> int:
        """获取节点信息观察间隔
        
        Returns:
            int: 返回观察间隔时间(秒)
        """
        return ObserverConfig.DA_INFO_INTERVAL
    
    def get_exception_interval(self) -> int:
        """获取异常情况下的观察间隔
        
        Returns:
            int: 返回异常情况下的观察间隔时间(秒)
        """
        return ObserverConfig.DA_INFO_EXCEPTION_INTERVAL
    
    def get_name(self) -> str:
        """获取节点信息观察者名称
        
        Returns:
            str: 返回观察者名称
        """
        return "DAInfo"