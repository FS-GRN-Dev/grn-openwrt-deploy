from abc import ABC, abstractmethod
import utils.logger


class StateObserver(ABC):
    """状态观察者(State Observer)基类"""

    def __init__(self, reporter):
        self.reporter = reporter
        self.logger = utils.logger.get_logger(self.get_name())

    @abstractmethod
    async def update(self) -> bool:
        """更新状态的抽象方法

        Returns:
            bool: 返回更新是否成功
        """
        pass

    @abstractmethod
    def get_interval(self) -> int:
        """获取观察间隔的抽象方法

        Returns:
            int: 返回观察间隔时间(秒)
        """
        pass

    @abstractmethod
    def get_exception_interval(self) -> int:
        """获取异常情况下的观察间隔的抽象方法

        Returns:
            int: 返回异常情况下的观察间隔时间(秒)
        """
        pass

    @abstractmethod
    def get_name(self) -> str:
        """获取观察者名称的抽象方法

        Returns:
            str: 返回观察者名称
        """
        pass
