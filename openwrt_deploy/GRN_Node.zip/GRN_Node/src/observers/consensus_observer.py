from .base import StateObserver

from generated import vps_management_pb2
from config.config import ObserverConfig

class ConcensusObserver(StateObserver):
    """
    共识监听观察者
    负责监听本地已启动的Relay是否已同步到Tor网络共识中。
    一旦检测到节点进入共识，将其状态从 CREATING 更新为 RUNNING 并上报。
    """
    def __init__(self, reporter, context):
        super().__init__(reporter)
        self.context = context
    
    def get_interval(self) -> int:
        """获取节点信息观察间隔
        
        Returns:
            int: 返回观察间隔时间(秒)
        """
        return ObserverConfig.CONSENSUS_INFO_INTERVAL
    
    def get_exception_interval(self) -> int:
        """获取异常情况下的观察间隔
        
        Returns:
            int: 返回异常情况下的观察间隔时间(秒)
        """
        return ObserverConfig.CONSENSUS_INFO_EXCEPTION_INTERVAL
    
    def get_name(self) -> str:
        """获取节点信息观察者名称
        
        Returns:
            str: 返回观察者名称
        """
        return "ConcensusObserver"
    
    async def update(self) -> bool:
        """更新节点状态信息
        
        Returns:
            bool: 返回更新是否成功
        """
        if not self.context.relays:
            return True
        
        updated_relays = []
        
        for relay_code, relay in self.context.relays.items():
            if not relay.fingerprint:
                continue

            # 只有在 Tor 已完成本地启动/引导后才检查是否进入共识
            if relay.status not in (
                vps_management_pb2.RelayStatus.RELAY_BOOTSTRAPPED,
                vps_management_pb2.RelayStatus.RELAY_CREATING,
            ):
                continue
            
            stem2tor = self.context.stem2tor_instances.get(relay_code)
            if not stem2tor:
                continue
            
            try:
                ns = await stem2tor.get_network_statuses(relay.fingerprint)
                
                if ns:
                    flags = ns.get('flags', [])
                    is_running = 'Running' in flags
                    is_valid = 'Valid' in flags
                    
                    if is_running and is_valid:
                        self.logger.info(f"🎉 节点 {relay.nickname} ({relay.fingerprint}) 已进入共识网络！")
                        relay.status = vps_management_pb2.RelayStatus.RELAY_RUNNING
                        updated_relays.append(relay)
                    else:
                        self.logger.info(f"节点 {relay.nickname} 在共识中，但 Flags 不足: {flags}")
                else:
                    self.logger.info(f"节点 {relay.nickname} ({relay.fingerprint}) 尚未出现在共识中")
            except Exception as e:
                self.logger.error(
                    f"查询共识状态失败: relay_code={relay_code}, fingerprint={relay.fingerprint}, err={e}",
                    exc_info=True,
                )
            
        if updated_relays:
            self.logger.info(f"检测到 {len(updated_relays)} 个节点状态变更为 RUNNING，正在上报...")
            success = await self.reporter.push_relays(updated_relays)
            return success
        
        return True