from .base import StateObserver
from typing import List
import asyncio

class StateSubject:
    """状态主题类"""
    
    def __init__(self):
        self.observers: List[StateObserver] = []
    
    def attach(self, observer: StateObserver):
        """附加观察者
        
        Args:
            observer (StateObserver): 观察者实例
        """
        self.observers.append(observer)
        
    def detach(self, observer: StateObserver):
        """分离观察者
        
        Args:
            observer (StateObserver): 观察者实例
        """
        self.observers.remove(observer)
        
    async def start_all(self):
        """启动所有观察者的更新任务"""
        tasks = [self._run_observer(observer) for observer in self.observers]
        await asyncio.gather(*tasks)
    
    async def _run_observer(self, observer: StateObserver):
        """运行单个观察者的更新方法
        
        Args:
            observer (StateObserver): 观察者实例
        """
        while True:
            try:
                success = await observer.update()
                if success:
                    await asyncio.sleep(observer.get_interval())
                else:
                    observer.logger.warning(f"观察者{observer.get_name()}推送超时，重试中...")
                    await asyncio.sleep(observer.get_exception_interval())
            except Exception as e:
                observer.logger.error(f"观察者 {observer.get_name()} 更新失败: {e}")
                await asyncio.sleep(observer.get_exception_interval())