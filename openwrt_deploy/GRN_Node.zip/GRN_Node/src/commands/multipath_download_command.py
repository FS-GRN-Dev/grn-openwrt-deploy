import asyncio
import json
import os
from typing import Any, Optional

from generated import VPS_M_pb2
from .command import Command
from services.multipath_download_service import MultipathDownloader


class MultipathDownloadCommand(Command):
    """多路径下载命令（PoC）：HTTP Range 分片并行下载 + 合并。

    绑定机制：每个分片请求通过 SOCKS5 代理认证，将 username=link_id，
    由 CircuitManager 基于 socks_username 把流 attach 到对应 circuit。

    期望 message (json) 示例：
    {
      "client_relay_code": "relay-...",
      "url": "http://<apache>/big.bin",
      "output_path": "/tmp/big.bin",
      "parts": 4,

      // 二选一：
      // 1) paths：每个分片一条电路路径（推荐）
      "paths": [ ["$fp1","$fp2","$fp3"], ["$..."], ["$..."], ["$..."] ],
      // 2) relay_fingerprints：单一路径，自动复制为 parts 条电路
      "relay_fingerprints": ["$fp1","$fp2","$fp3"],

      // 可选：如果你提前创建好了 circuits/links，也可以直接给 link_ids
      "link_ids": ["link-...", "link-...", "link-...", "link-..."],

      "timeout_sec": 300,
      "connect_timeout_sec": 15,
      "max_parallel": 4,
      "cleanup": true
    }
    """

    def get_command_type(self) -> VPS_M_pb2.CommandType:
        return VPS_M_pb2.CommandType.MULTIPATH_DOWNLOAD

    async def execute(self, msg_data: dict[str, Any], command_id: str) -> VPS_M_pb2.ClientMessage:
        url = msg_data.get("url")
        output_path = msg_data.get("output_path")
        parts = int(msg_data.get("parts", 0) or 0)
        client_relay_code = msg_data.get("client_relay_code")

        if not url:
            return self._create_response(command_id, False, "缺少 url 参数")
        if not output_path:
            return self._create_response(command_id, False, "缺少 output_path 参数")
        if parts <= 0:
            return self._create_response(command_id, False, "parts 必须 >= 1")
        if not client_relay_code:
            return self._create_response(command_id, False, "缺少 client_relay_code 参数")

        cleanup = bool(msg_data.get("cleanup", True))
        timeout_sec = int(msg_data.get("timeout_sec", 300))
        connect_timeout_sec = int(msg_data.get("connect_timeout_sec", 15))
        max_parallel = msg_data.get("max_parallel")
        max_parallel = int(max_parallel) if max_parallel is not None else None

        # SOCKS endpoint：默认用本机映射端口（容器 bridge/host 都适用）
        stem2tor = self.context.stem2tor_instances.get(client_relay_code)
        if not stem2tor:
            return self._create_response(command_id, False, f"Client Relay {client_relay_code} 不存在")
        proxy_host = "127.0.0.1"
        proxy_port = int(getattr(stem2tor, "socks_port", 9050) or 9050)

        # 1) 准备 link_ids / circuits
        link_ids: list[str] = list(msg_data.get("link_ids") or [])
        created_circuits: list[dict] = []  # {circuit_id, link_id}

        # 需要创建 circuits 的情况
        if not link_ids:
            paths = msg_data.get("paths")
            relay_fingerprints = msg_data.get("relay_fingerprints")

            if paths is None and relay_fingerprints is None:
                return self._create_response(
                    command_id,
                    False,
                    "缺少 paths 或 relay_fingerprints（或直接提供 link_ids）",
                )

            if paths is None:
                if not isinstance(relay_fingerprints, list) or not relay_fingerprints:
                    return self._create_response(command_id, False, "relay_fingerprints 必须为非空列表")
                paths = [list(relay_fingerprints) for _ in range(parts)]

            if not isinstance(paths, list) or len(paths) != parts:
                return self._create_response(command_id, False, f"paths 必须是长度为 parts({parts}) 的列表")

            for i in range(parts):
                path = paths[i]
                if not isinstance(path, list) or not path:
                    return self._create_response(command_id, False, f"paths[{i}] 必须为非空列表")

                circuit, assigned_link_id = await self.service.create_circuit_with_link(
                    relay_fingerprints=path,
                    client_relay_code=client_relay_code,
                    link_id=None,
                    set_as_default=False,
                )
                if not circuit or not assigned_link_id:
                    return self._create_response(command_id, False, f"创建电路失败 (part={i})")

                link_ids.append(assigned_link_id)
                created_circuits.append({"circuit_id": circuit.circuit_id, "link_id": assigned_link_id})

        if len(link_ids) < parts:
            return self._create_response(command_id, False, f"link_ids 数量不足：需要 {parts}，实际 {len(link_ids)}")

        # 2) 执行多路径下载
        downloader = MultipathDownloader(
            proxy_host=proxy_host,
            proxy_port=proxy_port,
            connect_timeout_sec=connect_timeout_sec,
            timeout_sec=timeout_sec,
            max_parallel=max_parallel,
        )

        # 输出目录不存在时自动创建
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

        # pycurl 是阻塞 IO：必须放到线程里执行，避免卡住 asyncio 事件循环。
        # 否则 CircuitManager 的 STREAM attach 处理会被延迟到 CONNECTTIMEOUT 之后，导致必现 "Unknown stream"。
        result = await asyncio.to_thread(
            downloader.download,
            url=url,
            output_path=output_path,
            parts=parts,
            link_ids=link_ids[:parts],
        )

        # 3) 可选清理 circuits（仅清理由本次命令创建的）
        if cleanup and created_circuits:
            for c in created_circuits:
                try:
                    await self.service.delete_circuit(c["circuit_id"], client_relay_code)
                except Exception:
                    pass

        payload = {
            "proxy": {"host": proxy_host, "port": proxy_port},
            "created_circuits": created_circuits,
            "result": result.to_dict(),
        }

        return self._create_response(command_id, bool(result.success), json.dumps(payload, ensure_ascii=False))
