from .command import Command
from typing import Any

from generated import vps_management_pb2


class InformDAInfoCommand(Command):
    """通知DA信息命令"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        """返回命令类型"""
        return vps_management_pb2.CommandType.INFORM_DA_INFO

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """处理管理面下发的DA信息通知命令。

        Args:
            msg_data (dict): 命令消息内容。
            command_id (str, optional): 命令ID。

        Returns:
            vps_management_pb2.ClientMessage: 处理DA信息结果响应。
        """
        if "da_info" in msg_data:
            da_info = msg_data.get("da_info")
            try:
                success = await self.service.update_da_info(da_info)
                if success:
                    self.logger.info(f"  收到并更新DA信息: {da_info}")
                    return self._create_response(
                        command_id=command_id, success=True, message=f"DA信息处理成功"
                    )
                else:
                    self.logger.error(f"  更新DA信息失败: {da_info}")
                    return self._create_response(
                        command_id=command_id, success=False, message=f"DA信息更新失败"
                    )
            except Exception as e:
                self.logger.error(f"  处理DA信息时发生异常: {e}")
                return self._create_response(
                    command_id=command_id,
                    success=False,
                    message=f"处理DA信息时发生异常: {e}",
                )
        else:
            self.logger.error("  消息中缺少'da_info'字段")
            return self._create_response(
                command_id=command_id, success=False, message="消息中缺少'da_info'字段"
            )
        #     da_info = msg_data['da_info']
        #     self.logger.info(f"  收到DA信息: {da_info}")

        #     # TODO: 更新DA信息到torrc
        #     self.node_client.dir_auth = da_info

        # return self._create_response(
        #     command_id=command_id,
        #     success=True,
        #     message=f"DA信息处理成功"
        # )
