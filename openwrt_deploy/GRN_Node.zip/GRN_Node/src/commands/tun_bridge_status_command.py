import json
import inspect
from typing import Any

from generated import VPS_M_pb2
from .command import Command


class TunBridgeStatusCommand(Command):
    def get_command_type(self) -> VPS_M_pb2.CommandType:
        return VPS_M_pb2.CommandType.TUN_BRIDGE_STATUS

    async def execute(self, msg_data: dict[str, Any], command_id: str) -> VPS_M_pb2.ClientMessage:
        try:
            bridges = self.service.status()
            if inspect.isawaitable(bridges):
                bridges = await bridges
            return self._create_response(command_id, True, json.dumps({"bridges": bridges}, ensure_ascii=False))
        except Exception as e:
            return self._create_response(command_id, False, f"获取状态失败: {e}")
