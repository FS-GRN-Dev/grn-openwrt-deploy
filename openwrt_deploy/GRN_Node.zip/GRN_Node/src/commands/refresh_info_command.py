from .command import Command
from typing import Any

from generated import vps_management_pb2


class RefreshInfoCommand(Command):
    """刷新信息命令"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        """返回命令类型"""
        return vps_management_pb2.CommandType.REFRESH_INFO

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """处理刷新节点信息命令，推送最新节点信息。

        Args:
            msg_data (dict): 命令消息内容。
            command_id (str, optional): 命令ID。

        Returns:
            vps_management_pb2.ClientMessage: 刷新节点信息结果响应。
        """
        self.logger.info("  刷新节点信息")

        try:
            success = await self.service.refresh_info()
            if success:
                return self._create_response(
                    command_id=command_id, success=True, message="节点信息刷新成功"
                )
            else:
                return self._create_response(
                    command_id=command_id, success=False, message="节点信息刷新失败"
                )
        except Exception as e:
            self.logger.error(f"  刷新节点信息异常: {e}")
            return self._create_response(
                command_id=command_id, success=False, message=f"节点信息刷新异常: {e}"
            )
        # # 推送节点信息
        # # TODO: 这个_push_node_info方法可能会替换为更合理的设计模式
        # # 暂时先用现有方法占位
        # result = await self.node_client.reporter.report_node_info()
        # self.logger.info(f"  刷新节点信息结果：{result}")
        # if not result:
        #     return self._create_response(
        #         command_id=command_id,
        #         success=False,
        #         message=f"节点信息刷新失败: {result}"
        #     )

        # # 推送Relay信息
        # result = await self.node_client.reporter.report_relay_info()
        # self.logger.info(f"  刷新Relay信息结果：{result}")
        # if not result:
        #     return self._create_response(
        #         command_id=command_id,
        #         success=False,
        #         message=f"Relay信息刷新失败: {result}"
        #     )

        # # 推送态势感知信息
        # result = await self.node_client.reporter.report_situation_awareness()
        # self.logger.info(f"  刷新态势感知信息结果：{result}")
        # if not result:
        #     return self._create_response(
        #         command_id=command_id,
        #         success=False,
        #         message=f"态势感知信息刷新失败: {result}"
        #     )

        # # 推送DA信息
        # result = await self.node_client.reporter.report_da_info()
        # self.logger.info(f"  刷新DA信息结果：{result}")
        # if not result:
        #     return self._create_response(
        #         command_id=command_id,
        #         success=False,
        #         message=f"DA信息刷新失败: {result}"
        #     )

        # return self._create_response(
        #     command_id=command_id,
        #     success=True,
        #     message=f"节点信息刷新成功"
        # )
