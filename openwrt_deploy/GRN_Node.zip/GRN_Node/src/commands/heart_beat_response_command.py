from .command import Command
from typing import Any

from generated import vps_management_pb2


class HeartBeatResponseCommand(Command):
    """心跳响应"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        """返回命令类型"""
        return vps_management_pb2.CommandType.HEART_BEAT_RESPONSE

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """处理刷新节点信息命令，推送最新节点信息。

        Args:
            msg_data (dict): 命令消息内容。
            command_id (str, optional): 命令ID。

        Returns:
            vps_management_pb2.ClientMessage: 刷新节点信息结果响应。
        """
        self.logger.info("收到心跳响应")
