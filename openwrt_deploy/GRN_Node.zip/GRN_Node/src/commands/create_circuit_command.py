from .command import Command
from typing import Any
import time
import json
from models.circuit import Circuit
from config.config import LinkType
from utils.command_payloads import normalize_create_circuit_payload

from generated import vps_management_pb2


class CreateCircuitCommand(Command):
    """创建电路命令"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        """返回命令类型"""
        return vps_management_pb2.CommandType.CREATE_CIRCUIT

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """处理创建电路命令，返回电路创建结果。

        Args:
            msg_data (dict): 命令消息内容。
            command_id (str, optional): 命令ID。

        Returns:
            vps_management_pb2.ClientMessage: 创建电路结果响应。
        """
        normalized_payload = normalize_create_circuit_payload(msg_data)
        path_type = normalized_payload.get("path_type")
        link_list = normalized_payload.get("link_list")

        if path_type and int(path_type) == LinkType.MULTI_LINK:
            return await self._execute_unified(msg_data, command_id, int(path_type), link_list)

        client_relay_code = msg_data.get("client_relay_code")
        relay_fingerprints = msg_data.get("relay_fingerprints", [])
        server_link_id = msg_data.get("link_id")  # 使用服务端的link_id，node_client.py不自己生成
        path_type = msg_data.get("path_type", LinkType.SINGLE_LINK)
        set_as_default = msg_data.get("set_as_default", False)  # 是否设为默认

        return_data = {
            "command_id": command_id,
            "link_id": server_link_id,
            "path_type": path_type,
            "circuit_code": 0  # 实际创建后会填充
        }  # 确保返回 link_id 给管理面，以便后续关联使用

        if not client_relay_code:
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message="缺少 client_relay_code 参数",
                data=json.dumps(return_data),
            )

        if not relay_fingerprints:
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message="缺少 relay_fingerprints 参数",
                data=json.dumps(return_data),
            )

        if not server_link_id:
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message="缺少 link_id 参数",
                data=json.dumps(return_data),
            )

        try:
            circuit, assigned_link_id = await self.service.create_circuit_with_link(
                relay_fingerprints=relay_fingerprints,
                client_relay_code=str(client_relay_code),
                link_id=str(server_link_id),
                set_as_default=set_as_default,
            )

            if circuit:
                self.logger.info(
                    f"电路 {circuit.circuit_id} 创建成功，关联链路: {assigned_link_id}"
                )

                response_data = circuit.to_json_response()
                response_data["link_id"] = assigned_link_id  # 确保返回 link_id

                return_data["circuit_info"] = response_data
                return_data["circuit_code"] = int(circuit.circuit_id) # 实际创建的电路ID

                return self._create_response_data(
                    command_id=command_id,
                    success=True,
                    message=f"创建单条链路 {assigned_link_id}----电路 {circuit.circuit_id}, 创建成功",
                    data=json.dumps(return_data),
                )
            else:
                return self._create_response_data(
                    command_id=command_id,
                    success=False,
                    message="创建电路失败",
                    data=json.dumps(return_data),
                )
        except Exception as e:
            self.logger.error(f"创建电路时发生异常: {e}")
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=f"创建电路时发生异常: {e}",
                data=json.dumps(return_data),
            )

    async def _execute_unified(
        self,
        msg_data: dict[str, Any],
        command_id: str,
        path_type: int,
        link_list: list[dict],
    ) -> vps_management_pb2.ClientMessage:
        normalized_payload = normalize_create_circuit_payload(msg_data)
        parent_link_id = normalized_payload.get("link_id", "")
        client_relay_code = normalized_payload.get("client_relay_code", "")
        link_list = normalized_payload.get("link_list", link_list)
        path_type = normalized_payload.get("path_type", path_type)

        exception_return_data = {
            "link_id": parent_link_id,
            "path_type": 2,
            "client_relay_code": client_relay_code,
            "sub_link_ids": [],
            "results": []
        }

        if not client_relay_code:
            return self._create_response_data(command_id=command_id, success=False, message="缺少 client_relay_code 参数", data=json.dumps(exception_return_data))

        if not link_list:
            return self._create_response_data(command_id=command_id, success=False, message="link_list 不能为空", data=json.dumps(exception_return_data))

        try:
            result = await self.service.create_link(
                parent_link_id=str(parent_link_id),
                client_relay_code=str(client_relay_code),
                path_type=path_type,
                link_list=link_list,
            )
            any_success = any(item.get("success") for item in result.get("results", []))

            self.logger.info(
                f"统一链路创建完成: parent_link_id={parent_link_id}, path_type={path_type}, "
                f"子链路数={len(link_list)}, 成功={sum(1 for item in result['results'] if item['success'])}"
            )

            return self._create_response_data(
                command_id=command_id,
                success=any_success,
                message=f"创建统一多链路电路 {parent_link_id}, 创建成功",
                data=json.dumps(result, ensure_ascii=False, default=str),
            )
        except Exception as e:
            self.logger.error(f"统一链路创建异常: {e}")
            return self._create_response_data(command_id=command_id, success=False, message=f"统一多链路电路 {parent_link_id} 创建异常: {e}", data=json.dumps(exception_return_data))