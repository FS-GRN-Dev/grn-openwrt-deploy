from .command import Command
from typing import Any, cast
import json
from generated import vps_management_pb2


class DestroyNodeCommand(Command):
    """销毁节点命令"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        """返回命令类型"""
        return cast(
            vps_management_pb2.CommandType, vps_management_pb2.CommandType.DESTROY_NODE
        )

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """处理销毁节点命令，销毁所有Relay并推送自毁信息。

        Args:
            msg_data (dict): 命令消息内容。
            command_id (str, optional): 命令ID。

        Returns:
            vps_management_pb2.ClientMessage: 销毁节点命令处理结果响应。
        """

        target_node_code = msg_data.get("node_code")
        self.logger.info(
            f"执行销毁Node命令， 当前节点ID：{self.context.node_code}, 目标节点code：{target_node_code}"
        )
        response_data = {"node_code": target_node_code}
        if self.context.node_code == target_node_code:
            self.logger.info("  准备销毁当前节点...")

            try:
                success = await self.service.destroy_node()
                if success:
                    self.logger.info("  销毁节点，销毁成功")
                    return self._create_response_data(
                        command_id=command_id,
                        success=True,
                        message="销毁节点，销毁成功",
                        data=json.dumps(response_data),
                    )
                else:
                    self.logger.error("  节点销毁失败")
                    return self._create_response_data(
                        command_id=command_id,
                        success=False,
                        message="节点销毁失败",
                        data=json.dumps(response_data),
                    )
            except Exception as e:
                self.logger.error(f"  节点销毁过程中出现错误: {e}")
                return self._create_response_data(
                    command_id=command_id,
                    success=False,
                    message=f"节点销毁过程中出现错误: {e}",
                    data=json.dumps(response_data),
                )
        else:
            self.logger.warning(f"  销毁目标节点ID不存在 {target_node_code}")
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message="销毁目标节点ID不存在",
                data=json.dumps(response_data),
            )
            # # 更新节点状态
            # self.node_client.node.status = vps_management_pb2.NodeStatus.NODE_DESTROYING

            # # 异步发送最后的状态更新
            # try:
            #     response = await self.node_client.stub.PushNodeInfo(vps_management_pb2.PushNodeInfoRequest(node=self.node_client.node))
            #     self.logger.info(f"  节点销毁状态更新结果：{response.message}")
            # except Exception as e:
            #     self.logger.error(f"  推送节点销毁状态失败: {e}")
            #     return self._create_response(
            #         command_id=command_id,
            #         success=False,
            #         message=f"推送节点销毁状态失败: {e}"
            #     )

            # # 发送自毁信息
            # self_destruction_info = vps_management_pb2.SelfDestructionInfo(
            #     node_id=self.node_client.node_id,
            #     ip_address=self.node_client.ip_address
            # )

            # try:
            #     await self.node_client.stub.PushSelfDestructionInfo(
            #         vps_management_pb2.PushSelfDestructionInfoRequest(
            #             self_destruction_info=self_destruction_info
            #         )
            #     )
            #     self.logger.info("  自毁信息已发送")

            #     # 创建一个任务来延迟退出，确保响应能够发送出去
            #     asyncio.create_task(self._delayed_exit())
            #     self.logger.info("  节点即将退出...")
            #     return self._create_response(
            #         command_id=command_id,
            #         success=True,
            #         message=f"节点销毁命令已执行"
            #     )

            # except Exception as e:
            #     self.logger.error(f"  发送自毁信息失败: {e}")
            #     return self._create_response(
            #         command_id=command_id,
            #         success=False,
            #         message=f"发送自毁信息失败: {e}"
            #     )
