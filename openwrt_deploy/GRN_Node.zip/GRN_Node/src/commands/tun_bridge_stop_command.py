import json
from typing import Any

from generated import VPS_M_pb2
from .command import Command


class TunBridgeStopCommand(Command):
    def get_command_type(self) -> VPS_M_pb2.CommandType:
        return VPS_M_pb2.CommandType.TUN_BRIDGE_STOP

    async def execute(self, msg_data: dict[str, Any], command_id: str) -> VPS_M_pb2.ClientMessage:
        bridge_code = str(msg_data.get("bridge_code") or "")
        if not bridge_code:
            return self._create_response(command_id, False, "缺少 bridge_code")

        try:
            bridge = await self.service.get_bridge_info(bridge_code)
            ok = await self.service.stop(bridge_code)
            if not ok:
                return self._create_response(command_id, False, f"bridge_code 不存在: {bridge_code}")
            return self._create_response(
                command_id,
                True,
                json.dumps({"bridge_code": bridge_code, "stopped": True, "bridge": bridge}, ensure_ascii=False),
            )
        except Exception as e:
            return self._create_response(command_id, False, f"停止失败: {e}")
