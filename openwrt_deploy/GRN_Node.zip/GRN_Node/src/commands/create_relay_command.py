from .command import Command
from typing import Any, cast
import json

from generated import vps_management_pb2
from utils.command_payloads import normalize_create_relay_payload


class CreateRelayCommand(Command):
    """创建Relay命令"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        """返回命令类型"""
        return cast(
            vps_management_pb2.CommandType, vps_management_pb2.CommandType.CREATE_RELAY
        )

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """执行创建Relay命令

        Args:
            msg_data (dict): 命令消息内容
            command_id (str): 命令ID

        Returns:
            vps_management_pb2.ClientMessage: 创建Relay命令处理结果响应
        """
        self.logger.info("执行创建Relay操作")

        normalized_payload = normalize_create_relay_payload(msg_data)

        # 生成唯一的Relay ID
        relay_type = normalized_payload.get("relay_type", vps_management_pb2.RelayType.RELAY_ANONYMOUS)
        relay_role = normalized_payload.get("relay_role", vps_management_pb2.RelayRole.ROLE_RELAY)
        auto_start_server_bridge = normalized_payload.get("auto_start_server_bridge")
        server_bridge = normalized_payload.get("server_bridge") or {}
        server_relay_id = normalized_payload.get("relay_id", 0)
        dir_auths = normalized_payload.get("dir_auths") or []

        return_data = {
            "relay_id": server_relay_id,
            "relay_code": "",  # 实际创建后会填充
        }
        try:
            result = await self.service.create_relay(
                server_relay_id,
                relay_type,
                relay_role,
                auto_start_server_bridge=auto_start_server_bridge,
                server_bridge_config=server_bridge,
                dir_auths=dir_auths,)
            
            relay_code = result.get("relay_code", "")
            return_data["relay_code"] = relay_code
            return_data["server_bridge_code"] = result.get("server_bridge_code", "")
            return_data["relay_info"] = result

            return self._create_response_data(
                command_id=command_id,
                success=True,
                message=f"创建中继: {relay_code}, 创建成功",
                data=json.dumps(return_data),
            )
        except ValueError as e:
            self.logger.error(f"  参数错误: {e}")
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=f"参数错误: {e}",
                data=json.dumps(return_data),
            )
        except RuntimeError as e:
            self.logger.error(f"  运行时错误: {e}")
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=f"创建失败: {e}",
                data=json.dumps(return_data),
            )
        except Exception as e:
            self.logger.error(f"  未知错误: {e}")
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=f"未知错误: {e}",
                data=json.dumps(return_data),
            )