from abc import ABC, abstractmethod
from typing import Any
from generated import vps_management_pb2
import time
import utils.logger


class Command(ABC):
    """命令(Command)基类"""

    def __init__(self, context, reporter, service):
        """初始化命令类
        Args:
            context (NodeContext): NodeContext实例，只提供数据访问能力
            reporter (StateReporter): StateReporter实例，用于上报节点状态
        """
        self.context = context
        self.reporter = reporter
        self.service = service
        self.logger = utils.logger.get_logger(f"{self.__class__.__name__}")

    @abstractmethod
    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """执行命令的抽象方法

        Args:
            msg_data(dict): 消息数据
            command_id(str, optional): 命令ID

        Returns:
            vps_management_pb2.ClientMessage: 返回客户端消息
        """
        pass

    @abstractmethod
    def get_command_type(self) -> vps_management_pb2.CommandType:
        """获取命令类型的抽象方法

        Returns:
            vps_management_pb2.CommandType: 返回命令类型
        """
        pass

    def _create_response(
        self,
        command_id: str,
        success: bool,
        message: str,
    ) -> vps_management_pb2.ClientMessage:
        """创建响应消息

        Args:
            command_id(str): 命令ID
            success(bool): 是否成功
            message(str): 响应消息内容

        Returns:
            vps_management_pb2.ClientMessage: 返回客户端消息
        """
        return vps_management_pb2.ClientMessage(
            node_code=self.context.node_code,
            relay_codes=[relay.relay_code for relay in self.context.relays.values()],
            ip_address=self.context.ip_address,
            timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
            message_type=f"{self.__class__.__name__.upper()}_RESPONSE",
            command_id=command_id,
            success=success,
            message=f"命令{command_id}-{message}",
            type=vps_management_pb2.ClientMessageType.COMMAND_RESPONSE,
            data="",
        )

    def _create_response_data(
        self,
        command_id: str,
        success: bool,
        message: str,
        data: str,
    ) -> vps_management_pb2.ClientMessage:
        """创建响应消息

        Args:
            command_id(str): 命令ID
            success(bool): 是否成功
            message(str): 响应消息内容

        Returns:
            vps_management_pb2.ClientMessage: 返回客户端消息
        """
        return vps_management_pb2.ClientMessage(
            node_code=self.context.node_code,
            relay_codes=[relay.relay_code for relay in self.context.relays.values()],
            ip_address=self.context.ip_address,
            timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
            message_type=f"{self.__class__.__name__.upper()}_RESPONSE",
            command_id=command_id,
            success=success,
            message=f"命令{command_id}-{message}",
            type=vps_management_pb2.ClientMessageType.COMMAND_RESPONSE,
            data=data,
        )
