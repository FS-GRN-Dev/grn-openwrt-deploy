from .command import Command
from typing import Any, Optional
import json

from generated import vps_management_pb2
from utils.command_payloads import normalize_switch_link_payload


class SwitchLinkCommand(Command):
    """启用/停用链路命令（SWITCH_LINK）。

    管理面只根据回执中的 enabled_link_ids 同步启用集合（集合内=启用，其余=未启用），
    不区分启用失败/停用失败；回滚由数据面落地后，本命令务必回带真实启用集合。
    """

    def get_command_type(self) -> vps_management_pb2.CommandType:
        return vps_management_pb2.CommandType.SWITCH_LINK

    def _response_payload(
        self,
        *,
        action: str,
        link_id: Any,
        switch_type: Any,
        client_relay_code: str,
        enabled_link_ids: Optional[list] = None,
        switch_result: Optional[dict] = None,
    ) -> dict[str, Any]:
        if enabled_link_ids is None:
            enabled_link_ids = self.service.snapshot_enabled_link_ids(client_relay_code)
        return {
            "action": action or "enable",
            "link_id": self._link_id_for_response(link_id),
            "switch_type": switch_type,
            "enabled_link_ids": enabled_link_ids,
            "switch_result": switch_result or {},
        }

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        normalized = normalize_switch_link_payload(msg_data)
        action = normalized.get("action") or ""
        link_id = normalized.get("link_id") or ""
        client_relay_code = normalized.get("client_relay_code") or ""
        switch_type = normalized.get("switch_type")
        bridge_info = normalized.get("bridge_info") or {}

        def _early_fail(message: str) -> vps_management_pb2.ClientMessage:
            # 参数错误也回带当前启用集合，避免管理面被空数组误清成全未启用
            payload = self._response_payload(
                action=action,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=str(client_relay_code),
            )
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=message,
                data=json.dumps(payload, ensure_ascii=False),
            )

        if not action:
            return _early_fail("缺少必要参数: action")
        if not link_id or not client_relay_code:
            return _early_fail("缺少必要参数: link_id 和 client_relay_code")
        if action == "enable" and switch_type is None:
            return _early_fail("enable 缺少必要参数: switch_type")

        try:
            result = await self.service.apply_link_enable_action(
                action=action,
                link_id=str(link_id),
                client_relay_code=str(client_relay_code),
                switch_type=switch_type,
                bridge_info=bridge_info,
            )
            # success=意图是否达成；rolled_back=是否补偿；enabled_link_ids=最终启用集合
            success = bool(result.get("success"))
            rolled_back = bool((result.get("switch_result") or {}).get("rolled_back"))
            message = result.get("message") or (
                "启用/停用链路成功" if success else "启用/停用链路失败"
            )
            response_data = self._response_payload(
                action=result.get("action", action),
                link_id=result.get("link_id", link_id),
                switch_type=result.get("switch_type", switch_type),
                client_relay_code=str(client_relay_code),
                enabled_link_ids=result.get("enabled_link_ids"),
                switch_result=result.get("switch_result") or {},
            )
            self.logger.info(
                f"链路 {link_id} {action} 完成 | success={success} | "
                f"rolled_back={rolled_back} | switch_type={switch_type} | "
                f"enabled={response_data['enabled_link_ids']}"
            )
            return self._create_response_data(
                command_id=command_id,
                success=success,
                message=message,
                data=json.dumps(response_data, ensure_ascii=False),
            )
        except Exception as e:
            self.logger.error(f"启用/停用链路异常: {e}")
            payload = self._response_payload(
                action=action,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=str(client_relay_code),
            )
            # 按错误处理，但仍回带当前启用集合，供管理面收敛状态
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=f"启用/停用链路异常: {e}",
                data=json.dumps(payload, ensure_ascii=False),
            )

    @staticmethod
    def _link_id_for_response(link_id: str) -> Any:
        try:
            return int(link_id)
        except (TypeError, ValueError):
            return link_id or "0"
