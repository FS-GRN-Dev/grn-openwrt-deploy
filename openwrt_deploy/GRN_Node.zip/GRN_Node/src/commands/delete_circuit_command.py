from .command import Command
from typing import Any
import time
import json

from generated import vps_management_pb2
from config.config import LinkType


class DeleteCircuitCommand(Command):
    """删除电路命令"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        """返回命令类型"""
        return vps_management_pb2.CommandType.DELETE_CIRCUIT

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """处理销毁电路命令，返回销毁结果。

        Args:
            msg_data (dict): 命令消息内容。
            command_id (str, optional): 命令ID。

        Returns:
            vps_management_pb2.ClientMessage: 电路销毁结果响应。
        """
        if "client_relay_code" not in msg_data or "path_type" not in msg_data or "link_id" not in msg_data:
            return self._create_response(
                command_id=command_id,
                success=False,
                message="缺少必要参数: client_relay_code 或 path_type(路径类型) 或者 link_id(链路ID)",
            )

        client_relay_code = msg_data["client_relay_code"] # 中继代码
        path_type = msg_data.get("path_type", LinkType.SINGLE_LINK)  # 路径类型
        link_id = msg_data.get("link_id", "")  # 链路ID
        self.logger.info(f"  销毁链路, client-relay-code: {client_relay_code}, link-id: {link_id}, path-type: {path_type} ")

        return_data = {
            "link_id": link_id,
        }  # 确保返回 link_id 给管理面，以便后续关联使用

        try:
            result = await self.service.delete_unified_link(int(path_type), str(link_id), str(client_relay_code))
            results = result.get("results", [])
            success_count = 0
            for item in results:
                if item.get("success"):
                    success_count += 1
            any_success = success_count > 0

            self.logger.info(
                f"销毁统一链路完成: path-type={path_type}, link-id={link_id}, client_relay_code={client_relay_code},"
                f"子链路数={len(results)}, 成功={success_count}"
            )

            return_data["delete_results"] = result

            return self._create_response_data(
                command_id=command_id,
                success=any_success,
                message=f"删除统一链路 {link_id}, 删除成功",
                data=json.dumps(return_data),
            )

        except Exception as e:
            self.logger.error(f"  销毁链路时出错: {e}")
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=f"销毁链路时出错: {e}",
                data=json.dumps(return_data),
            )