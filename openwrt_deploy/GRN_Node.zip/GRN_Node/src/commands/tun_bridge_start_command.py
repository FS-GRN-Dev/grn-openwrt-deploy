import json
from typing import Any

from generated import VPS_M_pb2
from .command import Command
from utils.command_payloads import normalize_tun_bridge_payload


class TunBridgeStartCommand(Command):
    def get_command_type(self) -> VPS_M_pb2.CommandType:
        return VPS_M_pb2.CommandType.TUN_BRIDGE_START

    async def execute(self, msg_data: dict[str, Any], command_id: str) -> VPS_M_pb2.ClientMessage:
        payload = normalize_tun_bridge_payload(msg_data)
        mode = str(payload.get("mode") or "")
        try:
            if mode == "server":
                bridge_code = await self.service.start_server(payload)
            elif mode == "client":
                bridge_code = await self.service.start_client(payload)
            else:
                return self._create_response(command_id, False, "缺少/非法 mode（必须为 client 或 server）")

            bridge = await self.service.get_bridge_info(bridge_code)
            if not bridge:
                bridge = {"bridge_code": bridge_code, "link_id": payload.get("link_id", "")}
            return self._create_response(command_id, True, json.dumps(bridge, ensure_ascii=False))
        except Exception as e:
            return self._create_response(command_id, False, f"启动失败: {e}")
