from .command import Command
from typing import Any, cast
import json
from generated import vps_management_pb2


class SetAllowAutoCircuitCommand(Command):
    """设置 Client Relay 是否允许 Tor 自动建路。"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        return cast(
            vps_management_pb2.CommandType,
            vps_management_pb2.CommandType.SET_ALLOW_AUTO_CIRCUIT,
        )

    def _build_response_data(
        self,
        server_relay_id: Any,
        client_relay_code: str,
        allow_auto_circuit: bool,
    ) -> dict[str, Any]:
        data: dict[str, Any] = {
            "allow_auto_circuit": bool(allow_auto_circuit),
            "client_relay_code": client_relay_code or "",
        }
        if server_relay_id is not None and server_relay_id != "":
            try:
                data["relay_id"] = int(server_relay_id)
            except (TypeError, ValueError):
                data["relay_id"] = server_relay_id
        return data

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        requested_allow = msg_data.get("allow_auto_circuit")
        client_relay_code = msg_data.get("client_relay_code") or ""
        if client_relay_code is not None:
            client_relay_code = str(client_relay_code).strip()
        server_relay_id = msg_data.get("relay_id")

        # 失败时回执 allow_auto_circuit 必须是数据面当前状态（供管理面回滚）
        current_allow = self.service.get_allow_auto_circuit(
            client_relay_code=client_relay_code or None
        )

        if "allow_auto_circuit" not in msg_data:
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message="缺少必要参数: allow_auto_circuit",
                data=json.dumps(
                    self._build_response_data(
                        server_relay_id, client_relay_code, current_allow
                    ),
                    ensure_ascii=False,
                ),
            )

        allow_auto_circuit = bool(requested_allow)

        try:
            await self.service.set_allow_auto_circuit(
                allow=allow_auto_circuit,
                client_relay_code=client_relay_code or None,
            )
            return self._create_response_data(
                command_id=command_id,
                success=True,
                message="设置是否允许Tor自动建路成功",
                data=json.dumps(
                    self._build_response_data(
                        server_relay_id, client_relay_code, allow_auto_circuit
                    ),
                    ensure_ascii=False,
                ),
            )
        except Exception as e:
            self.logger.error(f"设置 allow_auto_circuit 失败: {e}")
            # 失败后再次读取当前状态（设置未生效时应仍为旧值）
            current_allow = self.service.get_allow_auto_circuit(
                client_relay_code=client_relay_code or None
            )
            err_msg = str(e).strip() or "设置允许Tor自动建路失败"
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=err_msg,
                data=json.dumps(
                    self._build_response_data(
                        server_relay_id, client_relay_code, current_allow
                    ),
                    ensure_ascii=False,
                ),
            )
