from .command import Command
from typing import Any

from generated import vps_management_pb2


class SetNodeStatusCommand(Command):
    """设置节点状态命令"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        """返回命令类型"""
        return vps_management_pb2.CommandType.SET_NODE_STATUS

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """处理节点状态变更命令。

        Args:
            msg_data (dict): 命令消息内容。
            command_id (str, optional): 命令ID。

        Returns:
            vps_management_pb2.ClientMessage: 节点状态变更命令处理结果响应。
        """
        if "new_status" in msg_data:
            new_status = msg_data.get("new_status")
            try:
                success = await self.service.set_node_status(new_status)

                if success:
                    self.logger.info(f"  节点状态已更新为: {new_status}")
                    return self._create_response(
                        command_id=command_id,
                        success=True,
                        message=f"节点状态变更推送成功: {new_status}",
                    )
                else:
                    self.logger.error(f"  节点状态更新失败")
                    return self._create_response(
                        command_id=command_id,
                        success=False,
                        message=f"节点状态更新失败",
                    )
            except Exception as e:
                self.logger.error(f"  推送节点状态变更失败: {e}")
                return self._create_response(
                    command_id=command_id,
                    success=False,
                    message=f"节点状态变更推送失败: {e}",
                )

        else:
            self.logger.error("  命令消息缺少 'new_status' 字段")
            return self._create_response(
                command_id=command_id,
                success=False,
                message="命令消息缺少 'new_status' 字段",
            )
            # self.node_client.node.status = msg_data['new_status']
            # self.logger.info(f"  节点状态已更新为: {msg_data['new_status']}")
            # # 异步更新节点信息（转换为proto格式）
            # try:
            #     response = await self.node_client.stub.PushNodeInfo(
            #         vps_management_pb2.PushNodeInfoRequest(node=self.node_client.node.to_proto())
            #     )
            #     self.logger.info(f"  节点状态变更推送结果：{response.message}")
            #     return self._create_response(
            #         command_id=command_id,
            #         success=True,
            #         message=f"节点状态变更推送成功: {self.node_client.node.status}"
            #     )

            # except Exception as e:
            #     self.logger.error(f"  推送节点状态变更失败: {e}")
            #     return self._create_response(
            #         command_id=command_id,
            #         success=False,
            #         message=f"节点状态变更推送失败: {e}"
            #     )
