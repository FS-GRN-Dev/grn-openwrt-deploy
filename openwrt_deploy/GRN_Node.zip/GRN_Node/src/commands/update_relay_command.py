from .command import Command
from typing import Any

from generated import vps_management_pb2


class UpdateRelayCommand(Command):
    """更新Relay命令"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        """返回命令类型"""
        return vps_management_pb2.CommandType.UPDATE_RELAY

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """处理更新Relay配置命令。

        Args:
            msg_data (dict): 命令消息内容。
            command_id (str, optional): 命令ID。

        Returns:
            vps_management_pb2.ClientMessage: 更新Relay配置结果响应。
        """
        if "relay_id" in msg_data and "config" in msg_data:
            relay_id = msg_data["relay_id"]
            config = msg_data["config"]

            try:
                success = await self.service.update_relay(relay_id, config)
                if success:
                    return self._create_response(
                        command_id=command_id,
                        success=True,
                        message=f"Relay {relay_id} 配置更新成功",
                    )
                else:
                    return self._create_response(
                        command_id=command_id,
                        success=False,
                        message=f"Relay {relay_id} 不存在",
                    )
            except Exception as e:
                self.logger.error(f"  更新Relay配置时出错: {e}")
                return self._create_response(
                    command_id=command_id,
                    success=False,
                    message=f"更新Relay {relay_id} 配置时出错: {e}",
                )

        else:
            self.logger.error("  命令消息缺少'relay_id'或'config'字段")
            return self._create_response(
                command_id=command_id,
                success=False,
                message="命令消息缺少'relay_id'或'config'字段",
            )
            # if relay_id in self.node_client.relays:
            #     self.logger.info(f"  正在更新Relay配置: {relay_id}")

            #     # 更新Relay配置
            #     relay = self.node_client.relays[relay_id]
            #     # 根据配置更新Relay属性
            #     if 'nickname' in config:
            #         relay.nickname = config['nickname']
            #     if 'bandwidth' in config:
            #         relay.bandwidth = int(config['bandwidth'])
            #     if 'exit_policy' in config:
            #         relay.exit_policy = config['exit_policy']

            #     self.logger.info(f"  Relay配置已更新: {relay_id}")
            #     return self._create_response(
            #         command_id=command_id,
            #         success=True,
            #         message=f"Relay {relay_id} 配置更新成功"
            #     )
            # else:
            #     self.logger.error(f"  Relay不存在: {relay_id}")
            #     return self._create_response(
            #         command_id=command_id,
            #         success=False,
            #         message=f"Relay {relay_id} 不存在"
            #     )
