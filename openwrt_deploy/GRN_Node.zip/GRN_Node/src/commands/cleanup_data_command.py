from .command import Command
from typing import Any, cast
import json
from generated import vps_management_pb2


class CleanupDataCommand(Command):
    """清理数据命令：销毁节点上所有 Relay"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        return cast(
            vps_management_pb2.CommandType,
            vps_management_pb2.CommandType.CLEANUP_DATA,
        )

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """处理 CLEANUP_DATA 命令，销毁节点上所有 Relay。

        Args:
            msg_data (dict): 命令消息内容。
            command_id (str): 命令ID。

        Returns:
            vps_management_pb2.ClientMessage: 清理数据命令处理结果响应。
        """
        self.logger.info(f"执行清理数据命令 CLEANUP_DATA，命令ID: {command_id}")

        response_data = {
            "node_code": self.context.node_code,
            "action": msg_data.get("action", "cleanup_data"),
        }

        try:
            success, destroyed_relays, link_cleanup = await self.service.cleanup_data()
            response_data["destroyed_relays"] = destroyed_relays
            response_data["link_cleanup"] = link_cleanup
            if success:
                link_msg = ""
                if not link_cleanup.get("skipped"):
                    link_msg = f"，已清理 {link_cleanup.get('deleted_circuits_count', 0)} 条电路相关资源"
                return self._create_response_data(
                    command_id=command_id,
                    success=True,
                    message=f"清理数据成功，已销毁 {len(destroyed_relays)} 个中继{link_msg}",
                    data=json.dumps(response_data),
                )
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=f"清理数据部分失败，已销毁 {len(destroyed_relays)} 个中继",
                data=json.dumps(response_data),
            )
        except Exception as e:
            self.logger.error(f"清理数据失败: {e}")
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=f"清理数据失败: {e}",
                data=json.dumps(response_data),
            )
