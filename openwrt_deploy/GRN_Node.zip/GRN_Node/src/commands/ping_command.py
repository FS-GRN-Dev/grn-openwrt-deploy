"""
PingCommand — RTT 探测命令

管理面下发 PING 命令后，VPS 节点立即返回 COMMAND_RESPONSE，
管理面据此计算 gRPC 控制面链路的往返时延 (RTT)。

message 字段原样回传——管理面可在其中放置序列号或时间戳。
"""

from typing import Any
from generated import VPS_M_pb2
from commands.command import Command


class PingCommand(Command):

    def get_command_type(self) -> VPS_M_pb2.CommandType:
        return VPS_M_pb2.CommandType.PING

    async def execute(self, msg_data: dict[str, Any], command_id: str) -> VPS_M_pb2.ClientMessage:
        """收到 PING 后立即回应，将原始 message 原样返回。"""
        echo_payload = msg_data.get("echo", "")
        return VPS_M_pb2.ClientMessage(
            node_id=self.context.node_id,
            ip_address=self.context.ip_address,
            command_id=command_id,
            success=True,
            message=echo_payload,
            type=VPS_M_pb2.ClientMessageType.COMMAND_RESPONSE,
        )
