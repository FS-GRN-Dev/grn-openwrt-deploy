from .command import Command
from typing import Any, cast
import json
from generated import vps_management_pb2


class DestroyRelayCommand(Command):
    """销毁Relay命令"""

    def get_command_type(self) -> vps_management_pb2.CommandType:
        """返回命令类型"""
        return cast(
            vps_management_pb2.CommandType, vps_management_pb2.CommandType.DESTROY_RELAY
        )

    async def execute(
        self, msg_data: dict[str, Any], command_id: str
    ) -> vps_management_pb2.ClientMessage:
        """处理销毁Relay命令，销毁并推送节点信息。

        Args:
            msg_data (dict): 命令消息内容。
            command_id (str, optional): 命令ID。

        Returns:
            vps_management_pb2.ClientMessage: 销毁Relay命令处理结果响应。
        """
        self.logger.info(f"执行销毁Relay命令，命令ID: {command_id}")

        relay_code = msg_data.get("relay_code")
        server_relay_id = msg_data.get("relay_id")

        response_data = {"relay_code": relay_code, "relay_id": server_relay_id}

        try:
            success = await self.service.destroy_relay(relay_code)
            if not success:
                return self._create_response_data(
                    command_id=command_id,
                    success=False,
                    message=f"销毁中继: {relay_code}，销毁失败",
                    data=json.dumps(response_data),
                )
            else:
                return self._create_response_data(
                    command_id=command_id,
                    success=True,
                    message=f"销毁中继: {relay_code}, 销毁成功",
                    data=json.dumps(response_data),
                )
        except Exception as e:
            self.logger.error(f"销毁中继失败: {e}")
            return self._create_response_data(
                command_id=command_id,
                success=False,
                message=f"销毁中继失败: {e}",
                data=json.dumps(response_data),
            )

        # if 'relay_id' in msg_data:
        #     destroy_relay_id = msg_data['relay_id']
        #     if destroy_relay_id in self.node_client.relays:
        #         self.logger.info(f"  正在销毁Relay: {destroy_relay_id}")

        #         # 更新对应Relay状态
        #         self.node_client.relays[destroy_relay_id].mark_destroying()
        #         # TODO：基于Stem2Tor销毁Relay逻辑
        #         try:
        #             stem2tor = self.node_client.stem2tor_instances[destroy_relay_id]
        #             success = await stem2tor.stop_tor()
        #             if not success:
        #                 self.logger.error(f"  销毁Relay失败: {destroy_relay_id}")
        #                 return self._create_response(
        #                     command_id = command_id,
        #                     success=False,
        #                     message=f"销毁Relay失败: {destroy_relay_id}"
        #                 )
        #         except Exception as e:
        #             self.logger.error(f"  销毁Relay失败: {e}")
        #             return vps_management_pb2.ClientMessage(
        #                 command_id=command_id,
        #                 success=False,
        #                 message=f"销毁Relay失败: {e}"
        #             )

        #         self.logger.info(f"  Relay容器已销毁: {destroy_relay_id}")
        #         self.node_client.relays[destroy_relay_id].mark_stopped()
        #         # 从列表中移除
        #         # TODO: 如何把Relay信息从管理面(数据库)中删除？
        #         # 应该是标记好状态后push，再在本地删除就可以了
        #         # 或者等着定时上报，逻辑也比较简单
        #         # 不过从逻辑来讲，管理面指定删除后立马有反馈比较好

        #         del self.node_client.relays[destroy_relay_id]
        #         self.node_client.node.remove_relay(
        #             relay_id=destroy_relay_id,
        #             current_count=len(self.node_client.relays)
        #         )

        #         # 推送一次relays到管理服务器（转换为proto格式）
        #         try:
        #             relay_protos = [relay.to_proto() for relay in self.node_client.relays.values()]
        #             response = await self.node_client.stub.PushRelayInfo(
        #                 vps_management_pb2.PushRelayInfoRequest(relays=relay_protos)
        #             )
        #             self.logger.info(f"  Relay信息推送结果：{response.message}")
        #         except Exception as e:
        #             self.logger.error(f"  推送Relay信息失败: {e}")
        #             return self._create_response(
        #                 command_id = command_id,
        #                 success=False,
        #                 message=f"Relay信息推送失败: {e}"
        #             )

        #         # 删除对应的Stem2Tor实例
        #         if destroy_relay_id in self.node_client.stem2tor_instances:
        #             await self.node_client.stem2tor_instances[destroy_relay_id].stop_tor()
        #             del self.node_client.stem2tor_instances[destroy_relay_id]
        #             self.logger.info(f"  Stem2Tor实例已删除: {destroy_relay_id}")

        #         # 更新节点的Relay计数
        #         self.node_client.node.relay_count = len(self.node_client.relays)

        #         # 推送节点信息更新
        #         if not await self.node_client.reporter.report_node_info():
        #             return self._create_response(
        #                 command_id = command_id,
        #                 success=False,
        #                 message="节点信息推送失败"
        #             )
        #     else:
        #         self.logger.error(f"  Relay不存在: {destroy_relay_id}")
        #         return self._create_response(
        #             command_id = command_id,
        #             success=False,
        #             message=f"Relay {destroy_relay_id} 不存在"
        #         )

        #     return self._create_response(
        #         command_id = command_id,
        #         success=True,
        #         message=f"Relay {destroy_relay_id} 销毁成功"
        #     )
