from generated import vps_management_pb2

class NodeConfig:
    DEFAULT_NODE_STATUS = vps_management_pb2.NodeStatus.NODE_ONLINE
    DEFAULT_RISK_LEVEL = 0
    DEFAULT_TRAFFIC_IN = 0
    DEFAULT_TRAFFIC_OUT = 0
    DEFAULT_RELAY_COUNT = 0
    DEFAULT_MAX_RELAY_CAPACITY = 2
    
class StemConfig:
    DEFAULT_DIR_PORT = "9030"
    DEFAULT_OR_PORT = 9001
    DEFAULT_SOCKS_PORT = 9050
    DEFAULT_CONTROL_PORT = 9051
    DEFAULT_TOR_PASSWORD = "torpassword"
    DEFAULT_EXIT_POLICY = "reject *:*"
    DEFAULT_PLATFORM = "Linux"
    DEFAULT_ADDR = "localhost"
    DEFAULT_MAX_RETRIES = 10
    DEFAULT_NODE_WAIT_TIME = 30
    DEFAULT_CHECK_INTERVAL = 2.0
    
class ContainerConfig:
    DEFAULT_IMAGE = "grn-tor"
    DEFAULT_NETWORK_MODE = "bridge"

class GrpcConfig:
    DEFAULT_SERVER_ADDR = 'localhost:50051'
    RETRY_INTERVAL = 5
    HEARTBEAT_INTERVAL = 30
    EXIT_DELAY = 10
    DEFAULT_CA_CERT_PATH = "./credentials/ca.crt"
    DEFAULT_PRIVATE_KEY_PATH = "./credentials/client.key"
    DEFAULT_CERT_CHAIN_PATH = "./credentials/client_cert_chain.crt"
    DEFAULT_VERIFY_HOSTNAME = True # 主机名验证默认值（公共CA=True，自签名/私有CA可覆盖）
    SERVER_HOST_OVERRIDE = "localhost"
    CHANNEL_READY_TIMEOUT_SEC = 30
    STREAM_READ_TIMEOUT_SEC = 0  # 0 表示不超时，依赖 gRPC keepalive 检测死连接
    RECONNECT_MAX_BACKOFF_SEC = 60
    CHANNEL_REBUILD_AFTER_FAILURES = 3

class ObserverConfig:
    NODE_INFO_INTERVAL = 60
    NODE_INFO_EXCEPTION_INTERVAL = 5
    RELAY_INFO_INTERVAL = 600
    RELAY_INFO_EXCEPTION_INTERVAL = 30
    SITUATION_AWARENESS_INTERVAL = 600
    SITUATION_AWARENESS_EXCEPTION_INTERVAL = 30
    DA_INFO_INTERVAL = 600
    DA_INFO_EXCEPTION_INTERVAL = 30
    CONSENSUS_INFO_INTERVAL = 30
    CONSENSUS_INFO_EXCEPTION_INTERVAL = 5

class SystemConfig:
    DEFAULT_CPU_USAGE = 30.5
    DEFAULT_MEMORY_USAGE = 40.0
    DEFAULT_BYTES_RECV = 1024
    DEFAULT_BYTES_SENT = 2048
    
    RISK_THRESHOLD_CRITICAL = 90
    RISK_THRESHOLD_HIGH = 75
    RISK_THRESHOLD_MEDIUM = 60
    RISK_THRESHOLD_LOW = 40
    
    RISK_LEVEL_CRITICAL = 9
    RISK_LEVEL_HIGH = 7
    RISK_LEVEL_MEDIUM = 5
    RISK_LEVEL_LOW = 3
    RISK_LEVEL_MINIMAL = 1

class CommandConfig:
    RELAY_STARTUP_WAIT = 10

class LinkType:
    UNKNOWN_LINK = 0
    SINGLE_LINK = 1
    MULTI_LINK =2


class LinkEnableAction:
    ENABLE = "enable"
    DISABLE = "disable"


class SwitchType:
    SINGLE_TO_SINGLE = 1
    SINGLE_TO_MULTI = 2
    MULTI_TO_SINGLE = 3
    MULTI_TO_MULTI = 4
    NONE_TO_SINGLE = 5
    NONE_TO_MULTI = 6

class TunBridgeConfig:
    DEFAULT_LISTEN_HOST = "0.0.0.0"
    DEFAULT_LISTEN_PORT = 19000
    DEFAULT_MTU = 1300
    DEFAULT_CONNECT_TIMEOUT_SEC = 60
    DEFAULT_ENABLE_MPTCP = False
    DEFAULT_TUNNEL_COUNT = 2

class SingBoxConfig:
    BINARY: str = "sing-box"
    RUNTIME_CONFIG_DIR: str = "/tmp/grn-sing-box"
    LOG_DIR: str = "/tmp/grn-sing-box"
    CLIENT_TEMPLATE_PATH: str = "src/config/singbox/client_singbox.json"
    SERVER_TEMPLATE_PATH: str = "src/config/singbox/server_singbox.json"

    UUID: str = "11111111-1111-4111-8111-111111111111"
    LOG_LEVEL: str = "info"
    LOG_MAX_BYTES: int = 2 * 1024 * 1024
    LOG_BACKUP_COUNT: int = 2

    CLIENT_LISTEN_HOST: str = "0.0.0.0"
    CLIENT_LISTEN_PORT: int = 11090
    # OpenWrt(1.12)：redirect inbound 嗅探 + sniff_override_destination
    # 云 VPS(1.13)：改写到 route.rules 的 action=sniff（由 transparent_proxy 按 run_role 注入）
    CLIENT_SNIFF_ENABLED: bool = True
    CLIENT_SNIFF_OVERRIDE_DESTINATION: bool = True
    CLIENT_SNIFF_TIMEOUT: str = "300ms"
    SERVER_LISTEN_HOST: str = "0.0.0.0"
    SERVER_LISTEN_PORT: int = 11091

    CLASH_API_HOST: str = "127.0.0.1"
    CLASH_API_PORT: int = 9090
    CLASH_API_SECRET: str = "grn-secret"

    SELECTOR_TAG: str = "out-select"
    CLIENT_INBOUND_TAG: str = "redirect-in"
    SERVER_INBOUND_TAG: str = "mptcp-path-"
    DIRECT_OUTBOUND_TAG: str = "direct"
    SOCKS_OUTBOUND_TAG: str = "socks5"
    MPTCP_OUTBOUND_TAG: str = "mptcp-tunnel"

    DEFAULT_SOCKS_HOST: str = "127.0.0.1"
    DEFAULT_SOCKS_PORT: int = 9050
    # 缩短建连超时，避免 mux 排队把等待拖到数分钟
    DEFAULT_CONNECT_TIMEOUT: str = "5s"

    @classmethod
    def clash_api_url(cls) -> str:
        return f"http://{cls.CLASH_API_HOST}:{cls.CLASH_API_PORT}"

class LocalServiceConfig:
    DEFAULT_LOCAL_SOCKET_PATH = "/opt/local/local_ipc.sock"
    DEFAULT_MAX_MSG_LEN = 1024
