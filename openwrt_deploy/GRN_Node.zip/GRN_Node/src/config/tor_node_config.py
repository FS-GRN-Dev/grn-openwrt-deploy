from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from config.config import StemConfig, ContainerConfig

@dataclass
class TorNodeConfig:
    role: str
    nick: str
    pwd: str = StemConfig.DEFAULT_TOR_PASSWORD
    or_port: int = StemConfig.DEFAULT_OR_PORT
    socks_port: int = StemConfig.DEFAULT_SOCKS_PORT
    control_port: int = StemConfig.DEFAULT_CONTROL_PORT
    dir_port: Optional[str] = StemConfig.DEFAULT_DIR_PORT
    outer_ip_addr: Optional[str] = None
    dir_auths: Optional[List[Dict[str, Any]]] = None
    image: str = ContainerConfig.DEFAULT_IMAGE
    network_mode: str = ContainerConfig.DEFAULT_NETWORK_MODE