from typing import Any
from config.config import LinkType



def _coalesce(data: dict[str, Any], *keys: str, default: Any = None) -> Any:
    for key in keys:
        if key in data and data[key] is not None:
            return data[key]
    return default


def _normalize_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [item.strip() for item in value.split(",") if item.strip()]
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return []


def normalize_link_entries(
    link_entries: Any,
    default_client_relay_code: str = "",
) -> list[dict[str, Any]]:
    if not isinstance(link_entries, list):
        return []

    normalized_entries: list[dict[str, Any]] = []
    for item in link_entries:
        if not isinstance(item, dict):
            continue

        normalized_entries.append(
            {
                "client_relay_code": str(
                    _coalesce(
                        item,
                        "client_relay_code",
                        default=default_client_relay_code,
                    )
                    or default_client_relay_code
                ),
                "relay_codes": _normalize_list(_coalesce(item, "relay_codes", default=[])),
                "relay_fingerprints": _normalize_list(
                    _coalesce(item, "relay_fingerprints", "relay_codes", default=[])
                ),
                "circuit_id": str(_coalesce(item, "circuit_id", default="") or ""),
                "link_id": str(_coalesce(item, "link_id", default="") or ""),
            }
        )

    return normalized_entries


def normalize_create_circuit_payload(msg_data: dict[str, Any]) -> dict[str, Any]:
    client_relay_code = str(
        _coalesce(msg_data, "client_relay_code", default="") or ""
    )
    return {
        "link_id": str(_coalesce(msg_data, "link_id", "parent_link_id", default="") or ""),
        "client_relay_code": client_relay_code,
        "path_type": int(_coalesce(msg_data, "path_type", default=LinkType.SINGLE_LINK) or LinkType.SINGLE_LINK),
        "link_list": normalize_link_entries(
            _coalesce(msg_data, "link_list", "linkList", default=[]),
            default_client_relay_code=client_relay_code,
        ),
        "relay_fingerprints": _normalize_list(
            _coalesce(msg_data, "relay_fingerprints", "relay_codes", default=[])
        ),
        "set_as_default": bool(_coalesce(msg_data, "set_as_default", default=False)),
    }


def normalize_switch_link_payload(msg_data: dict[str, Any]) -> dict[str, Any]:
    action = str(_coalesce(msg_data, "action", default="") or "").strip().lower()
    link_id = str(_coalesce(msg_data, "link_id", default="") or "")
    client_relay_code = str(
        _coalesce(msg_data, "client_relay_code", default="") or ""
    )
    bridge_info = normalize_client_bridge_config(
        _coalesce(msg_data, "bridge_info", default={})
    )

    switch_type_raw = _coalesce(msg_data, "switch_type", default=None)
    switch_type = None
    if switch_type_raw is not None and str(switch_type_raw).strip() != "":
        try:
            switch_type = int(switch_type_raw)
        except (TypeError, ValueError):
            switch_type = None

    return {
        "action": action,
        "link_id": link_id,
        "client_relay_code": client_relay_code,
        "switch_type": switch_type,
        "bridge_info": bridge_info,
    }


def normalize_tunnels(tunnels: Any) -> list[dict[str, Any]]:
    if not isinstance(tunnels, list):
        return []

    normalized_tunnels: list[dict[str, Any]] = []
    for item in tunnels:
        if not isinstance(item, dict):
            continue
        normalized_tunnels.append(
            {
                "tun_name": str(_coalesce(item, "tun_name", default="") or ""),
                "tun_addr_cidr": str(_coalesce(item, "tun_addr_cidr", default="") or ""),
                "link_id": str(_coalesce(item, "link_id", default="") or ""),
            }
        )
    return normalized_tunnels


def normalize_tun_bridge_payload(msg_data: dict[str, Any]) -> dict[str, Any]:
    return {
        "mode": str(_coalesce(msg_data, "mode", default="") or "").lower(),
        "client_bridge_code": str(_coalesce(msg_data, "client_bridge_code", default="") or ""),
        "relay_code": str(_coalesce(msg_data, "relay_code", default="") or ""),
        "client_relay_code": str(
            _coalesce(msg_data, "client_relay_code", default="") or ""
        ),
        "link_id": str(_coalesce(msg_data, "link_id", "parent_link_id", default="") or ""),
        "server_bridge_code": str(_coalesce(msg_data, "server_bridge_code", default="") or ""),
        "listen_host": str(_coalesce(msg_data, "listen_host", default="") or ""),
        "listen_port": int(_coalesce(msg_data, "listen_port", default=0) or 0),
        "endpoint_host": str(_coalesce(msg_data, "endpoint_host", default="") or ""),
        "endpoint_port": int(_coalesce(msg_data, "endpoint_port", default=0) or 0),
        "proxy_host": str(_coalesce(msg_data, "proxy_host", default="") or ""),
        "proxy_port": int(_coalesce(msg_data, "proxy_port", default=0) or 0),
        "mtu": int(_coalesce(msg_data, "mtu", default=0) or 0),
        "connect_timeout_sec": int(_coalesce(msg_data, "connect_timeout_sec", default=0) or 0),
        "enable_mptcp": bool(_coalesce(msg_data, "enable_mptcp", default=True)),
        "aggregate": bool(_coalesce(msg_data, "aggregate", default=False)),
        "tunnels": normalize_tunnels(_coalesce(msg_data, "tunnels", default=[])),
        "server_tunnels": normalize_tunnels(_coalesce(msg_data, "server_tunnels", default=[])),
    }

def normalize_client_bridge_config(config: Any) -> dict[str, Any]:
    if not isinstance(config, dict):
        return {}
    payload = normalize_tun_bridge_payload({"mode": "ciient", **config})
    payload.pop("mode", None)
    return payload


def normalize_server_bridge_config(config: Any) -> dict[str, Any]:
    if not isinstance(config, dict):
        return {}
    payload = normalize_tun_bridge_payload({"mode": "server", **config})
    payload.pop("mode", None)
    return payload


def normalize_create_relay_payload(msg_data: dict[str, Any]) -> dict[str, Any]:
    return {
        "relay_type": _coalesce(msg_data, "relay_type", default=None),
        "relay_role": _coalesce(msg_data, "relay_role", default=None),
        "auto_start_server_bridge": _coalesce(msg_data, "auto_start_server_bridge", default=None),
        "server_bridge": normalize_server_bridge_config(
            _coalesce(msg_data, "server_bridge", "bridge_info", default={})
        ),
        "relay_id": _coalesce(msg_data, "relay_id", "relay_code", default=None),
        "dir_auths": _coalesce(msg_data, "da_info", default=None),
    }