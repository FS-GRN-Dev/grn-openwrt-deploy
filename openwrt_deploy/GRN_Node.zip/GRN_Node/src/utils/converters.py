from generated import vps_management_pb2

def get_role(role: vps_management_pb2.RelayRole) -> str:
    """获取节点角色的字符串表示。
    因为vps_management_pb2.RelayRole是枚举类型，所以我们需要将其转换为字符串。
    此外，由于vps_management_pb2.RelayRole的字符串与需要的字符串也不同，所以需要手动转换。

    Args:
        role (vps_management_pb2.RelayRole): 节点角色枚举值。

    Returns:
        str: 节点角色的字符串表示。
    """
    match role:
        case vps_management_pb2.RelayRole.ROLE_DA: return "da"
        case vps_management_pb2.RelayRole.ROLE_RELAY: return "relay"
        case vps_management_pb2.RelayRole.ROLE_EXIT: return "exit"
        case vps_management_pb2.RelayRole.ROLE_CLIENT: return "client"
        case vps_management_pb2.RelayRole.ROLE_HS: return "hs"
        case _:
            raise ValueError(f"未知的节点角色: {role}")


def classify_weight(consensus_weight):
    """旧版本中根据权重值推断权重类别（简化逻辑）"""
    if consensus_weight >= 30000:
        return "Guard"
    elif consensus_weight >= 15000:
        return "Exit"
    else:
        return "Middle"
