import argparse


def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="启动 NodeClient 并运行主循环")

    parser.add_argument(
        "-s",
        "--server_addr",
        type=str,
        default="127.0.0.1:50051",
        help="服务器地址 (默认: 127.0.0.1:50051)",
    )

    parser.add_argument(
        "-l", "--geo_location", type=str, default=None, help="地理位置 (默认: None)"
    )

    parser.add_argument(
        "-c",
        "--cloud_provider",
        type=str,
        default=None,
        help="云服务提供商 (默认: None)",
    )

    parser.add_argument(
        "-m",
        "--mode",
        type=str,
        default="cloud",
        help="运行模式 (默认: cloud, 私网环境请使用 test)",
    )

    parser.add_argument(
        "-addr", "--address", type=str, default=None, help="节点IP地址 (默认: None)"
    )
    parser.add_argument(
        "-longitude",
        "--longitude",
        type=float,
        default=0.0,
        help="节点经度 (默认: 0.0)",
    )
    parser.add_argument(
        "-latitude", "--latitude", type=float, default=0.0, help="节点纬度 (默认: 0.0)"
    )

    parser.add_argument(
        "-r",
        "--role",
        type=str,
        default=None,
        help="节点角色 (默认: None, 客户端(OpenWrt)请使用 openwrt)",
    )

    return parser.parse_args()
