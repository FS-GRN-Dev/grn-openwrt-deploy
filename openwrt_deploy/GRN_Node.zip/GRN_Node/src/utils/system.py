import psutil
from config.config import SystemConfig


def get_tcp_retrans_rate() -> float:
    """从 /proc/net/snmp 读取 TCP 重传率 (RetransSegs / OutSegs)。

    Returns:
        float: 重传率 (0.0~1.0)，读取失败时返回 0.0。
    """
    try:
        with open("/proc/net/snmp", "r") as f:
            lines = f.readlines()
        # 找到 Tcp: 的 header 行和 data 行
        header_line = None
        data_line = None
        for i, line in enumerate(lines):
            if line.startswith("Tcp:"):
                if header_line is None:
                    header_line = line.strip()
                else:
                    data_line = line.strip()
        if header_line is None or data_line is None:
            return 0.0
        headers = header_line.split()
        values = data_line.split()
        if len(headers) != len(values):
            return 0.0
        col_map = {h: v for h, v in zip(headers, values)}
        out_segs = int(col_map.get("OutSegs", 0))
        retrans_segs = int(col_map.get("RetransSegs", 0))
        if out_segs <= 0:
            return 0.0
        return min(1.0, retrans_segs / out_segs)
    except Exception:
        return 0.0

def get_cpu_usage() -> float:
    """获取当前CPU使用率。

    Returns:
        float: CPU使用率百分比。
    """
    try:
        return psutil.cpu_percent(interval=0.1)
    except:
        return SystemConfig.DEFAULT_CPU_USAGE


def get_memory_usage() -> float:
    """获取当前内存使用率。

    Returns:
        float: 内存使用率百分比。
    """
    try:
        return psutil.virtual_memory().percent
    except:
        return SystemConfig.DEFAULT_MEMORY_USAGE


def get_network_traffic() -> tuple[int, int]:
    """获取当前网络流量。

    Returns:
        tuple: (bytes_recv, bytes_sent) 接收和发送的字节数。
    """
    try:
        net_io = psutil.net_io_counters()
        return net_io.bytes_recv, net_io.bytes_sent
    except:
        return SystemConfig.DEFAULT_BYTES_RECV, SystemConfig.DEFAULT_BYTES_SENT


def calculate_risk_level() -> int:
    """根据CPU使用率等指标计算风险等级。

    Returns:
        int: 风险等级分值。
    """
    # TODO: 实现更复杂的风险计算逻辑
    cpu_usage = get_cpu_usage()
    if cpu_usage > SystemConfig.RISK_THRESHOLD_CRITICAL:
        return SystemConfig.RISK_LEVEL_CRITICAL
    elif cpu_usage > SystemConfig.RISK_THRESHOLD_HIGH:
        return SystemConfig.RISK_LEVEL_HIGH
    elif cpu_usage > SystemConfig.RISK_THRESHOLD_MEDIUM:
        return SystemConfig.RISK_LEVEL_MEDIUM
    elif cpu_usage > SystemConfig.RISK_THRESHOLD_LOW:
        return SystemConfig.RISK_LEVEL_LOW
    else:
        return SystemConfig.RISK_LEVEL_MINIMAL
