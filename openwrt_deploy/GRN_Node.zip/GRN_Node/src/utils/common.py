import time
from generated import vps_management_pb2

def create_general_message(node_client, command_id, success, message):
    node_code = getattr(node_client, "node_code", None) or getattr(
        node_client, "node_id", ""
    )
    return vps_management_pb2.ClientMessage(
        node_code=node_code,
        ip_address=node_client.ip_address,
        timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
        message_type="GENERAL_COMMAND_RESPONSE",
        command_id=command_id,
        success=success,
        message=message
    )
