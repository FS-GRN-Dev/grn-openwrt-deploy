import logging
import os
from typing import Optional
from logging.handlers import RotatingFileHandler

def setup_logging(
    log_level: str = "INFO",
    log_file: Optional[str] = "~/node_client.log",  # 新增日志文件路径参数
    max_bytes: int = 1024 * 1024 * 5,               # 单个日志文件最大5MB
    backup_count: int = 5,                          # 保留5个轮转文件
    enable_console: bool = False                    # 是否启用控制台输出
):
    """设置日志配置"""

    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, log_level.upper()))
    root_logger.handlers.clear()

    formatter = logging.Formatter(
        '%(asctime)s - NodeClient - %(name)s - %(levelname)s - %(message)s'
    )

    # 可选控制台输出
    if enable_console:
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        root_logger.addHandler(stream_handler)

    # 按大小轮转的文件处理器
    if log_file:
        log_file = os.path.expanduser(log_file)
        log_dir = os.path.dirname(log_file)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
        file_handler = RotatingFileHandler(
            filename=log_file,
            mode='a',         # 追加模式
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding="utf-8"  # 避免中文乱码
        )
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    # 返回当前模块名称的日志器
    return logging.getLogger(__name__)


def get_logger(name: str):
    """获取指定名称的日志记录器"""
    return logging.getLogger(name)