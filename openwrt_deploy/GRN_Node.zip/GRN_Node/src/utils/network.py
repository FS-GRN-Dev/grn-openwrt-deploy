import socket
import requests
from typing import Optional


def is_valid_ipv4(ip: str) -> bool:
    """简单检查是否是有效的 IPv4 地址"""
    parts = ip.split(".")
    if len(parts) != 4:
        return False
    for part in parts:
        if not part.isdigit() or not (0 <= int(part) <= 255):
            return False
    return True


def extract_provider(org: str) -> str:
    if not org:
        return ""
    # 去掉 AS 号
    provider = org.split(" ", 1)[1] if " " in org else org
    # 云服务商
    cloud_map = {
        "Alibaba": "阿里云",
        "Aliyun": "阿里云",
        "Tencent": "腾讯云",
        "Amazon": "AWS",
        "Google": "GCP",
        "Azure": "Azure",
        "Baidu": "百度云",
        "Huawei": "华为云",
    }
    for key, value in cloud_map.items():
        if key.lower() in provider.lower():
            return value
    # 中国三大运营商
    carrier_map = {
        "China Telecom": "中国电信",
        "China Unicom": "中国联通",
        "China Mobile": "中国移动",
        "Education and Research": "教育网",
    }
    for key, value in carrier_map.items():
        if key.lower() in provider.lower():
            return value
    return provider  # 默认返回原字符串

def extract_longitude_latitude(loc: str) -> tuple[float, float]:
    if not loc:
        return 0.0, 0.0
    
    latitude, longitude = map(float, loc.split(','))
    return latitude, longitude # 返回经纬度

def get_ip_geo_provider_info(logger):
    try:
        resp = requests.get("https://ipinfo.io/json", timeout=5)
        if resp.status_code != 200:
            return None, None, None
        data = resp.json()
        ip_address = data.get("ip", "")
        city = data.get("city", "")
        region = data.get("region", "")
        country = data.get("country", "")
        org = data.get("org", "")

        # 1. geo_location 优先取 city，无则 region，无则 country
        if city:
            geo_location = city
        elif region:
            geo_location = region
        else:
            geo_location = country

        cloud_provider = extract_provider(org)

        return ip_address, geo_location, cloud_provider
    except Exception as e:
        logger.error(f"[ipinfo.io] 获取公网信息失败: {e}")
        return None, None, None


def get_network_info(logger, ip_addr: Optional[str] = None, mode: str = "cloud"):
    """
    统一获取：IP、地理位置（优先城市）、云/运营商信息
    - ip_addr: 可选外部指定，优先返回
    - mode: 'cloud' 获取公网IP, 'test' 获取本地网卡IP
    """
    # 1. 明确指定了IP直接用
    if ip_addr and is_valid_ipv4(ip_addr):
        ip_address = ip_addr
        geo_location, cloud_provider, net_latitude, net_longitude = "", "", 0.0, 0.0
    else:
        try:
            # 获取公网信息
            resp = requests.get("https://ipinfo.io/json", timeout=5)
            if resp.status_code != 200:
                raise RuntimeError("ipinfo.io请求失败")
            data = resp.json()
            ip_address = data.get("ip", "")
            city = data.get("city", "")
            region = data.get("region", "")
            country = data.get("country", "")
            loc = data.get("loc", "")
            net_latitude, net_longitude = extract_longitude_latitude(loc)
            org = data.get("org", "")
            geo_location = city or region or country
            cloud_provider = extract_provider(org)
        except Exception as e:
            logger.error(f"[ipinfo.io] 获取公网信息失败: {e}")
            ip_address, geo_location, cloud_provider, net_latitude, net_longitude = "", "", "", 0.0, 0.0

    # 2. 本地测试模式下，获取本地网卡IP（用于开发环境/内网模拟）
    if mode == "test":
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
            if is_valid_ipv4(local_ip):
                ip_address = local_ip
            else:
                ip_address = "192.168.1.100"
        except Exception as e:
            logger.error(f"获取本地IP失败: {e}")
            ip_address = "192.168.1.100"

    # 最后兜底
    if not ip_address or not is_valid_ipv4(ip_address):
        ip_address = "192.168.1.100"

    return ip_address, geo_location, cloud_provider, net_latitude, net_longitude
