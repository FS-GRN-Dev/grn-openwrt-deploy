import os
import time
import uuid
from dataclasses import dataclass, asdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional, Sequence

import pycurl


@dataclass
class PartDownloadResult:
    index: int
    start: int
    end: int
    link_id: str
    part_path: str
    http_code: int
    bytes_downloaded: int
    elapsed_ms: int
    success: bool
    error: Optional[str] = None


@dataclass
class MultipathDownloadResult:
    request_id: str
    url: str
    output_path: str
    total_size: int
    parts: int
    accept_ranges: Optional[str]
    elapsed_ms: int
    success: bool
    error: Optional[str]
    part_results: list[PartDownloadResult]

    def to_dict(self) -> dict:
        return {
            **{k: v for k, v in asdict(self).items() if k != "part_results"},
            "part_results": [asdict(p) for p in self.part_results],
        }


class MultipathDownloader:
    def __init__(
        self,
        proxy_host: str,
        proxy_port: int,
        connect_timeout_sec: int = 15,
        timeout_sec: int = 300,
        max_parallel: Optional[int] = None,
        user_agent: str = "GRN-MultipathDownloader/1.0",
        insecure_tls: bool = False,
    ) -> None:
        self.proxy_host = proxy_host
        self.proxy_port = int(proxy_port)
        self.connect_timeout_sec = int(connect_timeout_sec)
        self.timeout_sec = int(timeout_sec)
        self.max_parallel = max_parallel
        self.user_agent = user_agent
        self.insecure_tls = insecure_tls

    def _apply_common_curl_options(self, c: pycurl.Curl) -> None:
        c.setopt(pycurl.PROXYTYPE, pycurl.PROXYTYPE_SOCKS5_HOSTNAME)
        c.setopt(pycurl.PROXY, f"{self.proxy_host}:{self.proxy_port}")
        c.setopt(pycurl.CONNECTTIMEOUT, self.connect_timeout_sec)
        c.setopt(pycurl.TIMEOUT, self.timeout_sec)
        c.setopt(pycurl.NOPROGRESS, 1)
        c.setopt(pycurl.USERAGENT, self.user_agent)
        c.setopt(pycurl.FOLLOWLOCATION, 1)
        c.setopt(pycurl.MAXREDIRS, 5)

        if self.insecure_tls:
            c.setopt(pycurl.SSL_VERIFYPEER, 0)
            c.setopt(pycurl.SSL_VERIFYHOST, 0)

    def _head(self, url: str, link_id: str, socks_password: str) -> tuple[int, Optional[str]]:
        c = pycurl.Curl()
        try:
            c.setopt(pycurl.URL, url)
            self._apply_common_curl_options(c)
            c.setopt(pycurl.NOBODY, 1)
            c.setopt(pycurl.PROXYUSERNAME, link_id)
            c.setopt(pycurl.PROXYPASSWORD, socks_password)
            c.perform()

            http_code = int(c.getinfo(pycurl.RESPONSE_CODE))
            if http_code < 200 or http_code >= 400:
                raise RuntimeError(f"HEAD HTTP {http_code}")

            content_length = int(c.getinfo(pycurl.CONTENT_LENGTH_DOWNLOAD))
            # Accept-Ranges 可能不被 pycurl 直接暴露；这里保留空。
            accept_ranges = None
            return content_length, accept_ranges
        finally:
            c.close()

    def _download_part(
        self,
        url: str,
        part_path: str,
        start: int,
        end: int,
        link_id: str,
        socks_password: str,
    ) -> PartDownloadResult:
        t0 = time.time()
        http_code = 0
        bytes_downloaded = 0
        try:
            os.makedirs(os.path.dirname(part_path) or ".", exist_ok=True)
            with open(part_path, "wb") as f:
                c = pycurl.Curl()
                try:
                    c.setopt(pycurl.URL, url)
                    self._apply_common_curl_options(c)
                    c.setopt(pycurl.WRITEDATA, f)
                    c.setopt(pycurl.RANGE, f"{start}-{end}")
                    c.setopt(pycurl.PROXYUSERNAME, link_id)
                    c.setopt(pycurl.PROXYPASSWORD, socks_password)
                    c.perform()
                    http_code = int(c.getinfo(pycurl.RESPONSE_CODE))
                    bytes_downloaded = int(c.getinfo(pycurl.SIZE_DOWNLOAD))

                    # Range 正常是 206；部分服务会返回 200（忽略 Range）。
                    if http_code not in (200, 206):
                        raise RuntimeError(f"GET(range) HTTP {http_code}")
                finally:
                    c.close()

            elapsed_ms = int((time.time() - t0) * 1000)
            expected = (end - start) + 1
            if http_code == 206 and bytes_downloaded != expected:
                raise RuntimeError(f"range bytes mismatch: expected {expected}, got {bytes_downloaded}")

            return PartDownloadResult(
                index=-1,
                start=start,
                end=end,
                link_id=link_id,
                part_path=part_path,
                http_code=http_code,
                bytes_downloaded=bytes_downloaded,
                elapsed_ms=elapsed_ms,
                success=True,
            )
        except Exception as e:
            elapsed_ms = int((time.time() - t0) * 1000)
            return PartDownloadResult(
                index=-1,
                start=start,
                end=end,
                link_id=link_id,
                part_path=part_path,
                http_code=http_code,
                bytes_downloaded=bytes_downloaded,
                elapsed_ms=elapsed_ms,
                success=False,
                error=str(e),
            )

    def download(
        self,
        url: str,
        output_path: str,
        parts: int,
        link_ids: Sequence[str],
        request_id: Optional[str] = None,
        tmp_dir: Optional[str] = None,
    ) -> MultipathDownloadResult:
        if parts <= 0:
            raise ValueError("parts must be >= 1")
        if not link_ids:
            raise ValueError("link_ids is required")

        request_id = request_id or uuid.uuid4().hex
        t0 = time.time()

        # 用第一个 link 做 HEAD（仅用于拿长度）。
        head_pwd = f"{request_id}:head"
        total_size, accept_ranges = self._head(url, link_ids[0], head_pwd)
        if total_size <= 0:
            raise RuntimeError(f"invalid content-length: {total_size}")

        tmp_dir = tmp_dir or (output_path + ".parts")
        os.makedirs(tmp_dir, exist_ok=True)

        # 计算 ranges
        base = total_size // parts
        rem = total_size % parts
        ranges: list[tuple[int, int]] = []
        cursor = 0
        for i in range(parts):
            seg = base + (1 if i < rem else 0)
            start = cursor
            end = cursor + seg - 1
            ranges.append((start, end))
            cursor = end + 1

        max_workers = self.max_parallel or parts
        max_workers = max(1, min(int(max_workers), parts))

        part_results: list[PartDownloadResult] = []
        futures = []
        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            for i, (start, end) in enumerate(ranges):
                link_id = link_ids[i % len(link_ids)]
                pwd = f"{request_id}:{i}"
                part_path = os.path.join(tmp_dir, f"part-{i:04d}.bin")
                fut = ex.submit(self._download_part, url, part_path, start, end, link_id, pwd)
                futures.append((i, fut))

            for i, fut in futures:
                r = fut.result()
                r.index = i
                part_results.append(r)

        part_results.sort(key=lambda x: x.index)
        any_fail = any(not p.success for p in part_results)
        if any_fail:
            elapsed_ms = int((time.time() - t0) * 1000)
            return MultipathDownloadResult(
                request_id=request_id,
                url=url,
                output_path=output_path,
                total_size=total_size,
                parts=parts,
                accept_ranges=accept_ranges,
                elapsed_ms=elapsed_ms,
                success=False,
                error="one or more parts failed",
                part_results=part_results,
            )

        # 合并
        os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
        with open(output_path, "wb") as out:
            for p in part_results:
                with open(p.part_path, "rb") as pf:
                    while True:
                        chunk = pf.read(1024 * 1024)
                        if not chunk:
                            break
                        out.write(chunk)

        final_size = os.path.getsize(output_path)
        elapsed_ms = int((time.time() - t0) * 1000)
        if final_size != total_size:
            return MultipathDownloadResult(
                request_id=request_id,
                url=url,
                output_path=output_path,
                total_size=total_size,
                parts=parts,
                accept_ranges=accept_ranges,
                elapsed_ms=elapsed_ms,
                success=False,
                error=f"merged size mismatch: expected {total_size}, got {final_size}",
                part_results=part_results,
            )

        return MultipathDownloadResult(
            request_id=request_id,
            url=url,
            output_path=output_path,
            total_size=total_size,
            parts=parts,
            accept_ranges=accept_ranges,
            elapsed_ms=elapsed_ms,
            success=True,
            error=None,
            part_results=part_results,
        )
