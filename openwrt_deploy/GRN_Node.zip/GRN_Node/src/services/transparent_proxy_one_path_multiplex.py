"""Transparent proxy integration backed by sing-box.

This module intentionally keeps only the sing-box based implementation.  The
old in-process TCP relay/proxy has been removed for this branch.
"""

import asyncio
import copy
import json
import logging
import os
import signal
import urllib.error
import urllib.parse
import urllib.request
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, Optional, Set

import utils.logger
from config.config import SingBoxConfig

PROXY_MODE_DIRECT = "direct"
PROXY_MODE_SOCKS = "socks"
PROXY_MODE_MPTCP = "mptcp"

SINGBOX_OUT_DIRECT = SingBoxConfig.DIRECT_OUTBOUND_TAG
SINGBOX_OUT_SOCKS = SingBoxConfig.SOCKS_OUTBOUND_TAG
SINGBOX_OUT_MPTCP = SingBoxConfig.MPTCP_OUTBOUND_TAG
SINGBOX_SELECTOR_TAG = SingBoxConfig.SELECTOR_TAG
SINGBOX_CLASH_API = SingBoxConfig.clash_api_url()
SINGBOX_CLASH_SECRET = SingBoxConfig.CLASH_API_SECRET
SINGBOX_UUID = SingBoxConfig.UUID
SINGBOX_CONFIG_DIR = Path(SingBoxConfig.RUNTIME_CONFIG_DIR)

_client_run_role: str = "vps"
_client_singbox_proxy: Optional["SingBoxProxy"] = None


def set_client_proxy_role(run_role: str) -> None:
    global _client_run_role, _client_singbox_proxy
    _client_run_role = str(run_role or "vps").strip().lower() or "vps"
    if _client_singbox_proxy is not None:
        _client_singbox_proxy.run_role = _client_run_role


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _load_json_config(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def _write_json_config(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
        fh.write("\n")


def _replace_placeholder_uuid(data: Any) -> Any:
    if isinstance(data, dict):
        return {key: _replace_placeholder_uuid(value) for key, value in data.items()}
    if isinstance(data, list):
        return [_replace_placeholder_uuid(value) for value in data]
    if data == "UUID":
        return SINGBOX_UUID
    return data


def _is_project_runtime_config(path: Path) -> bool:
    runtime_dir = Path(SingBoxConfig.RUNTIME_CONFIG_DIR).resolve()
    config_path = path.resolve()
    if runtime_dir not in config_path.parents:
        return False
    name = config_path.name
    return name in ("client_singbox.runtime.json", "server_singbox.runtime.json") or (
        name.startswith("server_singbox.") and name.endswith(".runtime.json")
    )


def _extract_singbox_config_arg(args: list[str]) -> Optional[Path]:
    if not args or Path(args[0]).name != Path(SingBoxConfig.BINARY).name:
        return None
    if "run" not in args:
        return None
    for index, arg in enumerate(args):
        if arg in ("-c", "--config") and index + 1 < len(args):
            return Path(args[index + 1])
        if arg.startswith("-c="):
            return Path(arg[3:])
        if arg.startswith("--config="):
            return Path(arg.split("=", 1)[1])
    return None


def _read_process_cmdline(pid: int) -> list[str]:
    try:
        raw = Path("/proc") / str(pid) / "cmdline"
        return [
            part.decode("utf-8", errors="replace")
            for part in raw.read_bytes().split(b"\0")
            if part
        ]
    except OSError:
        return []


def _iter_project_singbox_processes() -> list[tuple[int, Path]]:
    processes: list[tuple[int, Path]] = []
    proc_dir = Path("/proc")
    if not proc_dir.exists():
        return processes
    for entry in proc_dir.iterdir():
        if not entry.name.isdigit():
            continue
        pid = int(entry.name)
        if pid == os.getpid():
            continue
        config_path = _extract_singbox_config_arg(_read_process_cmdline(pid))
        if config_path is None or not _is_project_runtime_config(config_path):
            continue
        processes.append((pid, config_path.resolve()))
    return processes


def _config_listen_endpoints(config: dict[str, Any]) -> set[tuple[str, int]]:
    endpoints: set[tuple[str, int]] = set()
    for inbound in config.get("inbounds", []):
        try:
            port = int(inbound.get("listen_port") or 0)
        except (TypeError, ValueError):
            port = 0
        if port:
            endpoints.add((str(inbound.get("listen") or "0.0.0.0"), port))

    clash_api = config.get("experimental", {}).get("clash_api", {})
    controller = str(clash_api.get("external_controller") or "")
    host, separator, port_text = controller.rpartition(":")
    if separator:
        try:
            port = int(port_text)
        except ValueError:
            port = 0
        if port:
            endpoints.add((host or "0.0.0.0", port))
    return endpoints


def _endpoint_conflicts(
    first: set[tuple[str, int]],
    second: set[tuple[str, int]],
) -> bool:
    wildcard_hosts = {"", "0.0.0.0", "::"}
    for first_host, first_port in first:
        for second_host, second_port in second:
            if first_port != second_port:
                continue
            if (
                first_host == second_host
                or first_host in wildcard_hosts
                or second_host in wildcard_hosts
            ):
                return True
    return False


def _load_runtime_listen_endpoints(path: Path) -> set[tuple[str, int]]:
    try:
        return _config_listen_endpoints(_load_json_config(path))
    except (OSError, json.JSONDecodeError):
        return set()


class SingBoxProxy:
    """Run sing-box from repository templates and control selector outbound."""

    def __init__(
        self,
        role: str,
        template_path: Path,
        runtime_path: Path,
        run_role: Optional[str] = None,
    ) -> None:
        self.role = role
        self.template_path = template_path
        self.runtime_path = runtime_path
        self.run_role = str(run_role if run_role is not None else _client_run_role).strip().lower() or "vps"
        self.logger = utils.logger.get_logger(f"SingBoxProxy[{role}]")
        self._proc: Optional[asyncio.subprocess.Process] = None
        self._server_addr: str = ""
        self._server_port: int = 0
        self._socks_host: str = SingBoxConfig.DEFAULT_SOCKS_HOST
        self._socks_port: int = SingBoxConfig.DEFAULT_SOCKS_PORT
        self._log_tasks: Set[asyncio.Task] = set()
        self._process_logger: Optional[logging.Logger] = None

    @property
    def is_running(self) -> bool:
        return self._proc is not None and self._proc.returncode is None

    async def start_client(
        self,
        server_addr: str = "",
        server_port: int = 0,
        socks_host: str = SingBoxConfig.DEFAULT_SOCKS_HOST,
        socks_port: int = SingBoxConfig.DEFAULT_SOCKS_PORT,
    ) -> None:
        self._server_addr = server_addr or self._server_addr
        self._server_port = server_port or self._server_port
        self._socks_host = socks_host
        self._socks_port = int(socks_port)
        await self._restart(self._build_client_config())

    async def start_server(
        self,
        listen_hosts: list[str],
        listen_port: int = 0,
    ) -> None:
        await self._restart(
            self._build_server_config(listen_hosts=listen_hosts, listen_port=listen_port)
        )

    async def stop(self) -> None:
        proc = self._proc
        self._proc = None
        if proc is not None and proc.returncode is None:
            proc.terminate()
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
        await self._wait_log_tasks()
        self._close_process_logger()
        self.logger.info("sing-box stopped")

    async def switch_outbound(self, outbound: str) -> None:
        if not self.is_running:
            raise RuntimeError("sing-box is not running")

        await self._clash_put_proxy(SINGBOX_SELECTOR_TAG, outbound)
        self.logger.info("sing-box selector switched to %s", outbound)

    async def _clash_put_proxy(self, group_tag: str, outbound: str) -> None:
        payload = json.dumps({"name": outbound}).encode("utf-8")
        url = f"{SINGBOX_CLASH_API}/proxies/{urllib.parse.quote(group_tag, safe='')}"

        def _request() -> None:
            req = urllib.request.Request(
                url,
                data=payload,
                method="PUT",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {SINGBOX_CLASH_SECRET}",
                },
            )
            with urllib.request.urlopen(req, timeout=3) as resp:
                if resp.status not in (200, 204):
                    raise RuntimeError(
                        f"sing-box proxy switch failed: group={group_tag} "
                        f"target={outbound} status={resp.status}"
                    )

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, _request)

    def _use_legacy_inbound_sniff(self) -> bool:
        return self.run_role == "openwrt"

    def _use_route_rule_sniff(self) -> bool:
        return self.run_role == "vps"

    @staticmethod
    def _strip_inbound_sniff_fields(inbound: dict[str, Any]) -> None:
        inbound.pop("sniff", None)
        inbound.pop("sniff_override_destination", None)
        inbound.pop("sniff_timeout", None)

    def _apply_legacy_inbound_sniff(self, inbound: dict[str, Any]) -> None:
        inbound["sniff"] = True
        inbound["sniff_override_destination"] = bool(
            SingBoxConfig.CLIENT_SNIFF_OVERRIDE_DESTINATION
        )
        inbound["sniff_timeout"] = SingBoxConfig.CLIENT_SNIFF_TIMEOUT

    def _apply_route_rule_sniff(self, config: dict[str, Any], inbound_tag: str) -> None:
        route = config.setdefault("route", {})
        rules = [
            rule
            for rule in list(route.get("rules") or [])
            if not (
                isinstance(rule, dict)
                and rule.get("action") == "sniff"
                and (
                    rule.get("inbound") in (None, inbound_tag, [inbound_tag])
                    or inbound_tag in (rule.get("inbound") or [])
                )
            )
        ]
        rules.insert(
            0,
            {
                "inbound": inbound_tag,
                "action": "sniff",
                "timeout": SingBoxConfig.CLIENT_SNIFF_TIMEOUT,
            },
        )
        route["rules"] = rules

    def _apply_client_redirect_sniff(
        self, inbound: dict[str, Any], config: dict[str, Any]
    ) -> None:
        if not SingBoxConfig.CLIENT_SNIFF_ENABLED:
            self._strip_inbound_sniff_fields(inbound)
            return
        if self._use_legacy_inbound_sniff():
            self._apply_legacy_inbound_sniff(inbound)
            return
        if self._use_route_rule_sniff():
            self._strip_inbound_sniff_fields(inbound)
            self._apply_route_rule_sniff(config, SingBoxConfig.CLIENT_INBOUND_TAG)
            return
        self._strip_inbound_sniff_fields(inbound)

    def _build_client_config(self) -> dict[str, Any]:
        config = _replace_placeholder_uuid(copy.deepcopy(_load_json_config(self.template_path)))
        self._apply_common_config(config)
        for inbound in config.get("inbounds", []):
            if (
                inbound.get("tag") == SingBoxConfig.CLIENT_INBOUND_TAG
                or inbound.get("type") == "redirect"
            ):
                inbound["tag"] = SingBoxConfig.CLIENT_INBOUND_TAG
                inbound["listen"] = SingBoxConfig.CLIENT_LISTEN_HOST
                inbound["listen_port"] = SingBoxConfig.CLIENT_LISTEN_PORT
                self._apply_client_redirect_sniff(inbound, config)

        for outbound in config.get("outbounds", []):
            tag = str(outbound.get("tag") or "")
            outbound_type = outbound.get("type")
            if tag == SINGBOX_OUT_DIRECT or outbound_type == "direct":
                outbound["tag"] = SingBoxConfig.DIRECT_OUTBOUND_TAG
                outbound["type"] = "direct"
            elif tag == SINGBOX_OUT_MPTCP or outbound_type == "vless":
                # 单路主连接：mptcp-tunnel → 10.0.1.1（或 bridge 下发的对端 IP）
                outbound["tag"] = SingBoxConfig.MPTCP_OUTBOUND_TAG
                outbound["type"] = "vless"
                if self._server_addr:
                    outbound["server"] = self._server_addr
                outbound["server_port"] = self._server_port or SingBoxConfig.SERVER_LISTEN_PORT
                outbound["connect_timeout"] = SingBoxConfig.DEFAULT_CONNECT_TIMEOUT
                outbound["tcp_multi_path"] = True
                outbound.pop("tcp_keep_alive", None)
                outbound.pop("tcp_keep_alive_interval", None)
            elif tag == SINGBOX_OUT_SOCKS or outbound_type == "socks":
                outbound["tag"] = SingBoxConfig.SOCKS_OUTBOUND_TAG
                outbound["server"] = self._socks_host
                outbound["server_port"] = self._socks_port
        return config

    def _build_server_config(
        self,
        listen_hosts: list[str],
        listen_port: int = 0,
    ) -> dict[str, Any]:
        config = _replace_placeholder_uuid(copy.deepcopy(_load_json_config(self.template_path)))
        self._apply_common_config(config)
        server_inbounds = [
            inbound
            for inbound in config.get("inbounds", [])
            if (
                str(inbound.get("tag") or "").startswith(SingBoxConfig.SERVER_INBOUND_TAG)
                or inbound.get("type") == "vless"
            )
        ]
        if not server_inbounds:
            return config

        hosts = list(dict.fromkeys(str(host) for host in listen_hosts if str(host)))
        if not hosts:
            hosts = [SingBoxConfig.SERVER_LISTEN_HOST]

        inbound_template = server_inbounds[0]
        generated_inbounds: list[dict[str, Any]] = []
        for index, host in enumerate(hosts):
            inbound = copy.deepcopy(inbound_template)
            inbound["tag"] = f"{SingBoxConfig.SERVER_INBOUND_TAG}{index + 1}"
            inbound["listen"] = host
            inbound["listen_port"] = listen_port or SingBoxConfig.SERVER_LISTEN_PORT
            inbound["tcp_multi_path"] = True
            inbound.pop("tcp_keep_alive", None)
            inbound.pop("tcp_keep_alive_interval", None)
            generated_inbounds.append(inbound)

        config["inbounds"] = [
            inbound
            for inbound in config.get("inbounds", [])
            if inbound not in server_inbounds
        ] + generated_inbounds
        self.logger.info(
            "server sing-box inbounds: %s",
            ",".join(
                f"{item.get('tag')}@{item.get('listen')}:{item.get('listen_port')}"
                for item in generated_inbounds
            ),
        )
        return config

    def _apply_common_config(self, config: dict[str, Any]) -> None:
        config.setdefault("log", {})["level"] = SingBoxConfig.LOG_LEVEL
        clash_api = config.setdefault("experimental", {}).setdefault("clash_api", {})
        if self.role == "client":
            clash_api["external_controller"] = (
                f"{SingBoxConfig.CLASH_API_HOST}:{SingBoxConfig.CLASH_API_PORT}"
            )
            clash_api["secret"] = SingBoxConfig.CLASH_API_SECRET
        elif "experimental" in config:
            config.pop("experimental", None)

        for outbound in config.get("outbounds", []):
            if outbound.get("type") == "selector":
                outbound["tag"] = SingBoxConfig.SELECTOR_TAG
                outbound["outbounds"] = [
                    SingBoxConfig.DIRECT_OUTBOUND_TAG,
                    SingBoxConfig.MPTCP_OUTBOUND_TAG,
                    SingBoxConfig.SOCKS_OUTBOUND_TAG,
                ]
                outbound["default"] = SingBoxConfig.DIRECT_OUTBOUND_TAG

    async def _restart(self, config: dict[str, Any]) -> None:
        await self.stop()
        await self._cleanup_conflicting_processes(config)
        _write_json_config(self.runtime_path, config)
        log_path = self._log_path()
        self._process_logger = self._create_process_logger(log_path)
        self._proc = await asyncio.create_subprocess_exec(
            SingBoxConfig.BINARY,
            "run",
            "-c",
            str(self.runtime_path),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        if self._proc.stdout is not None:
            self._track_log_task(self._pump_process_log(self._proc.stdout))

        await asyncio.sleep(0.3)
        if self._proc.returncode is not None:
            await self._wait_log_tasks()
            self._close_process_logger()
            detail = self._tail_process_log(log_path, max_lines=30)
            if detail:
                self.logger.error("sing-box early exit log tail:\n%s", detail)
            raise RuntimeError(
                f"sing-box exited early with code {self._proc.returncode}"
                + (f": {detail.splitlines()[-1]}" if detail else "")
            )

        self.logger.info(
            "sing-box started with config %s, log=%s",
            self.runtime_path,
            log_path,
        )

    @staticmethod
    def _tail_process_log(log_path: Path, max_lines: int = 30) -> str:
        try:
            if not log_path.is_file():
                return ""
            lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
            return "\n".join(lines[-max_lines:]).strip()
        except OSError:
            return ""

    async def _cleanup_conflicting_processes(self, config: dict[str, Any]) -> None:
        expected_path = self.runtime_path.resolve()
        expected_endpoints = _config_listen_endpoints(config)
        for pid, config_path in _iter_project_singbox_processes():
            if self._proc is not None and self._proc.pid == pid:
                continue
            is_project_server = (
                self.role == "server"
                and config_path.name.startswith("server_singbox")
                and config_path.name.endswith(".runtime.json")
            )
            if (
                not is_project_server
                and config_path != expected_path
                and not _endpoint_conflicts(
                    expected_endpoints,
                    _load_runtime_listen_endpoints(config_path),
                )
            ):
                continue

            self.logger.warning(
                "terminating stale/conflicting sing-box process pid=%s config=%s",
                pid,
                config_path,
            )
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                continue
            except OSError as exc:
                self.logger.error("failed to terminate sing-box pid=%s: %s", pid, exc)
                continue

            for _ in range(30):
                if not Path("/proc", str(pid)).exists():
                    break
                await asyncio.sleep(0.1)
            else:
                try:
                    os.kill(pid, signal.SIGKILL)
                except ProcessLookupError:
                    continue
                except OSError as exc:
                    self.logger.error("failed to kill sing-box pid=%s: %s", pid, exc)
                    continue
                self.logger.warning("killed stale/conflicting sing-box process pid=%s", pid)

    def _log_path(self) -> Path:
        if self.role == "client":
            return Path(SingBoxConfig.LOG_DIR) / "client.log"
        return Path(SingBoxConfig.LOG_DIR) / "server.log"

    def _create_process_logger(self, log_path: Path) -> logging.Logger:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        logger = logging.getLogger(f"SingBoxProcess[{self.role}]")
        logger.setLevel(getattr(logging, SingBoxConfig.LOG_LEVEL.upper()))
        logger.propagate = False
        for handler in list(logger.handlers):
            if getattr(handler, "_grn_singbox_handler", False):
                logger.removeHandler(handler)
                handler.close()

        handler = RotatingFileHandler(
            filename=str(log_path),
            mode="a",
            maxBytes=int(SingBoxConfig.LOG_MAX_BYTES),
            backupCount=int(SingBoxConfig.LOG_BACKUP_COUNT),
            encoding="utf-8",
        )
        handler.setFormatter(logging.Formatter("%(message)s"))
        handler._grn_singbox_handler = True
        logger.addHandler(handler)
        return logger

    def _track_log_task(self, coroutine) -> None:
        task = asyncio.create_task(coroutine)
        self._log_tasks.add(task)
        task.add_done_callback(self._log_tasks.discard)

    async def _wait_log_tasks(self) -> None:
        tasks = [task for task in self._log_tasks if not task.done()]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _pump_process_log(self, reader: asyncio.StreamReader) -> None:
        logger = self._process_logger
        if logger is None:
            return
        try:
            while True:
                line = await reader.readline()
                if not line:
                    break
                logger.info(line.decode("utf-8", errors="replace").rstrip())
        except Exception as exc:
            self.logger.warning("failed to pump sing-box process log: %s", exc)

    def _close_process_logger(self) -> None:
        logger = self._process_logger
        self._process_logger = None
        if logger is None:
            return
        for handler in list(logger.handlers):
            if getattr(handler, "_grn_singbox_handler", False):
                logger.removeHandler(handler)
                handler.close()


async def start_client_singbox_proxy(
    server_connect_addr: str = "",
    server_proxy_port: int = 0,
    socks_host: str = SingBoxConfig.DEFAULT_SOCKS_HOST,
    socks_port: int = SingBoxConfig.DEFAULT_SOCKS_PORT,
) -> SingBoxProxy:
    """Start or restart the client-side sing-box transparent proxy."""
    global _client_singbox_proxy
    if _client_singbox_proxy is None:
        _client_singbox_proxy = SingBoxProxy(
            role="client",
            template_path=_repo_root() / SingBoxConfig.CLIENT_TEMPLATE_PATH,
            runtime_path=SINGBOX_CONFIG_DIR / "client_singbox.runtime.json",
            run_role=_client_run_role,
        )
    else:
        _client_singbox_proxy.run_role = _client_run_role
    await _client_singbox_proxy.start_client(
        server_addr=server_connect_addr,
        server_port=server_proxy_port or 0,
        socks_host=socks_host,
        socks_port=socks_port,
    )
    return _client_singbox_proxy


async def ensure_client_transparent_proxy(
    server_connect_addr: str = "",
    server_proxy_port: int = 0,
    socks_host: str = SingBoxConfig.DEFAULT_SOCKS_HOST,
    socks_port: int = SingBoxConfig.DEFAULT_SOCKS_PORT,
) -> None:
    """Start the client-side sing-box transparent proxy."""
    await start_client_singbox_proxy(
        server_connect_addr=server_connect_addr,
        server_proxy_port=server_proxy_port,
        socks_host=socks_host,
        socks_port=socks_port,
    )


async def start_server_singbox_proxy(
    listen_hosts: list[str],
    listen_port: int = 0,
) -> SingBoxProxy:
    """Start a server-side sing-box tunnel listener."""
    proxy = SingBoxProxy(
        role="server",
        template_path=_repo_root() / SingBoxConfig.SERVER_TEMPLATE_PATH,
        runtime_path=SINGBOX_CONFIG_DIR / "server_singbox.runtime.json",
    )
    await proxy.start_server(listen_hosts=listen_hosts, listen_port=listen_port)
    return proxy


async def _switch_singbox_client_outbound(outbound: str) -> None:
    if _client_singbox_proxy is None or not _client_singbox_proxy.is_running:
        raise RuntimeError("sing-box is not running")
    try:
        await _client_singbox_proxy.switch_outbound(outbound)
    except (urllib.error.URLError, TimeoutError, RuntimeError, OSError) as exc:
        _client_singbox_proxy.logger.error(
            "failed to switch sing-box selector to %s: %s", outbound, exc
        )
        raise RuntimeError(f"failed to switch sing-box selector to {outbound}") from exc


def derive_server_addr(server_tunnels: list[dict[str, Any]]) -> str:
    """取 server_tunnels 首个 TUN IP，作为单路主连接目标（通常 10.0.1.1）。"""
    if not server_tunnels:
        return ""
    first_cidr = str(server_tunnels[0].get("tun_addr_cidr") or "").strip()
    if not first_cidr:
        return ""
    from services import mptcp_config as _mptcp  # noqa

    return _mptcp.ip_from_cidr(first_cidr) or ""


def derive_server_addrs(server_tunnels: list[dict[str, Any]]) -> list[str]:
    """从 server_tunnels 提取各 TUN IP，供多路 mptcp-path-* 主连接使用。"""
    if not server_tunnels:
        return []
    from services import mptcp_config as _mptcp  # noqa

    addrs: list[str] = []
    for tunnel in server_tunnels:
        cidr = str(tunnel.get("tun_addr_cidr") or "").strip()
        if not cidr:
            continue
        ip = _mptcp.ip_from_cidr(cidr)
        if ip and ip not in addrs:
            addrs.append(ip)
    return addrs


def derive_peer_addrs(local_tunnels: list[dict[str, Any]]) -> list[str]:
    """从本机 tunnel CIDR 推导对端 IP：10.0.x.2 → 10.0.x.1，10.0.x.1 → 10.0.x.2。"""
    if not local_tunnels:
        return []
    from services import mptcp_config as _mptcp  # noqa

    peers: list[str] = []
    for tunnel in local_tunnels:
        cidr = str(tunnel.get("tun_addr_cidr") or "").strip()
        if not cidr:
            continue
        ip = _mptcp.ip_from_cidr(cidr)
        if not ip:
            continue
        parts = ip.split(".")
        if len(parts) != 4:
            continue
        try:
            last = int(parts[3])
        except ValueError:
            continue
        if last == 2:
            peer = f"{parts[0]}.{parts[1]}.{parts[2]}.1"
        elif last == 1:
            peer = f"{parts[0]}.{parts[1]}.{parts[2]}.2"
        else:
            continue
        if peer not in peers:
            peers.append(peer)
    return peers


async def switch_proxy_to_socks(
    host: str = SingBoxConfig.DEFAULT_SOCKS_HOST,
    port: int = SingBoxConfig.DEFAULT_SOCKS_PORT,
) -> None:
    """Switch the client sing-box selector to the SOCKS outbound."""
    logger = utils.logger.get_logger("SingBoxProxy[client]")
    try:
        if _client_singbox_proxy is None or not _client_singbox_proxy.is_running:
            await ensure_client_transparent_proxy(socks_host=host, socks_port=port)
        await _switch_singbox_client_outbound(SINGBOX_OUT_SOCKS)
    except Exception as exc:
        logger.error("failed to switch sing-box selector to socks5: %s", exc)
        raise


async def switch_proxy_to_mptcp(
    server_connect_addr: str = "",
    server_proxy_port: int = 0,
) -> None:
    """Switch the client sing-box selector to the single MPTCP tunnel outbound."""
    logger = utils.logger.get_logger("SingBoxProxy[client]")
    try:
        addr = str(server_connect_addr or "").strip()
        port = server_proxy_port or SingBoxConfig.SERVER_LISTEN_PORT
        if _client_singbox_proxy is None or not _client_singbox_proxy.is_running:
            await ensure_client_transparent_proxy(
                server_connect_addr=addr,
                server_proxy_port=port,
            )
        elif (
            _client_singbox_proxy._server_addr != addr
            or _client_singbox_proxy._server_port != port
        ):
            await _client_singbox_proxy.start_client(
                server_addr=addr,
                server_port=port,
                socks_host=_client_singbox_proxy._socks_host,
                socks_port=_client_singbox_proxy._socks_port,
            )
        elif addr:
            _client_singbox_proxy._server_addr = addr
            _client_singbox_proxy._server_port = port

        await _switch_singbox_client_outbound(SINGBOX_OUT_MPTCP)
    except Exception as exc:
        logger.error("failed to switch sing-box selector to mptcp-tunnel: %s", exc)
        raise


async def switch_proxy_to_direct() -> None:
    """Switch the client sing-box selector to direct outbound."""
    logger = utils.logger.get_logger("SingBoxProxy[client]")
    try:
        if _client_singbox_proxy is None or not _client_singbox_proxy.is_running:
            await ensure_client_transparent_proxy()
        await _switch_singbox_client_outbound(SINGBOX_OUT_DIRECT)
    except Exception as exc:
        logger.error("failed to switch sing-box selector to direct: %s", exc)
        raise


async def stop_client_proxy() -> None:
    """Stop the client-side sing-box proxy."""
    global _client_singbox_proxy
    if _client_singbox_proxy is not None:
        await _client_singbox_proxy.stop()
        _client_singbox_proxy = None
