from typing import Any, Dict, List, Optional, Set, Tuple

from generated import vps_management_pb2
from config.config import LinkType
import utils.logger

# grn_link.link_status
LINK_STATUS_NORMAL = 1
LINK_STATUS_CREATING = 2
LINK_STATUS_DESTROYING = 4


class NodeInitSyncService:
    """断线重连后通过 InitNodeSync 拉取管理面期望态并对账。"""

    def __init__(self, context, reporter, node_service, relay_service, link_service):
        self.context = context
        self.reporter = reporter
        self.node_service = node_service
        self.relay_service = relay_service
        self.link_service = link_service
        self.logger = utils.logger.get_logger(self.__class__.__name__)

    async def sync_after_reconnect(self, stub) -> bool:
        request = vps_management_pb2.InitNodeSyncRequest(
            node_code=self.context.node_code,
            local_relay_codes=[
                relay.relay_code for relay in self.context.relays.values()
            ],
        )
        self._attach_local_link_ids(request)

        try:
            response = await stub.InitNodeSync(request)
        except Exception as exc:
            self.logger.error(f"InitNodeSync 调用失败: {exc}")
            return False

        if not response.success:
            self.logger.error(f"InitNodeSync 失败: {response.message}")
            return False

        links = list(getattr(response, "links", []))
        self.logger.info(
            "InitNodeSync 成功 | sync_at=%s, da=%d, relay=%d, link=%d",
            response.sync_at,
            len(response.da_list),
            len(response.expected_relays),
            len(links),
        )

        await self._reconcile_da(list(response.da_list))
        await self._reconcile_relays(list(response.expected_relays))
        if links:
            await self._reconcile_links(links)
        await self.reporter.report_relay_info()
        return True

    def _attach_local_link_ids(self, request: vps_management_pb2.InitNodeSyncRequest) -> None:
        if not hasattr(request, "local_link_ids"):
            return
        for link_id in self.link_service.active_link_ids():
            try:
                request.local_link_ids.append(int(link_id))
            except (TypeError, ValueError):
                continue

    async def _reconcile_da(self, da_list: List[vps_management_pb2.DAInfo]) -> None:
        remote_dir_auth = [self._da_info_to_dir_auth(da) for da in da_list]
        if not self._is_da_consistent(self.context.dir_auth, remote_dir_auth):
            self.logger.info(
                "InitNodeSync DA 不一致，更新本地 dir_auth（共 %d 条）",
                len(remote_dir_auth),
            )
            await self.node_service.update_da_info(remote_dir_auth)
        else:
            self.logger.info("InitNodeSync DA 与本地一致，跳过更新")

    async def _reconcile_relays(
        self, expected_relays: List[vps_management_pb2.Relay]
    ) -> None:
        expected_by_code = {
            relay.relay_code: relay
            for relay in expected_relays
            if relay.relay_code
        }
        relays_to_destroy: Set[str] = set()

        for relay_code in list(self.context.relays.keys()):
            expected_relay = expected_by_code.get(relay_code)
            if self._should_destroy_local_relay(relay_code, expected_relay):
                relays_to_destroy.add(relay_code)
                continue

            local_relay = self.context.relays.get(relay_code)
            if local_relay and expected_relay and self._relay_attributes_mismatch(
                local_relay, expected_relay
            ):
                relays_to_destroy.add(relay_code)

        if not relays_to_destroy:
            self.logger.info("InitNodeSync Relay 与本地一致，无需销毁")
            return

        self.logger.warning(
            "InitNodeSync 销毁不一致 Relay: %s", sorted(relays_to_destroy)
        )

        #使用 self.relay_service.cleanup_data() 清理数据
        # try:
        #     success, destroyed_relays, link_cleanup = await self.relay_service.cleanup_data()
        #     if success:
        #         link_msg = ""
        #         if not link_cleanup.get("skipped"):
        #             link_msg = f"，已清理 {link_cleanup.get('deleted_circuits_count', 0)} 条电路相关资源"
        #         self.logger.info(f"清理数据成功，已销毁 {len(destroyed_relays)} 个中继{link_msg}")
        #     else:
        #         self.logger.warning(f"清理数据部分失败，已销毁 {len(destroyed_relays)} 个中继")
        # except Exception as e:
        #     self.logger.error(f"清理数据失败: {e}")

        for relay_code in sorted(relays_to_destroy):
            await self.relay_service.destroy_relay(relay_code)

    async def _reconcile_links(
        self, link_snapshots: List[Any]
    ) -> None:
        expected_ids = self._collect_expected_link_ids(link_snapshots)
        local_ids = set(self.link_service.active_link_ids())

        orphan_ids = local_ids - expected_ids
        if orphan_ids:
            self.logger.warning(
                "InitNodeSync 清理 orphan 链路: %s", sorted(orphan_ids)
            )
            for link_id in sorted(orphan_ids):
                client_relay_code = self.link_service.find_client_relay_for_link(
                    link_id
                )
                if client_relay_code:
                    await self.link_service.delete_circuit(
                        link_id, client_relay_code
                    )

        for snapshot in link_snapshots:
            await self._reconcile_link_snapshot(snapshot)

    async def _reconcile_link_snapshot(self, snapshot: Any) -> None:
        link_id = str(snapshot.link_id)
        link_status = int(snapshot.link_status)
        client_relay_code = str(snapshot.client_relay_code or "")

        if link_status == LINK_STATUS_DESTROYING:
            if self.link_service.has_local_link(link_id):
                await self._delete_link_snapshot(snapshot)
            return

        if link_status not in (LINK_STATUS_NORMAL, LINK_STATUS_CREATING):
            return

        path_type = int(snapshot.path_type or LinkType.SINGLE_LINK)
        if path_type == LinkType.MULTI_LINK and snapshot.sub_links:
            for sub_link in snapshot.sub_links:
                await self._ensure_sub_link(snapshot, sub_link)
            return

        await self._ensure_single_link(
            link_id=link_id,
            client_relay_code=client_relay_code,
            relay_fingerprints=list(snapshot.relay_fingerprints),
        )

    async def _ensure_sub_link(self, parent_snapshot: Any, sub_link: Any) -> None:
        sub_link_id = str(sub_link.link_id)
        sub_status = int(sub_link.link_status)
        client_relay_code = str(parent_snapshot.client_relay_code or "")

        if sub_status == LINK_STATUS_DESTROYING:
            if self.link_service.has_local_link(sub_link_id):
                await self.link_service.delete_circuit(
                    sub_link_id, client_relay_code
                )
            return

        if sub_status not in (LINK_STATUS_NORMAL, LINK_STATUS_CREATING):
            return

        await self._ensure_single_link(
            link_id=sub_link_id,
            client_relay_code=client_relay_code,
            relay_fingerprints=list(sub_link.relay_fingerprints),
        )

    async def _ensure_single_link(
        self,
        link_id: str,
        client_relay_code: str,
        relay_fingerprints: List[str],
    ) -> None:
        if not client_relay_code:
            self.logger.warning(
                "InitNodeSync 补建链路 %s 失败：缺少 client_relay_code", link_id
            )
            return

        if self.link_service.local_link_matches(
            link_id, client_relay_code, relay_fingerprints
        ):
            return

        if self.link_service.has_local_link(link_id):
            await self.link_service.delete_circuit(link_id, client_relay_code)

        try:
            circuit, assigned_link_id = await self.link_service.create_circuit_with_link(
                relay_fingerprints=relay_fingerprints,
                client_relay_code=client_relay_code,
                link_id=link_id,
                set_as_default=False,
            )
            if circuit and assigned_link_id:
                await self.reporter.report_circuit_rebuilt_info(
                    True, assigned_link_id, circuit
                )
                self.logger.info(
                    "InitNodeSync 补建链路成功 | link_id=%s circuit_id=%s",
                    assigned_link_id,
                    circuit.circuit_id,
                )
        except Exception as exc:
            self.logger.error(
                "InitNodeSync 补建链路 %s 失败: %s", link_id, exc
            )

    async def _delete_link_snapshot(self, snapshot: Any) -> None:
        client_relay_code = str(snapshot.client_relay_code or "")
        path_type = int(snapshot.path_type or LinkType.SINGLE_LINK)

        if path_type == LinkType.MULTI_LINK and snapshot.sub_links:
            for sub_link in snapshot.sub_links:
                sub_link_id = str(sub_link.link_id)
                relay_code = (
                    self.link_service.find_client_relay_for_link(sub_link_id)
                    or client_relay_code
                )
                if relay_code:
                    await self.link_service.delete_circuit(sub_link_id, relay_code)
            return

        link_id = str(snapshot.link_id)
        relay_code = (
            self.link_service.find_client_relay_for_link(link_id) or client_relay_code
        )
        if relay_code:
            await self.link_service.delete_circuit(link_id, relay_code)

    def _should_destroy_local_relay(
        self,
        relay_code: str,
        expected_relay: Optional[vps_management_pb2.Relay],
    ) -> bool:
        if expected_relay is None:
            self.logger.warning(
                "InitNodeSync 本地 Relay %s 不在管理面期望列表中", relay_code
            )
            return True
        if expected_relay.status == vps_management_pb2.RelayStatus.RELAY_DESTROYING:
            self.logger.warning(
                "InitNodeSync 管理面标记 Relay %s 为销毁中", relay_code
            )
            return True
        return False

    def _relay_attributes_mismatch(
        self,
        local_relay,
        expected_relay: vps_management_pb2.Relay,
    ) -> bool:
        if expected_relay.fingerprint and local_relay.fingerprint:
            if local_relay.fingerprint.upper() != expected_relay.fingerprint.upper():
                self.logger.warning(
                    "InitNodeSync Relay %s 指纹不一致", local_relay.relay_code
                )
                return True
        return False

    @staticmethod
    def _collect_expected_link_ids(link_snapshots: List[Any]) -> Set[str]:
        expected_ids: Set[str] = set()
        for snapshot in link_snapshots:
            if snapshot.link_id:
                expected_ids.add(str(snapshot.link_id))
            for sub_link in getattr(snapshot, "sub_links", []):
                if sub_link.link_id:
                    expected_ids.add(str(sub_link.link_id))
        return expected_ids

    @staticmethod
    def _da_info_to_dir_auth(da: vps_management_pb2.DAInfo) -> Dict[str, Any]:
        return {
            "nick": da.nick,
            "ip_address": da.ip_address,
            "or_port": da.or_port,
            "v3_ident": da.v3_ident,
            "fingerprint": da.fingerprint,
        }

    @staticmethod
    def _normalize_dir_auth_entry(entry: Dict[str, Any]) -> Tuple[str, str, int, str, str]:
        return (
            str(entry.get("nick") or ""),
            str(entry.get("ip_address") or entry.get("address") or ""),
            int(entry.get("or_port") or entry.get("orport") or 0),
            str(entry.get("v3_ident") or entry.get("v3ident") or ""),
            str(entry.get("fingerprint") or ""),
        )

    def _is_da_consistent(
        self,
        local_dir_auth: Optional[List[Dict[str, Any]]],
        remote_dir_auth: List[Dict[str, Any]],
    ) -> bool:
        local_set = {
            self._normalize_dir_auth_entry(item)
            for item in (local_dir_auth or [])
        }
        remote_set = {
            self._normalize_dir_auth_entry(item) for item in remote_dir_auth
        }
        return local_set == remote_set
