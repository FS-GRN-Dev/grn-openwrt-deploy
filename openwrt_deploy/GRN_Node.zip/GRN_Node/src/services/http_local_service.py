import threading
import json
from http.server import BaseHTTPRequestHandler, HTTPServer

import utils.logger

logger = utils.logger.get_logger("HttpLocalService")


class InfoHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/info':
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'GET')
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            response = self.server.info_getter()
            self.wfile.write(json.dumps(response).encode('utf-8'))
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        # 避免每个请求都打到 stderr，统一走 logger（需要时可开 DEBUG）
        logger.debug("%s - %s", self.address_string(), format % args)


class DynamicHTTPServer(HTTPServer):
    def __init__(self, server_address, RequestHandlerClass, info_getter):
        super().__init__(server_address, RequestHandlerClass)
        self.info_getter = info_getter


def _serve_forever(server: DynamicHTTPServer, host: str, port: int) -> None:
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        logger.info("本地 HTTP 服务已停止: http://%s:%s/info", host, port)
    except Exception as e:
        logger.error("本地 HTTP 服务异常退出: %s", e, exc_info=True)
    finally:
        try:
            server.server_close()
        except Exception:
            pass


def start_http_server(info_getter, host: str = '127.0.0.1', port: int = 50080):
    """阻塞运行 HTTP 服务；bind 失败抛出 OSError。"""
    server = DynamicHTTPServer((host, port), InfoHandler, info_getter)
    logger.info("本地 HTTP 服务启动成功: http://%s:%s/info", host, port)
    _serve_forever(server, host, port)


def start_openwrt_http_service(info_getter, host='127.0.0.1', port=50080):
    """
    启动 openwrt 模式下的本地 HTTP 服务。
    bind 在当前线程完成：成功则后台 serve，失败则抛异常给调用方。
    """
    logger.info("正在启动本地 HTTP 服务: %s:%s", host, port)
    try:
        server = DynamicHTTPServer((host, port), InfoHandler, info_getter)
    except OSError as e:
        logger.error(
            "本地 HTTP 服务启动失败（bind %s:%s）: %s", host, port, e, exc_info=True
        )
        raise

    logger.info("本地 HTTP 服务启动成功: http://%s:%s/info", host, port)
    http_thread = threading.Thread(
        target=_serve_forever,
        args=(server, host, port),
        daemon=True,
        name="openwrt-http-50080",
    )
    http_thread.start()
