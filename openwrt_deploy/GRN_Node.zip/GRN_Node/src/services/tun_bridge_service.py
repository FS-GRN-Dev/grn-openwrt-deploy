import asyncio
import json
import time
import uuid
from dataclasses import dataclass
from typing import Any, Optional

import utils.logger

from config.config import SingBoxConfig, TunBridgeConfig
from services.multi_tun_bridge import MultiTunBridge, MultiTunBridgeConfig, SingleTunnelConfig
from services.transparent_proxy import start_server_singbox_proxy
from services.tun_server import TunTunnelServer, TunTunnelServerConfig
from services import mptcp_config


@dataclass
class TunBridgeInstance:
    bridge_code: str
    mode: str  # "client" | "server"
    started_at: str

    # server fields
    listen_host: str = ""
    listen_port: int = 0

    # client fields
    endpoint_host: str = ""
    endpoint_port: int = 0

    mtu: int = 1300
    tunnels: list[dict[str, Any]] = None  # {tun_name,tun_addr_cidr,link_id}


class TunBridgeService:
    """Manage Tun-over-Tor bridges as long-running tasks on a node."""

    def __init__(self, context) -> None:
        self.context = context
        self.logger = utils.logger.get_logger(f"{self.__class__.__name__}")
        self.link_service = None

        self._bridges: dict[str, dict[str, Any]] = {}
        self._lock = asyncio.Lock()

    def set_link_service(self, link_service) -> None:
        self.link_service = link_service

    def _best_effort_cleanup_tun_names(self, tun_names: list[str]) -> None:
        """Best-effort 删除残留 TUN 网卡（未登记到 _bridges 的半途失败场景）。"""
        from services.tun_device import TunConfig, TunDevice

        owned: set[str] = set()
        for inst in self._bridges.values():
            for item in inst.get("tunnels") or []:
                if isinstance(item, dict):
                    name = str(item.get("tun_name") or "").strip()
                    if name:
                        owned.add(name)

        seen: set[str] = set()
        for name in tun_names:
            tun_name = str(name or "").strip()
            if not tun_name or tun_name in seen or tun_name in owned:
                continue
            seen.add(tun_name)
            try:
                TunDevice(TunConfig(name=tun_name, addr_cidr="0.0.0.0/32"))._best_effort_delete_iface(
                    tun_name
                )
            except Exception as exc:
                self.logger.warning("Failed to cleanup orphan TUN %s: %s", tun_name, exc)

    def _new_bridge_code(self) -> str:
        return f"bridge-{uuid.uuid4().hex[:12]}"

    def _serialize_bridge(self, bridge_code: str, inst: dict[str, Any]) -> dict[str, Any]:
        return {
            "bridge_code": bridge_code,
            "mode": str(inst.get("mode") or ""),
            "listen_host": str(inst.get("listen_host") or ""),
            "listen_port": int(inst.get("listen_port") or 0),
            "endpoint_host": str(inst.get("endpoint_host") or ""),
            "endpoint_port": int(inst.get("endpoint_port") or 0),
            "mtu": int(inst.get("mtu") or 0),
            "started_at": str(inst.get("started_at") or ""),
            "tunnels": list(inst.get("tunnels") or []),
            "enable_mptcp": bool(inst.get("enable_mptcp", False)),
            "aggregate": bool(inst.get("aggregate", False)),
            "mptcp_devs": list(inst.get("mptcp_devs") or []),
            "proxy_host": str(inst.get("proxy_host") or ""),
            "proxy_port": int(inst.get("proxy_port") or 0),
            "connect_timeout_sec": int(inst.get("connect_timeout_sec") or 0),
            "link_id": str(inst.get("link_id") or ""),
            "client_relay_code": str(inst.get("client_relay_code") or ""),
            "relay_code": str(inst.get("relay_code") or ""),
            "server_bridge_code": str(inst.get("server_bridge_code") or ""),
        }

    async def get_bridge_info(self, bridge_code: str) -> Optional[dict[str, Any]]:
        async with self._lock:
            inst = self._bridges.get(bridge_code)
            if not inst:
                return None
            return self._serialize_bridge(bridge_code, inst)

    async def update_bridge_metadata(self, bridge_code: str, **metadata: Any) -> None:
        async with self._lock:
            inst = self._bridges.get(bridge_code)
            if not inst:
                return
            inst.update(metadata)

    async def start_server(self, payload: dict[str, Any]) -> str:
        relay_code = str(payload.get("relay_code") or "")
        listen_host = str(payload.get("listen_host") or TunBridgeConfig.DEFAULT_LISTEN_HOST)
        listen_port = int(payload.get("listen_port") or 0)
        mtu = int(payload.get("mtu") or TunBridgeConfig.DEFAULT_MTU)

        tunnels_in = payload.get("tunnels") or []
        tunnels: list[SingleTunnelConfig] = []
        tunnels_meta: list[dict[str, Any]] = []
        for t in tunnels_in:
            if not isinstance(t, dict):
                continue
            tun_name = str(t.get("tun_name") or "")
            tun_addr_cidr = str(t.get("tun_addr_cidr") or "")
            link_id = str(t.get("link_id") or "")
            if not tun_name or not tun_addr_cidr:
                raise ValueError("tunnels 中每项必须包含 tun_name/tun_addr_cidr")
            tunnels.append(SingleTunnelConfig(tun_name=tun_name, tun_addr_cidr=tun_addr_cidr, link_id=link_id))
            tunnels_meta.append({"tun_name": tun_name, "tun_addr_cidr": tun_addr_cidr, "link_id": link_id})

        if listen_port <= 0:
            raise ValueError("listen_port 必须 > 0")
        if not tunnels:
            raise ValueError("至少需要一个 tunnel")

        aggregate = bool(payload.get("aggregate", False))

        # 启动前尽力清理同名残留 TUN，避免上次失败留下的网卡导致 EBUSY
        self._best_effort_cleanup_tun_names([t.tun_name for t in tunnels])

        server = TunTunnelServer(
            TunTunnelServerConfig(
                listen_host=listen_host,
                listen_port=listen_port,
                mtu=mtu,
                tunnels=tunnels,
                aggregate=aggregate,
            )
        )
        server_proxy = None
        mptcp_devs: list[str] = []  # 用于 stop 时清理
        try:
            await server.start()

            bridge_code = self._new_bridge_code()
            started_at = time.strftime("%Y-%m-%d %H:%M:%S")

            # ── MPTCP: server 端注册 signal endpoint (aggregate 模式跳过) ──
            enable_mptcp = bool(payload.get("enable_mptcp", False))
            if enable_mptcp and len(tunnels) > 1 and not aggregate:
                try:
                    mptcp_config.ensure_mptcp_enabled()
                    mptcp_config.flush_endpoints()  # 清除旧端点，避免干扰
                    extra_addr = len(tunnels) - 1
                    extra_subflow = len(tunnels) + 1
                    mptcp_config.set_limits(subflows=extra_subflow, add_addr_accepted=extra_addr)

                    # 尝试设置 roundrobin 调度器以均匀分配数据到多 subflow
                    mptcp_config.configure_scheduler("roundrobin")

                    # 使用内核实际分配的 TUN 设备名（可能与请求名不同）
                    ifnames = server.get_ifnames()
                    self.logger.info("TUN ifnames mapping (config→kernel): %s", ifnames)

                    # 第一个 tun 走主流；其余 tun 作为 signal endpoint
                    for t in tunnels[1:]:
                        actual_dev = ifnames.get(t.tun_name, t.tun_name)
                        addr = mptcp_config.ip_from_cidr(t.tun_addr_cidr)
                        mptcp_config.add_endpoint(addr, actual_dev, flags="signal")
                        mptcp_devs.append(actual_dev)

                    # 验证注册结果
                    registered = mptcp_config.show_endpoints()
                    self.logger.info(
                        "MPTCP signal endpoints registered for %d extra tun(s), "
                        "current endpoints: %s",
                        extra_addr,
                        [(ep.address, ep.dev, ep.flags) for ep in registered],
                    )
                except Exception as exc:
                    self.logger.error("MPTCP signal endpoint 注册失败: %s", exc, exc_info=True)

            # ── 透明代理: server 端（sing-box） ──
            server_proxy_port = int(
                payload.get("server_proxy_port") or SingBoxConfig.SERVER_LISTEN_PORT
            )
            server_proxy_hosts = [
                mptcp_config.ip_from_cidr(t.tun_addr_cidr)
                for t in tunnels
                if t.tun_addr_cidr
            ]
            server_proxy = await start_server_singbox_proxy(
                listen_hosts=server_proxy_hosts,
                listen_port=server_proxy_port,
            )
            self.logger.info(
                "Server sing-box transparent proxy started on %s:%s",
                ",".join(server_proxy_hosts),
                server_proxy_port,
            )

            async with self._lock:
                self._bridges[bridge_code] = {
                    "mode": "server",
                    "server": server,
                    "started_at": started_at,
                    "listen_host": listen_host,
                    "listen_port": listen_port,
                    "endpoint_host": "",
                    "endpoint_port": 0,
                    "mtu": mtu,
                    "tunnels": tunnels_meta,
                    "enable_mptcp": enable_mptcp,
                    "aggregate": aggregate,
                    "mptcp_devs": mptcp_devs,
                    "proxy_host": "",
                    "proxy_port": 0,
                    "connect_timeout_sec": 0,
                    "relay_code": relay_code,
                    "link_id": "",
                    "client_relay_code": "",
                    "server_bridge_code": bridge_code,
                    "proxy": server_proxy,
                }
        except Exception:
            # 半途失败时必须回收 TUN/代理，否则残留网卡会让后续创建一直 EBUSY
            if server_proxy is not None:
                try:
                    await server_proxy.stop()
                except Exception as exc:
                    self.logger.warning("Failed to stop server proxy after start failure: %s", exc)
            if mptcp_devs:
                try:
                    mptcp_config.cleanup_endpoints_by_devs(mptcp_devs)
                except Exception as exc:
                    self.logger.warning("Failed to cleanup MPTCP endpoints after start failure: %s", exc)
            try:
                await server.stop()
            except Exception as exc:
                self.logger.warning("Failed to stop TunTunnelServer after start failure: %s", exc)
            self._best_effort_cleanup_tun_names([t.tun_name for t in tunnels])
            raise

        self.logger.info("Tun bridge server started: bridge_code=%s listen=%s:%s mptcp=%s aggregate=%s", bridge_code, listen_host, listen_port, enable_mptcp, aggregate)
        return bridge_code

    async def start_client(self, payload: dict[str, Any]) -> str:
        client_relay_code = str(payload.get("client_relay_code") or "")
        parent_link_id = str(payload.get("link_id") or payload.get("parent_link_id") or "")
        server_bridge_code = str(payload.get("server_bridge_code") or "")
        endpoint_host = str(payload.get("endpoint_host") or "")
        endpoint_port = int(payload.get("endpoint_port") or 0)
        mtu = int(payload.get("mtu") or TunBridgeConfig.DEFAULT_MTU)
        connect_timeout_sec = int(
            payload.get("connect_timeout_sec") or TunBridgeConfig.DEFAULT_CONNECT_TIMEOUT_SEC
        )

        proxy_host = str(payload.get("proxy_host") or "")
        proxy_port = int(payload.get("proxy_port") or 0)

        if not client_relay_code:
            raise ValueError("缺少 client_relay_code")
        if not endpoint_host:
            raise ValueError("缺少 endpoint_host")
        if endpoint_port <= 0:
            raise ValueError("endpoint_port 必须 > 0")

        if not proxy_host or proxy_port <= 0:
            stem2tor = self.context.stem2tor_instances.get(client_relay_code)
            if not stem2tor:
                raise ValueError(f"Client Relay {client_relay_code} 不存在")
            proxy_host = "127.0.0.1"
            proxy_port = int(getattr(stem2tor, "socks_port", 9050) or 9050)

        tunnels_in = payload.get("tunnels") or []
        if parent_link_id:
            if not self.link_service:
                raise ValueError("TunBridgeService 尚未绑定 LinkService")
            tunnels_in = self.link_service.build_client_bridge_tunnels(
                parent_link_id,
                tunnel_templates=tunnels_in,
            )

        tunnels: list[SingleTunnelConfig] = []
        tunnels_meta: list[dict[str, Any]] = []
        for t in tunnels_in:
            if not isinstance(t, dict):
                continue
            tun_name = str(t.get("tun_name") or "")
            tun_addr_cidr = str(t.get("tun_addr_cidr") or "")
            link_id = str(t.get("link_id") or "")
            if not tun_name or not tun_addr_cidr or not link_id:
                raise ValueError("tunnels 中每项必须包含 tun_name/tun_addr_cidr/link_id")
            tunnels.append(SingleTunnelConfig(tun_name=tun_name, tun_addr_cidr=tun_addr_cidr, link_id=link_id))
            tunnels_meta.append({"tun_name": tun_name, "tun_addr_cidr": tun_addr_cidr, "link_id": link_id})

        if not tunnels:
            raise ValueError("至少需要一个 tunnel")

        aggregate = bool(payload.get("aggregate", False))

        # 启动前尽力清理同名残留 TUN，避免上次失败留下的网卡导致 EBUSY
        self._best_effort_cleanup_tun_names([t.tun_name for t in tunnels])

        bridge = MultiTunBridge(
            MultiTunBridgeConfig(
                proxy_host=proxy_host,
                proxy_port=proxy_port,
                endpoint_host=endpoint_host,
                endpoint_port=endpoint_port,
                tunnels=tunnels,
                mtu=mtu,
                connect_timeout_sec=connect_timeout_sec,
                aggregate=aggregate,
            )
        )

        mptcp_devs: list[str] = []
        try:
            await bridge.start()

            bridge_code = self._new_bridge_code()
            started_at = time.strftime("%Y-%m-%d %H:%M:%S")

            # ── MPTCP: client 端注册 subflow endpoint (aggregate 模式跳过) ──
            enable_mptcp = bool(payload.get("enable_mptcp", False))
            if enable_mptcp and len(tunnels) > 1 and not aggregate:
                try:
                    mptcp_config.ensure_mptcp_enabled()
                    mptcp_config.flush_endpoints()  # 清除旧端点，避免干扰
                    extra_addr = len(tunnels) - 1
                    extra_subflow = len(tunnels) + 1
                    mptcp_config.set_limits(subflows=extra_subflow, add_addr_accepted=extra_addr)

                    # 尝试设置 roundrobin 调度器以均匀分配数据到多 subflow
                    mptcp_config.configure_scheduler("roundrobin")

                    # 使用内核实际分配的 TUN 设备名（可能与请求名不同）
                    ifnames = bridge.get_ifnames()
                    self.logger.info("TUN ifnames mapping (config→kernel): %s", ifnames)

                    # 只为 TCP 隧道实际建立成功的 tunnel 注册 MPTCP endpoint
                    ok_tunnels = bridge.get_ok_tunnel_names()
                    registered_count = 0
                    for t in tunnels[1:]:
                        if t.tun_name not in ok_tunnels:
                            self.logger.warning(
                                "跳过 TCP 隧道未成功的 tunnel %s 的 MPTCP subflow endpoint 注册",
                                t.tun_name,
                            )
                            continue
                        actual_dev = ifnames.get(t.tun_name, t.tun_name)
                        addr = mptcp_config.ip_from_cidr(t.tun_addr_cidr)
                        mptcp_config.add_endpoint(addr, actual_dev, flags="subflow")
                        mptcp_devs.append(actual_dev)
                        registered_count += 1

                    # 验证注册结果
                    registered = mptcp_config.show_endpoints()
                    self.logger.info(
                        "MPTCP subflow endpoints: registered=%d/%d extra tun(s), "
                        "current endpoints: %s",
                        registered_count,
                        extra_addr,
                        [(ep.address, ep.dev, ep.flags) for ep in registered],
                    )
                except Exception as exc:
                    self.logger.error("MPTCP subflow endpoint 注册失败: %s", exc, exc_info=True)

            async with self._lock:
                self._bridges[bridge_code] = {
                    "mode": "client",
                    "bridge": bridge,
                    "started_at": started_at,
                    "listen_host": "",
                    "listen_port": 0,
                    "endpoint_host": endpoint_host,
                    "endpoint_port": endpoint_port,
                    "mtu": mtu,
                    "tunnels": tunnels_meta,
                    "proxy_host": proxy_host,
                    "proxy_port": proxy_port,
                    "connect_timeout_sec": connect_timeout_sec,
                    "client_relay_code": client_relay_code,
                    "enable_mptcp": enable_mptcp,
                    "aggregate": aggregate,
                    "mptcp_devs": mptcp_devs,
                    "relay_code": "",
                    "link_id": parent_link_id,
                    "server_bridge_code": server_bridge_code,
                }
        except Exception:
            if mptcp_devs:
                try:
                    mptcp_config.cleanup_endpoints_by_devs(mptcp_devs)
                except Exception as exc:
                    self.logger.warning("Failed to cleanup MPTCP endpoints after client start failure: %s", exc)
            try:
                await bridge.stop()
            except Exception as exc:
                self.logger.warning("Failed to stop MultiTunBridge after start failure: %s", exc)
            self._best_effort_cleanup_tun_names([t.tun_name for t in tunnels])
            raise

        if parent_link_id and self.link_service:
            self.link_service.bind_client_bridge(parent_link_id, bridge_code)

        self.logger.info(
            "Tun bridge client started: bridge_code=%s endpoint=%s:%s via socks=%s:%s mptcp=%s",
            bridge_code,
            endpoint_host,
            endpoint_port,
            proxy_host,
            proxy_port,
            enable_mptcp,
        )
        return bridge_code

    async def stop(self, bridge_code: str) -> bool:
        async with self._lock:
            inst = self._bridges.get(bridge_code)

        if not inst:
            return False

        mode = inst.get("mode")
        try:
            # ── server 端透明代理: 先于 bridge 停止 ──
            if mode == "server":
                proxy = inst.get("proxy")
                if proxy:
                    try:
                        await proxy.stop()
                        self.logger.info(
                            "Server transparent proxy stopped for bridge %s", bridge_code
                        )
                    except Exception as exc:
                        self.logger.warning(
                            "Failed to stop server transparent proxy: %s", exc
                        )

            if mode == "client":
                bridge = inst.get("bridge")
                if bridge:
                    await bridge.stop()
            elif mode == "server":
                server = inst.get("server")
                if server:
                    await server.stop()

            # ── MPTCP: 清理已注册的 endpoint ──
            mptcp_devs = inst.get("mptcp_devs") or []
            if mptcp_devs:
                try:
                    removed = mptcp_config.cleanup_endpoints_by_devs(mptcp_devs)
                    self.logger.info("MPTCP: cleaned up %d endpoint(s) for bridge %s", removed, bridge_code)
                except Exception as exc:
                    self.logger.warning("MPTCP endpoint 清理失败: %s", exc)
        finally:
            if mode == "client" and self.link_service:
                self.link_service.clear_client_bridge(
                    str(inst.get("link_id") or ""),
                    bridge_code=bridge_code,
                )
            async with self._lock:
                self._bridges.pop(bridge_code, None)

        self.logger.info("Tun bridge stopped: bridge_code=%s", bridge_code)
        return True

    async def status(self) -> list[dict[str, Any]]:
        async with self._lock:
            items = list(self._bridges.items())

        bridges: list[dict[str, Any]] = []
        for bridge_code, inst in items:
            bridges.append(self._serialize_bridge(bridge_code, inst))
        return bridges


def make_json_response(bridge_code: Optional[str] = None, bridges: Optional[list[dict[str, Any]]] = None) -> str:
    payload: dict[str, Any] = {}
    if bridge_code is not None:
        payload["bridge_code"] = bridge_code
    if bridges is not None:
        payload["bridges"] = bridges
    return json.dumps(payload, ensure_ascii=False)
