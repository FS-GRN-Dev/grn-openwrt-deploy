import asyncio
import json
from dataclasses import dataclass
from typing import Optional, Sequence

import utils.logger

from services.tun_device import TunConfig, TunDevice
from services.tun_tunnel import LengthPrefixedFraming


@dataclass(frozen=True)
class TunTunnelServerConfig:
    listen_host: str
    listen_port: int
    tunnels: Sequence[object]  # expects objects with tun_name/tun_addr_cidr attributes
    mtu: int = 1300
    max_frame: int = 4 * 1024 * 1024
    aggregate: bool = False


class TunTunnelServer:
    def __init__(self, cfg: TunTunnelServerConfig) -> None:
        self.cfg = cfg
        self.logger = utils.logger.get_logger("TunTunnelServer")
        self._tuns: dict[str, TunDevice] = {}
        self._server: asyncio.base_events.Server | None = None
        # Aggregate mode state
        self._agg_tun: Optional[TunDevice] = None
        self._agg_writers: list[asyncio.StreamWriter] = []
        self._agg_lock: Optional[asyncio.Lock] = None
        self._agg_reader_task: Optional[asyncio.Task] = None
        self._agg_stop: Optional[asyncio.Event] = None

    async def start(self) -> None:
        try:
            if self.cfg.aggregate:
                # Aggregate mode: create only the first TUN device
                first_t = self.cfg.tunnels[0]
                tun = TunDevice(TunConfig(name=first_t.tun_name, addr_cidr=first_t.tun_addr_cidr, mtu=self.cfg.mtu))
                # open 成功后立即登记，避免 configure 失败时 fd/网卡泄漏
                tun.open()
                self._tuns[first_t.tun_name] = tun
                tun.configure()
                self._agg_tun = tun
                self._agg_lock = asyncio.Lock()
                self._agg_stop = asyncio.Event()
                self.logger.info("TunTunnelServer AGGREGATE mode: shared tun=%s", first_t.tun_name)
            else:
                # Normal mode: create one TUN device per tunnel
                for t in self.cfg.tunnels:
                    tun = TunDevice(TunConfig(name=t.tun_name, addr_cidr=t.tun_addr_cidr, mtu=self.cfg.mtu))
                    tun.open()
                    self._tuns[t.tun_name] = tun
                    tun.configure()

            self._server = await asyncio.start_server(
                self._handle_client,
                host=self.cfg.listen_host,
                port=int(self.cfg.listen_port),
            )
        except Exception:
            await self.stop()
            raise
        addrs = ", ".join(str(s.getsockname()) for s in self._server.sockets or [])
        self.logger.info("TunTunnelServer listening on %s", addrs)

    async def stop(self) -> None:
        # Signal aggregate stop
        if self._agg_stop is not None:
            self._agg_stop.set()
        if self._agg_reader_task is not None:
            self._agg_reader_task.cancel()
            self._agg_reader_task = None
        # Close aggregate writers
        for w in self._agg_writers:
            try:
                w.close()
            except Exception:
                pass
        self._agg_writers.clear()

        if self._server:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        for tun in self._tuns.values():
            try:
                tun.close()
            except Exception:
                pass
        self._tuns.clear()
        self._agg_tun = None

    def get_ifnames(self) -> dict:
        """Return {config_name: actual_kernel_ifname} for all TUN devices."""
        return {name: (tun.ifname or name) for name, tun in self._tuns.items()}

    async def _handle_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        if self.cfg.aggregate:
            await self._handle_aggregate_client(reader, writer)
        else:
            await self._handle_normal_client(reader, writer)

    async def _handle_normal_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = writer.get_extra_info("peername")
        try:
            # First frame is handshake JSON: {"tun":"tun0"}
            raw = await LengthPrefixedFraming.read_frame(reader, max_frame=64 * 1024)
            hello = json.loads(raw.decode("utf-8"))
            tun_name = str(hello.get("tun") or "")
            if tun_name not in self._tuns:
                raise ValueError(f"unknown tun: {tun_name}")
            tun = self._tuns[tun_name]

            self.logger.info("accepted tunnel %s from %s", tun_name, peer)

            stop_evt = asyncio.Event()
            loop = asyncio.get_running_loop()

            async def tcp_to_tun() -> None:
                try:
                    while True:
                        pkt = await LengthPrefixedFraming.read_frame(reader, max_frame=self.cfg.max_frame)
                        await loop.run_in_executor(None, tun.write, pkt)
                except asyncio.IncompleteReadError:
                    pass
                finally:
                    stop_evt.set()

            async def tun_to_tcp() -> None:
                try:
                    while not stop_evt.is_set():
                        pkt = await loop.run_in_executor(None, tun.read, 65535)
                        if not pkt:
                            continue
                        writer.write(LengthPrefixedFraming.pack(pkt))
                        await writer.drain()
                finally:
                    stop_evt.set()

            await asyncio.gather(tcp_to_tun(), tun_to_tcp())
        except Exception as e:
            self.logger.error("tunnel session failed from %s: %s", peer, e)
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    # ------------------------------------------------------------------
    #  Aggregate mode: 1 shared TUN, N TCP connections, round-robin
    # ------------------------------------------------------------------

    async def _handle_aggregate_client(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        peer = writer.get_extra_info("peername")
        try:
            # Read handshake
            raw = await LengthPrefixedFraming.read_frame(reader, max_frame=64 * 1024)
            hello = json.loads(raw.decode("utf-8"))
            self.logger.info("aggregate tunnel connection from %s: %s", peer, hello)

            # Register writer for round-robin distribution
            async with self._agg_lock:
                self._agg_writers.append(writer)

            # Start the TUN reader task on first connection
            if self._agg_reader_task is None:
                self._agg_reader_task = asyncio.create_task(self._agg_tun_to_tcp())

            # TCP �� TUN: read packets from this connection and write to shared TUN
            loop = asyncio.get_running_loop()
            while True:
                pkt = await LengthPrefixedFraming.read_frame(reader, max_frame=self.cfg.max_frame)
                await loop.run_in_executor(None, self._agg_tun.write, pkt)

        except (asyncio.IncompleteReadError, ConnectionError, OSError):
            self.logger.info("aggregate tunnel from %s disconnected", peer)
        except Exception as e:
            self.logger.error("aggregate tunnel from %s error: %s", peer, e)
        finally:
            async with self._agg_lock:
                if writer in self._agg_writers:
                    self._agg_writers.remove(writer)
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def _agg_tun_to_tcp(self) -> None:
        """Read IP packets from shared TUN, distribute round-robin to connected clients."""
        loop = asyncio.get_running_loop()
        idx = 0
        while not self._agg_stop.is_set():
            try:
                pkt = await loop.run_in_executor(None, self._agg_tun.read, 65535)
            except Exception:
                break
            if not pkt:
                continue

            async with self._agg_lock:
                writers = list(self._agg_writers)
            if not writers:
                continue

            w = writers[idx % len(writers)]
            idx += 1
            try:
                w.write(LengthPrefixedFraming.pack(pkt))
                await w.drain()
            except Exception:
                pass  # broken writer removed by _handle_aggregate_client
