import asyncio
import json
from dataclasses import dataclass
from typing import Optional, Sequence

import utils.logger

from services.tun_device import TunConfig, TunDevice
from services.tun_tunnel import (
    LengthPrefixedFraming,
    SocksProxy,
    TunnelEndpoint,
    TunTcpTunnel,
    socks5_connect_sync,
)


@dataclass(frozen=True)
class SingleTunnelConfig:
    tun_name: str
    tun_addr_cidr: str
    link_id: str


@dataclass(frozen=True)
class MultiTunBridgeConfig:
    proxy_host: str
    proxy_port: int
    endpoint_host: str
    endpoint_port: int
    tunnels: Sequence[SingleTunnelConfig]
    mtu: int = 1300
    connect_timeout_sec: int = 15
    aggregate: bool = False


class MultiTunBridge:
    def __init__(self, cfg: MultiTunBridgeConfig) -> None:
        self.cfg = cfg
        self.logger = utils.logger.get_logger("MultiTunBridge")
        self._tuns: list[TunDevice] = []
        self._tunnels: list[TunTcpTunnel] = []
        self._ok_tunnel_names: set[str] = set()
        # Aggregate mode state
        self._agg_tun: Optional[TunDevice] = None
        self._agg_conns: list[tuple[asyncio.StreamReader, asyncio.StreamWriter]] = []
        self._agg_tasks: list[asyncio.Task] = []
        self._agg_stop: Optional[asyncio.Event] = None

    async def start(self) -> None:
        if self.cfg.aggregate:
            await self._start_aggregate()
        else:
            await self._start_normal()

    async def _start_normal(self) -> None:
        endpoint = TunnelEndpoint(self.cfg.endpoint_host, int(self.cfg.endpoint_port))

        start_tasks: list[asyncio.Task[None]] = []
        tunnel_cfgs: list[SingleTunnelConfig] = []

        try:
            for t in self.cfg.tunnels:
                tun = TunDevice(TunConfig(name=t.tun_name, addr_cidr=t.tun_addr_cidr, mtu=self.cfg.mtu))
                # open 成功后立即登记，避免 configure 失败时 fd/网卡泄漏
                tun.open()
                self._tuns.append(tun)
                tun.configure()

                proxy = SocksProxy(
                    host=self.cfg.proxy_host,
                    port=int(self.cfg.proxy_port),
                    username=t.link_id,
                    password="",
                )

                tunnel = TunTcpTunnel(
                    tun=tun,
                    endpoint=endpoint,
                    proxy=proxy,
                    connect_timeout=float(self.cfg.connect_timeout_sec),
                )
                self._tunnels.append(tunnel)
                tunnel_cfgs.append(t)

                self.logger.info(
                    "starting tunnel: tun=%s link_id=%s endpoint=%s:%s via socks=%s:%s timeout=%ss",
                    t.tun_name,
                    t.link_id,
                    endpoint.host,
                    endpoint.port,
                    proxy.host,
                    proxy.port,
                    self.cfg.connect_timeout_sec,
                )
                start_tasks.append(asyncio.create_task(tunnel.start()))
        except Exception:
            # 设备创建/配置中途失败时，回收已创建资源，避免下次启动出现 device busy
            await self.stop()
            raise

        results = await asyncio.gather(*start_tasks, return_exceptions=True)
        ok = 0
        for tcfg, res in zip(tunnel_cfgs, results):
            if isinstance(res, Exception):
                self.logger.error(
                    "tunnel start failed: tun=%s link_id=%s error=%s",
                    tcfg.tun_name,
                    tcfg.link_id,
                    res,
                )
            else:
                ok += 1
                self._ok_tunnel_names.add(tcfg.tun_name)

        if ok == 0:
            await self.stop()
            raise RuntimeError("all tunnels failed to start")

        self.logger.info("MultiTunBridge started: tunnels=%s ok=%s", len(self._tunnels), ok)

    # ------------------------------------------------------------------
    #  Aggregate mode: 1 TUN device, N TCP tunnels, round-robin packets
    # ------------------------------------------------------------------

    async def _start_aggregate(self) -> None:
        """Aggregate mode: single TUN device, N TCP tunnels through different
        Tor circuits, application-level round-robin packet distribution.

        No MPTCP kernel dependency. Works with any application (SSH, curl, etc.).
        """
        first_t = self.cfg.tunnels[0]

        # 1) Create single TUN device
        tun = TunDevice(TunConfig(name=first_t.tun_name, addr_cidr=first_t.tun_addr_cidr, mtu=self.cfg.mtu))
        try:
            tun.open()
            tun.configure()
        except Exception:
            try:
                tun.close()
            except Exception:
                pass
            raise
        self._tuns.append(tun)
        self._agg_tun = tun

        # 2) Connect N SOCKS5 tunnels in parallel
        loop = asyncio.get_running_loop()

        async def _connect_one(t: SingleTunnelConfig) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
            self.logger.info(
                "aggregate connect: link_id=%s endpoint=%s:%s via socks=%s:%s",
                t.link_id, self.cfg.endpoint_host, self.cfg.endpoint_port,
                self.cfg.proxy_host, self.cfg.proxy_port,
            )
            sock = await loop.run_in_executor(
                None,
                socks5_connect_sync,
                self.cfg.proxy_host,
                int(self.cfg.proxy_port),
                self.cfg.endpoint_host,
                int(self.cfg.endpoint_port),
                t.link_id,
                "x",
                float(self.cfg.connect_timeout_sec),
            )
            reader, writer = await asyncio.open_connection(sock=sock)
            # Handshake: tell server this is an aggregate tunnel
            hello = json.dumps({"tun": first_t.tun_name, "aggregate": True}).encode("utf-8")
            writer.write(LengthPrefixedFraming.pack(hello))
            await writer.drain()
            return reader, writer

        tasks = [asyncio.create_task(_connect_one(t)) for t in self.cfg.tunnels]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        ok = 0
        for t, res in zip(self.cfg.tunnels, results):
            if isinstance(res, Exception):
                self.logger.error("aggregate connect failed: link_id=%s error=%s", t.link_id, res)
            else:
                self._agg_conns.append(res)
                self._ok_tunnel_names.add(t.tun_name)
                ok += 1

        if ok == 0:
            await self.stop()
            raise RuntimeError("all aggregate tunnel connections failed")

        # 3) Start data plane
        self._agg_stop = asyncio.Event()
        # TUN---->TCP round-robin
        self._agg_tasks.append(asyncio.create_task(self._agg_tun_to_tcp()))
        # TCP---->TUN (one per connection)
        for i, (reader, _) in enumerate(self._agg_conns):
            self._agg_tasks.append(asyncio.create_task(self._agg_tcp_to_tun(reader, i)))

        self.logger.info(
            "MultiTunBridge AGGREGATE started: tun=%s connections=%d/%d",
            first_t.tun_name, ok, len(self.cfg.tunnels),
        )

    async def _agg_tun_to_tcp(self) -> None:
        """Read IP packets from shared TUN, distribute round-robin to TCP tunnels."""
        loop = asyncio.get_running_loop()
        idx = 0
        while not self._agg_stop.is_set():
            try:
                pkt = await loop.run_in_executor(None, self._agg_tun.read, 65535)
            except Exception:
                break
            if not pkt:
                continue
            conns = self._agg_conns
            if not conns:
                continue
            _, writer = conns[idx % len(conns)]
            idx += 1
            try:
                writer.write(LengthPrefixedFraming.pack(pkt))
                await writer.drain()
            except Exception:
                pass  # broken connection, will be handled

    async def _agg_tcp_to_tun(self, reader: asyncio.StreamReader, index: int) -> None:
        """Read IP packets from one TCP tunnel, write to shared TUN device."""
        loop = asyncio.get_running_loop()
        try:
            while not self._agg_stop.is_set():
                pkt = await LengthPrefixedFraming.read_frame(reader, max_frame=4 * 1024 * 1024)
                await loop.run_in_executor(None, self._agg_tun.write, pkt)
        except (asyncio.IncompleteReadError, ConnectionError, OSError):
            self.logger.warning("aggregate tunnel %d disconnected", index)

    # ------------------------------------------------------------------

    def get_ifnames(self) -> dict:
        """Return {config_name: actual_kernel_ifname} for all TUN devices."""
        return {
            t.tun_name: (tun.ifname or t.tun_name)
            for t, tun in zip(self.cfg.tunnels, self._tuns)
        }

    def get_ok_tunnel_names(self) -> set[str]:
        """Return the set of tun_name whose TCP tunnel started successfully."""
        return set(self._ok_tunnel_names)

    async def stop(self) -> None:
        # Aggregate mode cleanup
        if self._agg_stop is not None:
            self._agg_stop.set()
        for _, writer in self._agg_conns:
            try:
                writer.close()
            except Exception:
                pass
        for task in self._agg_tasks:
            task.cancel()
        self._agg_conns.clear()
        self._agg_tasks.clear()
        self._agg_tun = None

        # Non-aggregate mode cleanup
        await asyncio.gather(*(t.stop() for t in self._tunnels), return_exceptions=True)

        # Common: close TUN devices
        for tun in self._tuns:
            try:
                tun.close()
            except Exception:
                pass
        self._tunnels.clear()
        self._tuns.clear()
        self.logger.info("MultiTunBridge stopped")
