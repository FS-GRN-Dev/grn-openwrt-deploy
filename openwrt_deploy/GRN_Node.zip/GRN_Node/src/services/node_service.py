import asyncio
import sys
import os
from typing import Dict, List, Any
import time
import threading
from generated import vps_management_pb2
import utils.logger
from config.config import GrpcConfig


class NodeService:
    def __init__(self, context, reporter):
        self.context = context
        self.reporter = reporter
        self.logger = utils.logger.get_logger(f"{self.__class__.__name__}")

    async def set_node_status(self, new_status: int) -> bool:
        """设置节点状态"""
        self.logger.info(
            f"设置节点状态为: {vps_management_pb2.NodeStatus.Name(new_status)}"
        )
        self.context.node.status = new_status
        return await self.reporter.report_node_info()

    async def destroy_node(self) -> bool:
        """销毁节点 (自毁)"""
        self.logger.info("收到销毁节点指令！")

        # 1. 设置状态
        self.context.node.status = vps_management_pb2.NodeStatus.NODE_DESTROYING
        await self.reporter.report_node_info()
        await self.reporter.report_self_destruction_info()
        # 2. 停止所有 Relay
        # 这里需要访问 RelayService，或者直接操作 context
        # 为了避免循环依赖，建议在 Container 中协调，或者在这里直接操作 context
        for relay_code in list(self.context.stem2tor_instances.keys()):
            stem2tor = self.context.stem2tor_instances[relay_code]
            try:
                await stem2tor.stop_tor()
            except Exception as e:
                self.logger.error(f"停止 Relay {relay_code} 失败: {e}")

        # 3. 触发程序退出
        # 这是一个异步操作，通常我们会启动一个后台任务来执行退出，以便当前 gRPC 请求能返回
        asyncio.create_task(self._delayed_exit())
        return True

    # async def update_da_info(self, da_info: dict) -> bool:
    async def update_da_info(self, da_info: List[Dict[str, Any]]) -> bool:
        """更新 DA 信息"""
        self.logger.info(f"收到 DA 信息更新：{da_info}")
        self.context.dir_auth = da_info

        # 可能需要通知所有运行中的 Relay 更新配置
        # 这个逻辑之前没有，不确定有什么用（但理论需要）
        # 先与之前的实现保持一致，注释掉
        # for stem in self.context.stem2tor_instances.values():
        #     await stem.update_dir_auths(da_info)

        try:
            # 当前一个节点只支持一个relay，但是下面实现针对多个relay书写
            for relay_code, relay in self.context.relays.items():
                if relay.relay_role != vps_management_pb2.RelayRole.ROLE_DA:
                    # self.logger.warning(f"  Relay {relay_code} 不是DA角色，跳过")
                    continue

                stem2tor = self.context.stem2tor_instances.get(relay_code)
                if not stem2tor:
                    continue

                await stem2tor.disconnect_controller()

                await stem2tor.update_dir_auths(da_info)
                self.logger.info(f"当前Relay {relay_code}, 已更新所有DA信息到torrc中，并重新启动tor服务成功")

                tor_info = await stem2tor.connect_controller()
                if tor_info:
                    self.logger.info(f"当前Relay {relay_code}, 已重新连接 Tor 控制端口成功")
                else:
                    self.logger.info(f"当前Relay {relay_code}, 已重新连接 Tor 控制端口失败")
                    return False
                
            return True
        except Exception as e:
            self.logger.error(f"更新DA信息失败: {e}")
            return False

    async def refresh_info(self) -> bool:
        """刷新并上报所有信息"""
        self.logger.info("执行全量信息刷新")
        n_success = await self.reporter.report_node_info()
        r_success = await self.reporter.report_relay_info()
        # d_success = await self.reporter.report_da_info() # 视情况而定
        return n_success and r_success

    async def _delayed_exit(self):
        """延迟退出进程"""
        self.logger.info(f"节点将在 {GrpcConfig.EXIT_DELAY} 秒后退出...")
        await asyncio.sleep(GrpcConfig.EXIT_DELAY)

        # 退出程序
        try:
            sys.exit(0)
        except Exception as e:
            self.logger.error(f"调用sys.exit(0)出错: {e}")

        # 强制退出程序
        os._exit(0)
