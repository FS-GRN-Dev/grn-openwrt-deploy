"""MPTCP (Multipath TCP) system configuration utilities.

Wraps Linux MPTCP sysctl / ip-mptcp commands so that TunBridgeService can
enable kernel MPTCP, register/remove endpoints, and query subflow state.

All commands require CAP_NET_ADMIN (or root).
"""

import re
import subprocess
from dataclasses import dataclass, field
from typing import List, Optional

import utils.logger

logger = utils.logger.get_logger("MptcpConfig")


# ---------------------------------------------------------------------------
#  Data classes
# ---------------------------------------------------------------------------

@dataclass
class MptcpEndpointInfo:
    """Parsed result from `ip mptcp endpoint show`."""
    id: int
    address: str
    dev: str = ""
    flags: str = ""  # e.g. "signal", "subflow", "signal,subflow"


@dataclass
class MptcpSubflowInfo:
    """One subflow parsed from `ss -M` or `ip mptcp monitor`."""
    local_addr: str
    remote_addr: str
    dev: str = ""


# ---------------------------------------------------------------------------
#  helpers
# ---------------------------------------------------------------------------

def _run(args: List[str], *, check: bool = True, capture: bool = False) -> subprocess.CompletedProcess:
    """Run a system command, log it, and optionally capture stdout."""
    logger.debug("exec: %s", " ".join(args))
    return subprocess.run(args, check=check, capture_output=capture, text=True)


def ip_from_cidr(cidr: str) -> str:
    """Extract bare IP from CIDR notation, e.g. '10.0.0.1/24' -> '10.0.0.1'."""
    return cidr.split("/")[0]


# ---------------------------------------------------------------------------
#  MPTCP kernel toggle
# ---------------------------------------------------------------------------

def ensure_mptcp_enabled() -> None:
    """Enable MPTCP in the kernel (idempotent)."""
    _run(["sysctl", "-w", "net.mptcp.enabled=1"])
    logger.info("MPTCP enabled via sysctl")


def is_mptcp_enabled() -> bool:
    """Check if MPTCP is enabled in the kernel."""
    result = _run(["sysctl", "-n", "net.mptcp.enabled"], capture=True, check=False)
    return result.stdout.strip() == "1"


# ---------------------------------------------------------------------------
#  MPTCP limits
# ---------------------------------------------------------------------------

def set_limits(subflows: int, add_addr_accepted: Optional[int] = None) -> None:
    """Set kernel MPTCP limits.

    Parameters
    ----------
    subflows : maximum additional subflows per connection.
    add_addr_accepted : optional; how many ADD_ADDR the client will accept.
                        Defaults to *subflows* if not given.
    """
    if add_addr_accepted is None:
        add_addr_accepted = subflows
    _run(["ip", "mptcp", "limits", "set",
          "subflows", str(subflows),
          "add_addr_accepted", str(add_addr_accepted)])
    logger.info("MPTCP limits: subflows=%d add_addr_accepted=%d", subflows, add_addr_accepted)


# ---------------------------------------------------------------------------
#  MPTCP endpoint management
# ---------------------------------------------------------------------------

def add_endpoint(address: str, dev: str, flags: str = "subflow") -> None:
    """Register a local address as an MPTCP endpoint.

    Parameters
    ----------
    address : bare IP (not CIDR).
    dev     : network device name (e.g. 'tun1').
    flags   : 'signal' (server advertises), 'subflow' (client initiates),
              or 'signal,subflow'.
    """
    cmd = ["ip", "mptcp", "endpoint", "add", address, "dev", dev]
    for f in flags.split(","):
        f = f.strip()
        if f:
            cmd.append(f)
    _run(cmd)
    logger.info("MPTCP endpoint added: %s dev %s flags=%s", address, dev, flags)


def delete_endpoint(endpoint_id: int) -> None:
    """Remove an MPTCP endpoint by its kernel ID."""
    _run(["ip", "mptcp", "endpoint", "delete", "id", str(endpoint_id)], check=False)
    logger.debug("MPTCP endpoint deleted: id=%d", endpoint_id)


def flush_endpoints() -> None:
    """Remove all MPTCP endpoints."""
    _run(["ip", "mptcp", "endpoint", "flush"], check=False)
    logger.info("MPTCP endpoints flushed")


def show_endpoints() -> List[MptcpEndpointInfo]:
    """Parse output of `ip mptcp endpoint show`.

    Example output line::

        10.0.1.1 id 2 subflow dev tun1

    Returns a list of :class:`MptcpEndpointInfo`.
    """
    result = _run(["ip", "mptcp", "endpoint", "show"], capture=True, check=False)
    endpoints: List[MptcpEndpointInfo] = []
    if result.returncode != 0:
        return endpoints

    for line in result.stdout.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        # Parse: <address> id <N> [<flags>...] [dev <dev>]
        parts = line.split()
        if len(parts) < 3:
            continue
        address = parts[0]
        ep_id = 0
        dev = ""
        flags_parts: List[str] = []

        i = 1
        while i < len(parts):
            token = parts[i]
            if token == "id" and i + 1 < len(parts):
                ep_id = int(parts[i + 1])
                i += 2
            elif token == "dev" and i + 1 < len(parts):
                dev = parts[i + 1]
                i += 2
            else:
                # Could be a flag like 'signal', 'subflow', 'backup', 'fullmesh'
                if token in ("signal", "subflow", "backup", "fullmesh"):
                    flags_parts.append(token)
                i += 1

        endpoints.append(MptcpEndpointInfo(
            id=ep_id,
            address=address,
            dev=dev,
            flags=",".join(flags_parts),
        ))
    return endpoints


def find_endpoints_by_dev(dev_names: List[str]) -> List[MptcpEndpointInfo]:
    """Return MPTCP endpoints whose dev matches any name in *dev_names*."""
    all_eps = show_endpoints()
    target = set(dev_names)
    return [ep for ep in all_eps if ep.dev in target]


def cleanup_endpoints_by_devs(dev_names: List[str]) -> int:
    """Delete all MPTCP endpoints associated with given devices.

    Returns the number of endpoints removed.
    """
    eps = find_endpoints_by_dev(dev_names)
    for ep in eps:
        delete_endpoint(ep.id)
    if eps:
        logger.info("Cleaned up %d MPTCP endpoint(s) for devs %s", len(eps), dev_names)
    return len(eps)


# ---------------------------------------------------------------------------
#  MPTCP scheduler
# ---------------------------------------------------------------------------

def try_load_scheduler_module(name: str = "roundrobin") -> bool:
    """Try to load MPTCP scheduler kernel module (e.g. mptcp_sched_roundrobin).

    Returns True if the module was loaded or already available.
    """
    module_name = f"mptcp_sched_{name}"
    result = _run(["modprobe", module_name], check=False, capture=True)
    if result.returncode == 0:
        logger.info("MPTCP scheduler module loaded: %s", module_name)
        return True
    logger.debug("modprobe %s failed (may not be available): %s", module_name, result.stderr.strip())
    return False


def try_set_scheduler(name: str = "roundrobin") -> bool:
    """Try to set the MPTCP packet scheduler.

    Tries ``ip mptcp set scheduler <name>`` first (kernel >= 6.6),
    then falls back to sysctl ``net.mptcp.scheduler``.
    Returns True if the scheduler was set successfully.
    """
    # Attempt 1: ip mptcp set scheduler (kernel >= 6.6)
    result = _run(["ip", "mptcp", "set", "scheduler", name], check=False, capture=True)
    if result.returncode == 0:
        logger.info("MPTCP scheduler set to '%s' via ip-mptcp", name)
        return True

    # Attempt 2: sysctl (some kernels expose this knob)
    result = _run(["sysctl", "-w", f"net.mptcp.scheduler={name}"], check=False, capture=True)
    if result.returncode == 0:
        logger.info("MPTCP scheduler set to '%s' via sysctl", name)
        return True

    logger.warning(
        "Failed to set MPTCP scheduler to '%s' (may require kernel >= 6.6 or scheduler module); "
        "data distribution may be uneven across subflows",
        name,
    )
    return False


def configure_scheduler(preferred: str = "roundrobin") -> bool:
    """Best-effort configuration of an MPTCP scheduler that distributes
    data across subflows (rather than the default lowest-RTT-only policy).

    Tries to load the scheduler module and set it.  Falls back gracefully.
    """
    try_load_scheduler_module(preferred)
    return try_set_scheduler(preferred)
