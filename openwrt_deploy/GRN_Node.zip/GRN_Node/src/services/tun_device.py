import os
import fcntl
import struct
import subprocess
import errno
import select
import time
from dataclasses import dataclass
from typing import Optional


# Linux constants
_TUNSETIFF = 0x400454CA
_TUNSETPERSIST = 0x400454CB
_IFF_TUN = 0x0001
_IFF_NO_PI = 0x1000


@dataclass(frozen=True)
class TunConfig:
    name: str
    addr_cidr: str
    mtu: int = 1300
    persist: bool = False


class TunDevice:
    def __init__(self, config: TunConfig) -> None:
        self.config = config
        self.fd: Optional[int] = None
        self.ifname: Optional[str] = None

    def open(self) -> str:
        if self.fd is not None:
            raise RuntimeError("TUN already opened")

        if os.name != "posix":
            raise RuntimeError("TUN device is only supported on Linux")

        tun_path = "/dev/net/tun"
        if not os.path.exists(tun_path):
            raise RuntimeError("/dev/net/tun not found; require TUN support and device mounted")

        fd = os.open(tun_path, os.O_RDWR)
        ifr = struct.pack("16sH", self.config.name.encode("utf-8"), _IFF_TUN | _IFF_NO_PI)

        try:
            res = fcntl.ioctl(fd, _TUNSETIFF, ifr)
        except OSError as e:
            os.close(fd)
            fd = -1

            # ��������: Errno 16 (Device or resource busy)��
            # �Ⱦ�������ͬ���������������ӳ�������� 3 �Ρ�
            if e.errno in (errno.EBUSY, errno.EEXIST):
                last_exc = e
                for attempt in range(3):
                    self._best_effort_delete_iface(self.config.name)
                    time.sleep(0.3 * (attempt + 1))
                    fd = os.open(tun_path, os.O_RDWR)
                    try:
                        res = fcntl.ioctl(fd, _TUNSETIFF, ifr)
                        last_exc = None
                        break
                    except OSError as retry_e:
                        os.close(fd)
                        fd = -1
                        last_exc = retry_e
                        if retry_e.errno not in (errno.EBUSY, errno.EEXIST):
                            raise
                if last_exc is not None:
                    raise last_exc
            else:
                raise

        ifname = struct.unpack("16sH", res)[0].split(b"\x00", 1)[0].decode("utf-8")

        if self.config.persist:
            fcntl.ioctl(fd, _TUNSETPERSIST, struct.pack("I", 1))

        self.fd = fd
        self.ifname = ifname
        return ifname

    def _best_effort_delete_iface(self, ifname: str) -> None:
        # �� down ��ɾ����ȫ�� best-effort������������ʧ���ڸ�ԭʼ����
        try:
            subprocess.run(
                ["ip", "link", "set", "dev", ifname, "down"],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            pass
        try:
            subprocess.run(
                ["ip", "tuntap", "del", "dev", ifname, "mode", "tun"],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except Exception:
            pass

    def close(self) -> None:
        if self.fd is None:
            return
        ifname = self.ifname
        try:
            os.close(self.fd)
        finally:
            self.fd = None
            self.ifname = None
        if ifname and not self.config.persist:
            self._best_effort_delete_iface(ifname)

    def configure(self) -> None:
        if not self.ifname:
            raise RuntimeError("TUN not opened")

        # Use ip(8) to configure; keep minimal and explicit.
        # Note: requires CAP_NET_ADMIN.
        subprocess.run(["ip", "link", "set", "dev", self.ifname, "mtu", str(int(self.config.mtu))], check=True)
        subprocess.run(["ip", "addr", "replace", self.config.addr_cidr, "dev", self.ifname], check=True)
        subprocess.run(["ip", "link", "set", "dev", self.ifname, "up"], check=True)

    def read(self, max_len: int = 65535) -> bytes:
        fd = self.fd
        if fd is None:
            raise RuntimeError("TUN not opened")
        try:
            ready, _, _ = select.select([fd], [], [], 0.2)
        except (OSError, ValueError) as exc:
            if isinstance(exc, OSError) and exc.errno == errno.EBADF:
                return b""
            return b""
        if not ready:
            return b""
        try:
            return os.read(fd, max_len)
        except OSError as exc:
            if exc.errno in (errno.EBADF, errno.EIO):
                return b""
            raise

    def write(self, data: bytes) -> int:
        if self.fd is None:
            raise RuntimeError("TUN not opened")
        return os.write(self.fd, data)
