from typing import List, Optional
from generated import vps_management_pb2
from models.relay import Relay
from config.config import StemConfig, TunBridgeConfig
import utils.logger
from typing import cast


class RelayService:
    def __init__(self, context, reporter, factory, tun_bridge_service=None, link_service=None):
        self.context = context
        self.reporter = reporter
        self.factory = factory
        self.tun_bridge_service = tun_bridge_service
        self.link_service = link_service
        self.server_bridge_code: str = ""
        self.logger = utils.logger.get_logger(f"{self.__class__.__name__}")

    def _has_client_relay(self) -> bool:
        return any(
            relay.relay_role == vps_management_pb2.RelayRole.ROLE_CLIENT
            for relay in self.context.relays.values()
        )

    async def create_relay(
        self,
        server_relay_id: int,
        relay_type: int,
        relay_role: int,
        auto_start_server_bridge: bool | None = None,
        server_bridge_config: Optional[dict] = None,
        dir_auths: Optional[List[dict]] = None) -> str:

        # 1. 准备参数
        role_str = self.context._get_role(relay_role)

        # 确定实际使用的 dir_auths：优先使用传入的，其次使用上下文中的
        effective_dir_auths = dir_auths if dir_auths else self.context.dir_auth

        # 2. 校验依赖
        if role_str != "da" and not effective_dir_auths:
            raise ValueError("创建Relay失败: 缺少 dir_auth 信息")
        relay_type_enum = vps_management_pb2.RelayType.Name(
            cast(vps_management_pb2.RelayType.ValueType, relay_type)
        )

        if dir_auths and not self.context.dir_auth:
            self.logger.info(f"{role_str}未收到广播的 dir_auth 信息，使用传入的 dir_auths 更新上下文中的 dir_auth: {dir_auths}")
            self.context.dir_auth = dir_auths

        # 3. 生成 ID 和 Nickname (业务规则)
        relay_code = f"{role_str}-{self.context.node_code}-{relay_type_enum}"
        nickname = (
            f"{role_str}{self.context.node_code.replace('node-', '')}{relay_type}"
        )

        # 4. 创建 Stem2Tor 实例 (基础设施)
        # TODO: 修改为工厂方法
        stem2tor = self.factory.create(
            role=role_str,
            nick=nickname,
            pwd=StemConfig.DEFAULT_TOR_PASSWORD,
            or_port=StemConfig.DEFAULT_OR_PORT,
            socks_port=StemConfig.DEFAULT_SOCKS_PORT,
            control_port=StemConfig.DEFAULT_CONTROL_PORT,
            dir_port=StemConfig.DEFAULT_DIR_PORT,
            dir_auths=effective_dir_auths,
            outer_ip_addr=self.context.ip_address,
        )

        # 5. 保存实例 (状态管理)
        # 注意：这里先保存是为了防止启动过程中需要用到，但如果启动失败需要回滚
        self.context.stem2tor_instances[relay_code] = stem2tor
        self.logger.info(f"正在创建Relay: relay_code:{relay_code}, nickname:{nickname}")

        # 6. 启动容器
        try:
            tor_info = await stem2tor.start_tor()
            if not tor_info:
                # 回滚
                del self.context.stem2tor_instances[relay_code]
                raise RuntimeError(
                    f"Relay容器 {stem2tor.container_name} 启动失败 (Tor未成功启动)"
                )
        except Exception as e:
            # 回滚
            if relay_code in self.context.stem2tor_instances:
                del self.context.stem2tor_instances[relay_code]
            raise RuntimeError(f"Relay容器启动异常: {e}")

        self.logger.info(f"Relay容器创建成功，容器ID: {tor_info['container_id']}")

        # 7. 创建relay对象
        relay = Relay(
            relay_code=relay_code,
            nickname=nickname,
            fingerprint=tor_info["fingerprint"],
            ip_address=tor_info["address"],
            or_port=tor_info["or_port"],
            dir_port=tor_info["dir_port"],
            bandwidth=tor_info["bandwidth"],
            exit_policy=StemConfig.DEFAULT_EXIT_POLICY,
            published=tor_info["published"],
            flags=(
                tor_info["flags"]
                if isinstance(tor_info["flags"], list)
                else [tor_info["flags"]]
            ),
            version=tor_info["version"],
            platform=StemConfig.DEFAULT_PLATFORM,
            node_code=self.context.node_code,
            container_id=tor_info["container_id"],
            container_name=stem2tor.container_name,
            status=vps_management_pb2.RelayStatus.RELAY_BOOTSTRAPPED,
            relay_type=relay_type,
            relay_role=relay_role,
            server_relay_id=server_relay_id
        )

        # 8. 更新状态
        self.context.relays[relay_code] = relay
        self.context.node.add_relay(
            relay_code=relay_code,
            relay_type=relay.relay_type,
            current_count=len(self.context.relays),
        )

        # 9. 上报 (副作用)
        # 9.1 上报节点信息 (因为 relay_count 变了)
        await self.reporter.report_node_info()

        # 9.2 上报 Relay 信息 (增量)
        await self.reporter.push_relays([relay])

        # 9.3 (DA 特有) 上报 DA 信息
        if role_str == "da":
            await self.reporter.report_da_info()

        # 10. 遗留逻辑处理
        # 原代码中有 sleep 和 report_relay_info，这里我们暂时保留以维持行为一致
        # 但建议后续移除，因为 push_relays 已经上报了
        # await asyncio.sleep(CommandConfig.RELAY_STARTUP_WAIT)
        # await self.reporter.report_relay_info()

        bridge = None
        should_auto_start_server_bridge = auto_start_server_bridge
        if should_auto_start_server_bridge is None:
            should_auto_start_server_bridge = True

        if (
            relay_role == vps_management_pb2.RelayRole.ROLE_EXIT
            and self.tun_bridge_service
            and should_auto_start_server_bridge
        ):
            try:
                bridge = await self._auto_start_server_bridge(
                    relay_code,
                    server_bridge_config or {},
                )
                self.logger.info(
                    f"Exit Relay {relay_code} 自动启动 Server Bridge: {bridge.get('bridge_code', '')}"
                )
            except Exception as exc:
                self.logger.error(
                    f"Exit Relay {relay_code} 自动启动 Server Bridge 失败: {exc}"
                )
                # 中继已入库并上报，bridge 失败则回滚，避免「create_relay 成功但无 server_bridge」
                # 若 start_server 半途失败，server_bridge_code 可能为空，需按 tunnels 清残留网卡
                try:
                    await self._cleanup_failed_server_bridge(server_bridge_config or {})
                except Exception as cleanup_exc:
                    self.logger.error(
                        f"Server Bridge 失败后清理 TUN 异常: {cleanup_exc}"
                    )
                try:
                    await self.destroy_relay(
                        relay_code, skip_client_link_cleanup=True
                    )
                except Exception as destroy_exc:
                    self.logger.error(
                        f"Server Bridge 失败后回滚 Relay {relay_code} 异常: {destroy_exc}"
                    )
                raise RuntimeError(
                    f"Exit Relay Server Bridge 启动失败: {exc}"
                ) from exc

        return {
            "relay_code": relay_code,
            "server_bridge_code": self.server_bridge_code,
            "bridge": bridge,
        }
    
    def _default_server_tunnels(self, tunnel_count: int | None = None) -> list[dict[str, str]]:
        count = int(tunnel_count or TunBridgeConfig.DEFAULT_TUNNEL_COUNT)
        # server TUN 本机地址为 10.0.x.1（client 对端为 10.0.x.2）
        return [
            {
                "tun_name": f"tun{index + 1}",
                "tun_addr_cidr": f"10.0.{index + 1}.1/24",
                "link_id": "",
            }
            for index in range(count)
        ]

    def _build_server_bridge_payload(self, relay_code: str, bridge_config: dict) -> dict:
        tunnel_count = bridge_config.get("tunnel_count")
        return {
            "relay_code": relay_code,
            "listen_host": bridge_config.get("listen_host") or TunBridgeConfig.DEFAULT_LISTEN_HOST,
            "listen_port": int(
                bridge_config.get("listen_port") or TunBridgeConfig.DEFAULT_LISTEN_PORT
            ),
            "mtu": int(bridge_config.get("mtu") or TunBridgeConfig.DEFAULT_MTU),
            "enable_mptcp": bool(
                bridge_config.get("enable_mptcp", True)
            ),
            "aggregate": bool(
                bridge_config.get("aggregate", True)
            ),
            "tunnels": bridge_config.get("tunnels") or self._default_server_tunnels(tunnel_count),
        }

    async def _cleanup_failed_server_bridge(self, bridge_config: dict) -> None:
        """Server Bridge 启动失败时的补偿清理（含未登记 bridge_code 的残留 TUN）。"""
        if self.server_bridge_code and self.tun_bridge_service:
            try:
                ok = await self.tun_bridge_service.stop(self.server_bridge_code)
                if ok:
                    self.logger.info(
                        f"已停止失败的 Server Bridge: {self.server_bridge_code}"
                    )
                self.server_bridge_code = ""
            except Exception as exc:
                self.logger.warning(
                    f"停止失败的 Server Bridge {self.server_bridge_code} 异常: {exc}"
                )
                self.server_bridge_code = ""

        if not self.tun_bridge_service:
            return

        tunnels = bridge_config.get("tunnels") or self._default_server_tunnels(
            bridge_config.get("tunnel_count")
        )
        tun_names = [
            str(t.get("tun_name") or "")
            for t in tunnels
            if isinstance(t, dict) and t.get("tun_name")
        ]
        if tun_names:
            self.tun_bridge_service._best_effort_cleanup_tun_names(tun_names)
            self.logger.info(f"已尽力清理 Server Bridge 残留 TUN: {tun_names}")

    async def _auto_start_server_bridge(self, relay_code: str, bridge_config: dict) -> dict:
        payload = self._build_server_bridge_payload(relay_code, bridge_config)
        self.server_bridge_code = await self.tun_bridge_service.start_server(payload)
        bridge = await self.tun_bridge_service.get_bridge_info(self.server_bridge_code)
        return bridge or {"server_bridge_code": self.server_bridge_code}

    async def cleanup_data(self) -> tuple[bool, list[str], dict]:
        """清理节点上所有 Relay（响应 CLEANUP_DATA 指令）。"""
        self.logger.info("收到 CLEANUP_DATA 指令，开始清理节点数据")
        link_cleanup: dict = {"success": True, "skipped": True}

        if self._has_client_relay() and self.link_service:
            self.logger.info("检测到 Client Relay，先清理链路/电路/Client Bridge")
            link_cleanup = await self.link_service.cleanup_all_client_resources()
            link_cleanup["skipped"] = False

        relay_codes = list(self.context.relays.keys())
        destroyed_relays: list[str] = []
        all_success = link_cleanup.get("success", True)

        for relay_code in relay_codes:
            try:
                success = await self.destroy_relay(
                    relay_code, skip_client_link_cleanup=True
                )
                if success:
                    destroyed_relays.append(relay_code)
                else:
                    all_success = False
                    self.logger.error(f"清理数据时销毁 Relay 失败: {relay_code}")
            except Exception as e:
                all_success = False
                self.logger.error(f"清理数据时销毁 Relay 异常 {relay_code}: {e}")

        #重置上下文中的dir_auth
        self.context.dir_auth = []
        self.logger.info(f"重置上下文中的dir_auth 完成")

        self.logger.info(
            f"CLEANUP_DATA 完成，销毁 {len(destroyed_relays)}/{len(relay_codes)} 个中继"
        )
        return all_success, destroyed_relays, link_cleanup

    async def destroy_relay(
        self, relay_code: str, *, skip_client_link_cleanup: bool = False
    ) -> bool:
        if relay_code not in self.context.relays:
            self.logger.warning(f"尝试销毁不存在的Relay,默认返回成功。relay-code: {relay_code}")
            return True

        stem2tor = self.context.stem2tor_instances.get(relay_code)
        if (
            not skip_client_link_cleanup
            and stem2tor
            and stem2tor.role == "client"
            and self.link_service
        ):
            await self.link_service.cleanup_for_client_relay(relay_code)

        if stem2tor:
            try:
                result = await stem2tor.stop_tor()
                if not result:
                    self.logger.error(f"Relay {relay_code} 停止Tor容器失败，返回False")
                    return False
            except Exception as e:
                self.logger.error(f"销毁Relay容器异常: {e}")

            del self.context.stem2tor_instances[relay_code]

        del self.context.relays[relay_code]

        # 终止Server Bridge
        if self.server_bridge_code and self.tun_bridge_service:
            ok = await self.tun_bridge_service.stop(self.server_bridge_code)
            if ok:
                self.server_bridge_code = None
                self.logger.info(f"Relay {relay_code} 终止Server Bridge成功.")
            else:
                self.logger.warning(f"Relay {relay_code} 终止Server Bridge失败, server-bridge-code:{self.server_bridge_code}不存在.")

        self.context.node.remove_relay(
            relay_code=relay_code, current_count=len(self.context.relays)
        )

        #清理上下文中的dir_auth
        if self.context.dir_auth:
            self.context.dir_auth = []
            self.logger.info(f"清理上下文中的dir_auth 完成")

        await self.reporter.report_node_info()
        await self.reporter.report_relay_info()

        self.logger.info(f"Relay {relay_code} 销毁成功")
        return True

    async def update_relay(self, relay_code: str, config: dict) -> bool:
        if relay_code not in self.context.relays:
            self.logger.warning(f"尝试更新不存在的Relay: {relay_code}")
            return False

        relay = self.context.relays.get(relay_code)

        if "nickname" in config:
            relay.nickname = config["nickname"]
        if "bandwidth" in config:
            relay.bandwidth = config["bandwidth"]
        if "exit_policy" in config:
            relay.exit_policy = config["exit_policy"]

        await self.reporter.push_relays([relay])
        self.logger.info(f"Relay {relay_code} 更新成功")
        return True

    def get_allow_auto_circuit(
        self, client_relay_code: Optional[str] = None
    ) -> bool:
        """读取 Client Relay 当前是否允许 Tor 自动建路。"""
        if not self.link_service:
            return False
        return self.link_service.get_allow_auto_circuit(client_relay_code)

    async def set_allow_auto_circuit(
        self, allow: bool, client_relay_code: Optional[str] = None
    ) -> dict:
        """设置 Client Relay 是否允许 Tor 自动建路，并同步透明代理出口。

        透明代理同步失败时回滚 allow_auto_circuit 到变更前的值。
        """
        if not self.link_service:
            raise RuntimeError("LinkService 未绑定，无法设置 allow_auto_circuit")

        if not client_relay_code:
            raise ValueError("缺少必要参数: client_relay_code")

        relay = self.context.relays.get(client_relay_code)
        if not relay:
            raise ValueError(f"Client Relay {client_relay_code} 不存在")
        if relay.relay_role != vps_management_pb2.RelayRole.ROLE_CLIENT:
            raise ValueError("目标不是 CLIENT 角色中继")

        prev_allow = self.link_service.get_allow_auto_circuit(client_relay_code)
        result = self.link_service.set_allow_auto_circuit(
            allow=allow, client_relay_code=client_relay_code
        )
        try:
            proxy_mode = await self.link_service.sync_proxy_for_client_relay(
                client_relay_code
            )
            result["proxy_mode"] = proxy_mode
        except Exception as proxy_exc:
            self.logger.error(
                f"设置 allow_auto_circuit 后同步透明代理失败: {proxy_exc}"
            )
            try:
                self.link_service.set_allow_auto_circuit(
                    allow=prev_allow, client_relay_code=client_relay_code
                )
                self.logger.info(
                    f"已回滚 allow_auto_circuit={prev_allow}, "
                    f"client_relay_code={client_relay_code}"
                )
            except Exception as rollback_exc:
                self.logger.error(
                    f"回滚 allow_auto_circuit 失败: {rollback_exc}"
                )
            result["proxy_sync_error"] = str(proxy_exc)
            result["allow_auto_circuit"] = prev_allow
            raise

        self.logger.info(
            f"RelayService 已设置 allow_auto_circuit={allow}, "
            f"client_relay_code={client_relay_code}, proxy_mode={result.get('proxy_mode')}"
        )
        return result
