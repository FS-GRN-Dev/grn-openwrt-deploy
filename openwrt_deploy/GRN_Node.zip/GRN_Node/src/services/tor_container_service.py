import docker
import time
import socket
import re
import asyncio
import utils.logger
from typing import Optional, List, Dict, Any
from docker.models.containers import Container
from config.tor_node_config import TorNodeConfig

class TorContainerService:
    def __init__(self, config: TorNodeConfig):
        self.config = config
        self.client = docker.from_env()
        self.container: Optional[Container] = None
        self.container_id: Optional[str] = None
        self.container_ip_addr: Optional[str] = None
        self.container_name = f"{config.role}-{config.nick}"
        self.logger = utils.logger.get_logger("TorContainerService")

    def start_container(self) -> Optional[str]:
        """
        启动 Tor Docker 容器
        """
        try:
            # 清理旧容器
            for container in self.client.containers.list():
                container_ports = container.attrs['NetworkSettings']['Ports']
                # 简单的端口检查，实际可能需要更严谨的判断
                if str(self.config.or_port) in str(container_ports) or str(self.config.control_port) in str(container_ports):
                    container_image_tags = container.image.tags if container.image else []
                    container_image_tag = container_image_tags[0] if container_image_tags else None
                    if (self.config.image in container_image_tag) or container.name == self.container_name:
                         self.logger.warning(f"⚠️ 发现同名容器 镜像标签:{container_image_tag}，容器名:{container.name} 正在运行，正在停止并删除...")
                         container.stop()
                         container.remove()
                         self.logger.info(f"✅ 旧容器 {container.name} 已删除")

            # 检查是否存在停止的同名容器
            try:
                self.container = self.client.containers.get(self.container_name)
                if self.container.status != 'running':
                    self.container.start()
                
                self._update_container_ip()
                self.logger.warning(f"⚠️ 已存在同名容器: {self.container_name}，复用之。")
                return self.container.id
            except docker.errors.NotFound:
                pass

            self.logger.info(f"🚀 启动容器: {self.container_name}")
            
            # 构建环境变量
            environment = {
                "ROLE": self.config.role,
                "NICK": self.config.nick,
                "TOR_PWD": self.config.pwd,
                "OR_PORT": self.config.or_port,
                "CONTROL_PORT": self.config.control_port,
                "OUTER_IP_ADDR": self.config.outer_ip_addr,
                "DIR_PORT": self.config.dir_port,
            }

            if self.config.dir_auths:
                # if isinstance(self.config.dir_auths, dict):
                #      da = self.config.dir_auths
                #      environment["TOR_DIR_AUTHORITIES"] = f"DirAuthority {da['nick']} orport={da['or_port']} no-v2 " \
                #         f"v3ident={da['v3_ident']} {da['ip_address']} {da['fingerprint']}"
                # elif isinstance(self.config.dir_auths, list) and len(self.config.dir_auths) > 0:
                #      da = self.config.dir_auths[0]
                #      environment["TOR_DIR_AUTHORITIES"] = f"DirAuthority {da['nick']} orport={da['or_port']} no-v2 " \
                #         f"v3ident={da['v3_ident']} {da['ip_address']} {da['fingerprint']}"

                # 统一转换为 list 进行处理
                if isinstance(self.config.dir_auths, dict):
                    da_list = [self.config.dir_auths]
                elif isinstance(self.config.dir_auths, list):
                    da_list = self.config.dir_auths
                else:
                    da_list = []
    
                if da_list:
                    da_lines = []
                    for da in da_list:
                        # 拼接每一行 DirAuthority
                        da_lines.append(
                            f"DirAuthority {da['nick']} orport={da['or_port']} no-v2 "
                            f"v3ident={da['v3_ident']} {da['ip_address']} {da['fingerprint']}"
                        )
                    # 使用换行符连接多条配置，容器内脚本写入 torrc 时会自动变成多行
                    environment["TOR_DIR_AUTHORITIES"] = "\n".join(da_lines)

            run_args = {
                "image": self.config.image,
                "name": self.container_name,
                "detach": True,
                "environment": environment,
                "auto_remove": False,
                "network_mode": self.config.network_mode,
            }

            # 端口映射
            # 注意：端口映射不应依赖 outer_ip_addr。
            # outer_ip_addr 仅用于 Tor 节点对外宣告/路由相关逻辑；Docker publish 端口不需要它。
            # 若在 bridge 模式下不 publish SOCKS/CONTROL，宿主机将无法通过 127.0.0.1:<port> 访问，
            # 常见症状就是 client 侧出现 Connection refused。
            if self.config.network_mode != "host":
                ports = {}
                if self.config.role == "da":
                    ports = {
                        f"{self.config.control_port}/tcp": self.config.control_port,
                        f"{self.config.or_port}/tcp": self.config.or_port,
                        f"{self.config.dir_port}/tcp": self.config.dir_port,
                    }
                elif self.config.role == "relay" or self.config.role == "exit":
                    ports = {
                        f"{self.config.control_port}/tcp": self.config.control_port,
                        f"{self.config.or_port}/tcp": self.config.or_port,
                    }
                elif self.config.role == "client":
                    ports = {
                        f"{self.config.control_port}/tcp": self.config.control_port,
                        f"{self.config.socks_port}/tcp": self.config.socks_port
                    }
                run_args["ports"] = ports

            self.client.containers.run(**run_args)
            self.container = self.client.containers.get(self.container_name)
            
            # 检查容器状态
            if self.container.status != 'running':
                self.logger.warning(f"容器 {self.container_name} 未运行，正在启动...")
                self.container.start()
                time.sleep(1)  # 等待容器启动
            
            self._update_container_ip()

            if self.config.role == "da":
                time.sleep(3)

            self.start_tor_process()
            self.logger.info("⏳ 等待 Tor 控制端口就绪...")
            
            if self.wait_for_port(self.config.control_port):
                self.logger.info("✅ Tor 控制端口已就绪！")
                self.container_id = self.container.id
                return self.container.id
            else:
                self.logger.warning("❌ 等待超时，Shr 可能未成功启动")
            
            return None

        except docker.errors.DockerException as err:
            self.logger.error(f"🐳 Docker 错误: {err}")
        except Exception as e:
            self.logger.error(f"❌ 启动容器失败: {e}")
        
        return None

    def stop_container(self) -> bool:
        """停止并删除容器"""
        if self.container:
            try:
                self.logger.info(f"🧹 删除容器: {self.container_name} ")
                self.container.stop()
                self.container.remove()
                self.container = None
                self.container_id = None
                return True
            except docker.errors.NotFound:
                self.logger.warning(f"⚠️ 容器 {self.container_name} 不存在，跳过删除。 ")
            except docker.errors.APIError as e:
                self.logger.error(f"❌ 删除容器失败: {e} ")
                return False
        return True

    def _update_container_ip(self):
        """更新容器IP地址"""
        if self.container:
            self.container.reload()
            networks = self.container.attrs['NetworkSettings']['Networks']
            self.logger.info(f"networks: {networks}")
            network_info = networks.get(self.config.network_mode) or next(iter(networks.values()), {})
            self.logger.info(f"network_info: {network_info}")
            self.container_ip_addr = network_info.get('IPAddress', '')

    def wait_for_port(self, port: int, timeout: int = 10) -> bool:
        """等待某个端口变为可连接状态"""
        target_ip = self.container_ip_addr
        if not target_ip:
             # 如果是 host 模式，可能是 localhost
             if self.config.network_mode == 'host':
                 target_ip = '127.0.0.1'
             else:
                 return False

        for _ in range(timeout):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(1)
                try:
                    sock.connect((target_ip, port))
                    return True
                except (ConnectionRefusedError, socket.timeout, OSError):
                    time.sleep(1)
        return False

    def exec_command(self, cmd: str, user: str = "root"):
        """在容器内执行命令"""
        if self.container:
            return self.container.exec_run(cmd, user=user)
        return None

    def stop_tor_process(self):
        """停止容器内的 tor 进程"""
        if not self.container:
            self.logger.error("❌ 容器句柄未初始化")
            return
        self.logger.info("⛔ 停止容器内 tor 服务... ")
        self.container.exec_run("pkill -x tor", user="root")

    def start_tor_process(self):
        """以 debian-tor 用户重启 tor 进程"""
        if not self.container:
            self.logger.error("❌ 容器句柄未初始化")
            return
        self.logger.info("🔄 重启容器内 tor 服务... ")

        self.container.exec_run(
            "sudo -u debian-tor tor -f /etc/tor/torrc",
            user="root",
            detach=True
        )

    async def get_dir_auths(self) -> Optional[List[Dict[str, Any]]]:
        """从容器内获取 DirAuthority 信息"""
        if not self.container:
            self.logger.error("❌ 容器句柄未初始化")
            return None

        try:
            res = self.container.exec_run("cat /etc/tor/torrc")
            self.logger.info(f"exec_run: 命令执行结果: exit_code={res.exit_code}")

            if res.exit_code != 0:
                self.logger.error(f"❌ 获取torrc文件失败: {res.output.decode('utf-8')}")
                return None

            output = res.output.decode('utf-8')
            self.logger.info(f"res.output: {output}")
            self.logger.info(f"get_dir_auths: 文件内容获取成功，开始解析")

            dir_auths = []
            for line in output.splitlines():
                line = line.strip()
                if line.startswith("DirAuthority"):
                    parts = line.split()
                    if len(parts) >= 6:
                        nick = parts[1]
                        # 简单的正则提取，假设格式固定
                        orport_match = re.search(r'orport=(\d+)', line)
                        orport = int(orport_match.group(1)) if orport_match else None
                        v3ident_match = re.search(r'v3ident=([A-F0-9]+)', line)
                        v3ident = v3ident_match.group(1) if v3ident_match else None
                        fingerprint = parts[-1]

                        self.logger.info(f"nick: {nick}")
                        self.logger.info(f"orport: {orport}")
                        self.logger.info(f"v3ident: {v3ident}")
                        self.logger.info(f"fingerprint: {fingerprint}")
                        
                        # 尝试提取地址
                        # 排除已知 key=value 格式和 no-v2
                        address = None
                        for p in parts[2:]:
                            if not p.startswith(('orport=', 'no-v2', 'v3ident=')) and not p == fingerprint:
                                address = p
                                break
                        
                        self.logger.info(f"address: {address}")

                        if orport and v3ident and address and fingerprint:
                            dir_auths.append({
                                "nick": nick,
                                "orport": orport,
                                "v3ident": v3ident,
                                "address": address,
                                "fingerprint": fingerprint
                            })
            self.logger.info(f"get_dir_auths: 解析完成，共获取 {len(dir_auths)} 个DirAuthority")
            return dir_auths if dir_auths else None
        except Exception as e:
            self.logger.error(f"获取 DirAuths 失败: {e}")
            return None

    async def update_dir_auths(self, dir_auths: List[Dict]):
        """更新容器内的 DirAuthority 配置"""
        if not self.container:
            self.logger.error("❌ 容器句柄未初始化")
            return
        
        self.stop_tor_process()

        try:
            res = self.container.exec_run("cat /etc/tor/torrc ", user="root")
            torrc_text = res.output.decode('utf-8')

            cleaned_torrc = "\n".join(
                line for line in torrc_text.splitlines()
                if not line.strip().startswith("DirAuthority ")
            )

            dir_lines = [
                f"DirAuthority {a['nick']} orport={a['or_port']} no-v2 "
                f"v3ident={a['v3_ident']} {a['ip_address']} {a['fingerprint']} "
                for a in dir_auths
            ]
            
            updated_torrc = cleaned_torrc.strip() + "\n" + "\n".join(dir_lines) + "\n"

            # 写入文件
            escaped_content = updated_torrc.replace('"', '\\"').replace('$', '\\$')
            write_cmd = f'sh -c "echo \\"{escaped_content}\\" > /etc/tor/torrc"'
            self.logger.info(f"update_dir_auths: write_cmd={write_cmd}")
            result = self.container.exec_run(write_cmd, user="root")
            
            if result.exit_code != 0:
                self.logger.error(f"❌ 写入 torrc 失败: {result.output.decode('utf-8')}")

            self.start_tor_process()
            await asyncio.sleep(2)
            
            # 检查进程
            result = self.container.exec_run("pgrep tor ", user="root")
            if result.exit_code == 0:
                self.logger.info("🟢 tor 进程已启动 ")
            else:
                self.logger.error("❌ shr 启动失败，请检查 torrc 配置 ")
                
        except Exception as e:
            self.logger.error(f"更新 DirAuths 失败: {e}")
            raise e