import utils.logger
import asyncio
import uuid
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

from config.config import LinkType, TunBridgeConfig, LinkEnableAction, SwitchType
from core.circuit_manager import CircuitManager
from models.circuit import Circuit
from services.transparent_proxy import (
    derive_peer_addrs,
    derive_server_addrs,
    switch_proxy_to_direct,
    switch_proxy_to_mptcp,
    switch_proxy_to_socks,
)

from generated import vps_management_pb2


@dataclass
class LinkGroup:
    link_id: str
    client_relay_code: str
    path_type: int
    links: list[dict[str, Any]] = field(default_factory=list)
    sub_link_ids: list[str] = field(default_factory=list)
    client_bridge_code: str = ""
    server_bridge_code: str = ""


class LinkService:
    def __init__(self, context, reporter, tun_bridge_service=None):
        self.context = context
        self.reporter = reporter
        self.tun_bridge_service = tun_bridge_service
        self.logger = utils.logger.get_logger(f"{self.__class__.__name__}")

        # Dev Features, for testing only
        self._circuit_managers: Dict[str, CircuitManager] = {}
        self._link_groups: Dict[str, LinkGroup] = {}
        self._parent_link_map: Dict[str, list[str]] = {}
        self._parent_path_type: Dict[str, int] = {}
        # 找不到映射电路时是否允许 Tor 自动建路（默认禁止）
        self._allow_auto_circuit_default: bool = False
        self._allow_auto_circuit_by_relay: Dict[str, bool] = {}
        self._enable_locks: Dict[str, asyncio.Lock] = {}

    def _new_link_group_id(self) -> str:
        return f"link-group-{uuid.uuid4().hex[:8]}"

    def _store_link_group(self, group: LinkGroup) -> None:
        self._link_groups[group.link_id] = group
        self._parent_link_map[group.link_id] = list(group.sub_link_ids)
        self._parent_path_type[group.link_id] = group.path_type

    def _remove_link_group(self, link_id: str) -> None:
        self._link_groups.pop(link_id, None)
        self._parent_link_map.pop(link_id, None)
        self._parent_path_type.pop(link_id, None)

    def _build_legacy_single_group(self, link_id: str) -> Optional[LinkGroup]:
        for relay_code, manager in self._circuit_managers.items():
            if manager.get_circuit_for_link(link_id):
                return LinkGroup(
                    link_id=link_id,
                    client_relay_code=relay_code,
                    path_type=1,
                    links=[
                        {
                            "link_id": link_id,
                            "client_relay_code": relay_code,
                            "relay_fingerprints": [],
                            "circuit_id": manager.get_circuit_for_link(link_id),
                        }
                    ],
                    sub_link_ids=[link_id],
                )
        return None

    def get_link_group(self, link_id: str) -> Optional[LinkGroup]:
        if not link_id:
            return None
        if link_id in self._link_groups:
            return self._link_groups[link_id]

        parent_link_id = self._find_parent_link(link_id)
        if parent_link_id and parent_link_id in self._link_groups:
            return self._link_groups[parent_link_id]

        return self._build_legacy_single_group(link_id)

    def bind_client_bridge(self, link_id: str, bridge_code: str) -> None:
        group = self.get_link_group(link_id)
        if not group:
            return
        stored_group = self._link_groups.get(group.link_id)
        if stored_group:
            stored_group.client_bridge_code = bridge_code

    def clear_client_bridge(self, link_id: str, bridge_code: Optional[str] = None) -> None:
        group = self.get_link_group(link_id)
        if not group:
            return
        stored_group = self._link_groups.get(group.link_id)
        if not stored_group:
            return
        if bridge_code and stored_group.client_bridge_code != bridge_code:
            return
        stored_group.client_bridge_code = ""

    async def rename_link_group(self, old_link_id: str, new_link_id: str) -> Optional[LinkGroup]:
        if old_link_id == new_link_id:
            return self._link_groups.get(old_link_id)
        if new_link_id in self._link_groups:
            raise ValueError(f"link_id 已存在: {new_link_id}")

        group = self._link_groups.pop(old_link_id, None)
        if not group:
            return None

        self._parent_link_map.pop(old_link_id, None)
        self._parent_path_type.pop(old_link_id, None)

        group.link_id = new_link_id
        self._store_link_group(group)

        if self.tun_bridge_service and group.client_bridge_code:
            await self.tun_bridge_service.update_bridge_metadata(
                group.client_bridge_code,
                link_id=new_link_id,
            )
        return group

    def build_client_bridge_tunnels(
        self,
        link_id: str,
        tunnel_templates: Optional[list[dict[str, Any]]] = None,
    ) -> list[dict[str, Any]]:
        group = self.get_link_group(link_id)
        if not group or not group.sub_link_ids:
            raise ValueError(f"未找到可用于 TunClientBridge 的链路组: {link_id}")

        templates = tunnel_templates or []
        tunnels: list[dict[str, Any]] = []
        for index, sub_link_id in enumerate(group.sub_link_ids):
            template = templates[index] if index < len(templates) else {}
            tun_name = str(template.get("tun_name") or f"tun{index}")
            tun_addr_cidr = str(template.get("tun_addr_cidr") or f"10.0.{index + 1}.1/24")
            tunnels.append(
                {
                    "tun_name": tun_name,
                    "tun_addr_cidr": tun_addr_cidr,
                    "link_id": sub_link_id,
                }
            )
        return tunnels

    def get_or_create_circuit_manager(
        self, client_relay_code: str
    ) -> Optional[CircuitManager]:
        """获取或创建指定 Client Relay 的 CircuitManager"""
        # 实际来讲，一般只有被指定为 Client Relay 的节点才会有 CircuitManager
        if client_relay_code in self._circuit_managers:
            return self._circuit_managers[client_relay_code]

        stem2tor = self.context.stem2tor_instances.get(client_relay_code)
        if not stem2tor:
            self.logger.error(f"Client Relay {client_relay_code} 不存在")
            return None

        manager = CircuitManager(self.context, self.reporter, stem2tor, client_relay_code)
        allow = self._allow_auto_circuit_by_relay.get(
            client_relay_code, self._allow_auto_circuit_default
        )
        manager.set_allow_auto_circuit(allow)
        self._circuit_managers[client_relay_code] = manager
        return manager

    def get_allow_auto_circuit(
        self, client_relay_code: Optional[str] = None
    ) -> bool:
        """读取指定 Client Relay（或默认）当前 allow_auto_circuit 状态。"""
        if client_relay_code:
            manager = self._circuit_managers.get(client_relay_code)
            if manager is not None:
                return bool(manager.allow_auto_circuit)
            return bool(
                self._allow_auto_circuit_by_relay.get(
                    client_relay_code, self._allow_auto_circuit_default
                )
            )
        return bool(self._allow_auto_circuit_default)

    def set_allow_auto_circuit(
        self, allow: bool, client_relay_code: Optional[str] = None
    ) -> dict[str, Any]:
        """设置 Client Relay 是否允许 Tor 自动建路。

        Args:
            allow: True 允许 attach(0)；False 无映射时 close_stream
            client_relay_code: 指定 Client Relay；为空则更新默认值并应用到全部已有 manager
        """
        allow = bool(allow)
        updated: list[str] = []

        if client_relay_code:
            self._allow_auto_circuit_by_relay[client_relay_code] = allow
            manager = self._circuit_managers.get(client_relay_code)
            if manager:
                manager.set_allow_auto_circuit(allow)
            updated.append(client_relay_code)
        else:
            self._allow_auto_circuit_default = allow
            for relay_code, manager in self._circuit_managers.items():
                self._allow_auto_circuit_by_relay[relay_code] = allow
                manager.set_allow_auto_circuit(allow)
                updated.append(relay_code)

        self.logger.info(
            f"set_allow_auto_circuit allow={allow}, "
            f"client_relay_code={client_relay_code or '<all>'}, updated={updated}"
        )
        return {
            "allow_auto_circuit": allow,
            "client_relay_code": client_relay_code or "",
            "updated_relays": updated,
        }

    async def sync_proxy_for_client_relay(self, client_relay_code: str) -> str:
        """按激活链路与 allow_auto_circuit 同步透明代理出口。

        状态机：
        - 有激活多链路 → 保持 mptcp（不因本开关改动）
        - 有激活单链路 → socks5
        - 都无激活且 allow_auto_circuit=开 → socks5
        - 都无激活且 allow_auto_circuit=关 → direct

        Returns:
            目标模式标签：\"mptcp-tunnel\" | \"socks5\" | \"direct\"
            （mptcp-tunnel 表示检测到多链路激活且未改 selector）
        """
        client_relay_code = str(client_relay_code or "").strip()
        if not client_relay_code:
            raise ValueError("缺少 client_relay_code，无法同步透明代理")

        manager = self._circuit_managers.get(client_relay_code)
        if manager and manager.get_active_multi_link_id():
            self.logger.info(
                "sync_proxy: 已有激活多链路，保持 mptcp "
                f"(client_relay_code={client_relay_code}, "
                f"multi={manager.get_active_multi_link_id()})"
            )
            return "mptcp-tunnel"

        single_count = manager.get_active_single_count() if manager else 0
        allow = self.get_allow_auto_circuit(client_relay_code)

        if single_count > 0 or allow:
            await switch_proxy_to_socks()
            mode = "socks5"
        else:
            await switch_proxy_to_direct()
            mode = "direct"

        self.logger.info(
            f"sync_proxy: 已切换到 {mode} "
            f"(client_relay_code={client_relay_code}, "
            f"single_count={single_count}, allow_auto_circuit={allow})"
        )
        return mode

    async def create_circuit_with_link(
        self,
        relay_fingerprints: list,
        client_relay_code: str,
        link_id: Optional[str] = None,
        set_as_default: bool = False,
    ) -> tuple[Optional[Circuit], Optional[str]]:
        """
        创建电路并关联到 Link

        Args:
            relay_fingerprints: 路径指纹列表
            client_relay_code: 发起建链的 Client Relay ID
            link_id: 可选，指定 link_id；如果不指定则自动生成
            set_as_default: 是否设为默认链路（兼容字段；新链路默认不激活，需 enable 入池）

        Returns:
            (Circuit, link_id) 或 (None, None)
        """
        # 1. 获取 CircuitManager
        manager = self.get_or_create_circuit_manager(client_relay_code)
        if not manager:
            raise ValueError(f"Client Relay {client_relay_code} 不存在或未启动")

        # 2. 确保 CircuitManager 已启动
        if not manager._is_running:
            success = await manager.start()
            if not success:
                raise RuntimeError("CircuitManager 启动失败")

        # 3. 生成或使用提供的 link_id
        if not link_id:
            link_id = manager.generate_link_id()

        # 4. 注册链路并创建电路
        circuit_id = await manager.register_link(
            link_id=link_id, path=relay_fingerprints, set_as_default=set_as_default
        )

        if not circuit_id:
            raise RuntimeError("电路创建失败")

        self.logger.info(f"电路创建成功: {circuit_id}, 关联链路: {link_id}")

        # 5. 获取电路详细信息
        stem2tor = self.context.stem2tor_instances.get(client_relay_code)
        circuit_info = await stem2tor.get_circuit_info(circuit_id)

        if circuit_info:
            circuit = Circuit.from_stem_circuit_info(
                circuit_id=circuit_id,
                circuit_info=circuit_info,
                relay_fingerprints=relay_fingerprints,
                client_relay_code=client_relay_code,
                node_code=self.context.node_code,
                link_id=link_id,  # 新增：关联 link_id
            )

            # 存储到活动电路字典
            self.context.active_circuits[circuit_id] = circuit
            return circuit, link_id
        else:
            self.logger.error(f"无法获取电路信息: {circuit_id}")
            return None, link_id

    async def create_link(
        self,
        parent_link_id: str,
        client_relay_code: str,
        path_type: int,
        link_list: list[dict],
    ) -> dict:
        if not link_list:
            raise ValueError("link_list 不能为空")

        normalized_path_type = 2 if int(path_type) == 2 else 1
        entries = link_list if normalized_path_type == 2 else link_list[:1]

        requested_parent_link_id = str(parent_link_id or "")
        parent_link_id = requested_parent_link_id or self._new_link_group_id()
        results: list[dict[str, Any]] = []
        sub_link_ids: list[str] = []
        successful_links: list[dict[str, Any]] = []

        for index, entry in enumerate(entries):
            sub_link_id = entry.get("link_id") or None
            relay_code = entry.get("client_relay_code") or client_relay_code
            fingerprints = entry.get("relay_fingerprints") or entry.get("relay_ids") or []
            if isinstance(fingerprints, str):
                fingerprints = [fp.strip() for fp in fingerprints.split(",") if fp.strip()]

            try:
                circuit, assigned_link_id = await self.create_circuit_with_link(
                    relay_fingerprints=fingerprints,
                    client_relay_code=relay_code,
                    link_id=sub_link_id,
                    set_as_default=False,
                )
                circuit_id = circuit.circuit_id if circuit else None
                if assigned_link_id:
                    sub_link_ids.append(assigned_link_id)
                result_item = {
                    "link_id": assigned_link_id,
                    "circuit_code": circuit_id,
                    "circuit_info": circuit.to_json_response() if circuit else None,
                    "client_relay_code": relay_code,
                    "relay_fingerprints": fingerprints,
                    "success": circuit is not None,
                    "error": None if circuit else "电路创建成功但无法获取电路信息",
                }
                results.append(result_item)
                if circuit is not None and assigned_link_id:
                    successful_links.append(result_item)
            except Exception as exc:
                self.logger.error(f"子链路创建失败 (index={index}): {exc}")
                results.append(
                    {
                        "link_id": sub_link_id or "",
                        "circuit_code": None,
                        "circuit_info": None,
                        "client_relay_code": relay_code,
                        "relay_fingerprints": fingerprints,
                        "success": False,
                        "error": str(exc),
                    }
                )

        if sub_link_ids:
            if not requested_parent_link_id and normalized_path_type == 1:
                parent_link_id = sub_link_ids[0]
            group = LinkGroup(
                link_id=parent_link_id,
                client_relay_code=client_relay_code,
                path_type=normalized_path_type,
                links=successful_links,
                sub_link_ids=sub_link_ids,
            )
            self._store_link_group(group)

        return {
            "link_id": parent_link_id,
            "path_type": normalized_path_type,
            "client_relay_code": client_relay_code,
            "sub_link_ids": sub_link_ids,
            "results": results,
        }

    def get_sub_links(self, parent_link_id: str) -> list[str]:
        group = self.get_link_group(parent_link_id)
        if not group:
            return []
        return list(group.sub_link_ids)

    async def delete_link_group(self, parent_link_id: str, client_relay_code: str) -> dict:
        group = self.get_link_group(parent_link_id)
        if not group:
            return {"link_id": parent_link_id, "results": [], "warning": "链路组不存在"}

        if group.link_id in self._link_groups:
            self._remove_link_group(group.link_id)

        entry_map = {
            str(entry.get("link_id") or ""): entry for entry in group.links if entry.get("link_id")
        }
        results = []
        for sub_link_id in group.sub_link_ids:
            entry = entry_map.get(sub_link_id, {})
            relay_code = entry.get("client_relay_code") or client_relay_code or group.client_relay_code
            try:
                ok = await self.delete_circuit(sub_link_id, relay_code)
                results.append({"link_id": sub_link_id, "client_relay_code": relay_code, "success": ok, "error": None if ok else "删除电路失败"})
            except Exception as exc:
                results.append({"link_id": sub_link_id, "client_relay_code": relay_code, "success": False, "error": str(exc)})
        return {"link_id": group.link_id, "results": results}

    async def create_circuit(
        self, relay_fingerprints: list, client_relay_code: str
    ) -> Circuit | None:
        """
        创建电路
        Args:
            relay_ids: 路径上的 Relay 指纹列表 (或 ID)
            client_relay_code: 发起建链的本地 Client Relay ID
        """
        # 保持接口兼容，调用 create_circuit_with_link，不关联 Link
        circuit, _ = await self.create_circuit_with_link(
            relay_fingerprints=relay_fingerprints,
            client_relay_code=client_relay_code,
            set_as_default=False,
        )
        return circuit

    async def delete_circuit(self, link_id: str, client_relay_code: str) -> bool:
        """删除电路"""
        stem2tor = self.context.stem2tor_instances.get(client_relay_code)
        if not stem2tor:
            raise ValueError(f"Client Relay {client_relay_code} 不存在")

        circuit_id = None
        manager = self._circuit_managers.get(client_relay_code)
        # 尽量在关闭前标记，避免 CLOSED 事件触发自动重建
        if manager:
            circuit_id = manager.get_circuit_for_link(link_id)
            if circuit_id not in self.context.active_circuits:
                # 电路可能已在 CLOSED/重建失败时从 active_circuits 移除，
                # 但仍需清掉 _link_circuit_map 与启用池，避免轮询命中死电路。
                await manager.unregister_link(link_id, delete_circuit=False)
                self.logger.warning(f"尝试销毁不存在的电路,默认返回成功。circuit_id: {circuit_id}")
                return True

            manager.mark_circuit_for_manual_close(circuit_id)
        else:
            self.logger.error(f"销毁电路失败, client_relay_code对应电路管理器不存在，link-id: {link_id}")
            return False

        self.logger.info(f"正在删除电路: {circuit_id}")
        success = await stem2tor.delete_circuit(circuit_id)

        if success:
            # 清理 link -> circuit 映射，避免后续流继续命中已删除电路
            if manager:
                circuit_link_id = None
                circuit_model = self.context.active_circuits.get(circuit_id)
                if circuit_model and getattr(circuit_model, "link_id", None):
                    circuit_link_id = circuit_model.link_id
                if not circuit_link_id:
                    circuit_link_id = manager.find_link_by_circuit_id(circuit_id)
                if circuit_link_id:
                    await manager.unregister_link(circuit_link_id, delete_circuit=False)

            self.context.active_circuits.pop(circuit_id, None)

            self.logger.info(f"电路 {circuit_id} 删除成功")
        else:
            self.logger.warning(f"电路 {circuit_id} 删除失败")
            if manager:
                # 删除失败时撤销一次忽略标记
                try:
                    manager._ignore_closed_circuits.discard(str(circuit_id))
                except Exception:
                    pass
        return success

    # async def delete_link(self, link_id: str, client_relay_code: str) -> bool:
    #     """删除链路（会同时删除关联的电路）"""
    #     manager = self._circuit_managers.get(client_relay_code)
    #     if manager:
    #         return await manager.unregister_link(link_id)
    #     return False
    
    async def delete_single_link(self, link_id: str, client_relay_code: str) -> list[dict[str, Any]]:
        """删除单链路（会同时删除关联的电路）"""
        results: list[dict[str, Any]] = []
        success = await self.delete_circuit(link_id, client_relay_code)
        if success:
            # 有激活多 → 保持 mptcp；有激活单 → socks；都无 → 按 allow 收敛
            await self.sync_proxy_for_client_relay(client_relay_code)

        result_item = {
            "link_id": link_id,
            "client_relay_code": client_relay_code,
            "success": success,
            "error": None if success else "删除电路失败",
        }
        results.append(result_item)

        return results

    async def delete_multi_link(self, link_id: str, client_relay_code: str) -> list[dict[str, Any]]:
        """删除多链路（会同时删除关联的电路）"""
        result = {
            "link_id": link_id,
            "path_type": LinkType.MULTI_LINK,
            "success": False,
            "old_bridge_cleanup": None,
            "old_bridge_info": None,
            "delete_old_link_results": None,
        }
        results: list[dict[str, Any]] = []

        manager = self._circuit_managers.get(client_relay_code)
        deleting_active_multi = bool(
            manager and manager.get_active_multi_link_id() == link_id
        )
        # 先停 bridge / 删组并清 multi 标记，再按剩余激活态 + allow 收敛 selector
        await self.stop_client_bridge(result, link_id, client_relay_code, True)
        if deleting_active_multi:
            await self.sync_proxy_for_client_relay(client_relay_code)
        bridge_cleanup = result.get("old_bridge_cleanup")
        if bridge_cleanup and isinstance(bridge_cleanup, list) and len(bridge_cleanup) > 0:
            first_bridge = bridge_cleanup[0]
            ok = first_bridge.get("stopped", False)
            if ok:
                self.logger.info(f"停止client bridge成功, link-id: {link_id}, client_relay_code: {client_relay_code}")
            else:
                self.logger.error(f"停止client bridge失败, link-id: {link_id}, client_relay_code: {client_relay_code}")
        else:
            self.logger.warning(f"client bridge的bridge info不存在, link-id: {link_id}, client_relay_code: {client_relay_code}")

        delete_old_link_results = result.get("delete_old_link_results") or {}
        results = list(delete_old_link_results.get("results") or [])
        # 节点本地已无该多链路组时，delete_link_group 会返回空 results + warning。
        # 对管理面按幂等删除成功处理，避免 None.get 崩溃或空结果被当成硬失败。
        if not results and delete_old_link_results.get("warning"):
            results = [
                {
                    "link_id": link_id,
                    "client_relay_code": client_relay_code,
                    "success": True,
                    "error": None,
                    "warning": delete_old_link_results.get("warning"),
                }
            ]

        return results

    async def delete_unified_link(self, path_type: int, link_id: str, client_relay_code: str) -> list[dict[str, Any]]:
        """删除统一链路"""
        """分成以下两种case进行实现
            1> 销毁单链路
            2> 销毁多链路
        """
        results: list[dict[str, Any]] = []

        if path_type == LinkType.SINGLE_LINK:
            results = await self.delete_single_link(link_id, client_relay_code)
        elif path_type == LinkType.MULTI_LINK:
            results = await self.delete_multi_link(link_id, client_relay_code)
        else:
            self.logger.error(f"删除统一链路失败, 未知的链路类型，path_type: {path_type}, link-id: {link_id}, client_relay_code: {client_relay_code}")
            results = []

        return {
            "path_type": path_type,
            "link_id": link_id,
            "client_relay_code": client_relay_code,
            "results": results,
        }

    def _get_enable_lock(self, client_relay_code: str) -> asyncio.Lock:
        if client_relay_code not in self._enable_locks:
            self._enable_locks[client_relay_code] = asyncio.Lock()
        return self._enable_locks[client_relay_code]

    @staticmethod
    def _link_id_for_response(link_id: str) -> Any:
        try:
            return int(link_id)
        except (TypeError, ValueError):
            return link_id

    def _build_enable_response(
        self,
        *,
        action: str,
        link_id: str,
        switch_type: Optional[int],
        client_relay_code: str,
        success: bool,
        switch_result: Optional[dict] = None,
        message: str = "",
        rolled_back: bool = False,
    ) -> dict[str, Any]:
        """构造启用/停用回执。

        管理面只根据 enabled_link_ids 同步启用集合（集合内=启用，其余=未启用）。
        success 表示本次意图是否达成；发生回滚时 success=False，并标记
        switch_result.rolled_back=True；enabled_link_ids 始终为回滚后的真实集合。
        """
        manager = self._circuit_managers.get(client_relay_code)
        enabled = manager.get_enabled_parent_link_ids() if manager else []
        result_switch = dict(switch_result or {})
        if rolled_back:
            result_switch["rolled_back"] = True
            # success 表示意图是否达成：发生回滚则保持失败（False），
            # 管理面启用态只看 enabled_link_ids
        return {
            "action": action,
            "link_id": self._link_id_for_response(link_id),
            "switch_type": switch_type,
            "enabled_link_ids": [self._link_id_for_response(x) for x in enabled],
            "switch_result": result_switch,
            "success": success,
            "message": message,
            "client_relay_code": client_relay_code,
        }

    def snapshot_enabled_link_ids(self, client_relay_code: str) -> list[Any]:
        """供 SWITCH_LINK 回执在异常路径回带当前启用集合。"""
        manager = self._circuit_managers.get(str(client_relay_code or "").strip())
        if not manager:
            return []
        return [self._link_id_for_response(x) for x in manager.get_enabled_parent_link_ids()]

    async def apply_link_enable_action(
        self,
        *,
        action: str,
        link_id: str,
        client_relay_code: str,
        switch_type: Optional[int] = None,
        bridge_info: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        """处理管理面启用/停用链路（SWITCH_LINK 新载荷）。"""
        action = (action or "").strip().lower()
        link_id = str(link_id).strip()
        client_relay_code = str(client_relay_code).strip()
        bridge_info = bridge_info or {}

        if not link_id or not client_relay_code:
            return self._build_enable_response(
                action=action or "enable",
                link_id=link_id or "0",
                switch_type=switch_type,
                client_relay_code=client_relay_code or "",
                success=False,
                message="缺少 link_id 或 client_relay_code",
            )

        async with self._get_enable_lock(client_relay_code):
            if action == LinkEnableAction.DISABLE:
                return await self._disable_link(
                    link_id=link_id,
                    client_relay_code=client_relay_code,
                )
            if action != LinkEnableAction.ENABLE:
                return self._build_enable_response(
                    action=action,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    message=f"不支持的 action: {action}",
                )
            if switch_type is None:
                return self._build_enable_response(
                    action=action,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    message="enable 缺少 switch_type",
                )
            return await self._enable_link_by_switch_type(
                switch_type=int(switch_type),
                link_id=link_id,
                client_relay_code=client_relay_code,
                bridge_info=bridge_info,
            )

    async def _enable_link_by_switch_type(
        self,
        *,
        switch_type: int,
        link_id: str,
        client_relay_code: str,
        bridge_info: dict[str, Any],
    ) -> dict[str, Any]:
        manager = self.get_or_create_circuit_manager(client_relay_code)
        if not manager:
            return self._build_enable_response(
                action=LinkEnableAction.ENABLE,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=client_relay_code,
                success=False,
                message=f"Client Relay {client_relay_code} 不存在",
            )
        if not manager._is_running:
            ok = await manager.start()
            if not ok:
                return self._build_enable_response(
                    action=LinkEnableAction.ENABLE,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    message="CircuitManager 启动失败",
                )

        switch_result: dict[str, Any] = {
            "switch_type": switch_type,
            "link_id": link_id,
        }
        if switch_type == SwitchType.SINGLE_TO_SINGLE:
            return await self._enable_single_to_single(
                manager=manager,
                link_id=link_id,
                client_relay_code=client_relay_code,
                switch_result=switch_result,
            )
        if switch_type == SwitchType.NONE_TO_SINGLE:
            return await self._enable_none_to_single(
                manager=manager,
                link_id=link_id,
                client_relay_code=client_relay_code,
                switch_result=switch_result,
            )
        if switch_type == SwitchType.MULTI_TO_SINGLE:
            return await self._enable_multi_to_single(
                manager=manager,
                link_id=link_id,
                client_relay_code=client_relay_code,
                switch_result=switch_result,
            )
        if switch_type in (
            SwitchType.SINGLE_TO_MULTI,
            SwitchType.NONE_TO_MULTI,
            SwitchType.MULTI_TO_MULTI,
        ):
            return await self._enable_to_multi(
                switch_type=switch_type,
                manager=manager,
                link_id=link_id,
                client_relay_code=client_relay_code,
                bridge_info=bridge_info,
                switch_result=switch_result,
            )
        return self._build_enable_response(
            action=LinkEnableAction.ENABLE,
            link_id=link_id,
            switch_type=switch_type,
            client_relay_code=client_relay_code,
            success=False,
            switch_result=switch_result,
            message=f"不支持的 switch_type: {switch_type}",
        )

    async def _safe_proxy_socks(self) -> None:
        try:
            await switch_proxy_to_socks()
        except Exception as proxy_exc:
            self.logger.error(f"回滚切换 socks 失败: {proxy_exc}")

    async def _safe_proxy_direct(self) -> None:
        try:
            await switch_proxy_to_direct()
        except Exception as proxy_exc:
            self.logger.error(f"回滚切换 direct 失败: {proxy_exc}")

    async def _safe_proxy_by_active_pool(self, manager: CircuitManager) -> None:
        """无激活多链路时：按剩余单池 + allow_auto_circuit 收敛到 socks 或 direct。

        与 sync_proxy_for_client_relay（无 multi 分支）语义一致：
        - 有激活单链路 → socks5
        - 无单 + allow 开 → socks5
        - 无单 + allow 关 → direct
        """
        active_single_count = manager.get_active_single_count()
        if manager.allow_auto_circuit or active_single_count > 0:
            await self._safe_proxy_socks()
        else:
            await self._safe_proxy_direct()

    async def _rollback_on_enable_failure(
        self,
        *,
        manager: CircuitManager,
        switch_type: int,
        link_id: str,
        newly_activated_single: bool = False,
    ) -> None:
        """按 switch_type 做启用失败补偿；proxy 一律按剩余池 + allow 收敛。"""
        if switch_type == SwitchType.SINGLE_TO_SINGLE:
            manager.deactivate_single(link_id)
        elif switch_type == SwitchType.NONE_TO_SINGLE:
            if newly_activated_single:
                manager.deactivate_single(link_id)
        elif switch_type == SwitchType.MULTI_TO_SINGLE:
            manager.deactivate_single(link_id)
        elif switch_type in (
            SwitchType.SINGLE_TO_MULTI,
            SwitchType.NONE_TO_MULTI,
            SwitchType.MULTI_TO_MULTI,
        ):
            if manager.get_active_multi_link_id() == link_id:
                manager.clear_multi_active()
        await self._safe_proxy_by_active_pool(manager)

    def _restore_prev_singles(
        self,
        manager: CircuitManager,
        prev_singles: list[str],
        switch_result: dict[str, Any],
    ) -> bool:
        """单切多失败时尽力恢复清池前的单链路；全部回到池中则返回 True。"""
        if not prev_singles:
            switch_result["restore_prev_singles"] = {
                "requested": [],
                "restored": [],
                "failed": [],
            }
            return False
        restored: list[str] = []
        failed: list[str] = []
        for prev_lid in prev_singles:
            try:
                if manager.activate_single(prev_lid):
                    restored.append(prev_lid)
                else:
                    failed.append(prev_lid)
            except Exception as reactivate_exc:
                self.logger.error(
                    f"单切多回滚 activate_single({prev_lid}) 失败: {reactivate_exc}"
                )
                failed.append(prev_lid)
        switch_result["restore_prev_singles"] = {
            "requested": list(prev_singles),
            "restored": restored,
            "failed": failed,
        }
        pool = set(manager.get_active_single_pool())
        return all(str(lid) in pool for lid in prev_singles)

    async def _rollback_single_to_multi_failure(
        self,
        *,
        manager: CircuitManager,
        link_id: str,
        prev_singles: list[str],
        switch_result: dict[str, Any],
    ) -> None:
        """单切多失败：清 multi、恢复旧单池；restore 成功 → socks，否则池+allow。"""
        if manager.get_active_multi_link_id() == link_id:
            manager.clear_multi_active()
        restore_ok = self._restore_prev_singles(
            manager, prev_singles, switch_result
        )
        switch_result["restore_prev_singles_ok"] = restore_ok
        try:
            if restore_ok:
                await self._safe_proxy_socks()
            else:
                await self._safe_proxy_by_active_pool(manager)
        except Exception as proxy_exc:
            self.logger.error(f"单切多回滚切换 proxy 异常: {proxy_exc}")
            switch_result["proxy_rollback_error"] = str(proxy_exc)

    async def _enable_single_to_single(
        self,
        *,
        manager: CircuitManager,
        link_id: str,
        client_relay_code: str,
        switch_result: dict[str, Any],
    ) -> dict[str, Any]:
        switch_type = SwitchType.SINGLE_TO_SINGLE
        try:
            ok = manager.activate_single(link_id)
            switch_result["activate_single"] = ok
            if not ok:
                manager.deactivate_single(link_id)
                return self._build_enable_response(
                    action=LinkEnableAction.ENABLE,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    switch_result=switch_result,
                    message="单切单失败：无电路映射",
                )
            try:
                active_single_count = manager.get_active_single_count()
                if manager.allow_auto_circuit or active_single_count > 0:
                    await switch_proxy_to_socks()
                else:
                    await switch_proxy_to_direct()
            except Exception as proxy_exc:
                await self._rollback_on_enable_failure(
                    manager=manager,
                    switch_type=switch_type,
                    link_id=link_id,
                )
                return self._build_enable_response(
                    action=LinkEnableAction.ENABLE,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    switch_result=switch_result,
                    rolled_back=True,
                    message=f"单切单 proxy 切换异常，已 deactivate 新单: {proxy_exc}",
                )
            return self._build_enable_response(
                action=LinkEnableAction.ENABLE,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=client_relay_code,
                success=True,
                switch_result=switch_result,
                message="启用单链路成功",
            )
        except Exception as exc:
            self.logger.error(f"单切单异常: {exc}")
            try:
                await self._rollback_on_enable_failure(
                    manager=manager,
                    switch_type=switch_type,
                    link_id=link_id,
                )
            except Exception as rollback_exc:
                self.logger.error(f"单切单回滚异常: {rollback_exc}")
            return self._build_enable_response(
                action=LinkEnableAction.ENABLE,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=client_relay_code,
                success=False,
                switch_result=switch_result,
                rolled_back=True,
                message=f"启用链路异常已回滚: {exc}",
            )

    async def _enable_none_to_single(
        self,
        *,
        manager: CircuitManager,
        link_id: str,
        client_relay_code: str,
        switch_result: dict[str, Any],
    ) -> dict[str, Any]:
        switch_type = SwitchType.NONE_TO_SINGLE
        newly_activated_single = False
        try:
            was_in_pool = link_id in manager.get_active_single_pool()
            ok = manager.activate_single(link_id)
            switch_result["activate_single"] = ok
            newly_activated_single = bool(ok) and not was_in_pool
            if not ok:
                manager.deactivate_single(link_id)
                return self._build_enable_response(
                    action=LinkEnableAction.ENABLE,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    switch_result=switch_result,
                    message="无切单失败：无电路映射",
                )
            try:
                active_single_count = manager.get_active_single_count()
                if manager.allow_auto_circuit or active_single_count > 0:
                    await switch_proxy_to_socks()
                else:
                    await switch_proxy_to_direct()
            except Exception as proxy_exc:
                await self._rollback_on_enable_failure(
                    manager=manager,
                    switch_type=switch_type,
                    link_id=link_id,
                    newly_activated_single=newly_activated_single,
                )
                return self._build_enable_response(
                    action=LinkEnableAction.ENABLE,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    switch_result=switch_result,
                    rolled_back=True,
                    message=(
                        f"无切单 proxy 切换异常已回滚（按池+allow 收敛）: {proxy_exc}"
                    ),
                )
            return self._build_enable_response(
                action=LinkEnableAction.ENABLE,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=client_relay_code,
                success=True,
                switch_result=switch_result,
                message="启用单链路成功",
            )
        except Exception as exc:
            self.logger.error(f"无切单异常: {exc}")
            try:
                await self._rollback_on_enable_failure(
                    manager=manager,
                    switch_type=switch_type,
                    link_id=link_id,
                    newly_activated_single=newly_activated_single,
                )
            except Exception as rollback_exc:
                self.logger.error(f"无切单回滚异常: {rollback_exc}")
            return self._build_enable_response(
                action=LinkEnableAction.ENABLE,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=client_relay_code,
                success=False,
                switch_result=switch_result,
                rolled_back=True,
                message=f"启用链路异常已回滚: {exc}",
            )

    async def _enable_multi_to_single(
        self,
        *,
        manager: CircuitManager,
        link_id: str,
        client_relay_code: str,
        switch_result: dict[str, Any],
    ) -> dict[str, Any]:
        switch_type = SwitchType.MULTI_TO_SINGLE
        try:
            old_multi = manager.get_active_multi_link_id() or ""
            if old_multi:
                try:
                    await self.stop_client_bridge(
                        switch_result, old_multi, client_relay_code
                    )
                except Exception as stop_exc:
                    self.logger.error(f"多切单 stop_client_bridge 异常: {stop_exc}")
                    switch_result["stop_client_bridge_error"] = str(stop_exc)
                manager.clear_multi_active()
            manager.clear_all_singles()
            ok = manager.activate_single(link_id)
            switch_result["activate_single"] = ok
            switch_result["old_multi_link_id"] = old_multi
            if not ok:
                await self._rollback_on_enable_failure(
                    manager=manager,
                    switch_type=switch_type,
                    link_id=link_id,
                )
                return self._build_enable_response(
                    action=LinkEnableAction.ENABLE,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    switch_result=switch_result,
                    rolled_back=True,
                    message="多切单失败：单链路无电路映射，已按池+allow 收敛 proxy",
                )
            try:
                active_single_count = manager.get_active_single_count()
                if manager.allow_auto_circuit or active_single_count > 0:
                    await switch_proxy_to_socks()
                else:
                    await switch_proxy_to_direct()
            except Exception as proxy_exc:
                await self._rollback_on_enable_failure(
                    manager=manager,
                    switch_type=switch_type,
                    link_id=link_id,
                )
                return self._build_enable_response(
                    action=LinkEnableAction.ENABLE,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    switch_result=switch_result,
                    rolled_back=True,
                    message=(
                        f"多切单 proxy 切换异常已回滚（按池+allow 收敛）: {proxy_exc}"
                    ),
                )
            return self._build_enable_response(
                action=LinkEnableAction.ENABLE,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=client_relay_code,
                success=True,
                switch_result=switch_result,
                message="多切单成功",
            )
        except Exception as exc:
            self.logger.error(f"多切单异常: {exc}")
            try:
                await self._rollback_on_enable_failure(
                    manager=manager,
                    switch_type=switch_type,
                    link_id=link_id,
                )
            except Exception as rollback_exc:
                self.logger.error(f"多切单回滚异常: {rollback_exc}")
            return self._build_enable_response(
                action=LinkEnableAction.ENABLE,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=client_relay_code,
                success=False,
                switch_result=switch_result,
                rolled_back=True,
                message=f"启用链路异常已回滚: {exc}",
            )

    async def _enable_to_multi(
        self,
        *,
        switch_type: int,
        manager: CircuitManager,
        link_id: str,
        client_relay_code: str,
        bridge_info: dict[str, Any],
        switch_result: dict[str, Any],
    ) -> dict[str, Any]:
        """单切多 / 无切多 / 多切多。"""
        bridge_started = False
        prev_singles_before_clear: list[str] = []

        async def _stop_new_bridge_best_effort() -> None:
            try:
                await self.stop_client_bridge(
                    switch_result, link_id, client_relay_code
                )
            except Exception as stop_exc:
                self.logger.error(
                    f"启用多链路回滚 stop_client_bridge 异常: {stop_exc}"
                )
                switch_result["stop_new_bridge_error"] = str(stop_exc)

        try:
            old_multi = manager.get_active_multi_link_id() or ""
            if old_multi and old_multi != link_id:
                try:
                    await self.stop_client_bridge(
                        switch_result, old_multi, client_relay_code
                    )
                except Exception as stop_exc:
                    self.logger.error(
                        f"启用多链路时 stop_client_bridge 异常: {stop_exc}"
                    )
                    switch_result["stop_client_bridge_error"] = str(stop_exc)
                manager.clear_multi_active()
            if old_multi:
                switch_result["old_multi_link_id"] = old_multi

            await self.start_client_bridge(
                switch_result, link_id, client_relay_code, bridge_info
            )
            bridge_ok = bool(
                (switch_result.get("new_bridge_info") or {}).get("success")
            )
            if not bridge_ok:
                if manager.get_active_multi_link_id() == link_id:
                    manager.clear_multi_active()
                # Bridge 未起来：按剩余单池 + allow 收敛（单切多时单池仍在 → socks）
                try:
                    await self._safe_proxy_by_active_pool(manager)
                except Exception as proxy_exc:
                    self.logger.error(
                        f"启用多链路 Bridge 失败后切换 proxy 异常: {proxy_exc}"
                    )
                    switch_result["proxy_rollback_error"] = str(proxy_exc)
                return self._build_enable_response(
                    action=LinkEnableAction.ENABLE,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    switch_result=switch_result,
                    rolled_back=True,
                    message=(
                        "单切多失败：启动 Bridge 失败，已回滚（按池+allow 收敛）"
                        if switch_type == SwitchType.SINGLE_TO_MULTI
                        else "启用多链路失败：启动 Bridge 失败，已按池+allow 收敛"
                    ),
                )

            bridge_started = True
            if switch_type in (
                SwitchType.SINGLE_TO_MULTI,
                SwitchType.NONE_TO_MULTI,
            ):
                prev_singles_before_clear = manager.get_active_single_pool()
                manager.clear_all_singles()
            manager.set_multi_active(link_id)
            try:
                await self._switch_proxy_mode(bridge_info)
            except Exception as proxy_exc:
                # Bridge 已启动但 proxy 失败：停 bridge，单切多恢复旧单池并按 restore 切 proxy
                await _stop_new_bridge_best_effort()
                if switch_type == SwitchType.SINGLE_TO_MULTI:
                    await self._rollback_single_to_multi_failure(
                        manager=manager,
                        link_id=link_id,
                        prev_singles=prev_singles_before_clear,
                        switch_result=switch_result,
                    )
                    rollback_msg = (
                        f"单切多 proxy 切换异常已回滚"
                        f"（停 bridge + 恢复旧单池）: {proxy_exc}"
                    )
                else:
                    if manager.get_active_multi_link_id() == link_id:
                        manager.clear_multi_active()
                    await self._rollback_on_enable_failure(
                        manager=manager,
                        switch_type=switch_type,
                        link_id=link_id,
                    )
                    rollback_msg = (
                        f"启用多链路 proxy 切换异常已回滚"
                        f"（停 bridge + 按池+allow 收敛）: {proxy_exc}"
                    )
                return self._build_enable_response(
                    action=LinkEnableAction.ENABLE,
                    link_id=link_id,
                    switch_type=switch_type,
                    client_relay_code=client_relay_code,
                    success=False,
                    switch_result=switch_result,
                    rolled_back=True,
                    message=rollback_msg,
                )
            return self._build_enable_response(
                action=LinkEnableAction.ENABLE,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=client_relay_code,
                success=True,
                switch_result=switch_result,
                message="启用多链路成功",
            )
        except Exception as exc:
            self.logger.error(f"启用多链路异常: {exc}")
            try:
                if bridge_started or bool(
                    (switch_result.get("new_bridge_info") or {}).get("success")
                ):
                    await _stop_new_bridge_best_effort()
                if switch_type == SwitchType.SINGLE_TO_MULTI:
                    await self._rollback_single_to_multi_failure(
                        manager=manager,
                        link_id=link_id,
                        prev_singles=prev_singles_before_clear,
                        switch_result=switch_result,
                    )
                else:
                    await self._rollback_on_enable_failure(
                        manager=manager,
                        switch_type=switch_type,
                        link_id=link_id,
                    )
            except Exception as rollback_exc:
                self.logger.error(f"启用多链路回滚异常: {rollback_exc}")
            return self._build_enable_response(
                action=LinkEnableAction.ENABLE,
                link_id=link_id,
                switch_type=switch_type,
                client_relay_code=client_relay_code,
                success=False,
                switch_result=switch_result,
                rolled_back=True,
                message=f"启用链路异常已回滚: {exc}",
            )

    async def _disable_link(
        self,
        *,
        link_id: str,
        client_relay_code: str,
    ) -> dict[str, Any]:
        manager = self._circuit_managers.get(client_relay_code)
        if not manager:
            return self._build_enable_response(
                action=LinkEnableAction.DISABLE,
                link_id=link_id,
                switch_type=None,
                client_relay_code=client_relay_code,
                success=False,
                message=f"Client Relay {client_relay_code} 不存在",
            )

        switch_result: dict[str, Any] = {"link_id": link_id}
        group = self.get_link_group(link_id)
        if group:
            resolved_path = group.path_type
        elif manager.get_active_multi_link_id() == link_id:
            resolved_path = LinkType.MULTI_LINK
        elif manager.get_circuit_for_link(link_id):
            resolved_path = LinkType.SINGLE_LINK
        else:
            resolved_path = None

        is_multi = (
            resolved_path == LinkType.MULTI_LINK
            or manager.get_active_multi_link_id() == link_id
        )
        was_in_single_pool = link_id in manager.get_active_single_pool()
        deactivated_single = False
        # 多链路停用进度：异常时只补未完成步骤，避免整段重跑
        multi_bridge_stopped = False
        multi_cleared = False

        async def _ensure_multi_disabled(*, best_effort: bool) -> None:
            """把多链路收敛到「未启用」，proxy 按剩余单池 + allow 选择 socks/direct。

            best_effort=False：成功路径，任一步失败直接抛出。
            best_effort=True：异常补偿，只补未完成步骤，错误仅记日志。
            """
            nonlocal multi_bridge_stopped, multi_cleared
            if manager.get_active_multi_link_id() == link_id:
                if not multi_bridge_stopped:
                    try:
                        await self.stop_client_bridge(
                            switch_result, link_id, client_relay_code
                        )
                        multi_bridge_stopped = True
                    except Exception as stop_exc:
                        if not best_effort:
                            raise
                        self.logger.error(
                            f"停用多链路补做 stop_client_bridge 失败: {stop_exc}"
                        )
                if not multi_cleared:
                    manager.clear_multi_active()
                    multi_cleared = True
                    switch_result["disabled_multi"] = True
            elif not multi_cleared:
                # 目标多链路本就未激活
                switch_result["disabled_multi"] = False
                switch_result["skipped"] = "目标多链路当前未激活"
                multi_cleared = True

            # 成功/失败均按 allow + 剩余单池收敛（需求：停多失败也按 allow）
            await self._safe_proxy_by_active_pool(manager)

        async def _rollback_single_disable_failure() -> None:
            """停用单失败（方案甲）：尽量恢复该单，再按池+allow 收敛 proxy。

            1）若本次已出池，尽量 activate 回去
            2）池非空（含刚加回）→ socks；池空 → 按 allow（开 socks / 关 direct）
            """
            if deactivated_single:
                try:
                    manager.activate_single(link_id)
                except Exception as reactivate_exc:
                    self.logger.error(
                        f"停用单回滚 activate_single 失败: {reactivate_exc}"
                    )
            await self._safe_proxy_by_active_pool(manager)

        try:
            if is_multi:
                try:
                    await _ensure_multi_disabled(best_effort=False)
                except Exception as multi_exc:
                    # 只补未完成步骤，不再整段重复执行
                    await _ensure_multi_disabled(best_effort=True)
                    return self._build_enable_response(
                        action=LinkEnableAction.DISABLE,
                        link_id=link_id,
                        switch_type=None,
                        client_relay_code=client_relay_code,
                        success=False,
                        switch_result=switch_result,
                        rolled_back=True,
                        message=f"停用多链路异常已收敛为停用（按池+allow 收敛 proxy）: {multi_exc}",
                    )
                return self._build_enable_response(
                    action=LinkEnableAction.DISABLE,
                    link_id=link_id,
                    switch_type=None,
                    client_relay_code=client_relay_code,
                    success=True,
                    switch_result=switch_result,
                    message="停用多链路成功",
                )

            try:
                ok = manager.deactivate_single(link_id)
                deactivated_single = was_in_single_pool
                switch_result["deactivate_single"] = ok
                active_single_count = manager.get_active_single_count()
                # 最后一个单：allow 开 → 显式切 socks；allow 关 → direct
                if ok and active_single_count == 0:
                    if manager.allow_auto_circuit:
                        await switch_proxy_to_socks()
                    else:
                        await switch_proxy_to_direct()
            except Exception as single_exc:
                await _rollback_single_disable_failure()
                return self._build_enable_response(
                    action=LinkEnableAction.DISABLE,
                    link_id=link_id,
                    switch_type=None,
                    client_relay_code=client_relay_code,
                    success=False,
                    switch_result=switch_result,
                    rolled_back=True,
                    message=f"停用单链路异常已回滚（尽量恢复单链路，proxy 按池+allow 收敛）: {single_exc}",
                )
            return self._build_enable_response(
                action=LinkEnableAction.DISABLE,
                link_id=link_id,
                switch_type=None,
                client_relay_code=client_relay_code,
                success=True,
                switch_result=switch_result,
                message="停用单链路成功",
            )
        except Exception as exc:
            self.logger.error(f"停用链路异常: {exc}")
            try:
                if is_multi:
                    await _ensure_multi_disabled(best_effort=True)
                else:
                    await _rollback_single_disable_failure()
            except Exception as rollback_exc:
                self.logger.error(f"停用失败回滚异常: {rollback_exc}")
            return self._build_enable_response(
                action=LinkEnableAction.DISABLE,
                link_id=link_id,
                switch_type=None,
                client_relay_code=client_relay_code,
                success=False,
                switch_result=switch_result,
                rolled_back=True,
                message=f"停用链路异常已回滚: {exc}",
            )

    async def switch_single_link(self, link_id: str, client_relay_code: str) -> bool:
        """激活单链路（加入轮询池）。"""
        self.logger.info(f"正在激活单链路: {link_id}")
        manager = self._circuit_managers.get(client_relay_code)
        if manager:
            switch_result = manager.activate_single(link_id)
            self.logger.info(f"激活单链路结果: {link_id}, success={switch_result}")
            return switch_result
        else:
            self.logger.error(f"激活单链路失败, client_relay_code对应电路管理器不存在，link-id: {link_id}")
            return False


    def get_link_circuit_mappings(self, client_relay_code: str) -> Dict[str, str]:
        """获取指定 Client Relay 的所有 link->circuit 映射"""
        manager = self._circuit_managers.get(client_relay_code)
        if manager:
            return manager.get_all_mappings()
        return {}

    def active_link_ids(self) -> list[str]:
        """返回节点本地已知 link_id 列表（供 InitNodeSync 上报）。"""
        link_ids: set[str] = set()
        for group in self._link_groups.values():
            if group.link_id:
                link_ids.add(str(group.link_id))
            for sub_link_id in group.sub_link_ids:
                link_ids.add(str(sub_link_id))
        for manager in self._circuit_managers.values():
            for link_id in manager.get_all_mappings().keys():
                link_ids.add(str(link_id))
        return sorted(link_ids)

    def has_local_link(self, link_id: str) -> bool:
        return bool(self.get_link_group(link_id) or self._find_circuit_id_for_link(link_id))

    def find_client_relay_for_link(self, link_id: str) -> str:
        group = self.get_link_group(link_id)
        if group and group.client_relay_code:
            return group.client_relay_code
        for relay_code, manager in self._circuit_managers.items():
            if manager.get_circuit_for_link(link_id):
                return relay_code
        return ""

    def local_link_matches(
        self,
        link_id: str,
        client_relay_code: str,
        relay_fingerprints: list[str],
    ) -> bool:
        circuit_id = self._find_circuit_id_for_link(link_id)
        if not circuit_id:
            return False

        circuit = self.context.active_circuits.get(circuit_id)
        if not circuit:
            return False
        if client_relay_code and circuit.client_relay_code != client_relay_code:
            return False
        if not relay_fingerprints:
            return True

        local_fps = [fp.upper() for fp in circuit.relay_fingerprints]
        expected_fps = [fp.upper() for fp in relay_fingerprints]
        return local_fps == expected_fps

    def _find_circuit_id_for_link(self, link_id: str) -> Optional[str]:
        group = self.get_link_group(link_id)
        if group:
            for entry in group.links:
                if str(entry.get("link_id") or "") == link_id and entry.get("circuit_id"):
                    return str(entry["circuit_id"])
        for manager in self._circuit_managers.values():
            circuit_id = manager.get_circuit_for_link(link_id)
            if circuit_id:
                return str(circuit_id)
        return None

    def delete_circuit_manager_for_client_relay_code(self, client_relay_code: str) -> bool:
        """根据 client_relay_code 删除对应的电路管理器"""
        if client_relay_code in self._circuit_managers:
            del self._circuit_managers[client_relay_code]
            return True
        self.logger.warning(f"尝试删除不存在的电路管理器, client_relay_code: {client_relay_code}")
        return False

    async def _stop_client_bridge_code(self, bridge_code: str) -> dict[str, Any]:
        self.logger.info(f"开始停止 Client Bridge: {bridge_code}")
        if not bridge_code:
            return {"bridge_code": bridge_code, "stopped": True, "skipped": True}
        if not self.tun_bridge_service:
            return {"bridge_code": bridge_code, "stopped": False, "error": "tun_bridge_service 不可用"}
        try:
            ok = await self.tun_bridge_service.stop(bridge_code)
            if ok:
                self.logger.info(f"停止 Client Bridge 成功: {bridge_code}")
                await asyncio.sleep(0.8)
            else:
                self.logger.error(f"停止 Client Bridge 失败 {bridge_code}")
            return {"bridge_code": bridge_code, "stopped": ok}
        except Exception as exc:
            self.logger.error(f"停止 Client Bridge 失败 {bridge_code}: {exc}")
            return {"bridge_code": bridge_code, "stopped": False, "error": str(exc)}

    async def _cleanup_orphan_circuits_for_relay(
        self, client_relay_code: str
    ) -> list[dict[str, Any]]:
        manager = self._circuit_managers.get(client_relay_code)
        if not manager:
            return []

        results: list[dict[str, Any]] = []
        for link_id in list(manager.get_all_mappings().keys()):
            try:
                ok = await self.delete_circuit(link_id, client_relay_code)
                results.append(
                    {
                        "link_id": link_id,
                        "client_relay_code": client_relay_code,
                        "success": ok,
                        "error": None if ok else "删除电路失败",
                    }
                )
            except Exception as exc:
                results.append(
                    {
                        "link_id": link_id,
                        "client_relay_code": client_relay_code,
                        "success": False,
                        "error": str(exc),
                    }
                )
        return results

    async def _stop_client_bridges_for_relay(self, client_relay_code: str) -> list[dict[str, Any]]:
        if not self.tun_bridge_service:
            return []

        stopped: list[dict[str, Any]] = []
        for bridge in await self.tun_bridge_service.status():
            if bridge.get("mode") != "client":
                continue
            if str(bridge.get("client_relay_code") or "") != client_relay_code:
                continue
            bridge_code = str(bridge.get("bridge_code") or "")
            if not bridge_code:
                continue
            stopped.append(await self._stop_client_bridge_code(bridge_code))
        return stopped

    async def cleanup_for_client_relay(self, client_relay_code: str) -> dict[str, Any]:
        """清理指定 Client Relay 的链路、电路与 Client Bridge（Tor 容器须仍在运行）。"""
        result: dict[str, Any] = {
            "client_relay_code": client_relay_code,
            "success": True,
            "stopped_bridges": [],
            "deleted_link_groups": [],
            "orphan_circuits": [],
            "errors": [],
        }

        groups = [
            group
            for group in list(self._link_groups.values())
            if group.client_relay_code == client_relay_code
        ]
        groups.sort(key=lambda group: group.path_type, reverse=True)

        for group in groups:
            if group.path_type == LinkType.MULTI_LINK and group.client_bridge_code:
                bridge_result = await self._stop_client_bridge_code(group.client_bridge_code)
                result["stopped_bridges"].append(bridge_result)
                if not bridge_result.get("stopped"):
                    result["success"] = False
                    result["errors"].append(
                        f"停止 Client Bridge 失败: {group.client_bridge_code}"
                    )

            try:
                delete_result = await self.delete_link_group(group.link_id, client_relay_code)
                result["deleted_link_groups"].append(delete_result)
                for item in delete_result.get("results", []):
                    if not item.get("success"):
                        result["success"] = False
            except Exception as exc:
                result["success"] = False
                result["errors"].append(f"删除链路组 {group.link_id} 异常: {exc}")
                self.logger.error(f"清理 Client Relay {client_relay_code} 链路组失败: {exc}")

        result["orphan_circuits"] = await self._cleanup_orphan_circuits_for_relay(
            client_relay_code
        )
        for item in result["orphan_circuits"]:
            if not item.get("success"):
                result["success"] = False

        remaining_bridges = await self._stop_client_bridges_for_relay(client_relay_code)
        result["stopped_bridges"].extend(remaining_bridges)
        for bridge_result in remaining_bridges:
            if not bridge_result.get("stopped"):
                result["success"] = False

        manager = self._circuit_managers.get(client_relay_code)
        if manager:
            try:
                await manager.stop()
            except Exception as exc:
                result["success"] = False
                result["errors"].append(f"停止 CircuitManager 异常: {exc}")
                self.logger.error(
                    f"停止 Client Relay {client_relay_code} CircuitManager 失败: {exc}"
                )
            self.delete_circuit_manager_for_client_relay_code(client_relay_code)

        self.logger.info(
            f"Client Relay {client_relay_code} 链路清理完成, success={result['success']}"
        )
        return result

    def _collect_client_relay_codes(self) -> set[str]:
        client_relay_codes: set[str] = set()
        for relay_code, relay in self.context.relays.items():
            if relay.relay_role == vps_management_pb2.RelayRole.ROLE_CLIENT:
                client_relay_codes.add(relay_code)
        for relay_code, stem2tor in self.context.stem2tor_instances.items():
            if getattr(stem2tor, "role", None) == "client":
                client_relay_codes.add(relay_code)
        client_relay_codes.update(self._circuit_managers.keys())
        return client_relay_codes

    async def cleanup_all_client_resources(self) -> dict[str, Any]:
        """清理节点上所有 Client Relay 的链路、电路与 Client Bridge。"""
        client_relay_codes = self._collect_client_relay_codes()
        per_relay_results: list[dict[str, Any]] = []
        all_success = True

        self.logger.info(
            f"开始清理 Client 资源, client_relay_codes={sorted(client_relay_codes)}"
        )

        for client_relay_code in sorted(client_relay_codes):
            relay_result = await self.cleanup_for_client_relay(client_relay_code)
            per_relay_results.append(relay_result)
            if not relay_result.get("success"):
                all_success = False

        leftover_bridges: list[dict[str, Any]] = []
        if self.tun_bridge_service:
            for bridge in await self.tun_bridge_service.status():
                if bridge.get("mode") != "client":
                    continue
                bridge_code = str(bridge.get("bridge_code") or "")
                if not bridge_code:
                    continue
                bridge_result = await self._stop_client_bridge_code(bridge_code)
                leftover_bridges.append(bridge_result)
                if not bridge_result.get("stopped"):
                    all_success = False

        self._link_groups.clear()
        self._parent_link_map.clear()
        self._parent_path_type.clear()
        self.context.active_circuits.clear()

        deleted_circuits_count = sum(
            len(result.get("orphan_circuits", []))
            + sum(
                len(group.get("results", []))
                for group in result.get("deleted_link_groups", [])
            )
            for result in per_relay_results
        )
        stopped_bridges = [
            bridge
            for result in per_relay_results
            for bridge in result.get("stopped_bridges", [])
        ] + leftover_bridges

        summary = {
            "success": all_success,
            "client_relay_codes": sorted(client_relay_codes),
            "per_relay_results": per_relay_results,
            "stopped_bridges": stopped_bridges,
            "deleted_circuits_count": deleted_circuits_count,
        }
        self.logger.info(f"Client 资源清理完成, success={all_success}")
        return summary

    def _find_parent_link(self, link_id: str) -> Optional[str]:
        if link_id in self._link_groups:
            return link_id
        for parent_id, sub_ids in self._parent_link_map.items():
            if link_id in sub_ids:
                return parent_id
        return None

    async def _find_bridges_with_link_ids(self, link_ids: set[str]) -> List[str]:
        if not self.tun_bridge_service:
            return []
        bridge_codes = []
        bridges = await self.tun_bridge_service.status()
        for bridge in bridges:
            tunnels = bridge.get("tunnels", [])
            for tunnel in tunnels:
                if tunnel.get("link_id") in link_ids:
                    bridge_codes.append(bridge.get("bridge_code", ""))
                    break
        return bridge_codes

    async def switch_link_old(
        self,
        old_link_id: str,
        client_relay_code: str,
        new_path_type: int,
        new_link_list: List[dict],
        new_parent_link_id: Optional[str] = None,
    ) -> dict:
        if new_parent_link_id is None:
            new_parent_link_id = old_link_id

        old_group = self.get_link_group(old_link_id)
        old_parent_link_id = old_group.link_id if old_group else (self._find_parent_link(old_link_id) or old_link_id)
        old_path_type = old_group.path_type if old_group else 1

        result = {
            "old_link_id": old_link_id,
            "new_link_id": new_parent_link_id,
            "old_path_type": old_path_type,
            "new_path_type": new_path_type,
            "delete_results": None,
            "bridge_cleanup": [],
            "create_results": None,
            "bridge_replacement": None,
        }

        if not old_group:
            self.logger.warning(f"旧链路 {old_link_id} 未找到，将直接创建新链路")

        old_sub_link_ids = old_group.sub_link_ids if old_group else []
        temp_parent_link_id = new_parent_link_id
        if temp_parent_link_id == old_parent_link_id:
            temp_parent_link_id = f"{new_parent_link_id}-pending-{uuid.uuid4().hex[:6]}"

        self.logger.info(
            f"切换链路: old={old_link_id} (parent={old_parent_link_id}, type={old_path_type}, "
            f"subs={old_sub_link_ids}) -> new_type={new_path_type}, new_parent={new_parent_link_id}"
        )

        create_results = await self.create_link(
            parent_link_id=temp_parent_link_id,
            client_relay_code=client_relay_code,
            path_type=new_path_type,
            link_list=new_link_list,
        )
        result["create_results"] = create_results

        success_results = [item for item in create_results.get("results", []) if item.get("success")]
        if not success_results:
            return result

        new_group = self.get_link_group(create_results.get("link_id", temp_parent_link_id))
        if not new_group:
            result["create_results"]["error"] = "新链路组创建后未能注册到节点状态"
            return result

        old_bridge_info = None
        old_bridge_codes: List[str] = []
        if self.tun_bridge_service:
            if old_group and old_group.client_bridge_code:
                old_bridge_codes = [old_group.client_bridge_code]
                old_bridge_info = await self.tun_bridge_service.get_bridge_info(old_group.client_bridge_code)
            elif old_sub_link_ids:
                old_bridge_codes = await self._find_bridges_with_link_ids(set(old_sub_link_ids))
                if old_bridge_codes:
                    old_bridge_info = await self.tun_bridge_service.get_bridge_info(old_bridge_codes[0])

        # ── 先停旧 bridge，释放 TUN 设备，避免新 bridge 创建时 Device busy ──
        bridge_cleanup: List[Dict[str, Any]] = []
        if old_bridge_codes and self.tun_bridge_service:
            for bridge_code in old_bridge_codes:
                try:
                    ok = await self.tun_bridge_service.stop(bridge_code)
                    bridge_cleanup.append({"bridge_code": bridge_code, "stopped": ok})
                    self.logger.info(f"已停止旧 Bridge: {bridge_code}, success={ok}")
                except Exception as exc:
                    bridge_cleanup.append({"bridge_code": bridge_code, "stopped": False, "error": str(exc)})
                    self.logger.error(f"停止旧 Bridge {bridge_code} 失败: {exc}")
        result["bridge_cleanup"] = bridge_cleanup

        # ── 等待内核释放 TUN 设备 ──
        if bridge_cleanup:
            await asyncio.sleep(0.8)

        # ── 用旧 bridge 参数启动新 bridge ──
        if old_bridge_info and self.tun_bridge_service:
            replacement_payload = {
                "mode": "client",
                "client_relay_code": client_relay_code,
                "link_id": new_group.link_id,
                "endpoint_host": old_bridge_info.get("endpoint_host", ""),
                "endpoint_port": old_bridge_info.get("endpoint_port", 0),
                "proxy_host": old_bridge_info.get("proxy_host", ""),
                "proxy_port": old_bridge_info.get("proxy_port", 0),
                "mtu": old_bridge_info.get("mtu", TunBridgeConfig.DEFAULT_MTU),
                "connect_timeout_sec": old_bridge_info.get(
                    "connect_timeout_sec",
                    TunBridgeConfig.DEFAULT_CONNECT_TIMEOUT_SEC,
                ),
                "enable_mptcp": old_bridge_info.get("enable_mptcp", False),
                "server_bridge_code": old_bridge_info.get("server_bridge_code", ""),
                "tunnels": [
                    {
                        "tun_name": tunnel.get("tun_name", ""),
                        "tun_addr_cidr": tunnel.get("tun_addr_cidr", ""),
                    }
                    for tunnel in old_bridge_info.get("tunnels", [])
                ],
            }
            try:
                new_bridge_code = await self.tun_bridge_service.start_client(replacement_payload)
                new_bridge_info = await self.tun_bridge_service.get_bridge_info(new_bridge_code)
                result["bridge_replacement"] = {
                    "success": True,
                    "old_bridge_code": old_bridge_info.get("bridge_code", ""),
                    "new_bridge_code": new_bridge_code,
                    "bridge": new_bridge_info,
                }
            except Exception as exc:
                await self.delete_link_group(new_group.link_id, client_relay_code)
                result["bridge_replacement"] = {
                    "success": False,
                    "old_bridge_code": old_bridge_info.get("bridge_code", ""),
                    "error": str(exc),
                }
                return result

        result["delete_results"] = await self.delete_link_group(old_parent_link_id, client_relay_code)

        if new_group.link_id != new_parent_link_id:
            renamed_group = await self.rename_link_group(new_group.link_id, new_parent_link_id)
            if renamed_group:
                result["create_results"]["link_id"] = renamed_group.link_id
                result["create_results"]["sub_link_ids"] = renamed_group.sub_link_ids

        return result

    async def switch_link(
        self,
        old_path_type: int,
        old_link_id: str,
        new_path_type: int,
        new_link_id: str,
        client_relay_code: str,
        bridge_info: dict[str, Any],
    ) -> dict:
        """分成以下四种case进行实现
            1> 单链路切换单链路
            2> 单链路切换多链路
            3> 多链路切换多链路
            4> 多链路切换单链路
        """
        if (old_path_type == LinkType.SINGLE_LINK or old_path_type == LinkType.UNKNOWN_LINK) and new_path_type == LinkType.SINGLE_LINK:
            return await self.switch_single_to_single(old_path_type, old_link_id, new_link_id, client_relay_code)
        elif (old_path_type == LinkType.SINGLE_LINK or old_path_type == LinkType.UNKNOWN_LINK) and new_path_type == LinkType.MULTI_LINK:
            return await self.switch_single_to_multi(old_path_type, old_link_id, new_link_id, client_relay_code, bridge_info)
        elif old_path_type == LinkType.MULTI_LINK and new_path_type == LinkType.MULTI_LINK:
            return await self.switch_multi_to_multi(old_link_id, new_link_id, client_relay_code, bridge_info)
        elif old_path_type == LinkType.MULTI_LINK and new_path_type == LinkType.SINGLE_LINK:
            return await self.switch_multi_to_single(old_link_id, new_link_id, client_relay_code, bridge_info)
        else:
            self.logger.error(f"切换统一链路失败, 不支持的切换链路类型组合，old_path_type: {old_path_type}, new_path_type: {new_path_type}, old-link-id: {old_link_id}, new-link-id: {new_link_id}, client_relay_code: {client_relay_code}")
            return {"success": False,}
    
    async def switch_single_to_single(
        self,
        old_path_type: int,
        old_link_id: str,
        new_link_id: str,
        client_relay_code: str,
    ) -> dict:
        """单链路切换单链路实现
        """
        result = {
            "old_link_id": old_link_id,
            "new_link_id": new_link_id,
            "old_path_type": old_path_type,
            "new_path_type": LinkType.SINGLE_LINK,
            "success": False,
        }

        self.logger.info(f"正在切换链路,单链路切换单链路: old_path_type: {old_path_type}, old-link-id={old_link_id}, new-link-id={new_link_id}")
        if old_link_id == new_link_id:
            self.logger.info(f"单链路切换单链路，且新旧链路是同一链路(新旧链路ID相同)，无需切换.")
            result["success"] = True
            # await switch_proxy_to_socks()
            return result

        switch_result = await self.switch_single_link(
            link_id=new_link_id,
            client_relay_code=client_relay_code,
        )
        result["success"] = switch_result

        # 3. 切换透明代理模式（失败兜底 direct）
        if result.get("success"):
            await switch_proxy_to_socks()
        else:
            await switch_proxy_to_direct()

        return result

    async def switch_single_to_multi(
        self,
        old_path_type: int,
        old_link_id: str,
        new_link_id: str,
        client_relay_code: str,
        bridge_info: dict[str, Any],
    ) -> dict:
        """单链路切换多链路实现
        """
        self.logger.info(f"正在切换链路,单链路切换多链路: old_path_type: {old_path_type}, old-link-id={old_link_id}, new-link-id={new_link_id}")
        result = {
            "old_link_id": old_link_id,
            "new_link_id": new_link_id,
            "old_path_type": old_path_type,
            "new_path_type": LinkType.MULTI_LINK,
            "success": False,
            "new_bridge_info": None,
        }
        
        if old_path_type == LinkType.SINGLE_LINK:
            # 1. 先把单链路置为未激活状态
            manager = self._circuit_managers.get(client_relay_code)
            if manager:
                inactive_result = manager.mark_default_link_for_inactive(old_link_id)
                if inactive_result:
                    self.logger.info(f"设置单链路为未激活状态成功: {old_link_id}")
                else:
                    self.logger.error(f"设置单链路为未激活状态失败: old-link-id: {old_link_id}")
                    return result
            else:
                self.logger.error(f"设置单链路为未激活状态失败, client_relay_code对应电路管理器不存在，old-link-id: {old_link_id}")
                return result

        # 2. 启动新 client-bridge
        await self.start_client_bridge(result, new_link_id, client_relay_code, bridge_info)

        # 3. 切换透明代理模式（失败兜底 direct）
        if result.get("success"):
            await self._switch_proxy_mode(bridge_info)
        else:
            await switch_proxy_to_direct()

        return result

    async def switch_multi_to_multi(
        self,
        old_link_id: str,
        new_link_id: str,
        client_relay_code: str,
        bridge_info: dict[str, Any],
    ) -> dict:
        """多链路切换多链路实现
        """
        self.logger.info(f"正在切换链路,多链路切换多链路: old-link-id={old_link_id}, new-link-id={new_link_id}")
        result = {
            "old_link_id": old_link_id,
            "new_link_id": new_link_id,
            "old_path_type": LinkType.MULTI_LINK,
            "new_path_type": LinkType.MULTI_LINK,
            "success": False,
            "old_bridge_info": None,
            "old_bridge_cleanup": None,
            "new_bridge_info": None,
        }

        if old_link_id == new_link_id:
            self.logger.info(f"多链路切换多链路，且新旧链路是同一链路(新旧链路ID相同)，无需切换.")
            result["success"] = True
            # await self._switch_proxy_mode(bridge_info)
            return result

        # 1. 停止旧 client-bridge
        await self.stop_client_bridge(result, old_link_id, client_relay_code)

        # 2. 启动新 client-bridge
        await self.start_client_bridge(result, new_link_id, client_relay_code, bridge_info)

        # 3. 切换透明代理模式（失败兜底 direct）
        if result.get("success"):
            await self._switch_proxy_mode(bridge_info)
        else:
            await switch_proxy_to_direct()

        return result

    async def switch_multi_to_single(
        self,
        old_link_id: str,
        new_link_id: str,
        client_relay_code: str,
        bridge_info: dict[str, Any],
    ) -> dict:
        """多链路切换单链路实现
        """
        self.logger.info(f"正在切换链路,多链路切换单链路: old-link-id={old_link_id}, new-link-id={new_link_id}")
        result = {
            "old_link_id": old_link_id,
            "new_link_id": new_link_id,
            "old_path_type": LinkType.MULTI_LINK,
            "new_path_type": LinkType.SINGLE_LINK,
            "success": False,
            "old_bridge_cleanup": None,
            "old_bridge_info": None,
        }

        # 1. 提前切 SOCKS，避免 bridge 拆除期间 MPTCP 连接失败
        await switch_proxy_to_socks()

        # 2. 停止旧 client-bridge
        await self.stop_client_bridge(result, old_link_id, client_relay_code)

        # 3. 切换到单链路
        switch_result = await self.switch_single_link(
            link_id=new_link_id,
            client_relay_code=client_relay_code,
        )

        result["success"] = switch_result

        # 4. 链路切换失败兜底 direct
        if not switch_result:
            await switch_proxy_to_direct()

        return result

    async def _switch_proxy_mode(self, bridge_info: dict[str, Any]) -> None:
        """根据 bridge_info 切换透明代理模式。

        多路径（MPTCP / aggregate）→ server proxy 模式
        单路径 → SOCKS 模式

        启用多链路成功路径约定管理面满足 enable_mptcp 且隧道数 > 1（或 aggregate）；
        判定为多路径但无法推导对端地址时抛错，由上层回滚。
        """
        enable_mptcp = bool(bridge_info.get("enable_mptcp", False))
        aggregate = bool(bridge_info.get("aggregate", False))
        tunnels = bridge_info.get("tunnels", []) or []
        server_tunnels = bridge_info.get("server_tunnels", []) or []
        # MPTCP 时延模式 或 aggregate 轮询模式：走 server proxy
        is_multi_path = aggregate or (
            enable_mptcp and max(len(tunnels), len(server_tunnels)) > 1
        )
        if is_multi_path:
            # 优先 server_tunnels（对端 listen IP）；缺失时用本机 tunnels 推导对端
            server_addrs = derive_server_addrs(server_tunnels)
            if not server_addrs and tunnels:
                server_addrs = derive_peer_addrs(tunnels)
            if not server_addrs:
                raise RuntimeError(
                    "启用多链路成功但无法推导 mptcp 对端地址，拒绝保持错误 selector"
                )
            self.logger.info(
                "switch proxy to mptcp with %d path(s): %s",
                len(server_addrs),
                ",".join(server_addrs),
            )
            await switch_proxy_to_mptcp(server_addrs)
        else:
            await switch_proxy_to_socks()

    async def stop_client_bridge(self, result: dict[str, Any], old_link_id: str, client_relay_code: str, delete_link_group: bool = False):
        """停止client-bridge
        """
        # 1. 查找多链路组
        old_group = self.get_link_group(old_link_id)
        if not old_group:
            if "create_mutli_link_results" not in result:
                result["create_mutli_link_results"] = {}
            result["create_mutli_link_results"]["error"] = "旧链路组创建后未能注册到节点状态"
            self.logger.error(f"查找旧链路组失败, old_link_id: {old_link_id}")
            # 即使本地无链路组，仍尽量清掉“当前激活多链路”标记，并在需要时走幂等删除结果。
            manager = self._circuit_managers.get(client_relay_code)
            if manager and str(manager.get_active_multi_link_id() or "") == str(old_link_id):
                manager.clear_multi_active()
            if delete_link_group:
                result["delete_old_link_results"] = await self.delete_link_group(
                    old_link_id, client_relay_code
                )
            return

        # 2. 查找多链路组bridge_info
        old_bridge_info = None
        old_bridge_code = old_group.client_bridge_code
        if self.tun_bridge_service:
            if old_group and old_bridge_code:
                old_bridge_info = await self.tun_bridge_service.get_bridge_info(old_group.client_bridge_code)
                result["old_bridge_info"] = old_bridge_info

        # 3. 停止旧 client-bridge
        bridge_cleanup = []
        if old_bridge_code and self.tun_bridge_service:
            try:
                ok = await self.tun_bridge_service.stop(old_bridge_code)
                bridge_cleanup.append({"bridge_code": old_bridge_code, "stopped": ok})
                self.logger.info(f"已停止旧 Bridge: {old_bridge_code}, success={ok}")
            except Exception as exc:
                bridge_cleanup.append({"bridge_code": old_bridge_code, "stopped": False, "error": str(exc)})
                self.logger.error(f"停止旧 Bridge {old_bridge_code} 失败: {exc}")
            
            result["old_bridge_cleanup"] = bridge_cleanup

        # 4. 等待内核释放 TUN 设备
        if bridge_cleanup:
            await asyncio.sleep(0.8)

        if delete_link_group:
            self.logger.info(f"开始删除链路组, old_link_id: {old_link_id}")
            result["delete_old_link_results"] = await self.delete_link_group(old_link_id, client_relay_code)

        # 本地仍有 link group 时也要清激活多标记，避免后续 sync_proxy 误判仍有 mptcp
        manager = self._circuit_managers.get(client_relay_code)
        if manager and str(manager.get_active_multi_link_id() or "") == str(old_link_id):
            manager.clear_multi_active()

    async def start_client_bridge(self, result: dict[str, Any], new_link_id: str, client_relay_code: str, bridge_info: dict[str, Any]):
        """启动client-bridge
        """
        # 1. 查找多链路组
        new_group = self.get_link_group(new_link_id)
        if not new_group:
            if "create_mutli_link_results" not in result:
                result["create_mutli_link_results"] = {}
            result["create_mutli_link_results"]["error"] = "新链路组创建后未能注册到节点状态"
            result["new_bridge_info"] = {
                "success": False,
                "error": "新链路组创建后未能注册到节点状态",
            }
            self.logger.error(f"查找新链路组失败, new_link_id: {new_link_id}")
            return

        # 2. 用bridge_info参数启动新 client-bridge
        if not bridge_info or not self.tun_bridge_service:
            result["new_bridge_info"] = {
                "success": False,
                "error": "缺少 bridge_info 或 TunBridgeService",
            }
            self.logger.error(
                f"启动 Bridge 缺少参数, new_link_id={new_link_id}, "
                f"has_bridge_info={bool(bridge_info)}, has_service={bool(self.tun_bridge_service)}"
            )
            return

        new_bridge_info = {
            "mode": "client",
            "client_relay_code": client_relay_code,
            "link_id": new_group.link_id,
            "endpoint_host": bridge_info.get("endpoint_host", ""),
            "endpoint_port": bridge_info.get("endpoint_port", 0),
            "proxy_host": bridge_info.get("proxy_host", ""),
            "proxy_port": bridge_info.get("proxy_port", 0),
            "mtu": bridge_info.get("mtu", TunBridgeConfig.DEFAULT_MTU),
            "connect_timeout_sec": bridge_info.get(
                "connect_timeout_sec",
                TunBridgeConfig.DEFAULT_CONNECT_TIMEOUT_SEC,
            ),
            "enable_mptcp": bridge_info.get("enable_mptcp", False),
            "server_bridge_code": bridge_info.get("server_bridge_code", ""),
            "aggregate": bridge_info.get("aggregate", False),
            "tunnels": [
                {
                    "tun_name": tunnel.get("tun_name", ""),
                    "tun_addr_cidr": tunnel.get("tun_addr_cidr", ""),
                }
                for tunnel in bridge_info.get("tunnels", [])
            ],
        }
        try:
            new_bridge_code = await self.tun_bridge_service.start_client(new_bridge_info)
            new_bridge_info = await self.tun_bridge_service.get_bridge_info(new_bridge_code)
            result["new_bridge_info"] = {
                "success": True,
                "new_bridge_code": new_bridge_code,
                "bridge": new_bridge_info,
            }
            result["success"] = True
        except Exception as exc:
            self.logger.error(f"启动新 Bridge 失败: {exc}")
            # await self.delete_link_group(new_group.link_id, client_relay_code)
            result["new_bridge_info"] = {
                "success": False,
                "error": str(exc),
            }