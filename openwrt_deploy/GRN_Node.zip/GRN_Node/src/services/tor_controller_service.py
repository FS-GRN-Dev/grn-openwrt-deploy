import time
import asyncio
import stem.control
import utils.logger
from stem import ControllerError, StreamStatus
from stem import Signal
from stem.control import EventType, Controller
from typing import Optional, List, Dict, Union, Callable, Any
from config.config import StemConfig
from config.tor_node_config import TorNodeConfig


def _looks_like_fingerprint(value: str) -> bool:
    v = (value or "").strip()
    if v.startswith("$"):
        v = v[1:]
    if len(v) != 40:
        return False
    try:
        int(v, 16)
        return True
    except Exception:
        return False


def _normalize_router_id(value: str) -> str:
    v = (value or "").strip()
    if _looks_like_fingerprint(v):
        v = v[1:] if v.startswith("$") else v
        return f"${v.upper()}"
    return v

class TorControllerService:
    def __init__(self, config: TorNodeConfig):
        self.config = config
        self.controller: Optional[Controller] = None
        self.logger = utils.logger.get_logger("TorControllerService")
        
        # 全局监听器状态
        self._global_stream_listener = None
        self._global_circuit_id = None
        self._global_circuit_listener = None

    async def connect(self, address: str = StemConfig.DEFAULT_ADDR, max_retries: int = StemConfig.DEFAULT_MAX_RETRIES) -> bool:
        """连接到 Tor 控制端口"""
        self.logger.info(f"⏳ 正在连接 Tor 控制端口 {address}:{self.config.control_port}...")
        
        for i in range(max_retries):
            try:
                self.controller = Controller.from_port(
                    address=address, 
                    port=self.config.control_port
                )
                self.controller.authenticate(password=self.config.pwd)

                # 运行时注入关键 torrc（免重打包）：
                # - client: 允许通过 Tor 访问 10/8 等 internal addresses，否则 SOCKS CONNECT 会在 Tor 层直接被拒绝，且可能看不到 STREAM 事件。
                # - exit: 允许 exit 到 10/8:80/443（按需收窄），否则即使电路建立也无法连内网目标。
                try:
                    if self.config.role == "client":
                        try:
                            self.controller.set_conf("ClientRejectInternalAddresses", "0")
                        except Exception as e:
                            self.logger.warning(f"SETCONF ClientRejectInternalAddresses 失败: {e}")

                        # Crucial for link_id-based routing: ensure Tor chooses username/password
                        # auth when offered, so STREAM events include SOCKS_USERNAME.
                        try:
                            self.controller.set_conf("PreferSOCKSNoAuth", "0")
                        except Exception as e:
                            self.logger.warning(f"SETCONF PreferSOCKSNoAuth 失败: {e}")
                    elif self.config.role == "exit":
                        try:
                            # Some Tor versions may implicitly reject private ranges regardless of ExitPolicy.
                            # Best-effort disable to allow private testnets.
                            try:
                                self.controller.set_conf("ExitPolicyRejectPrivate", "0")
                            except Exception as e:
                                self.logger.warning(f"SETCONF ExitPolicyRejectPrivate 失败: {e}")

                            # 多行 ExitPolicy 需要以列表形式下发
                            self.controller.set_conf(
                                "ExitPolicy",
                                [
                                    # 测试网络：允许 exit 访问 10/8 内网的任意端口，
                                    # 否则像 Tun-over-Tor 这种自定义端口（例如 19000）会在 SOCKS CONNECT 阶段卡住/超时。
                                    "accept 10.0.0.0/8:1-65535",
                                    "reject *:*",
                                ],
                            )

                            # Nudge Tor to reload config / republish descriptor sooner.
                            # Not all environments support all signals; ignore failures.
                            try:
                                self.controller.signal(Signal.HUP)
                            except Exception:
                                try:
                                    self.controller.signal(Signal.RELOAD)
                                except Exception:
                                    pass
                        except Exception as e:
                            self.logger.warning(f"SETCONF ExitPolicy 失败: {e}")
                except Exception:
                    # 注入失败不应影响控制连接本身
                    pass

                # 连接自检：打印 pid/version，快速排查“连到了错误的控制端口/错误的 Tor 实例”。
                try:
                    pid = None
                    version = None
                    client_reject_internal = None
                    exit_policy = None
                    try:
                        pid = self.controller.get_info("process/pid")
                    except Exception:
                        pass
                    try:
                        version = self.controller.get_info("version")
                    except Exception:
                        pass
                    try:
                        client_reject_internal = self.controller.get_conf("ClientRejectInternalAddresses")
                    except Exception:
                        pass
                    try:
                        # ExitPolicy 可能是多值；Stem 会返回 list 或 str
                        exit_policy = self.controller.get_conf("ExitPolicy")
                    except Exception:
                        pass
                    self.logger.info(
                        "✅ 成功连接 Tor 控制端口 %s:%s (pid=%s, version=%s, ClientRejectInternalAddresses=%s, ExitPolicy=%s)",
                        address,
                        self.config.control_port,
                        pid,
                        version,
                        client_reject_internal,
                        exit_policy,
                    )
                except Exception:
                    self.logger.info("✅ 成功连接 Tor 控制端口")
                return True
            except Exception as e:
                self.logger.debug(f"  第{i+1}次尝试连接失败: {e}")
                await asyncio.sleep(1)
        
        self.logger.error("❌ 连接 Shr 控制端口超时")
        return False

    def close(self):
        """关闭控制器连接"""
        if self.controller:
            try:
                self.controller.close()
            except Exception as e:
                self.logger.error(f"关闭控制器失败: {e}")
            finally:
                self.controller = None

    def _get_controller(self) -> Controller:
        """获取控制器实例，如果未连接则抛出异常"""
        if self.controller is None:
            raise RuntimeError("控制器未连接。请先调用 connect() 并确保连接成功。")
        return self.controller

    async def create_circuit(self, path: List[str]) -> Optional[str]:
        """创建电路"""
        ctrl = self._get_controller()
        try:
            normalized_path = [_normalize_router_id(p) for p in (path or [])]

            # 关键：在 Tor 控制协议里，指纹应使用 "$FINGERPRINT"。
            # 若不加 "$"，Tor 可能把它当成 nickname，从而抛出 "No such router"。

            # 次要但高频：即使 relay 自己进入共识，client tor 也可能还没下载到最新共识/描述符。
            # 在创建电路前做一次轻量等待：确保每个 hop 在 *client* 的路由表里可见。
            # 这里用 get_network_status 检查（无需下载 descriptor），短时重试即可。
            # 在测试网络/冷启动场景下，client 下载共识/descriptor 可能需要更久。
            # 如果 hop 在 *client* 路由表里不可见，直接 new_circuit 必然触发 "No such router"。
            # 因此这里默认等待更久，并在最终仍不可见时直接失败（给出缺失指纹与 bootstrap 信息）。
            max_wait_s = 120
            deadline = time.time() + max_wait_s
            missing: List[str] = []
            while True:
                missing.clear()
                for hop in normalized_path:
                    # 只对指纹做可见性检查
                    if not _looks_like_fingerprint(hop):
                        continue
                    fp = hop[1:] if hop.startswith("$") else hop
                    try:
                        # 避免依赖 GETINFO ns/id/<fp>（部分环境会返回 unrecognized keywords）。
                        # 先尝试直接查询；失败则降级为遍历 ns/all。
                        try:
                            ctrl.get_network_status(fp)
                        except Exception:
                            found = False
                            try:
                                for ns in ctrl.get_network_statuses() or []:
                                    if (ns.fingerprint or "").upper() == fp.upper():
                                        found = True
                                        break
                            except Exception:
                                found = False
                            if not found:
                                raise
                    except Exception:
                        missing.append(fp)

                if not missing or time.time() >= deadline:
                    break
                await asyncio.sleep(1)

            if missing:
                try:
                    bootstrap = ctrl.get_info("status/bootstrap-phase")
                except Exception:
                    bootstrap = "unknown"
                self.logger.error(
                    "创建电路失败：client 侧路由表/共识仍不可见的 hop=%s; bootstrap=%s; path=%s",
                    missing,
                    bootstrap,
                    path,
                )
                return None

            cir_id = ctrl.new_circuit(normalized_path, purpose="controller", await_build=True)
            return cir_id
        except stem.ControllerError as e:
            self.logger.error(f"创建电路失败: {e}; path={path}")
            return None

    async def delete_circuit(self, cir_id: str) -> bool:
        """删除电路"""
        ctrl = self._get_controller()
        try:
            ctrl.close_circuit(cir_id)
            return True
        except stem.ControllerError as e:
            self.logger.error(f"关闭电路{cir_id}失败: {e}")
            return False

    async def get_circuit_info(self, cir_id: Optional[str] = None) -> Union[Dict, List[Dict], None]:
        """获取电路信息"""
        ctrl = self._get_controller()

        def _format_circuit(circuit):
            return {
                'id': circuit.id,
                'status': circuit.status,
                'purpose': circuit.purpose,
                'path': [(hop[0], hop[1]) for hop in circuit.path],
                'hs_state': circuit.hs_state,
                'rend_query': circuit.rend_query,
                'created': circuit.created,
                'reason': circuit.reason,
                'remote_reason': circuit.remote_reason,
                'socks_username': circuit.socks_username,
                'socks_password': circuit.socks_password
            }

        try:
            if cir_id:
                circuit = ctrl.get_circuit(cir_id)
                return _format_circuit(circuit)
            else:
                circuits = ctrl.get_circuits()
                return [_format_circuit(circuit) for circuit in circuits]
        except stem.ControllerError as e:
            self.logger.error(f"获取电路信息失败: {e}")
            return None

    async def get_network_statuses(self, fingerprint: Optional[str] = None) -> Optional[Union[Dict, List[Dict]]]:
        """获取网络状态"""
        ctrl = self._get_controller()
        try:
            if fingerprint:
                # 兼容：部分 tor/控制端口可能不支持 GETINFO ns/id/<fp>（会报 unrecognized keywords）。
                # 优先走精确查询；失败时降级为拉取 ns/all 进行过滤。
                fp = fingerprint
                if fp and fp.startswith("$"):
                    fp = fp[1:]
                try:
                    ns = ctrl.get_network_status(fp)
                except Exception as e:
                    self.logger.info(f"ctrl.get_network_status(fp) exception:{e}")
                    ns = None
                    try:
                        for item in ctrl.get_network_statuses() or []:
                            if (item.fingerprint or "").upper() == (fp or "").upper():
                                ns = item
                                break
                    except Exception as e:
                        self.logger.info(f"ctrl.get_network_statuses() exception:{e}")
                        ns = None

                if not ns:
                    return None
                return {
                    'nickname': ns.nickname,
                    'fingerprint': ns.fingerprint,
                    'address': ns.address,
                    'or_port': ns.or_port,
                    'dir_port': ns.dir_port,
                    'flags': list(ns.flags),
                    'bandwidth': ns.bandwidth,
                    'version': str(ns.version) if ns.version else 'Unknown',
                    'published': str(ns.published)
                }
            else:
                network_statuses = ctrl.get_network_statuses()
                return [{
                    'nickname': ns.nickname,
                    'fingerprint': ns.fingerprint,
                    'address': ns.address,
                    'or_port': ns.or_port,
                    'dir_port': ns.dir_port,
                    'flags': list(ns.flags),
                    'bandwidth': ns.bandwidth,
                    'version': str(ns.version) if ns.version else 'Unknown',
                    'published': str(ns.published)
                } for ns in network_statuses]
        except stem.ControllerError as e:
            self.logger.error(f"获取网络状态失败: {e}")
            return None

    async def get_streams(self) -> Optional[List[Dict]]:
        """获取流信息"""
        ctrl = self._get_controller()
        try:
            streams = ctrl.get_streams()
            return [{
                'id': stream.id,
                'status': stream.status,
                'circuit_id': stream.circ_id,
                'target': stream.target,
                'purpose': stream.purpose,
                'source': stream.source
            } for stream in streams]
        except stem.ControllerError as e:
            self.logger.error(f"获取流信息失败: {e}")
            return None

    async def start_global_stream_listener(self, circuit_id: str) -> bool:
        """启动全局流监听器"""
        ctrl = self._get_controller()
        
        # 检查电路是否存在
        try:
            circ = ctrl.get_circuit(circuit_id)
            if not circ or circ.status != 'BUILT':
                self.logger.warning(f"电路 {circuit_id} 不存在或未建立")
                return False
        except Exception as e:
            self.logger.error(f"获取电路 {circuit_id} 信息失败: {e}")
            return False

        if self._global_stream_listener and self._global_circuit_id == circuit_id:
            return True

        if self._global_stream_listener:
            self.stop_global_stream_listener()

        try:
            ctrl.set_conf('__LeaveStreamsUnattached', '1')
        except Exception as e:
            self.logger.error(f"设置 __LeaveStreamsUnattached 失败: {e}")
            return False

        self._global_circuit_id = circuit_id

        def stream_listener(stream):
            if stream.status not in {StreamStatus.NEW, StreamStatus.NEWRESOLVE}:
                return
            if not self._global_circuit_id:
                return
            try:
                ctrl.attach_stream(stream.id, self._global_circuit_id)
                self.logger.info(f"成功将流 {stream.id} 附加到电路 {self._global_circuit_id}")
            except Exception as e:
                self.logger.error(f"附加流 {stream.id} 失败: {e}")

        def circuit_listener(circuit):
            if not self._global_circuit_id:
                return
            if str(circuit.id) == str(self._global_circuit_id) and circuit.status in ("FAILED", "CLOSED"):
                self.logger.warning(f"⚠️ 电路 {self._global_circuit_id} 已关闭或失败，停止全局流监听器。")
                self.stop_global_stream_listener()

        try:
            ctrl.add_event_listener(stream_listener, EventType.STREAM)
            ctrl.add_event_listener(circuit_listener, EventType.CIRC)
            self._global_stream_listener = stream_listener
            self._global_circuit_listener = circuit_listener
            self.logger.info(f"✅ 全局流监听器已启动，绑定到电路: {circuit_id}")
            return True
        except Exception as e:
            self.logger.error(f"启动全局流监听器失败: {e}")
            try:
                ctrl.set_conf('__LeaveStreamsUnattached', '0')
            except:
                pass
            self._global_circuit_id = None
            self._global_circuit_listener = None
            self._global_stream_listener = None
            return False

    def stop_global_stream_listener(self) -> None:
        """停止全局流监听器"""
        ctrl = self._get_controller()
        if self._global_stream_listener:
            try:
                ctrl.remove_event_listener(self._global_stream_listener)
            except:
                pass

        if self._global_circuit_listener:
            try:
                ctrl.remove_event_listener(self._global_circuit_listener)
            except:
                pass

        try:
            ctrl.set_conf('__LeaveStreamsUnattached', '0')
        except:
            pass

        self._global_stream_listener = None
        self._global_circuit_listener = None
        self._global_circuit_id = None

    async def wait_for_tor_node(self, nickname: str, container_id: str,
                                max_wait_time: int = StemConfig.DEFAULT_NODE_WAIT_TIME, check_interval: float = StemConfig.DEFAULT_CHECK_INTERVAL) -> Optional[Dict]:
        """等待节点在网络中注册"""
        start_time = time.time()
        
        # Client 不会出现在网络状态中
        if self.config.role == "client":
            return {
                'nickname': nickname,
                'fingerprint': '',
                'address': self.config.outer_ip_addr or '',
                'or_port': self.config.or_port,
                'dir_port': None,
                'flags': [],
                'bandwidth': None,
                'version': '',
                'published': '',
                'container_id': container_id
            }
        self.logger.info(f"⏳ 正在等待节点 {nickname} 初始化并获取本地信息...")
        
        while time.time() - start_time < max_wait_time:
            try:
                ctrl = self._get_controller()
                
                # 1. 检查boostrap状态，只需要能响应即可
                try:
                    status = ctrl.get_info("status/bootstrap-phase")
                    self.logger.debug(f"当前 bootstrap 状态: {status}")
                except Exception as e:
                    self.logger.error(f"获取 bootstrap 状态失败: {e}")
                    pass
                
                # 2. 从本地获取指纹
                fingerprint = ctrl.get_info("fingerprint", None)
                if not fingerprint:
                    self.logger.debug("⚠️ 未获取到指纹，继续等待...")
                    await asyncio.sleep(check_interval)
                    continue
                
                # 3. 设置地址
                address = self.config.outer_ip_addr
                if not address:
                    try:
                        address = ctrl.get_info("address", None)
                    except Exception as e:
                        self.logger.error(f"获取节点地址失败: {e}")
                        address = None
                        
                # 4. 获取版本
                version = ctrl.get_info("version", "Unknown")
                
                # 构造返回信息
                node_info = {
                    'nickname': nickname,
                    'fingerprint': fingerprint,
                    'address': address or '',
                    'or_port': int(self.config.or_port) if self.config.or_port else None,
                    'dir_port': int(self.config.dir_port) if self.config.dir_port else None,
                    'flags': [], # 本地无法获取共识Flags，留空，由管理面后续异步更新
                    'bandwidth': None,
                    'version': str(version),
                    'published': time.strftime("%Y-%m-%d %H:%M:%S"),
                    'container_id': container_id
                }
                
                self.logger.info(f"✅ 成功获取节点 {nickname} 本地信息 (Fingerprint: {fingerprint})")
                return node_info

            except Exception as e:
                self.logger.error(f"⚠️ 查找节点错误: {e}")
                await asyncio.sleep(check_interval)

        self.logger.warning(f"❌ 等待超时：未找到节点 {nickname}")
        return {
            'nickname': nickname,
            'fingerprint': '',
            'address': self.config.outer_ip_addr or '',
            'or_port': self.config.or_port,
            'dir_port': None,
            'flags': [],
            'bandwidth': None,
            'version': '',
            'published': '',
            'container_id': container_id
        }