import asyncio
import json
import socket
import struct
import ipaddress
from dataclasses import dataclass
from typing import Optional

import utils.logger
from services.tun_device import TunDevice


@dataclass(frozen=True)
class TunnelEndpoint:
    host: str
    port: int


@dataclass(frozen=True)
class SocksProxy:
    host: str
    port: int
    username: str
    password: str = ""


def socks5_connect_sync(
    proxy_host: str,
    proxy_port: int,
    dest_host: str,
    dest_port: int,
    username: str,
    password: str = "x",
    timeout: float = 15.0,
) -> socket.socket:
    """Blocking SOCKS5 connect with username/password auth.

    Standalone version of the SOCKS5 handshake used by TunTcpTunnel,
    suitable for aggregate-mode connections where one TUN device is shared
    across multiple TCP tunnels.

    Returns the connected socket with timeout cleared.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((proxy_host, int(proxy_port)))
    except TimeoutError as e:
        s.close()
        raise TimeoutError(
            f"SOCKS5 TCP connect timed out: {proxy_host}:{proxy_port} timeout={timeout}s"
        ) from e

    uname = username.encode("utf-8")[:255]
    pw = (password if password else "x").encode("utf-8")[:255]

    try:
        # 1) Greeting: only USERPASS (0x02)
        s.sendall(b"\x05\x01\x02")
        resp = s.recv(2)
        if len(resp) != 2 or resp[0] != 0x05 or resp[1] != 0x02:
            raise OSError(f"SOCKS5 proxy rejected USERPASS auth (resp={resp!r})")

        # 2) Auth (RFC 1929)
        s.sendall(bytes([0x01, len(uname)]) + uname + bytes([len(pw)]) + pw)
        auth = s.recv(2)
        if len(auth) != 2 or auth[1] != 0x00:
            raise OSError(f"SOCKS5 auth failed (resp={auth!r})")

        # 3) CONNECT request
        try:
            ip = ipaddress.ip_address(dest_host)
        except ValueError:
            ip = None

        if ip is None:
            host_bytes = dest_host.encode("idna")
            atyp_field = bytes([0x03, len(host_bytes)]) + host_bytes
        elif isinstance(ip, ipaddress.IPv4Address):
            atyp_field = bytes([0x01]) + ip.packed
        else:
            atyp_field = bytes([0x04]) + ip.packed

        s.sendall(b"\x05\x01\x00" + atyp_field + struct.pack(">H", int(dest_port)))

        header = s.recv(4)
        if len(header) != 4 or header[0] != 0x05 or header[1] != 0x00:
            raise OSError(f"SOCKS5 CONNECT failed (header={header!r})")

        # Consume BND.ADDR + BND.PORT
        atyp_rep = header[3]
        if atyp_rep == 0x01:
            s.recv(4 + 2)
        elif atyp_rep == 0x04:
            s.recv(16 + 2)
        elif atyp_rep == 0x03:
            ln = s.recv(1)
            if ln:
                s.recv(ln[0] + 2)
        else:
            s.recv(2)
    except Exception:
        s.close()
        raise

    s.settimeout(None)
    return s


class LengthPrefixedFraming:
    @staticmethod
    def pack(payload: bytes) -> bytes:
        return struct.pack(">I", len(payload)) + payload

    @staticmethod
    async def read_exact(reader: asyncio.StreamReader, n: int) -> bytes:
        data = await reader.readexactly(n)
        return data

    @classmethod
    async def read_frame(cls, reader: asyncio.StreamReader, max_frame: int = 1024 * 1024) -> bytes:
        header = await cls.read_exact(reader, 4)
        (length,) = struct.unpack(">I", header)
        if length < 0 or length > max_frame:
            raise ValueError(f"invalid frame length: {length}")
        return await cls.read_exact(reader, length)


class TunTcpTunnel:
    def __init__(
        self,
        tun: TunDevice,
        endpoint: TunnelEndpoint,
        proxy: SocksProxy,
        connect_timeout: float = 15.0,
        max_frame: int = 4 * 1024 * 1024,
    ) -> None:
        self.tun = tun
        self.endpoint = endpoint
        self.proxy = proxy
        self.logger = utils.logger.get_logger("TunTcpTunnel")
        self.connect_timeout = float(connect_timeout)
        self.max_frame = int(max_frame)

        self._stop_evt = asyncio.Event()
        self._writer: Optional[asyncio.StreamWriter] = None
        self._reader: Optional[asyncio.StreamReader] = None
        self._stop_lock = asyncio.Lock()
        # Generation token: only the current connection may trigger reconnect.
        self._generation: int = 0
        self._reconnect_evt: Optional[asyncio.Event] = None
        self._run_task: Optional[asyncio.Task] = None
        # Both pumps are short-lived (one pair per TCP connection).
        self._tun_to_tcp_task: Optional[asyncio.Task] = None
        self._tcp_to_tun_task: Optional[asyncio.Task] = None

    async def start(self) -> None:
        self._stop_evt.clear()
        self._generation = 0
        self._run_task = asyncio.create_task(self._run_with_reconnect())

    async def _run_with_reconnect(self) -> None:
        """Reconnect loop: rebuild tunnel on circuit failure with backoff.

        Scheme B: each TCP generation owns a short-lived pump pair. Before the
        next connect we cancel+await both pumps so a stale tun.read cannot fire
        a dead reconnect_evt or race a second reader on the same TUN.
        """
        backoff = 1.0
        while not self._stop_evt.is_set():
            try:
                reader, writer = await self._connect()
                try:
                    await self._send_handshake(writer)
                except Exception:
                    try:
                        writer.close()
                    except Exception:
                        pass
                    raise
                reconnect_evt, gen = self._activate_connection(reader, writer)
                self._tun_to_tcp_task = asyncio.create_task(
                    self._pump_tun_to_tcp(writer, reconnect_evt, gen)
                )
                self._tcp_to_tun_task = asyncio.create_task(
                    self._pump_tcp_to_tun(reader, reconnect_evt, gen)
                )
                await reconnect_evt.wait()
                if self._stop_evt.is_set():
                    break
                backoff = 1.0
                self.logger.info("Tunnel %s reconnecting...", self.tun.ifname)
            except Exception as exc:
                if self._stop_evt.is_set():
                    break
                self.logger.warning("Tunnel %s connect failed: %s", self.tun.ifname, exc)
            finally:
                # Invalidate first so any late pump error cannot wake a stale evt.
                self._reconnect_evt = None
                self._close_current_connection()
                await self._stop_pumps()
            if self._stop_evt.is_set():
                break
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 30.0)

    async def stop(self) -> None:
        async with self._stop_lock:
            self._request_shutdown()
            writer = self._writer
            if writer:
                try:
                    await writer.wait_closed()
                except Exception:
                    pass

            await self._stop_pumps()
            await self._cancel_task(self._run_task)
            self._run_task = None
            self._reconnect_evt = None
            self._writer = None
            self._reader = None

    async def _stop_pumps(self) -> None:
        """Cancel both short-lived pumps and wait until they fully exit."""
        tasks = [
            task
            for task in (self._tun_to_tcp_task, self._tcp_to_tun_task)
            if task is not None
        ]
        for task in tasks:
            if not task.done():
                task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        self._tun_to_tcp_task = None
        self._tcp_to_tun_task = None

    @staticmethod
    async def _cancel_task(task: Optional[asyncio.Task]) -> None:
        if task is None or task.done():
            return
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        except Exception:
            pass

    def _request_shutdown(self) -> None:
        self._stop_evt.set()
        evt = self._reconnect_evt
        self._reconnect_evt = None
        if evt is not None:
            evt.set()
        self._close_current_connection()

    def _close_current_connection(self) -> None:
        writer = self._writer
        self._writer = None
        self._reader = None
        if writer:
            try:
                writer.close()
            except Exception:
                pass

    def _signal_reconnect(self, reconnect_evt: asyncio.Event, gen: int) -> None:
        """Only the active generation may wake the reconnect loop."""
        if self._stop_evt.is_set():
            return
        if gen != self._generation:
            return
        if reconnect_evt is not self._reconnect_evt:
            return
        reconnect_evt.set()

    async def _connect(self) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
        # Helpful hint: Tor commonly rejects connections to internal/private IP ranges.
        # In that case, Tor may detach the stream with REMOTE_REASON=EXITPOLICY.
        try:
            ip = ipaddress.ip_address(self.endpoint.host)
            if ip.is_private or ip.is_loopback or ip.is_link_local:
                self.logger.warning(
                    "endpoint %s looks like an internal IP; Shr exits often reject this (EXITPOLICY). "
                    "If this is a private testnet, ensure exit allows private ranges and client sets ClientRejectInternalAddresses=0.",
                    self.endpoint.host,
                )
        except ValueError:
            # hostname: cannot classify
            pass

        async def _hint_if_control_port() -> None:
            # Common pitfall: user passes Tor control port (default 9051) as SOCKS proxy port.
            # Tor control replies to 'PROTOCOLINFO 1' with 250-*, while SOCKS expects binary greeting.
            try:
                probe = socket.create_connection((self.proxy.host, int(self.proxy.port)), timeout=1.5)
                try:
                    probe.sendall(b"PROTOCOLINFO 1\r\n")
                    data = probe.recv(64)
                finally:
                    try:
                        probe.close()
                    except Exception:
                        pass

                if data.startswith(b"250"):
                    self.logger.error(
                        "proxy %s:%s looks like a Tor CONTROL port (got %r). "
                        "Please use the Tor SOCKS port instead (often 9050).",
                        self.proxy.host,
                        self.proxy.port,
                        data,
                    )
            except Exception:
                # Probe failure: ignore, we will raise the original connect error.
                return

        def _socks5_connect_userpass_only() -> socket.socket:
            """Connect to destination through SOCKS5 proxy using username/password auth only.

            This is important for Tor+STREAM isolation: Tor only includes SOCKS_USERNAME in
            STREAM events when the connection actually uses username/password auth.

            Many SOCKS clients advertise both NOAUTH and USERPASS; Tor often picks NOAUTH,
            resulting in socks_username=None and breaking link_id-based routing.
            """

            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(self.connect_timeout)
            try:
                s.connect((self.proxy.host, int(self.proxy.port)))
            except TimeoutError as e:
                raise TimeoutError(
                    f"SOCKS5 TCP connect to proxy timed out: proxy={self.proxy.host}:{self.proxy.port} "
                    f"timeout={self.connect_timeout}s"
                ) from e

            username = (self.proxy.username or "").encode("utf-8")
            password_text = self.proxy.password
            if password_text is None:
                password_text = ""
            # Use a non-empty password to avoid edge cases where some SOCKS servers reject empty.
            # Circuit routing only relies on username (link_id), not password.
            password = (password_text if password_text else "x").encode("utf-8")

            if len(username) > 255:
                raise ValueError("SOCKS username too long")
            if len(password) > 255:
                raise ValueError("SOCKS password too long")

            # 1) Greeting: VER=5, NMETHODS=1, METHODS=[0x02 USERPASS]
            s.sendall(b"\x05\x01\x02")
            try:
                resp = s.recv(2)
            except TimeoutError as e:
                raise TimeoutError(
                    f"SOCKS5 greeting timed out: proxy={self.proxy.host}:{self.proxy.port} timeout={self.connect_timeout}s"
                ) from e
            if len(resp) != 2:
                raise TimeoutError("SOCKS5 proxy did not respond to greeting")
            if resp[0] != 0x05:
                raise OSError(f"invalid SOCKS version in response: {resp[0]}")
            if resp[1] != 0x02:
                raise OSError(f"SOCKS5 proxy does not accept USERPASS auth (method={resp[1]})")

            # 2) USERPASS auth (RFC1929): VER=1, ULEN, UNAME, PLEN, PASSWD
            s.sendall(bytes([0x01, len(username)]) + username + bytes([len(password)]) + password)
            try:
                auth = s.recv(2)
            except TimeoutError as e:
                raise TimeoutError(
                    f"SOCKS5 auth timed out: proxy={self.proxy.host}:{self.proxy.port} user={self.proxy.username} "
                    f"timeout={self.connect_timeout}s"
                ) from e
            if len(auth) != 2:
                raise TimeoutError("SOCKS5 proxy did not respond to auth")
            if auth[0] != 0x01 or auth[1] != 0x00:
                raise OSError(f"SOCKS5 auth failed (resp={auth!r})")

            # 3) CONNECT request
            dest_host = self.endpoint.host
            dest_port = int(self.endpoint.port)
            try:
                ip = ipaddress.ip_address(dest_host)
            except ValueError:
                ip = None

            if ip is None:
                host_bytes = dest_host.encode("idna")
                if len(host_bytes) > 255:
                    raise ValueError("SOCKS domain name too long")
                atyp = 0x03
                addr_field = bytes([len(host_bytes)]) + host_bytes
            elif isinstance(ip, ipaddress.IPv4Address):
                atyp = 0x01
                addr_field = ip.packed
            else:
                atyp = 0x04
                addr_field = ip.packed

            req = b"\x05\x01\x00" + bytes([atyp]) + addr_field + struct.pack(">H", dest_port)
            s.sendall(req)

            # Reply: VER, REP, RSV, ATYP, BND.ADDR, BND.PORT
            try:
                header = s.recv(4)
            except TimeoutError as e:
                raise TimeoutError(
                    f"SOCKS5 CONNECT reply timed out: proxy={self.proxy.host}:{self.proxy.port} "
                    f"dest={self.endpoint.host}:{self.endpoint.port} user={self.proxy.username} timeout={self.connect_timeout}s"
                ) from e
            if len(header) != 4:
                raise TimeoutError("SOCKS5 proxy did not respond to CONNECT")
            ver, rep, _rsv, atyp_rep = header
            if ver != 0x05:
                raise OSError(f"invalid SOCKS version in CONNECT reply: {ver}")
            if rep != 0x00:
                raise OSError(f"SOCKS5 CONNECT failed (rep={rep})")

            # Consume BND.ADDR/BND.PORT
            if atyp_rep == 0x01:
                to_read = 4
            elif atyp_rep == 0x04:
                to_read = 16
            elif atyp_rep == 0x03:
                try:
                    ln = s.recv(1)
                except TimeoutError as e:
                    raise TimeoutError(
                        f"SOCKS5 CONNECT reply timed out (BND domain len): proxy={self.proxy.host}:{self.proxy.port} "
                        f"timeout={self.connect_timeout}s"
                    ) from e
                if len(ln) != 1:
                    raise TimeoutError("SOCKS5 proxy did not provide BND domain length")
                to_read = ln[0]
            else:
                raise OSError(f"invalid ATYP in CONNECT reply: {atyp_rep}")

            if to_read:
                try:
                    _ = s.recv(to_read)
                except TimeoutError as e:
                    raise TimeoutError(
                        f"SOCKS5 CONNECT reply timed out (BND addr): proxy={self.proxy.host}:{self.proxy.port} "
                        f"timeout={self.connect_timeout}s"
                    ) from e
                if len(_) != to_read:
                    raise TimeoutError("SOCKS5 proxy did not provide full BND address")
            try:
                port_bytes = s.recv(2)
            except TimeoutError as e:
                raise TimeoutError(
                    f"SOCKS5 CONNECT reply timed out (BND port): proxy={self.proxy.host}:{self.proxy.port} "
                    f"timeout={self.connect_timeout}s"
                ) from e
            if len(port_bytes) != 2:
                raise TimeoutError("SOCKS5 proxy did not provide BND port")

            # keep timeout during connect only; caller will clear to None
            return s

        s: Optional[socket.socket] = None
        # Use a blocking socket + executor so the event loop stays responsive.

        loop = asyncio.get_running_loop()
        try:
            s = await loop.run_in_executor(None, _socks5_connect_userpass_only)
        except TimeoutError:
            # Only run the control-port probe for common control ports. Probing a real
            # SOCKS port with 'PROTOCOLINFO' will create confusing SOCKS_PROTOCOL logs.
            if int(self.proxy.port) in (9051, 9151):
                await _hint_if_control_port()
            raise
        except Exception as e:
            # PySocks wraps many socket errors into GeneralProxyError("Socket error", ...).
            # If the proxy port is wrong (e.g., CONTROL port), handshake often times out.
            msg = str(e)
            if "timed out" in msg.lower():
                if int(self.proxy.port) in (9051, 9151):
                    await _hint_if_control_port()
            raise
        finally:
            if s is not None:
                # keep timeout during connect only; enable TCP keepalive
                # 30s idle → 10s interval × 3 = 60s dead detection
                try:
                    s.settimeout(None)
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                    s.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 30)
                    s.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 10)
                    s.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 3)
                except Exception:
                    pass

        if s is None:
            raise RuntimeError("SOCKS connection not established")

        reader, writer = await asyncio.open_connection(sock=s)
        return reader, writer

    async def _send_handshake(self, writer: asyncio.StreamWriter) -> None:
        # First frame is a JSON hello so server can select tun.
        hello = {"tun": self.tun.ifname or ""}
        payload = (json.dumps(hello, ensure_ascii=False)).encode("utf-8")
        writer.write(LengthPrefixedFraming.pack(payload))
        await writer.drain()

    def _activate_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> tuple[asyncio.Event, int]:
        """Publish connection state after handshake; bump generation for pumps."""
        self._reader = reader
        self._writer = writer
        self._generation += 1
        gen = self._generation
        reconnect_evt = asyncio.Event()
        self._reconnect_evt = reconnect_evt
        self.logger.info(
            "TUN tunnel connected: tun=%s -> %s:%s via socks=%s:%s user=%s",
            self.tun.ifname,
            self.endpoint.host,
            self.endpoint.port,
            self.proxy.host,
            self.proxy.port,
            self.proxy.username,
        )
        return reconnect_evt, gen

    async def _pump_tun_to_tcp(
        self,
        writer: asyncio.StreamWriter,
        reconnect_evt: asyncio.Event,
        gen: int,
    ) -> None:
        """Short-lived TUN→TCP pump for one TCP generation."""
        loop = asyncio.get_running_loop()
        try:
            while not self._stop_evt.is_set():
                try:
                    pkt = await loop.run_in_executor(None, self.tun.read, 65535)
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    self.logger.error("tun read failed (%s): %s", self.tun.ifname, e)
                    self._signal_reconnect(reconnect_evt, gen)
                    return
                if not pkt:
                    continue
                try:
                    writer.write(LengthPrefixedFraming.pack(pkt))
                    await writer.drain()
                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    self.logger.error("tun->tcp pump failed (%s): %s", self.tun.ifname, e)
                    self._signal_reconnect(reconnect_evt, gen)
                    return
        except asyncio.CancelledError:
            raise

    async def _pump_tcp_to_tun(
        self,
        reader: asyncio.StreamReader,
        reconnect_evt: asyncio.Event,
        gen: int,
    ) -> None:
        """Short-lived TCP→TUN pump for one TCP generation."""
        loop = asyncio.get_running_loop()
        try:
            while not self._stop_evt.is_set():
                pkt = await LengthPrefixedFraming.read_frame(reader, max_frame=self.max_frame)
                await loop.run_in_executor(None, self.tun.write, pkt)
        except asyncio.CancelledError:
            raise
        except asyncio.IncompleteReadError:
            self.logger.warning("tcp->tun closed (%s)", self.tun.ifname)
            self._signal_reconnect(reconnect_evt, gen)
        except Exception as e:
            # Do NOT call _request_shutdown(): that permanently stops reconnect.
            self.logger.error("tcp->tun pump failed (%s): %s", self.tun.ifname, e)
            self._signal_reconnect(reconnect_evt, gen)
