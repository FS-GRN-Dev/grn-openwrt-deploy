#!/usr/bin/env python3
"""临时打开 Tor 文件日志：启动时 set_conf(Log)，Ctrl+C 退出时 reset_conf(Log)。

用法（在宿主机、已安装 stem、能连上 Tor ControlPort 的环境执行）：

  # 默认：info 级别写容器内 /var/log/tor/*.log，按 Ctrl+C 自动关掉 Log
  python scripts/listen_tor_log.py

  # 需要更细（磁盘涨得快，仅短时排查）
  python scripts/listen_tor_log.py --level debug

  # 同时把控制口日志事件打印到终端
  python scripts/listen_tor_log.py --level info --print-events

  # 控制口不是默认 9051 / 密码不是 torpassword 时
  python scripts/listen_tor_log.py --port 9051 --password torpassword

另开终端看【容器内】日志（Docker 场景）：

  docker ps | grep client
  docker exec <容器ID或名> tail -f /var/log/tor/info.log
  docker exec <容器ID或名> tail -f /var/log/tor/debug.log
  docker exec <容器ID或名> grep -E "unused for|circuit_expire|idle timeout" /var/log/tor/info.log

退出后确认 Log 已关：

  python -c "from stem.control import Controller; c=Controller.from_port(port=9051); c.authenticate(password='torpassword'); print(c.get_conf('Log', multiple=True))"
  # 期望输出: []

注意：
- Tor 在 Docker 内时，日志写在容器内 /var/log/tor/，不是宿主机同名目录。
- 本脚本不会发 HUP；对临时 Log 发 HUP 会按磁盘 torrc 重载并把 Log 冲掉。
- 默认 --level info，避免 debug 长期写盘撑爆磁盘；查完务必 Ctrl+C 正常退出。
"""

from __future__ import annotations

import argparse
import time

from stem.control import Controller, EventType


DEFAULT_PORT = 9051
DEFAULT_PASSWORD = "torpassword"
DEFAULT_LOG_DIR = "/var/log/tor"


def _build_log_configs(log_dir: str, level: str) -> list[str]:
    """按级别分文件：debug 最全，info/notice 更省磁盘。"""
    enable = {
        "debug": ["debug", "info", "notice", "warn", "err"],
        "info": ["info", "notice", "warn", "err"],
        "notice": ["notice", "warn", "err"],
    }.get(level)
    if not enable:
        raise ValueError(f"不支持的 level={level}")
    return [f"{lv} file {log_dir}/{lv}.log" for lv in enable]


def listen_tor_log(
    port: int,
    password: str,
    log_dir: str,
    level: str,
    print_events: bool,
) -> None:
    log_configs = _build_log_configs(log_dir, level)
    enabled = False

    def on_log_event(event):
        print(f"[Tor] [{event.severity}] {event.message}")

    with Controller.from_port(port=port) as controller:
        controller.authenticate(password=password)

        # 记录原配置，退出时尽量恢复（多数环境原本是空）
        try:
            previous = controller.get_conf("Log", multiple=True) or []
        except Exception:
            previous = []

        try:
            controller.reset_conf("Log")
            controller.set_conf("Log", log_configs)
            enabled = True
            print(f"已开启 Log ({level}) -> {log_dir}/*.log")
            print(f"当前 Log: {controller.get_conf('Log', multiple=True)}")
            print("按 Ctrl+C 停止并关闭 Log（不会发 HUP）")

            if print_events:
                # 控制口事件流：不依赖读文件；DEBUG 事件量很大，默认只订 INFO+
                event_types = [EventType.INFO, EventType.NOTICE, EventType.WARN, EventType.ERR]
                if level == "debug":
                    event_types.insert(0, EventType.DEBUG)
                controller.add_event_listener(on_log_event, *event_types)

            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n正在关闭 Log ...")
        finally:
            if enabled:
                try:
                    if previous:
                        controller.set_conf("Log", previous)
                        print(f"已恢复原 Log: {previous}")
                    else:
                        controller.reset_conf("Log")
                        print("已 reset_conf(Log)，当前 Log 为空")
                    print(f"确认: {controller.get_conf('Log', multiple=True)}")
                except Exception as exc:
                    print(f"关闭 Log 失败: {exc}")


def main() -> None:
    parser = argparse.ArgumentParser(description="临时开启/关闭 Tor 文件日志")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="Tor ControlPort")
    parser.add_argument("--password", default=DEFAULT_PASSWORD, help="控制口密码")
    parser.add_argument(
        "--log-dir",
        default=DEFAULT_LOG_DIR,
        help="Tor 进程视角下的日志目录（Docker 内一般为 /var/log/tor）",
    )
    parser.add_argument(
        "--level",
        choices=["notice", "info", "debug"],
        default="info",
        help="日志级别（默认 info，避免 debug 撑爆磁盘）",
    )
    parser.add_argument(
        "--print-events",
        action="store_true",
        help="同时把控制口日志事件打印到终端",
    )
    args = parser.parse_args()
    listen_tor_log(
        port=args.port,
        password=args.password,
        log_dir=args.log_dir,
        level=args.level,
        print_events=args.print_events,
    )


if __name__ == "__main__":
    main()
