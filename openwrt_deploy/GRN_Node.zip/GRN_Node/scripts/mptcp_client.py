#!/usr/bin/env python3
"""MPTCP bulk data client for experiments.

Connects to an MPTCP server and receives all data, reporting
file completion time (FCT) and average throughput.

Usage:
    python3 mptcp_client.py [--host 10.88.0.1] [--port 8080]

Requires Linux kernel 5.6+ with MPTCP enabled.
"""

import argparse
import socket
import time

IPPROTO_MPTCP = 262


def main():
    parser = argparse.ArgumentParser(description="MPTCP bulk data client")
    parser.add_argument("--host", type=str, required=True, help="Server address (e.g. 10.88.0.1)")
    parser.add_argument("--port", type=int, default=8080, help="Server port")
    args = parser.parse_args()

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, IPPROTO_MPTCP)
    except OSError:
        print("MPTCP socket creation failed. Falling back to regular TCP.")
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    proto = "MPTCP" if s.proto == IPPROTO_MPTCP else "TCP"
    print(f"[{proto}] Connecting to {args.host}:{args.port} ...")

    s.connect((args.host, args.port))
    print(f"Connected.")

    total = 0
    t0 = time.monotonic()
    last_report = t0

    try:
        while True:
            data = s.recv(65536)
            if not data:
                break
            total += len(data)

            # Progress report every 2 seconds
            now = time.monotonic()
            if now - last_report >= 2.0:
                elapsed = now - t0
                speed = total / elapsed / (1024 * 1024) if elapsed > 0 else 0
                print(f"  received {total/(1024*1024):.1f} MB  ({speed:.1f} MB/s)")
                last_report = now
    except (ConnectionResetError, BrokenPipeError) as e:
        print(f"Connection broken: {e}")
    finally:
        s.close()

    elapsed = time.monotonic() - t0
    speed = total / elapsed / (1024 * 1024) if elapsed > 0 else 0

    print("=" * 50)
    print(f"Total received : {total / (1024*1024):.1f} MB")
    print(f"FCT            : {elapsed:.2f} s")
    print(f"Avg throughput : {speed:.2f} MB/s")
    print(f"Avg throughput : {speed * 1024:.0f} KB/s")
    print("=" * 50)


if __name__ == "__main__":
    main()
