#!/usr/bin/env python3
"""Per-TUN interface throughput sampler for MPTCP experiments.

Reads /proc/net/dev every INTERVAL seconds, computes per-interface
delta throughput (KB/s), and writes CSV rows to stdout (or a file).

Usage:
    python3 metrics_sampler.py [--interval 1.0] [--prefix mtun] [--out FILE]

Output columns:
    elapsed_s, <iface>_rx_kbps, <iface>_tx_kbps, ..., total_rx_kbps, total_tx_kbps
"""

import argparse
import re
import signal
import sys
import time


def parse_proc_net_dev(prefix: str) -> dict:
    """Parse /proc/net/dev and return {iface: (rx_bytes, tx_bytes)} for matching interfaces."""
    result = {}
    with open("/proc/net/dev", "r") as f:
        for line in f:
            line = line.strip()
            if ":" not in line:
                continue
            iface, rest = line.split(":", 1)
            iface = iface.strip()
            if not iface.startswith(prefix):
                continue
            fields = rest.split()
            # fields[0] = rx_bytes, fields[8] = tx_bytes
            rx_bytes = int(fields[0])
            tx_bytes = int(fields[8])
            result[iface] = (rx_bytes, tx_bytes)
    return result


def main():
    parser = argparse.ArgumentParser(description="Per-TUN throughput sampler")
    parser.add_argument("--interval", type=float, default=1.0, help="Sampling interval (seconds)")
    parser.add_argument("--prefix", type=str, default="mtun", help="Interface name prefix to match")
    parser.add_argument("--out", type=str, default="", help="Output CSV file (default: stdout)")
    args = parser.parse_args()

    outf = open(args.out, "w") if args.out else sys.stdout

    stop = False

    def _sighandler(sig, frame):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGINT, _sighandler)
    signal.signal(signal.SIGTERM, _sighandler)

    # First sample — discover interfaces and get baseline counters
    prev = parse_proc_net_dev(args.prefix)
    if not prev:
        print(f"No interfaces matching prefix '{args.prefix}' found. Waiting...", file=sys.stderr)
        while not prev and not stop:
            time.sleep(args.interval)
            prev = parse_proc_net_dev(args.prefix)
        if stop:
            return

    ifaces = sorted(prev.keys())
    # Print CSV header
    cols = []
    for iface in ifaces:
        cols.append(f"{iface}_rx_kbps")
        cols.append(f"{iface}_tx_kbps")
    cols.append("total_rx_kbps")
    cols.append("total_tx_kbps")
    print("elapsed_s," + ",".join(cols), file=outf, flush=True)

    t0 = time.monotonic()
    prev_time = t0

    while not stop:
        time.sleep(args.interval)
        now_time = time.monotonic()
        dt = now_time - prev_time
        if dt <= 0:
            continue

        cur = parse_proc_net_dev(args.prefix)
        # Ensure we track same set of interfaces
        cur_ifaces = sorted(cur.keys())
        if cur_ifaces != ifaces:
            # interfaces changed — update
            ifaces = cur_ifaces
            cols = []
            for iface in ifaces:
                cols.append(f"{iface}_rx_kbps")
                cols.append(f"{iface}_tx_kbps")
            cols.append("total_rx_kbps")
            cols.append("total_tx_kbps")
            # Re-print header
            print("# interfaces changed", file=outf, flush=True)
            print("elapsed_s," + ",".join(cols), file=outf, flush=True)

        elapsed = now_time - t0
        total_rx = 0.0
        total_tx = 0.0
        values = []

        for iface in ifaces:
            rx_prev, tx_prev = prev.get(iface, (0, 0))
            rx_cur, tx_cur = cur.get(iface, (0, 0))
            rx_kbps = (rx_cur - rx_prev) / dt / 1024.0
            tx_kbps = (tx_cur - tx_prev) / dt / 1024.0
            values.append(f"{rx_kbps:.1f}")
            values.append(f"{tx_kbps:.1f}")
            total_rx += rx_kbps
            total_tx += tx_kbps

        values.append(f"{total_rx:.1f}")
        values.append(f"{total_tx:.1f}")
        print(f"{elapsed:.1f},{','.join(values)}", file=outf, flush=True)

        prev = cur
        prev_time = now_time

    if args.out:
        outf.close()
    print("Sampler stopped.", file=sys.stderr)


if __name__ == "__main__":
    main()
