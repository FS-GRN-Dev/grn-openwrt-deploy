#!/usr/bin/env python3
"""Plot experiment results from metrics_sampler CSV files.

Generates publication-ready figures for Q1 (failover) and Q2 (throughput aggregation).

Usage:
    # Q1: Failover comparison
    python3 plot_experiment.py q1 --single q1_single.csv --mptcp q1_mptcp.csv \
        --fault-time 60 --out fig_failover.pdf

    # Q2: Throughput smoothing (multiple runs)
    python3 plot_experiment.py q2 --single s1.csv s2.csv s3.csv s4.csv s5.csv \
        --mptcp m1.csv m2.csv m3.csv m4.csv m5.csv --out fig_smoothing.pdf

Requires: matplotlib, numpy
"""

import argparse
import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# IEEE two-column figure style
plt.rcParams.update({
    "font.size": 9,
    "font.family": "serif",
    "figure.figsize": (3.5, 2.4),
    "axes.labelsize": 9,
    "axes.titlesize": 9,
    "legend.fontsize": 7,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "lines.linewidth": 1.2,
    "grid.alpha": 0.3,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.05,
})


def load_csv(path: str):
    """Load a metrics_sampler CSV file.

    Returns (elapsed[], total_rx_kbps[]).
    Skips comment lines starting with #.
    """
    elapsed = []
    total_rx = []
    with open(path, "r") as f:
        reader = csv.DictReader(
            (row for row in f if not row.startswith("#")),
        )
        for row in reader:
            elapsed.append(float(row["elapsed_s"]))
            total_rx.append(float(row["total_rx_kbps"]))
    return np.array(elapsed), np.array(total_rx)


def smooth(y, window=5):
    """Simple moving average."""
    if len(y) < window:
        return y
    kernel = np.ones(window) / window
    return np.convolve(y, kernel, mode="same")


# ─── Q1: Failover Figure ─────────────────────────────────────────────

def plot_q1(args):
    fig, ax = plt.subplots()

    # Load single-path
    t_s, rx_s = load_csv(args.single)
    ax.plot(t_s, smooth(rx_s), color="tab:red", label="Single-path", alpha=0.85)

    # Load MPTCP
    t_m, rx_m = load_csv(args.mptcp)
    ax.plot(t_m, smooth(rx_m), color="tab:blue", label="ResiTun (k=2)")

    # Mark fault injection time
    if args.fault_time:
        ax.axvline(x=args.fault_time, color="black", linestyle="--", linewidth=0.8, alpha=0.6)
        ax.text(args.fault_time + 2, ax.get_ylim()[1] * 0.9, "fault injected",
                fontsize=7, color="black", va="top")

    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Throughput (KB/s)")
    ax.set_ylim(bottom=0)
    ax.legend(loc="best")
    ax.grid(True)

    out = args.out or "fig_failover.pdf"
    fig.savefig(out)
    print(f"Saved: {out}")
    plt.close(fig)


# ─── Q2: Throughput Smoothing Figure ──────────────────────────────────

def plot_q2(args):
    fig, ax = plt.subplots()

    # Average across runs for single-path
    single_runs = [load_csv(p) for p in args.single]
    mptcp_runs = [load_csv(p) for p in args.mptcp]

    def plot_band(runs, color, label):
        """Plot mean ± stddev band from multiple runs."""
        # Resample all runs to common time axis
        max_t = min(r[0][-1] for r in runs)
        common_t = np.arange(0, max_t, 1.0)
        resampled = []
        for t, rx in runs:
            resampled.append(np.interp(common_t, t, rx))
        matrix = np.array(resampled)
        mean = np.mean(matrix, axis=0)
        std = np.std(matrix, axis=0)
        mean_s = smooth(mean, window=5)
        std_s = smooth(std, window=5)
        ax.plot(common_t, mean_s, color=color, label=label)
        ax.fill_between(common_t, mean_s - std_s, mean_s + std_s,
                        color=color, alpha=0.15)

    plot_band(single_runs, "tab:red", "Single-path")
    plot_band(mptcp_runs, "tab:blue", "ResiTun (k=2)")

    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Throughput (KB/s)")
    ax.set_ylim(bottom=0)
    ax.legend(loc="best")
    ax.grid(True)

    out = args.out or "fig_smoothing.pdf"
    fig.savefig(out)
    print(f"Saved: {out}")
    plt.close(fig)

    # ── Print statistics table ──
    print("\n=== Throughput Statistics ===")
    print(f"{'Config':<20} {'Mean (KB/s)':>12} {'StdDev':>10} {'CV':>8}")
    print("-" * 54)
    for name, runs in [("Single-path", single_runs), ("ResiTun (k=2)", mptcp_runs)]:
        all_rx = np.concatenate([rx for _, rx in runs])
        mean_v = np.mean(all_rx)
        std_v = np.std(all_rx)
        cv = std_v / mean_v if mean_v > 0 else 0
        print(f"{name:<20} {mean_v:>12.1f} {std_v:>10.1f} {cv:>8.3f}")

    # ── Print per-run FCT table ──
    print("\n=== File Completion Time (FCT) ===")
    for name, runs in [("Single-path", single_runs), ("ResiTun (k=2)", mptcp_runs)]:
        fcts = [t[-1] for t, _ in runs]
        print(f"{name}: FCTs = {[f'{f:.1f}s' for f in fcts]}, "
              f"mean = {np.mean(fcts):.1f}s, std = {np.std(fcts):.1f}s")


# ─── Main ─────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Plot ResiTun experiment results")
    sub = parser.add_subparsers(dest="cmd")

    # Q1
    p1 = sub.add_parser("q1", help="Plot Q1 failover figure")
    p1.add_argument("--single", required=True, help="Single-path CSV")
    p1.add_argument("--mptcp", required=True, help="MPTCP CSV")
    p1.add_argument("--fault-time", type=float, default=None, help="Fault injection time (s)")
    p1.add_argument("--out", type=str, default="", help="Output file")

    # Q2
    p2 = sub.add_parser("q2", help="Plot Q2 throughput smoothing")
    p2.add_argument("--single", nargs="+", required=True, help="Single-path CSV files (multiple runs)")
    p2.add_argument("--mptcp", nargs="+", required=True, help="MPTCP CSV files (multiple runs)")
    p2.add_argument("--out", type=str, default="", help="Output file")

    args = parser.parse_args()
    if args.cmd == "q1":
        plot_q1(args)
    elif args.cmd == "q2":
        plot_q2(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
