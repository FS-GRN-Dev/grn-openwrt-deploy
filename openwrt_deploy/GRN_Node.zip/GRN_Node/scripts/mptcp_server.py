#!/usr/bin/env python3
"""MPTCP bulk data server for experiments.

Creates a native MPTCP socket (IPPROTO_MPTCP=262) and sends a
specified amount of data to each connecting client.

Usage:
    python3 mptcp_server.py [--host 0.0.0.0] [--port 8080] [--size-mb 100]

Requires Linux kernel 5.6+ with MPTCP enabled.
"""

import argparse
import socket
import time

IPPROTO_MPTCP = 262


def main():
    parser = argparse.ArgumentParser(description="MPTCP bulk data server")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Bind address")
    parser.add_argument("--port", type=int, default=8080, help="Bind port")
    parser.add_argument("--size-mb", type=int, default=100, help="Total data to send per connection (MB)")
    args = parser.parse_args()

    total_bytes = args.size_mb * 1024 * 1024
    chunk = b"X" * (64 * 1024)  # 64 KB chunks

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM, IPPROTO_MPTCP)
    except OSError:
        print("MPTCP socket creation failed. Falling back to regular TCP.")
        print("Make sure: sysctl net.mptcp.enabled=1 and kernel >= 5.6")
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((args.host, args.port))
    s.listen(5)
    proto = "MPTCP" if s.proto == IPPROTO_MPTCP else "TCP"
    print(f"[{proto}] Server listening on {args.host}:{args.port}, will send {args.size_mb} MB per connection")

    try:
        while True:
            conn, addr = s.accept()
            print(f"Connection from {addr}")
            t0 = time.monotonic()
            sent = 0
            try:
                while sent < total_bytes:
                    remaining = total_bytes - sent
                    to_send = chunk if remaining >= len(chunk) else chunk[:remaining]
                    conn.sendall(to_send)
                    sent += len(to_send)
                elapsed = time.monotonic() - t0
                speed = sent / elapsed / (1024 * 1024) if elapsed > 0 else 0
                print(f"Sent {sent / (1024*1024):.1f} MB to {addr} in {elapsed:.1f}s ({speed:.1f} MB/s)")
            except (BrokenPipeError, ConnectionResetError) as e:
                elapsed = time.monotonic() - t0
                print(f"Connection to {addr} broken after {sent/(1024*1024):.1f} MB in {elapsed:.1f}s: {e}")
            finally:
                conn.close()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        s.close()


if __name__ == "__main__":
    main()
