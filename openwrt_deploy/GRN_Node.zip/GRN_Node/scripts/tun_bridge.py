"""Minimal Tun-over-Tor bridge (manual PoC runner).

This script is intentionally independent from grpc command flow.
It creates multiple tun devices and connects each to the same remote endpoint
through Tor SOCKS, using SOCKS username=link_id to bind different circuits.

Prerequisites (Linux):
- CAP_NET_ADMIN (or run as root)
- /dev/net/tun available
- Tor client SOCKS reachable at proxy_host:proxy_port
- Remote endpoint reachable from Tor (public IP:port or onion service)

Example:
python scripts/tun_bridge.py \
  --proxy-host 127.0.0.1 --proxy-port 9050 \
  --endpoint-host 1.2.3.4 --endpoint-port 9000 \
  --tunnel tun0=10.0.1.1/24,link-aaaa1111 \
  --tunnel tun1=10.0.2.1/24,link-bbbb2222
"""

import argparse
import asyncio
import os
import sys

# Allow running from repo root: add ../src to import path
_HERE = os.path.dirname(os.path.abspath(__file__))
_SRC = os.path.abspath(os.path.join(_HERE, "..", "src"))
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)

from services.multi_tun_bridge import SingleTunnelConfig  # type: ignore[import-not-found]
import utils.logger  # type: ignore[import-not-found]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["client", "server"], default="client")
    p.add_argument("--log-level", default="INFO", help="Logging level (DEBUG/INFO/WARNING/ERROR)")
    p.add_argument("--proxy-host")
    p.add_argument("--proxy-port", type=int)
    p.add_argument("--endpoint-host", required=True)
    p.add_argument("--endpoint-port", type=int, required=True)
    p.add_argument("--mtu", type=int, default=1300)
    p.add_argument("--connect-timeout-sec", type=int, default=60)
    p.add_argument(
        "--tunnel",
        action="append",
        default=[],
        help="Format: tunX=10.0.X.1/24,link-xxxx",
    )
    return p.parse_args()


def parse_tunnels(items: list[str]) -> list[SingleTunnelConfig]:
    tunnels: list[SingleTunnelConfig] = []
    for item in items:
        # tun0=10.0.1.1/24,link-aaaa
        if "=" not in item or "," not in item:
            raise ValueError(f"invalid --tunnel: {item}")
        tun_name, rest = item.split("=", 1)
        addr, link_id = rest.split(",", 1)
        tunnels.append(SingleTunnelConfig(tun_name=tun_name.strip(), tun_addr_cidr=addr.strip(), link_id=link_id.strip()))
    return tunnels


async def main() -> None:
    args = parse_args()
    # This PoC script is often run standalone (outside node_client.py), so we must
    # set up logging explicitly. Otherwise INFO logs will not show up.
    utils.logger.setup_logging(args.log_level)
    tunnels = parse_tunnels(args.tunnel)
    if not tunnels:
        raise SystemExit("at least one --tunnel is required")

    if args.mode == "server":
        from services.tun_server import TunTunnelServer, TunTunnelServerConfig  # type: ignore[import-not-found]

        server = TunTunnelServer(
            TunTunnelServerConfig(
                listen_host=args.endpoint_host,
                listen_port=args.endpoint_port,
                mtu=args.mtu,
                tunnels=tunnels,
            )
        )
        await server.start()
        await asyncio.Event().wait()

    if not args.proxy_host or not args.proxy_port:
        raise SystemExit("--proxy-host/--proxy-port are required in client mode")

    from services.multi_tun_bridge import MultiTunBridge, MultiTunBridgeConfig  # type: ignore[import-not-found]

    bridge = MultiTunBridge(
        MultiTunBridgeConfig(
            proxy_host=args.proxy_host,
            proxy_port=args.proxy_port,
            endpoint_host=args.endpoint_host,
            endpoint_port=args.endpoint_port,
            tunnels=tunnels,
            mtu=args.mtu,
            connect_timeout_sec=args.connect_timeout_sec,
        )
    )
    await bridge.start()
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
