import stem
from stem.util.enum import UppercaseEnum
from stem.control import EventType, Controller


#启动一个 http 文件下载服务（本机ip为 10.8.12.135），并放置一个 待下载的文件
#python3 -m http.server 8888 --bind 0.0.0.0

# 你的文件下载服务目标地址（与curl一致）
TARGET_ADDR = '10.8.12.135:8888'
# 存储curl请求对应的stream_id（用于关联STREAM_BW/CIRC）
target_stream_id = None



def listen_tor_events():
    # 连接Tor控制端口（容器内Tor的9051端口已映射到宿主机）
    with Controller.from_port(port=9051) as controller:
        try:
            # 认证（无密码则直接authenticate，有密码需传入）
            controller.authenticate(password="torpassword")
            print("✅ 已连接到Tor控制端口，开始监听核心事件...\n")

            # 定义事件回调函数（处理STREAM/CIRC等核心事件）
            def handle_event(event):
                global target_stream_id

                try:
                    # 捕获STREAM事件（数据流，对应你的下载请求）
                    if isinstance(event, stem.response.events.StreamEvent):
                        print(f"📡 STREAM事件 - 状态: {event.status} | purpose：{event.purpose} | 目标地址: {event.target} | 流ID: {event.id} | 电路ID：{event.circ_id}")

                        socks_username = getattr(event, 'socks_username', None)
                        socks_password = getattr(event, 'socks_password', None)
                        client_protocol = getattr(event, 'client_protocol', None)
                        print(f"Socks用户名: {socks_username}, 密码：{socks_password}, 客户端协议：{client_protocol}")

                        if event.reason:
                            print(f"❌ 失败原因: {event.reason}")
                        if event.remote_reason:
                            print(f"❌ 远程失败原因: {event.remote_reason}")

                        print(f"📡 ---------------------------------------------------------------------------------------------------------------------------------------")

                        # 解析event.target的IP和端口
                        target = str(event.target)
                        event_ip, event_port = target.split(':')

                        # 拆分目标地址
                        target_ip, target_port = TARGET_ADDR.split(':')

                        # 精准匹配IP+端口
                        if event_ip == target_ip and event_port == target_port:
                            target_stream_id = event.id
                            print(f"\n===== STREAM事件（核心）=====")
                            print(f"流ID: {event.id}")
                            print(f"电路ID：: {event.circ_id}")
                            print(f"状态: {event.status}")
                            print(f"目标地址: {event.target}")
                            if event.reason:
                                print(f"❌ 失败原因: {event.reason}")
                            if event.remote_reason:
                                print(f"❌ 远程失败原因: {event.remote_reason}")
                            print(f"🔍 捕获到目标下载请求！STREAM详情: {event}")
                            print(f"========================================================================================================================================")

                    # 捕获STREAM_BW事件（核心：流的传输数据）
                    elif isinstance(event, stem.response.events.StreamBwEvent):
                        if event.id == target_stream_id:
                            print(f"\n===== STREAM_BW事件 ======")
                            print(f"流ID: {event.id}")
                            print(f"本次下载字节: {event.read}")
                            print(f"累计下载字节: {event.total_read if hasattr(event, 'total_read') else 0}")
                            print(f"========================================================================================================================================")

                    # 捕获CIRC事件（电路，数据流的传输载体）
                    elif isinstance(event, stem.response.events.CircuitEvent):
                        print(f"🔌 CIRC事件 - 状态: {event.status} | 电路ID: {event.id} | 路径: {event.path}")

                        # 关注绑定到目标流的电路，或所有失败的电路
                        if (target_stream_id and f"CLIENT_STREAM {target_stream_id}" in str(event.purpose)) or event.status == "FAILED":
                            print(f"\n===== [核心] CIRC事件 =====")
                            print(f"电路ID: {event.id} | 状态: {event.status}")
                            print(f"用途: {event.purpose} | 失败原因: {event.reason if event.reason else '无'}")
                            print(f"========================================================================================================================================")

                    # 捕获GUARD事件（守护节点状态）
                    elif isinstance(event, stem.response.events.GuardEvent):
                        print(f"\n===== GUARD事件 =====")
                        print(f"[GUARD]")

                        fingerprint = getattr(event, 'endpoint_fingerprint', 'unknown')
                        nickname= getattr(event, 'endpoint_nickname', 'unknown')
                        guard_type= getattr(event, 'guard_type', 'ENTRY')
                        status = getattr(event, 'status', 'UP')

                        print(f"  指纹: {fingerprint}")
                        print(f"  昵称: {nickname}")
                        print(f"  类型: {guard_type}")
                        print(f"  状态: {status}")

                        print(f"========================================================================================================================================")

                    # 捕获ORCONN事件（Tor节点连接状态）
                    elif isinstance(event, stem.response.events.ORConnEvent):
                        print(f"\n===== [新增] ORCONN事件 =====")
                        print(f"节点地址: {event.endpoint} | 状态: {event.status} ID：{event.id}")
                        print(f"========================================================================================================================================")

                    # 捕获带宽事件（可看到下载的字节数）
                    elif isinstance(event, stem.response.events.BandwidthEvent):
                        pass
                        #print(f"📊 带宽统计 - 下载: {event.read} bytes | 上传: {event.written} bytes")
                    
                    # 捕获客户端状态事件（确认Tor联网状态）
                    elif isinstance(event, stem.response.events.StatusEvent):
                        if event.type == 'STATUS_CLIENT' and event.action == 'CONNECTED':
                            print(f"🌐 Tor已连接到网络，可处理代理请求")

                    # 捕获NETWORK_LIVENESS事件（辅助：网络连通性）
                    elif isinstance(event, stem.response.events.NetworkLivenessEvent):
                        print(f"\n===== NETWORK_LIVENESS事件 =====")
                        print(f"Tor是否在线: {event.alive}")
                        print(f"========================================================================================================================================")

                    # 捕获SIGNAL事件（辅助：切换新身份）
                    elif isinstance(event, stem.response.events.SignalEvent):
                        print(f"\n===== SIGNAL事件 ======")
                        print(f"发送的信号: {event.signal}")
                        print(f"执行状态: {event.status}")
                        print(f"========================================================================================================================================")

                except Exception as e:
                    print(f"❌ 处理事件异常: {e}")

            # 订阅核心事件（只订阅需要的，减少冗余）
            controller.add_event_listener(handle_event, 
                stem.control.EventType.STREAM,
                stem.control.EventType.STREAM_BW,
                stem.control.EventType.CIRC,
                stem.control.EventType.GUARD,
                stem.control.EventType.ORCONN,
                stem.control.EventType.BW,
                stem.control.EventType.STATUS_CLIENT,
                stem.control.EventType.NETWORK_LIVENESS,
                stem.control.EventType.SIGNAL
            )

            # 保持监听（按Ctrl+C停止）
            print("⚠️  已订阅STREAM/STREAM_BW/CIRC/GUARD/ORCONN/BW/STATUS_CLIENT/NETWORK_LIVENESS/SIGNAL事件，执行curl下载命令可触发事件捕获...")
            while True:
                pass

        except stem.SocketError:
            print("❌ 连接Tor控制端口失败，请检查9051端口是否映射、Tor是否启动")
        except stem.connection.AuthenticationFailure:
            print("❌ Tor控制端口认证失败，请检查torrc中的HashedControlPassword配置")
        except KeyboardInterrupt:
            print("\n🛑 停止监听Tor事件")
        except Exception as e:
            print(f"❌ 监听异常: {e}")

if __name__ == "__main__":
    listen_tor_events()
