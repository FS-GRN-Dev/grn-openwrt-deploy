#!/usr/bin/env bash
# 从 GRN_Node 源码制作云节点部署制品：
#   NodeManagement.tar.gz  — 节点管理程序（node_client 等）
#   grn-tor.tar            — Tor 容器镜像
#
# 用法：
#   ./scripts/pack-node-artifacts.sh [输出目录]
# 默认输出到 ../grn-client-ansible/
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="${1:-$(cd "${ROOT_DIR}/../grn-client-ansible" && pwd)}"

log() { echo "[$(date '+%F %T')] $*"; }

[[ -f "${ROOT_DIR}/requirements.txt" ]] || { echo "ERROR: 请在 GRN_Node 仓库根目录相关路径运行"; exit 1; }
[[ -f "${ROOT_DIR}/src/core/node_client.py" ]] || { echo "ERROR: 缺少 src/core/node_client.py"; exit 1; }
[[ -f "${ROOT_DIR}/src/credentials/ca.crt" ]] || {
  echo "ERROR: 缺少 src/credentials/ca.crt（须与 grn-backend gRPC CA 同源）"
  exit 1
}
[[ -d "${OUT_DIR}" ]] || { echo "ERROR: 输出目录不存在: ${OUT_DIR}"; exit 1; }
[[ -f "${ROOT_DIR}/src/docker/Dockerfile" ]] || { echo "ERROR: 缺少 src/docker/Dockerfile"; exit 1; }

STAGING="$(mktemp -d)"
trap 'rm -rf "${STAGING}"' EXIT

log "打包 NodeManagement.tar.gz → ${OUT_DIR}"
mkdir -p "${STAGING}/NodeManagement"
rsync -a \
  --exclude '.git' \
  --exclude '.venv' \
  --exclude 'venv' \
  --exclude '__pycache__' \
  --exclude '.pytest_cache' \
  --exclude 'NodeManagement.tar.gz' \
  --exclude 'grn-tor.tar' \
  --exclude '*.pyc' \
  "${ROOT_DIR}/" "${STAGING}/NodeManagement/"

tar -czf "${OUT_DIR}/NodeManagement.tar.gz" -C "${STAGING}" NodeManagement
log "  → ${OUT_DIR}/NodeManagement.tar.gz ($(du -h "${OUT_DIR}/NodeManagement.tar.gz" | awk '{print $1}'))"

log "构建并导出 grn-tor 镜像"
if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: 需要 docker 才能构建 grn-tor.tar"
  exit 1
fi

docker build -t grn-tor:latest "${ROOT_DIR}/src/docker"
docker save grn-tor:latest -o "${OUT_DIR}/grn-tor.tar"
log "  → ${OUT_DIR}/grn-tor.tar ($(du -h "${OUT_DIR}/grn-tor.tar" | awk '{print $1}'))"

log "完成。随后可执行 grn-server-deploy/pack-release.sh 打管理面部署包"
