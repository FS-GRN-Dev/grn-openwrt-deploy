#!/bin/bash
# ==============================================================================
# 使用说明：
#   $0 start  [SERVER_ADDR]   启动服务，SERVER_ADDR 格式示例：36.134.205.22:50050
#   $0 stop                   停止服务
#   $0 restart [SERVER_ADDR]  重启服务
#   $0 status                 查看运行状态
# 地址来源（优先顺序）：
#   1) 位置参数 SERVER_ADDR
#   2) 环境变量 GRN_SERVER_ADDR（管理面 SSH 启停会这样传）
# 示例：
#   ./script.sh start 36.134.205.22:50050
#   GRN_SERVER_ADDR=36.134.205.22:50050 ./script.sh start
#   ./script.sh restart 36.134.205.22:50050
# ==============================================================================
APP_NAME="node_client"
DEPLOY_DIR="/home/node-test"
WORK_DIR="${DEPLOY_DIR}/NodeManagement"
APP_SCRIPT="${WORK_DIR}/src/core/node_client.py"
PYTHON_BIN="${DEPLOY_DIR}/venv/bin/python"
PID_FILE="/var/run/${APP_NAME}.pid"

resolve_server_addr() {
    echo "${1:-${GRN_SERVER_ADDR:-}}"
}

# 读取进程命令行中的 -s 地址；失败返回空
get_running_server_addr() {
    local PID="$1"
    local CMD
    CMD=$(ps -p "$PID" -o args= 2>/dev/null) || return 0
    # 匹配: ... node_client.py ... -s <addr>
    if [[ "$CMD" =~ node_client\.py[[:space:]].*-s[[:space:]]+([^[:space:]]+) ]]; then
        echo "${BASH_REMATCH[1]}"
    fi
}

# 确认 PID 真是 node_client.py（避免 PID 复用误判）
is_node_client_pid() {
    local PID="$1"
    local CMD
    CMD=$(ps -p "$PID" -o args= 2>/dev/null) || return 1
    [[ "$CMD" == *node_client.py* ]]
}

# 检查进程是否在运行；成功时把 PID 写回 PID_FILE
is_running() {
    local PID=""
    if [ -f "$PID_FILE" ]; then
        PID=$(cat "$PID_FILE")
        if kill -0 "$PID" 2>/dev/null && is_node_client_pid "$PID"; then
            return 0
        fi
        rm -f "$PID_FILE"
    fi
    PID=$(pgrep -f "node_client.py.*-s " | head -n 1)
    if [ -n "$PID" ] && is_node_client_pid "$PID"; then
        echo "$PID" > "$PID_FILE"
        return 0
    fi
    return 1
}

start_app() {
    local SERVER_ADDR
    SERVER_ADDR="$(resolve_server_addr "$2")"
    if [ -z "${SERVER_ADDR}" ]; then
        echo "[-] Error: Must specify server address! Format example: 36.134.205.22:50050"
        echo "[-] Usage: $0 start 36.134.205.22:50050"
        echo "[-]    or: GRN_SERVER_ADDR=36.134.205.22:50050 $0 start"
        return 1
    fi

    echo "[+] Starting $APP_NAME, server address: ${SERVER_ADDR}"

    if is_running; then
        local PID CURRENT_ADDR
        PID=$(cat "$PID_FILE")
        CURRENT_ADDR="$(get_running_server_addr "$PID")"
        if [ "$CURRENT_ADDR" = "$SERVER_ADDR" ]; then
            echo "[!] $APP_NAME already running with same server (PID: $PID, -s $CURRENT_ADDR)."
            return 0
        fi
        echo "[!] $APP_NAME running with different server (PID: $PID, -s ${CURRENT_ADDR:-unknown}), restarting for $SERVER_ADDR..."
        stop_app
    fi

    if [ ! -f "$APP_SCRIPT" ]; then
        echo "[-] Error: $APP_SCRIPT not found."
        return 1
    fi
    if [ ! -f "$PYTHON_BIN" ]; then
        echo "[-] Error: Python interpreter not found at $PYTHON_BIN"
        return 1
    fi

    cd "$WORK_DIR" || return 1
    nohup "$PYTHON_BIN" \
        "$APP_SCRIPT" \
        -s "$SERVER_ADDR" \
        >/dev/null 2>&1 &
    echo $! > "$PID_FILE"

    sleep 2
    if is_running; then
        echo "[+] $APP_NAME started successfully (PID: $(cat "$PID_FILE"), -s $SERVER_ADDR)."
    else
        echo "[-] Failed to start $APP_NAME."
        rm -f "$PID_FILE"
        return 1
    fi
}

stop_app() {
    echo "[-] Stopping $APP_NAME..."
    if ! is_running; then
        # 兜底清掉可能残留的同名进程
        pkill -f "node_client.py.*-s " 2>/dev/null || true
        rm -f "$PID_FILE" 2>/dev/null
        echo "[-] $APP_NAME is not running."
        return 0
    fi
    local PID
    PID=$(cat "$PID_FILE")
    kill "$PID" 2>/dev/null
    local i
    for i in $(seq 1 5); do
        if ! kill -0 "$PID" 2>/dev/null; then
            break
        fi
        sleep 1
    done
    if kill -0 "$PID" 2>/dev/null; then
        echo "[!] $APP_NAME did not stop gracefully, killing (SIGKILL)..."
        kill -9 "$PID" 2>/dev/null
    fi
    # 再扫一遍，避免漏杀
    pkill -f "node_client.py.*-s " 2>/dev/null || true
    rm -f "$PID_FILE"
    echo "[-] $APP_NAME stopped."
}

status_app() {
    echo "[*] Checking $APP_NAME status..."
    if is_running; then
        local PID ADDR
        PID=$(cat "$PID_FILE")
        ADDR="$(get_running_server_addr "$PID")"
        echo "[*] $APP_NAME is running (PID: $PID, -s ${ADDR:-unknown})."
    else
        echo "[*] $APP_NAME is not running."
    fi
}

case "$1" in
    start)
        start_app "$@"
        ;;
    stop)
        stop_app
        ;;
    restart)
        stop_app
        start_app "$@"
        ;;
    status)
        status_app
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status} [SERVER_ADDR]"
        echo "Example:"
        echo "  $0 start 36.134.205.22:50050"
        echo "  GRN_SERVER_ADDR=36.134.205.22:50050 $0 start"
        echo "  $0 restart 36.134.205.22:50050"
        exit 1
        ;;
esac
