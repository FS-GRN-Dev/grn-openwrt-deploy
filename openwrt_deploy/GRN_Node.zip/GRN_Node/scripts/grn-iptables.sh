#!/bin/sh

CHAIN="GRN"
LAN_IF="br-lan"
TCP_PORT="11090"
#DNS_PORT="50053"

add_rules() {
    echo "[+] Adding iptables rules..."

    # 创建链（如果不存在）
    iptables -t nat -N $CHAIN 2>/dev/null

    # 清空链
    iptables -t nat -F $CHAIN

    # 排除内网
    iptables -t nat -A $CHAIN -d 127.0.0.0/8 -j RETURN
    iptables -t nat -A $CHAIN -d 192.168.0.0/16 -j RETURN
    iptables -t nat -A $CHAIN -d 10.0.0.0/8 -j RETURN
    iptables -t nat -A $CHAIN -d 172.16.0.0/12 -j RETURN

    # 排除 bogon / 保留地址段（DNS 劫持等会导致请求发往这些地址）
    iptables -t nat -A $CHAIN -d 0.0.0.0/8 -j RETURN
    iptables -t nat -A $CHAIN -d 169.254.0.0/16 -j RETURN
    iptables -t nat -A $CHAIN -d 224.0.0.0/4 -j RETURN
    iptables -t nat -A $CHAIN -d 240.0.0.0/4 -j RETURN

    # TCP 转发
    iptables -t nat -A $CHAIN -p tcp -j REDIRECT --to-ports $TCP_PORT

    # 挂 PREROUTING（避免重复添加）
    iptables -t nat -C PREROUTING -i $LAN_IF -p tcp -j $CHAIN 2>/dev/null || \
    iptables -t nat -A PREROUTING -i $LAN_IF -p tcp -j $CHAIN

    # DNS 劫持（避免重复）
    #iptables -t nat -C PREROUTING -i $LAN_IF -p udp --dport 53 -j REDIRECT --to-ports $DNS_PORT 2>/dev/null || \
    #iptables -t nat -A PREROUTING -i $LAN_IF -p udp --dport 53 -j REDIRECT --to-ports $DNS_PORT

    echo "[+] Done."
}

del_rules() {
    echo "[-] Deleting iptables rules..."

    # 删除 PREROUTING 规则
    while iptables -t nat -C PREROUTING -i $LAN_IF -p tcp -j $CHAIN 2>/dev/null; do
        iptables -t nat -D PREROUTING -i $LAN_IF -p tcp -j $CHAIN
    done

    #while iptables -t nat -C PREROUTING -i $LAN_IF -p udp --dport 53 -j REDIRECT --to-ports $DNS_PORT 2>/dev/null; do
    #    iptables -t nat -D PREROUTING -i $LAN_IF -p udp --dport 53 -j REDIRECT --to-ports $DNS_PORT
    #done

    # 清空并删除链
    iptables -t nat -F $CHAIN 2>/dev/null
    iptables -t nat -X $CHAIN 2>/dev/null

    echo "[-] Done."
}

status_rules() {
    echo "[*] Current NAT rules:"
    iptables -t nat -L -n -v --line-numbers
}

case "$1" in
    start)
        add_rules
        ;;
    stop)
        del_rules
        ;;
    restart)
        del_rules
        add_rules
        ;;
    status)
        status_rules
        ;;
    *)
        echo "Usage: $0 {start|stop|restart|status}"
        exit 1
        ;;
esac