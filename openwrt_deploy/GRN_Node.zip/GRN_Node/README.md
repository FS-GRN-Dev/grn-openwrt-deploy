节点管理后端，与管理面gRPC Server通信，主要负责两项工作：
- 定时将各类信息上报，如节点信息、DA信息等；
- 接收管理面gRPC Server下发的命令(Command)，根据命令类型执行具体的操作（创建Relay、创建电路等），并返回响应。

相关API总结如下：
### 1. HandleStatusChange
- 功能：处理`SET_NODE_STATUS`类型Command
- 实现逻辑：
	- 修改Node Client本地的node status
	- PushNodeInfo到gRPC Server
### 2. HandleRoleChange
- 功能：处理`SET_NODE_ROLE`类型Command
- 实现逻辑：
	- 修改Node Client本地的node role
	- PushNodeInfo到gRPC Server

### 3. HandleCreateRelay
- 功能：处理`CREATE_RELAY`类型Command
- 实现逻辑：
	- 在Node中创建Relay对象
	- PushRelayInfo到gRPC Server
- 讨论：
	- 目前缺少实际创建Relay容器的过程和方法
	- $ 已实现，基于docker库
	- ! 待测试
### 4, HandleDestroyRelay
- 功能：处理`DESTROY_RELAY`类型Command
- 实现逻辑：
	- 在Node中删除对应的Relay对象
	- PushNodeInfo到gRPC Server
- 讨论：
	- 目前缺少实际删除Relay容器的过程和方法
	- $ 已实现，基于docker库
	- ! 待测试
### 5, HandleDestroyNode
- 功能：处理`DESTROY_NODE`类型Command
- 实现逻辑：
	- PushSelfDestructionInfo到gRPC Server
	- 断开连接
- 讨论：
	- 目前是真实断开连接
### 6. HandleDAInfo
- 功能：处理`DA_INFO`类型Command
- 实现逻辑：
	- 接收DA信息，调用Stem API更新配置
- 讨论：
	- 目前对DA信息没有处理(缺少主动上传DA信息的方法)
	- 需要结合Stem API，把相关信息写入到对应的torrc中
### 7. HandleRefreshInfo
- 功能：处理`REFRESH_INFO`类型Command
- 实现逻辑：
	- 执行各种Push API
- 讨论：
	- 目前只实现了PushNodeInfo，可以再增加一些（已增加PushSituationAwarenessInfo和PushDAInfo）
### 8. HandleUpdateRelay
- 功能：处理`UPDATE_RELAY`
- 实现逻辑：
	- 根据下发的Command中的msg，更新字段
- 讨论：
	- 需要结合Stem API调整torrc
	- ! 这个API暂时没用到，仅保留接口
### 9. HandleCreateCircuit
- 功能：处理`CREATE_CIRCUIT`
- 实现逻辑：
	- 基于下发的fingerprints，调用Stem API创建电路
	- 返回结果
- 讨论：
	- Stem API待实现
### 10. HandleDestroyCircuit
- 功能：处理`DESTROY_CIRCUIT`
- 实现逻辑：
	- 基于下发的circuit_id，调用Stem API关闭对应的电路
- 讨论：
	- Stem API待实现


### 11. Push\*\*\*Info
- 功能：均为定时上报相关信息
- 实现逻辑：
	- asyncio.sleep+while try
- 讨论：
	- 可能需要进一步细化


### 12. MultipathDownload (PoC)
- 功能：处理`MULTIPATH_DOWNLOAD`
- 实现逻辑：
	- 按 `parts` 把目标文件拆成多个 HTTP Range（字节区间）
	- 每个分片请求通过 SOCKS5 代理认证（username=link_id），由节点侧 CircuitManager 把流 attach 到对应电路
	- 并行下载各分片，完成后按顺序合并为目标文件
	- 可选：下载结束后清理由本次命令创建的电路
- message(json) 示例：
```json
{
	"client_relay_code": "relay-...",
	"url": "http://<apache>/big.bin",
	"output_path": "/tmp/big.bin",
	"parts": 4,

	"paths": [
		["$fp1", "$fp2", "$fp3"],
		["$fp4", "$fp5", "$fp6"],
		["$fp7", "$fp8", "$fp9"],
		["$fpa", "$fpb", "$fpc"]
	],

	"timeout_sec": 300,
	"connect_timeout_sec": 15,
	"max_parallel": 4,
	"cleanup": true
}
```

### 13. Tun-over-Tor 多路径隧道（PoC，面向 MPTCP 路线）

用途：提供多个独立的 L3 隧道（tun0/tun1/...），每条隧道通过 Tor SOCKS 建立一条 TCP 通道，并用 `username=link_id` 复用现有 `CircuitManager` 的 `attach_stream` 机制把该通道绑定到指定电路。

这一步本身不做透明代理/iptables，仅提供“多条隧道管道”。在此之上可按你们 SSH 可行性验证的方式配置 MPTCP（`ip mptcp endpoint ...`）做 subflow 聚合。

代码：
- PoC runner: [VPS/NodeManagement/scripts/tun_bridge.py](VPS/NodeManagement/scripts/tun_bridge.py)
- 核心实现: [VPS/NodeManagement/src/services/tun_device.py](VPS/NodeManagement/src/services/tun_device.py), [VPS/NodeManagement/src/services/tun_tunnel.py](VPS/NodeManagement/src/services/tun_tunnel.py), [VPS/NodeManagement/src/services/tun_server.py](VPS/NodeManagement/src/services/tun_server.py)

说明：该 PoC 脚本用于“先跑通 TUN 多隧道 + Tor 承载”，脚本本身不依赖管理面 gRPC Server 的命令分发逻辑；但它**必须**能连到一个实际在运行的 Tor SOCKS（例如 127.0.0.1:9050）。

在你们当前的部署方式里，Tor 容器通常不是常驻服务：需要先通过 `deploy.sh` 启动 NodeManagement（`node_client.py` 常驻），再由管理面下发 `CREATE_RELAY`/相关命令拉起 Tor 容器并 publish SOCKS 端口。若 Tor 容器未启动或未 publish 端口，client 侧会直接报 `Connection refused`。

前置条件（Linux）：
- 需要 `CAP_NET_ADMIN`（通常用 root/特权容器运行）
- 需要 `/dev/net/tun`
- 需要 `ip` 命令（iproute2）
- Client 端需要 Tor SOCKS 可访问（例如 127.0.0.1:9050）。
- 建议先在 client VPS 上确认 SOCKS 监听：`ss -lntp | grep 9050`；如果你们用的是 docker publish，也可以用 `docker ps --format '{{.Names}} {{.Ports}}' | grep 9050`。
- 注意：如果当前机器上只启动了 `ROLE_DA/ROLE_RELAY/ROLE_EXIT` 容器（例如你贴的 `da-...`），它们默认不会监听/暴露 `9050`，因此连 `127.0.0.1:9050` 会是 `Connection refused`。PoC Client 需要管理面下发 `CREATE_RELAY` 且 `relay_role=ROLE_CLIENT`（或在另一台 VPS 上有 client tor）才能拿到 SOCKS。
- 注意：如果你没有运行 NodeManagement 的 CircuitManager 做 `attach_stream`，请不要把 Tor 设置成 `__LeaveStreamsUnattached=1`（否则流会卡住）。
- 仅用脚本验证时，建议在 torrc 里启用 `IsolateSOCKSAuth`，这样不同 `link_id` 会更倾向于走不同电路（但不保证指定路径）。

运行示例：
- Server 端（监听 0.0.0.0:19000，并创建 tun0/tun1）：
	- 由于9000会被Graylog容器占用，换了个端口
	- `sudo -E $(which python) scripts/tun_bridge.py --mode server --endpoint-host 0.0.0.0 --endpoint-port 19000 --tunnel tun0=10.0.1.2/24,link-server0 --tunnel tun1=10.0.2.2/24,link-server1`
- Client 端（通过 Tor SOCKS 连接 server_ip:9000，并创建 tun0/tun1）：
	- 需要运行好gRPC Server和Node Client，并在上面创建Client Relay
	- 新增一个venv:
		- `python3 -m venv ~/tun-venv`
		- `source ~/tun-venv/bin/activate`
		- `pip install PySocks asyncio`
	- `source ~/tun-venv/bin/activate`
	- `sudo -E $(which python) scripts/tun_bridge.py --mode client --proxy-host 127.0.0.1 --proxy-port 9050 --endpoint-host 10.177.53.69 --endpoint-port 19000 --tunnel tun0=10.0.1.1/24,link-aaaa1111 --tunnel tun1=10.0.2.1/24,link-bbbb2222`

### 14. 透明代理（sing-box）

当前透明代理由 `sing-box` 承担。client 侧通过 iptables `REDIRECT` 接收用户 TCP 流量，再由 sing-box selector 在 `direct`、`socks5`、`mptcp-tunnel` 三个 outbound 之间切换；server 侧由 sing-box 监听 MPTCP tunnel，并将流量转发到用户原始目标。


#### 安装 sing-box

client 和 server 都需要能直接执行 `sing-box`：
官方安装说明：`https://sing-box.sagernet.org/installation/package-manager/`。

```bash
curl -fsSL https://sing-box.app/install.sh | sh
sing-box version
```
也可以使用其他系统包管理器或手动安装方式，只要 `sing-box` 在 `PATH` 中即可。

OpenWrt 可优先使用软件源安装：

```sh
opkg update
opkg install sing-box
sing-box version
```

#### 配置和端口

配置入口是 `src/config/config.py` 中的 `SingBoxConfig`。需要修改监听端口、selector API、日志路径、UUID、SOCKS 默认地址等运行参数时，优先改这里。

常用字段：

- `CLIENT_LISTEN_HOST` / `CLIENT_LISTEN_PORT`：client redirect inbound 监听地址和端口，默认 `0.0.0.0:11090`
- `SERVER_LISTEN_HOST` / `SERVER_LISTEN_PORT`：server mptcp inbound 默认监听地址和端口，默认 `0.0.0.0:11091`
- `CLASH_API_HOST` / `CLASH_API_PORT` / `CLASH_API_SECRET`：client selector API，默认 `127.0.0.1:9090`
- `DEFAULT_SOCKS_HOST` / `DEFAULT_SOCKS_PORT`：单路径 SOCKS5 outbound 默认地址，默认 `127.0.0.1:9050`
- `UUID`：client/server VLESS tunnel 使用的 UUID，两端必须一致
- `RUNTIME_CONFIG_DIR` / `LOG_DIR`：运行时配置和 sing-box 日志目录，默认 `/tmp/grn-sing-box`

模板配置位于 `src/config/singbox/client_singbox.json` 和 `src/config/singbox/server_singbox.json`。模板只保留 sing-box 的结构、tag 和协议类型，里面的端口、地址、secret 等占位值会在启动时被 `SingBoxConfig` 和 bridge 运行参数覆盖。
server 模板中保留了 `mptcp-path-1`、`mptcp-path-2`、`mptcp-path-3` 三个示例 inbound；启动 server bridge 时会根据实际 `tunnels` 列表重新生成 inbound，tag 依次为 `mptcp-path-1`、`mptcp-path-2`、`mptcp-path-3`，分别监听各 tunnel 的 server TUN IP。


目前singbox + mptcp(多路径) 有两种实现：
1> 只开启一个路径(one path，例如:10.0.1.1(server sing-box监听端口)），业务流在一个路径上的mptcp主连接池间流动，mptcp 子流自动构建。
   实现文件（src/config/singbox/client_singbox_one_path_multiplex.json, src/config/config_one_path_multiplex.py, src/services/transparent_proxy_one_path_multplex.py）

2> 开启多个路径，默认实现(many paths，例如:10.0.1.1(server sing-box监听端口), 10.0.2.1, 10.0.3.1, ......），多个路径使用urltest进行探测，并根据最小时延选择最优路径传输，多个路径之间构成路径冗余，并能自动切换。
   业务流在选择的路径上的mptcp主连接池间流动，mptcp 子流自动构建。


实际传给 sing-box 的配置会生成到：

- `/tmp/grn-sing-box/client_singbox.runtime.json`
- `/tmp/grn-sing-box/server_singbox.runtime.json`

排查配置问题时以运行时配置为准。

#### 启动透明代理规则，scripts/grn-iptables.sh

在 client 路由器或需要接管 LAN 流量的节点上执行(grn-iptables.sh已在程序里自动调用，不需要手动调用)


脚本默认从 `br-lan` 的 `PREROUTING` 捕获 TCP 流量，并重定向到 `11090`。如果 LAN 网卡不是 `br-lan`，先修改 `grn-iptables.sh` 中的 `LAN_IF`。

如果修改了 `SingBoxConfig.CLIENT_LISTEN_PORT`，也要同步修改 `grn-iptables.sh` 中的 `TCP_PORT`，两者必须一致。

常用命令：

```bash
grn-iptables.sh status
grn-iptables.sh restart
grn-iptables.sh stop
```

iptables 规则只负责把 TCP 流量送到 sing-box。sing-box 进程由 GRN Node 在链路切换时确保启动；server bridge 启动时会拉起 server 侧 sing-box，并监听对应的 TUN IP。

#### 查看 sing-box 日志

sing-box 日志默认写入 `/tmp/grn-sing-box`：

```bash
tail -f /tmp/grn-sing-box/client.log
tail -f /tmp/grn-sing-box/server.log
```

日志默认级别为 `info`，并启用简单 size-based rotation。默认单文件最大 `2 MiB`，保留 `2` 个历史文件，可在 `SingBoxConfig.LOG_MAX_BYTES` 和 `SingBoxConfig.LOG_BACKUP_COUNT` 中调整。


#### 排查命令

确认 sing-box 已启动并监听：
```bash
ss -lntp | grep -E '11090|11091|9090'
netstat -a | grep -E '11091' | grep ESTABLISHED
netstat -a | grep -E '11090' | grep ESTABLISHED
```

查看tun网卡流量：
```bash
ip -s link show tun1 && ip -s link show tun2 && ip -s link show tun3

watch -n 1 'ip -s link show tun1; echo; ip -s link show tun2; echo ; ip -s link show tun3'
```

查看连接：
```bash
ss -tnp |grep -E '10.0.1.1|10.0.2.1|10.0.3.1'

netstat -a | grep -E '10.0.1.1|10.0.2.1|10.0.3.1'

ss -ntM |grep -E '10.0.1.1|10.0.2.1|10.0.3.1'

ss -ntM | grep 'mptcp'
```

检查运行时配置：
```bash
python3 -m json.tool /tmp/grn-sing-box/client_singbox.runtime.json

sing-box check -c /tmp/grn-sing-box/client_singbox.runtime.json

sing-box check -c /tmp/grn-sing-box/server_singbox.runtime.json
```

查看 selector：
```bash
curl -H 'Authorization: Bearer grn-secret' http://127.0.0.1:9090/proxies/out-select
```

查看当前使用的path：
```bash
curl -s -H "Authorization: Bearer grn-secret" http://127.0.0.1:9090/proxies/mptcp-tunnel
```

看各 path 延迟：
```bash
curl -s -H "Authorization: Bearer grn-secret" http://127.0.0.1:9090/proxies/mptcp-path-1

curl -s -H "Authorization: Bearer grn-secret" http://127.0.0.1:9090/proxies/mptcp-path-2

curl -s -H "Authorization: Bearer grn-secret" http://127.0.0.1:9090/proxies/mptcp-path-3
```

手动切换 selector：
```bash
curl -X PUT \
  -H 'Authorization: Bearer grn-secret' \
  -H 'Content-Type: application/json' \
  -d '{"name":"direct"}' \
  http://127.0.0.1:9090/proxies/out-select
```

`name` 可取 `direct`、`socks5`、`mptcp-tunnel`。正常运行时不需要手动切换，链路切换逻辑会自动调用 sing-box selector API。

后续扩展：
	1> sing-box 代理两端都可以加TLS证书，实现加密通信。
	2> sing-box 后续如果支持loadbalance调度，就可以支持urltest和loadbalance，两种调度方式了。



### 15.pytest，windows 和 linux 都可以跑
### pytest 命令, python -m pytest 或者 pytest

### pytest 配置在 pytest.ini 里

### 准备venv环境 (省略)
source /home/node-test/venv/bin/activate
cd GRN_Node


### 跑全部测试用例
pytest


### 只跑部分测试用例，例如：只跑某一类 / 某一个文件：
pytest src/tests/test_commands
pytest src/tests/test_core/test_stem_api_core.py


### 自动过滤测试用例（按目录或者按文件排除），在 tests/conftest.py 里
pytest_collection_modifyitems/skip_prefixes 配置列表里进行配置